/* ==========================================================================
   Essensplanung – App Teil 4: Rezepte, Einstellungen, Anmeldung, Start
   ========================================================================== */

/* ---------- Rezepte (Fundus) ---------- */
function recipeMatches(r) {
  const f = recipeFilter;
  if (EP.laneOf(r) !== f.kind) return false;
  if (f.status === 'active' && !r.inRotation) return false;
  if (f.status === 'paused' && r.inRotation) return false;
  if (f.tag && !(r.tags || []).includes(f.tag)) return false;
  if (f.q) {
    const q = f.q.toLowerCase();
    const inIng = r.ingredients.some(x => { const i = ingById(x.ingredientId); return i && i.name.toLowerCase().includes(q); });
    if (!r.name.toLowerCase().includes(q) && !(r.tags || []).some(t => t.toLowerCase().includes(q)) && !inIng) return false;
  }
  return true;
}
function vRecipes() {
  const kind = recipeFilter.kind;
  const all = liveRecipes().filter(r => EP.laneOf(r) === kind);
  const tags = [...new Set(all.flatMap(r => r.tags || []))].sort((a, b) => a.localeCompare(b, 'de'));
  const list = all.filter(recipeMatches).sort((a, b) => a.name.localeCompare(b.name, 'de'));
  const pp = db.settings.portionsPerDay;
  const seg = (k, l) => `<button data-act="rstatus" data-arg="${k}" aria-pressed="${recipeFilter.status === k}">${l}</button>`;
  const ph = { MAIN: 'Rezeptname eingeben', LUNCH: 'z. B. Nudelsuppe', CAKE: 'z. B. Apfelkuchen' }[kind];
  return `${laneSeg(kind, 'rkind')}
    <div class="quick" style="margin-top:12px"><input class="in" id="qa" placeholder="${ph}" enterkeyhint="done" autocomplete="off">
      <button class="btn primary" data-act="qa" aria-label="Rezept anlegen">+</button></div>
    <p class="hint">Enter legt das Rezept an. Mehrere Zeilen einfügen legt mehrere Rezepte an.</p>
    <button class="btn quiet small impbtn" data-act="rimport">Rezepte aus JSON importieren</button>
    ${all.length ? `<input class="in" id="rq" placeholder="Suchen nach Name, Tag oder Zutat" value="${esc(recipeFilter.q)}" style="margin-top:14px">
    <div class="seg" style="margin-top:10px">${seg('all', 'Alle')}${seg('active', 'In Rotation')}${seg('paused', 'Pausiert')}</div>
    ${tags.length ? `<div class="chips">${tags.map(t => `<button class="chip" data-act="rtag" data-arg="${esc(t)}" aria-pressed="${recipeFilter.tag === t}">${esc(t)}</button>`).join('')}</div>` : ''}` : ''}
    <div class="rlist">${list.map(r => {
      const n = daysOf(r), ck = coverKey(r);
      return `<div class="rcard ${r.inRotation ? '' : 'paused'}">
        <button class="head" data-act="edit" data-arg="${r.id}" style="width:100%">
          ${ck ? `<img class="thumb" data-img="${ck}" data-thumb="1" alt="">` : ''}
          <span class="grow"><span class="nm" style="display:block">${esc(r.name)}</span>
          <span class="meta" style="display:block">${kind === 'MAIN' ? `${r.servings} Portionen = ${daysLabel(n)}${r.daysOverride ? ' (fest)' : ''}` : `${r.servings} ${kind === 'CAKE' ? 'Stücke' : 'Portionen'}`}${r.ingredients.length ? `, ${r.ingredients.length} Zutaten` : ''}${EP.seasonLabel(r) ? `<br>Saison: ${EP.seasonLabel(r)}` : ''}</span></span>
        </button>
        <div class="ctrl">
          <label><span class="switch"><input type="checkbox" data-rot="${r.id}" ${r.inRotation ? 'checked' : ''} aria-label="In Rotation"><i></i></span>${r.inRotation ? 'In Rotation' : 'Pausiert'}</label>
          <div class="wstep"><button data-act="w" data-arg="${r.id}|-1" aria-label="Seltener">−</button><output>×${r.weight}</output><button data-act="w" data-arg="${r.id}|1" aria-label="Häufiger">+</button></div>
        </div></div>`;
    }).join('') || (all.length ? '<p class="empty">Keine Treffer.</p>' : `<div class="empty"><p class="serif">${{ MAIN: 'Dein Fundus ist leer', LUNCH: 'Noch keine Mittagsgerichte', CAKE: 'Noch keine Kuchen' }[kind]}</p>
      <p>${{ MAIN: 'Tipp oben einen Gerichtnamen ein – Portionen, Zutaten und Anleitung kannst du später ergänzen.', LUNCH: 'Kleine Gerichte fürs Wochenende mit eigener Rotation.', CAKE: 'Kuchen kommen zusätzlich zum Essen dazu und haben ihre eigene Rotation.' }[kind]}</p>
      <div class="btns">${kind === 'MAIN' ? (liveRecipes().some(r => EP.laneOf(r) === 'MAIN') ? '' : '<button class="btn" data-act="seed">Beispielrezepte laden</button>')
        : `<button class="btn" data-act="seedlane" data-arg="${kind}">${kind === 'LUNCH' ? '6 Mittagsgerichte als Vorschlag laden' : '7 Kuchen als Vorschlag laden'}</button>`}</div></div>`)}</div>
    ${all.length ? `<p class="hint" style="text-align:center">${all.filter(r => r.inRotation).length} von ${all.length} in Rotation${kind === 'MAIN' ? `, ${pp} Portionen pro Tag` : ''}</p>` : ''}`;
}

/* ---------- Rezept-Import (Antwort aus dem Scanner-Chat) ---------- */
function importSheet(prefill) {
  const canRead = !!(navigator.clipboard && navigator.clipboard.readText);
  openSheet(`<h2>Rezepte importieren</h2>
    <p class="sub" style="margin-top:6px">Füge die Antwort aus dem Rezept-Scanner-Chat ein. Text vor oder nach dem Block stört nicht.</p>
    <textarea class="in" id="imp-t" placeholder="{ &quot;format&quot;: &quot;essensplanung-import&quot;, … }" autocapitalize="off" autocorrect="off" spellcheck="false" style="margin-top:12px;min-height:150px;font-size:14px">${esc(prefill || '')}</textarea>
    <p class="warn hidden" id="imp-err" role="alert" style="font-size:14px;margin-top:8px"></p>
    <div class="btns two">${canRead ? '<button class="btn" data-x="paste">Einfügen</button>' : ''}<button class="btn" data-x="file" ${canRead ? '' : 'style="grid-column:1/-1"'}>Datei wählen</button></div>
    <input type="file" id="imp-f" accept=".json,.txt,application/json,text/plain" class="hidden">
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Weiter</button></div>`, el => {
    const ta = $('#imp-t', el), err = $('#imp-err', el);
    const fail = m => { err.textContent = m; err.classList.remove('hidden'); };
    const next = () => {
      const t = ta.value.trim();
      if (!t) return fail('Bitte zuerst die Antwort aus dem Chat einfügen.');
      let recs;
      try { recs = EP.parseRecipeImport(t); } catch (e) { return fail(e.message); }
      importPreview(recs, t);
    };
    ta.oninput = () => err.classList.add('hidden');
    const p = $('[data-x=paste]', el);
    if (p) p.onclick = async () => {
      try { const t = await navigator.clipboard.readText(); if (t) { ta.value = t; err.classList.add('hidden'); } else fail('Die Zwischenablage ist leer.'); }
      catch (e) { fail('Kein Zugriff auf die Zwischenablage. Tippe lange ins Feld und wähle „Einsetzen“.'); }
    };
    $('[data-x=file]', el).onclick = () => $('#imp-f', el).click();
    $('#imp-f', el).onchange = async e => { const f = e.target.files[0]; if (!f) return; ta.value = await f.text(); e.target.value = ''; next(); };
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = next;
  });
}
function importPreview(recs, rawText) {
  const items = recs.map(rec => {
    const ex = findRecipeByName(rec.name);
    const dup = !!(ex && !ex.archivedAt);
    return { rec, kind: rec.kind, dup, include: true, mode: dup ? 'skip' : ex ? 'replace' : 'new' };
  });
  const segBtn = (i, attr, val, cur, label) => `<button data-x="${attr}" data-i="${i}" data-v="${val}" aria-pressed="${cur === val}">${label}</button>`;
  const card = (it, i) => {
    const r = it.rec, newIngs = r.ingredients.filter(x => !findIngredient(x.name)).length;
    const steps = r.instructions ? r.instructions.split('\n').filter(l => l.trim()).length : 0;
    const meta = [`${r.servings} ${it.kind === 'CAKE' ? 'Stücke' : 'Portionen'}`, `${r.ingredients.length} Zutaten${newIngs ? ` (${newIngs} neu)` : ''}`,
      `${steps} ${steps === 1 ? 'Schritt' : 'Schritte'}`, r.prepTimeMinutes ? r.prepTimeMinutes + ' Min.' : ''].filter(Boolean).join(', ');
    return `<div class="rcard impcard" data-card="${i}">
      <label class="imphead"><input type="checkbox" data-inc="${i}" checked aria-label="${esc(r.name)} importieren"><span class="nm">${esc(r.name)}</span></label>
      <p class="meta">${meta}</p>
      <div class="seg lane-seg" style="margin-top:10px">${EP.LANES.map(l => segBtn(i, 'kind', l.key, it.kind, LANE_LABEL[l.key])).join('')}</div>
      ${it.dup ? `<p class="hint warn" style="margin-top:10px">„${esc(r.name)}“ gibt es schon.</p>
        <div class="seg" style="margin-top:6px">${segBtn(i, 'mode', 'skip', it.mode, 'Überspringen')}${segBtn(i, 'mode', 'replace', it.mode, 'Ersetzen')}${segBtn(i, 'mode', 'copy', it.mode, 'Als Kopie')}</div>
        <p class="hint" data-modehint="${i}"></p>` : ''}
      ${r.warnings.length ? `<ul class="box warnbox" style="margin-top:10px">${r.warnings.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}
      <details class="impdetails"><summary>Zutaten und Anleitung ansehen</summary>
        <ul class="impings">${r.ingredients.map(x => `<li><b>${x.quantity == null ? '' : esc(EP.fmtNum(x.quantity) + ' ' + (x.unit ? EP.UNITS[x.unit][x.quantity > 1 && EP.UNITS[x.unit].p ? 'p' : 's'] : ''))}</b> ${esc(x.name)}${x.note ? `<small>, ${esc(x.note)}</small>` : ''}</li>`).join('') || '<li>Keine Zutaten</li>'}</ul>
        ${r.instructions ? `<div class="md">${renderMd(r.instructions).intro}<ol class="impsteps">${renderMd(r.instructions).steps.map(t => `<li>${t}</li>`).join('')}</ol></div>` : ''}
        ${r.notes ? `<p class="hint">${esc(r.notes)}</p>` : ''}
      </details>
    </div>`;
  };
  const MODE_HINT = { skip: 'Das vorhandene Rezept bleibt unverändert.', replace: 'Zutaten, Portionen und Anleitung werden ersetzt. Bilder, Gewichtung und Rotation bleiben.', copy: 'Wird mit Zusatz „(2)“ im Namen angelegt.' };
  openSheet(`<h2>${items.length === 1 ? '1 Rezept gefunden' : items.length + ' Rezepte gefunden'}</h2>
    <p class="sub" style="margin-top:6px">Prüfe die Art und hake ab, was übernommen werden soll. Details kannst du danach im Rezept bearbeiten.</p>
    ${items.map(card).join('')}
    <div class="btns two"><button class="btn" data-x="back">Zurück</button><button class="btn primary" data-x="yes"></button></div>`, el => {
    const count = () => items.filter(it => it.include && it.mode !== 'skip').length;
    const refresh = () => {
      const n = count(), b = $('[data-x=yes]', el);
      b.textContent = n ? (n === 1 ? '1 Rezept importieren' : n + ' Rezepte importieren') : 'Nichts ausgewählt';
      b.disabled = !n;
      items.forEach((it, i) => {
        const h = $(`[data-modehint="${i}"]`, el); if (h) h.textContent = MODE_HINT[it.mode];
        $(`[data-card="${i}"]`, el).classList.toggle('off', !it.include || it.mode === 'skip');
      });
    };
    $$('[data-inc]', el).forEach(c => c.onchange = () => {
      const it = items[+c.dataset.inc]; it.include = c.checked;
      if (c.checked && it.dup && it.mode === 'skip') { it.mode = 'copy'; $$(`[data-x=mode][data-i="${c.dataset.inc}"]`, el).forEach(b => b.setAttribute('aria-pressed', b.dataset.v === 'copy')); }
      refresh();
    });
    $$('[data-x=kind],[data-x=mode]', el).forEach(b => b.onclick = () => {
      const i = +b.dataset.i, key = b.dataset.x;
      items[i][key] = b.dataset.v;
      if (key === 'kind' && b.dataset.v === 'CAKE' && items[i].rec.servings <= 4) items[i].rec.servings = 12;
      $$(`[data-x=${key}][data-i="${i}"]`, el).forEach(x => x.setAttribute('aria-pressed', x === b));
      if (key === 'mode' && b.dataset.v !== 'skip') { items[i].include = true; $(`[data-inc="${i}"]`, el).checked = true; }
      if (key === 'kind') { const m = $(`[data-card="${i}"] .meta`, el); m.textContent = m.textContent.replace(/^\d+ (Stücke|Portionen)/, `${items[i].rec.servings} ${b.dataset.v === 'CAKE' ? 'Stücke' : 'Portionen'}`); }
      refresh();
    });
    $('[data-x=back]', el).onclick = () => importSheet(rawText);
    $('[data-x=yes]', el).onclick = () => {
      const chosen = items.filter(it => it.include && it.mode !== 'skip');
      if (!chosen.length) return;
      closeSheet();
      const res = importRecipes(chosen);
      recipeFilter = Object.assign(recipeFilter, { kind: chosen[0].kind, q: '', tag: '', status: 'all' });
      const parts = [res.added ? `${res.added} importiert` : '', res.replaced ? `${res.replaced} ersetzt` : ''].filter(Boolean).join(', ');
      change(`${parts || 'Nichts geändert'}.${res.newIngredients ? ` ${res.newIngredients} neue Zutaten – Einkaufsorte unter ⚙ prüfen.` : ''}`);
    };
    refresh();
  });
}

/* ---------- Rezept bearbeiten ---------- */
let editState = null;
function openEdit(id, kind) {
  const r = id ? recipeById(id) : newRecipe('', kind);
  editState = { isNew: !id, dirty: false, r: deep(r),
    rows: r.ingredients.slice().sort((a, b) => a.sortOrder - b.sortOrder).map(x => {
      const i = ingById(x.ingredientId);
      return { name: i ? i.name : '', qty: x.quantity == null ? '' : EP.fmtNum(x.quantity), unit: x.unit || '', note: x.note || '', cat: i ? i.category : 'SONSTIGES' };
    }) };
  go('edit');
}
function vEdit() {
  if (!editState) return '<p class="empty">Kein Rezept geöffnet.</p>';
  const r = editState.r, s = db.settings;
  const hint = EP.daysHint(r, s), kind = EP.laneOf(r), isMain = kind === 'MAIN';
  const allYear = !r.seasonMonths || !r.seasonMonths.length || r.seasonMonths.length >= 12;
  const unitOpts = sel => `<option value="" ${!sel ? 'selected' : ''}>—</option>` + EP.UNIT_ORDER.map(u => `<option value="${u}" ${sel === u ? 'selected' : ''}>${EP.UNITS[u].s}</option>`).join('');
  const catOpts = sel => EP.CATEGORIES.map(c => `<option value="${c.key}" ${sel === c.key ? 'selected' : ''}>${c.label}</option>`).join('');
  const rows = editState.rows.map((x, i) => {
    const known = !x.name.trim() || !!findIngredient(x.name);
    return `<div class="ingrow" data-row="${i}">
      <div class="l1">
        <input class="in" data-f="qty" value="${esc(x.qty)}" inputmode="decimal" placeholder="Menge" aria-label="Menge">
        <select class="in" data-f="unit" aria-label="Einheit">${unitOpts(x.unit)}</select>
        <input class="in" data-f="name" value="${esc(x.name)}" list="inglist" placeholder="Zutat" aria-label="Zutat" autocomplete="off">
        <button class="x" data-act="rowdel" data-arg="${i}" aria-label="Zutat entfernen">✕</button>
      </div>
      <div class="l2">
        <input class="in" data-f="note" value="${esc(x.note)}" placeholder="Notiz, z. B. fein gewürfelt" aria-label="Notiz">
        <button class="x" data-act="rowup" data-arg="${i}" aria-label="Nach oben">▲</button>
        <button class="x" data-act="rowdown" data-arg="${i}" aria-label="Nach unten">▼</button>
      </div>
      <div class="newcat ${known ? 'hidden' : ''}">Neue Zutat – Kategorie: <select class="in" data-f="cat">${catOpts(x.cat)}</select></div>
    </div>`;
  }).join('');
  const imgs = (r.images || []).slice().sort((a, b) => a.sortOrder - b.sortOrder);
  return `<datalist id="inglist">${EP.live(db.ingredients).sort((a, b) => a.name.localeCompare(b.name, 'de')).map(i => `<option value="${esc(i.name)}">`).join('')}</datalist>
    <label class="field" style="margin-top:0"><span>Name</span><input class="in nameinput" id="e-name" value="${esc(r.name)}" maxlength="120" placeholder="z. B. Linsensuppe"></label>
    <div class="field"><span>Art</span>
      <div class="seg">${EP.LANES.map(l => `<button data-act="ekind" data-arg="${l.key}" aria-pressed="${kind === l.key}">${l.short}</button>`).join('')}</div>
      <p class="hint">${isMain ? 'Normale Mahlzeit, belegt je nach Portionen mehrere Tage.' : kind === 'LUNCH' ? 'Zusätzliches Mittagessen an den eingestellten Tagen, eigene Rotation.' : 'Kommt zusätzlich zum Essen dazu, eigene Rotation.'}</p></div>
    <div class="field"><span>${kind === 'CAKE' ? 'Stücke' : 'Portionen pro Zubereitung'}</span>
      <div class="stepper"><button data-act="serv" data-arg="-1" aria-label="Weniger">−</button><output id="e-serv">${r.servings}</output><button data-act="serv" data-arg="1" aria-label="Mehr">+</button></div>
      ${isMain ? `<p class="live" id="e-live">${liveDaysText(r)}</p><p class="hint" id="e-hint">${esc(hint)}</p>` : ''}</div>
    ${isMain ? `<label class="field"><span>Tage fest vorgeben (optional)</span><input class="in" id="e-days" inputmode="numeric" value="${r.daysOverride || ''}" placeholder="leer = aus den Portionen berechnen"></label>` : ''}
    <div class="field"><div class="row"><span class="grow" style="margin:0;color:var(--ink);font-weight:600">Ganzjährig vorschlagen</span>
      <label class="switch"><input type="checkbox" id="e-allyear" ${allYear ? 'checked' : ''} aria-label="Ganzjährig vorschlagen"><i></i></label></div>
      ${allYear ? '' : `<p class="hint" style="margin:8px 0 6px">Nur in diesen Monaten vorschlagen:</p>
      <div class="months">${EP.MONTHS.map((m, i) => `<button class="chip" data-act="emonth" data-arg="${i + 1}" aria-pressed="${r.seasonMonths.includes(i + 1)}">${m}</button>`).join('')}</div>`}
    </div>
    <div class="field"><span>Wie oft pro Durchlauf</span>
      <div class="stepper"><button data-act="ew" data-arg="-1" aria-label="Seltener">−</button><output>×${r.weight}</output><button data-act="ew" data-arg="1" aria-label="Häufiger">+</button></div></div>
    <div class="field"><div class="row"><span class="grow" style="margin:0;color:var(--ink);font-weight:600">In Rotation</span>
      <label class="switch"><input type="checkbox" id="e-rot" ${r.inRotation ? 'checked' : ''} aria-label="In Rotation"><i></i></label></div></div>

    <h3>Zutaten</h3>
    <p class="hint" style="margin-top:0">Mengen gelten für die ganze Zubereitung. Ohne Menge = nach Geschmack.</p>
    ${rows}
    <button class="btn" data-act="rowadd" style="margin-top:10px">Zutat hinzufügen</button>

    <h3>Anleitung</h3>
    <textarea class="in" id="e-ins" placeholder="Eine Zeile pro Schritt, z. B.&#10;1. Zwiebeln fein würfeln&#10;2. In Olivenöl anschwitzen">${esc(r.instructions)}</textarea>
    <div class="row" style="gap:10px">
      <label class="field grow"><span>Zubereitungszeit (min)</span><input class="in" id="e-time" inputmode="numeric" value="${r.prepTimeMinutes || ''}"></label>
      <label class="field grow"><span>Tags</span><input class="in" id="e-tags" value="${esc((r.tags || []).join(', '))}" placeholder="vegetarisch, schnell"></label>
    </div>
    <label class="field"><span>Notizen</span><textarea class="in" id="e-notes" style="min-height:70px">${esc(r.notes)}</textarea></label>

    <h3>Bilder</h3>
    <div class="gallery">${imgs.map(im => `<button data-act="img" data-arg="${im.fileKey}" aria-label="Bild bearbeiten"><img data-img="${im.fileKey}" data-thumb="1" alt="">${im.isCover ? '<span class="cover">Titelbild</span>' : ''}</button>`).join('')}
      <button class="add" data-act="imgadd" aria-label="Bild hinzufügen">+</button></div>
    <input type="file" id="e-file" accept="image/*" multiple class="hidden">

    <div class="btns">
      <button class="btn primary" data-act="save">Rezept speichern</button>
      ${editState.isNew ? '' : `<button class="btn" data-act="cook" data-arg="${r.id}">Kochansicht</button>
      <button class="btn danger" data-act="archive">Rezept löschen</button>`}
    </div>`;
}
function liveDaysText(r) {
  return `= ${daysLabel(EP.daysFor(r, db.settings))} bei ${db.settings.portionsPerDay} Portionen/Tag${r.daysOverride ? ' (fest vorgegeben)' : ''}`;
}
function readEditForm() {
  const r = editState.r;
  const v = id => ($('#' + id) || {}).value;
  if ($('#e-name')) r.name = v('e-name');
  if ($('#e-days')) { const d = parseInt(v('e-days'), 10); r.daysOverride = d > 0 ? d : null; }
  if ($('#e-rot')) r.inRotation = $('#e-rot').checked;
  r.instructions = v('e-ins') || '';
  const t = parseInt(v('e-time'), 10); r.prepTimeMinutes = t > 0 ? t : null;
  r.tags = (v('e-tags') || '').split(',').map(x => x.trim()).filter(Boolean);
  r.notes = v('e-notes') || '';
  $$('[data-row]').forEach(el => {
    const row = editState.rows[+el.dataset.row]; if (!row) return;
    $$('[data-f]', el).forEach(f => { row[f.dataset.f] = f.value; });
  });
}
function saveEdit() {
  readEditForm();
  const e = editState, r = e.r;
  r.name = r.name.trim();
  if (!r.name) return notify('Bitte einen Namen eingeben.');
  if (r.seasonMonths && (!r.seasonMonths.length || r.seasonMonths.length >= 12)) r.seasonMonths = null;
  if (EP.laneOf(r) !== 'MAIN') r.daysOverride = null;
  const dup = findRecipeByName(r.name);
  if (dup && dup.id !== r.id && !dup.archivedAt) return notify('Ein Rezept mit diesem Namen gibt es schon.');
  // Zutaten auflösen, unbekannte anlegen
  const ings = [];
  e.rows.forEach((x, k) => {
    if (!x.name.trim()) return;
    const qty = parseQty(x.qty);
    let ing = findIngredient(x.name);
    if (!ing) ing = createIngredient(x.name, x.cat || 'SONSTIGES', x.unit || 'STUECK');
    ings.push({ ingredientId: ing.id, quantity: qty, unit: qty == null ? null : (x.unit || ing.defaultUnit || 'STUECK'), note: x.note.trim(), sortOrder: k + 1 });
  });
  r.ingredients = ings;
  const old = recipeById(r.id);
  if (old) Object.assign(old, r); else db.recipes.push(r);
  const target = old || r;
  EP.touch(target);
  EP.syncRecipeIntoCycles(db, target, rng);
  editState = null;
  route = stack.pop() || { name: 'recipes' };
  change('Gespeichert.');
}

/* ---------- Kochansicht (Phase 3) ---------- */
let wakeLock = null;
async function lockScreen() { try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {} }
function renderMd(md) {
  const lines = String(md || '').split('\n');
  const steps = [], notes = [];
  lines.forEach(l => {
    const t = l.trim(); if (!t) return;
    const m = t.match(/^(\d+)[.)]\s+(.*)$/);
    if (m) steps.push(m[2]); else if (steps.length) steps[steps.length - 1] += ' ' + t; else notes.push(t);
  });
  const fmt = s => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  if (!steps.length) return { steps: notes.map(fmt), intro: '' };
  return { steps: steps.map(fmt), intro: notes.map(n => `<p>${fmt(n)}</p>`).join('') };
}
function openCook(id) {
  const r = recipeById(id); if (!r) return;
  const ck = coverKey(r), md = renderMd(r.instructions);
  const ing = r.ingredients.slice().sort((a, b) => a.sortOrder - b.sortOrder).map(x => {
    const i = ingById(x.ingredientId);
    const q = x.quantity == null ? 'nach Geschmack' : EP.sumAmounts([{ quantity: x.quantity, unit: x.unit }]).text;
    return `<li><span class="q">${esc(q)}</span><span>${esc(i ? i.name : '')}${x.note ? `, <span class="sub">${esc(x.note)}</span>` : ''}</span></li>`;
  }).join('');
  const el = $('#cookview');
  el.innerHTML = `<div class="inner">
    <div class="row"><span class="grow"></span><button class="btn small" data-act="closecook">Schließen</button></div>
    <h1>${esc(r.name)}</h1>
    <p class="sub" style="font-size:17px">${r.servings} Portionen${r.prepTimeMinutes ? `, ${r.prepTimeMinutes} min` : ''}</p>
    ${ck ? `<img class="hero" data-img="${ck}" data-thumb="0" alt="">` : ''}
    ${ing ? `<h3 style="font-size:20px">Zutaten</h3><ul class="ing">${ing}</ul>` : ''}
    ${md.steps.length ? `<h3 style="font-size:20px">Zubereitung</h3><div class="md">${md.intro}</div><ol class="steps-big">${md.steps.map(s => `<li>${s}</li>`).join('')}</ol>` : ''}
    ${r.notes ? `<h3 style="font-size:20px">Notizen</h3><p style="font-size:18px">${esc(r.notes)}</p>` : ''}
    <p class="hint" style="margin-top:24px">Der Bildschirm bleibt an, solange die Kochansicht offen ist. Tippe auf Zutaten und Schritte, um sie abzuhaken.</p></div>`;
  el.classList.remove('hidden');
  $$('.ing li, .steps-big li', el).forEach(li => li.onclick = () => li.classList.toggle('done'));
  Images.hydrate(el);
  lockScreen();
}
function closeCook() {
  $('#cookview').classList.add('hidden');
  if (wakeLock) { wakeLock.release().catch(() => {}); wakeLock = null; }
}

/* ---------- Zutaten (Stammdaten) ---------- */
let ingQuery = '';
function vIngredients() {
  const all = EP.live(db.ingredients).filter(i => !ingQuery || i.name.toLowerCase().includes(ingQuery.toLowerCase()));
  const srcLabel = { MARKT: 'Markt', SUPERMARKT: 'Supermarkt', VORRAT: 'Vorrat' };
  return `<input class="in" id="iq" placeholder="Zutat suchen" value="${esc(ingQuery)}">
    <button class="btn" data-act="ingnew" style="margin-top:10px">Neue Zutat</button>
    ${EP.CATEGORIES.map(c => {
      const items = all.filter(i => i.category === c.key).sort((a, b) => a.name.localeCompare(b.name, 'de'));
      if (!items.length) return '';
      return `<h3>${esc(c.label)}</h3><div class="box">${items.map(i => `<button class="item" data-act="ing" data-arg="${i.id}">
        <span class="nm">${esc(i.name)}</span><span class="amt">${srcLabel[EP.sourceOf(i, db.settings)]}${i.shoppingSource ? ' (angepasst)' : ''}</span></button>`).join('')}</div>`;
    }).join('') || '<p class="empty">Noch keine Zutaten. Sie entstehen automatisch, wenn du sie in einem Rezept einträgst.</p>'}`;
}
function ingredientSheet(id) {
  const i = id ? ingById(id) : { name: '', category: 'GEMUESE', shoppingSource: null, defaultUnit: 'STUECK' };
  const used = id ? ingredientUsage(id) : 0;
  const others = EP.live(db.ingredients).filter(x => x.id !== id).sort((a, b) => a.name.localeCompare(b.name, 'de'));
  openSheet(`<h2>${id ? 'Zutat bearbeiten' : 'Neue Zutat'}</h2>
    <label class="field"><span>Name (Einzahl)</span><input class="in" id="in-n" value="${esc(i.name)}"></label>
    <label class="field"><span>Kategorie</span><select class="in" id="in-c">${EP.CATEGORIES.map(c => `<option value="${c.key}" ${c.key === i.category ? 'selected' : ''}>${c.label}</option>`).join('')}</select></label>
    <label class="field"><span>Einkaufsort</span><select class="in" id="in-s">
      <option value="" ${!i.shoppingSource ? 'selected' : ''}>Wie Kategorie</option>
      <option value="MARKT" ${i.shoppingSource === 'MARKT' ? 'selected' : ''}>Markt</option>
      <option value="SUPERMARKT" ${i.shoppingSource === 'SUPERMARKT' ? 'selected' : ''}>Supermarkt</option>
      <option value="VORRAT" ${i.shoppingSource === 'VORRAT' ? 'selected' : ''}>Vorrat</option></select></label>
    <label class="field"><span>Standardeinheit</span><select class="in" id="in-u">${EP.UNIT_ORDER.map(u => `<option value="${u}" ${u === i.defaultUnit ? 'selected' : ''}>${EP.UNITS[u].s}</option>`).join('')}</select></label>
    ${id ? `<p class="hint">In ${used} ${used === 1 ? 'Rezept' : 'Rezepten'} verwendet.</p>` : ''}
    <div class="btns"><button class="btn primary" data-x="save">Speichern</button>
    ${id && others.length ? `<label class="field"><span>Zusammenführen in</span><select class="in" id="in-m"><option value="">Zutat wählen</option>${others.map(o => `<option value="${o.id}">${esc(o.name)}</option>`).join('')}</select></label>
      <button class="btn" data-x="merge">Zusammenführen</button>` : ''}
    ${id ? `<button class="btn danger" data-x="del" ${used ? 'disabled style="opacity:.5"' : ''}>${used ? 'Löschen nicht möglich (in Verwendung)' : 'Zutat löschen'}</button>` : ''}
    <button class="btn quiet" data-x="no">Abbrechen</button></div>`, el => {
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=save]', el).onclick = () => {
      const name = $('#in-n', el).value.trim();
      if (!name) return notify('Bitte einen Namen eingeben.');
      const ex = findIngredient(name);
      if (ex && ex.id !== id) return notify('Diese Zutat gibt es schon – nutze „Zusammenführen“.');
      const tgt = id ? ingById(id) : createIngredient(name);
      Object.assign(tgt, { name, category: $('#in-c', el).value, shoppingSource: $('#in-s', el).value || null, defaultUnit: $('#in-u', el).value });
      EP.touch(tgt); closeSheet(); change('Gespeichert.');
    };
    const m = $('[data-x=merge]', el);
    if (m) m.onclick = () => {
      const to = $('#in-m', el).value; if (!to) return notify('Bitte eine Zielzutat wählen.');
      mergeIngredient(id, to); closeSheet(); change('Zusammengeführt.');
    };
    const d = $('[data-x=del]', el);
    if (d && !used) d.onclick = () => { EP.tomb(ingById(id)); closeSheet(); change('Gelöscht.'); };
  });
}

/* ---------- Rotation ---------- */
function vRotation() {
  const before = db.rotation.length;
  EP.LANES.forEach(l => EP.nextEntries(db, 1, null, rng, l.key, EP.monthOf(EP.todayISO())));
  if (db.rotation.length !== before) persist();
  const stLabel = { PENDING: ['Offen', ''], PLANNED: ['Geplant', 'cook'], DONE: ['Gekocht', 'done'], SKIPPED: ['Ausgelassen', 'block'] };
  const fixed = db.settings.rotationMode === 'FIXED';
  const actives = EP.activeRecipes(db).sort((a, b) => a.sortOrder - b.sortOrder);
  const allCycles = EP.LANES.flatMap(l => EP.openCycles(db, l.key).map(c => [l.key, c]));
  return (allCycles.length ? allCycles.map(([lane, c]) => {
    const es = EP.cycleEntries(db, c, lane);
    return `<h3>${LANE_LABEL[lane]} · Durchlauf ${c}</h3><div class="box">${es.map(e => {
      const r = recipeById(e.recipeId), [l0, cls] = stLabel[e.status];
      const l = e.status === 'SKIPPED' && e.skipReason === 'SEASON' ? 'Keine Saison' : l0;
      return `<div class="item"><span class="nm serif" style="font-size:17px">${esc(r ? r.name : '–')}${r && r.weight > 1 ? ` <span class="sub">(${e.occurrence}/${r.weight})</span>` : ''}</span>
        <span class="badge ${cls}">${l}</span>
        ${e.status === 'PENDING' ? `<button class="btn quiet small" data-act="rpost" data-arg="${e.id}">Später</button><button class="btn quiet small" data-act="rskip" data-arg="${e.id}">Auslassen</button>` : ''}</div>`;
    }).join('')}</div>`;
  }).join('') : '<p class="empty">Keine offenen Durchläufe – leg Rezepte an und nimm sie in die Rotation.</p>')
  + (fixed && actives.length ? `<h3>Feste Reihenfolge</h3><p class="hint" style="margin-top:0">Gilt ab dem nächsten Durchlauf.</p><div class="box">${actives.map((r, i) => `<div class="item">
      <span class="nm serif">${esc(r.name)}</span>
      <button class="btn quiet small" data-act="sortup" data-arg="${r.id}" ${i === 0 ? 'disabled' : ''} aria-label="Nach oben">▲</button>
      <button class="btn quiet small" data-act="sortdown" data-arg="${r.id}" ${i === actives.length - 1 ? 'disabled' : ''} aria-label="Nach unten">▼</button></div>`).join('')}</div>` : '')
  + `<div class="btns"><button class="btn danger" data-act="rreset">Rotation neu starten</button></div>`;
}

/* ---------- Einstellungen ---------- */
function vSettings() {
  const s = db.settings;
  const segb = (key, val, label) => `<button data-act="set" data-arg="${key}|${val}" aria-pressed="${s[key] === val}">${label}</button>`;
  const syncTxt = Sync.enabled() ? (Sync.isPB ? 'Verbunden mit deinem Pi' : `Verbunden mit GitHub ${esc(Sync.repo.owner)}/${esc(Sync.repo.name)} (alt)`) : 'Nicht eingerichtet – Daten nur auf diesem Gerät';
  return `<div class="box stack">
      <div class="row"><span class="grow"><b>Portionen pro Tag</b><span class="hint" style="display:block;margin:0">Wie viel euer Haushalt pro Tag isst</span></span>
        <div class="stepper"><button data-act="ppd" data-arg="-1" aria-label="Weniger">−</button><output>${s.portionsPerDay}</output><button data-act="ppd" data-arg="1" aria-label="Mehr">+</button></div></div>
      <div><b>Bei krummen Portionen</b><div class="seg" style="margin-top:8px">${segb('roundingMode', 'FLOOR', 'Abrunden')}${segb('roundingMode', 'CEIL', 'Aufrunden')}</div>
        <p class="hint">${s.roundingMode === 'FLOOR' ? '5 Portionen bei 2 pro Tag = 2 Tage, 1 Portion bleibt übrig.' : '5 Portionen bei 2 pro Tag = 3 Tage, am letzten Tag nur 1 Portion.'}</p></div>
      <div><b>Reihenfolge der Rotation</b><div class="seg" style="margin-top:8px">${segb('rotationMode', 'SHUFFLE', 'Jedes Mal neu mischen')}${segb('rotationMode', 'FIXED', 'Feste Reihenfolge')}</div></div>
      <div class="row"><span class="grow"><b>Marktliste mit Mengen</b></span><label class="switch"><input type="checkbox" id="s-mq" ${s.marketListShowQuantities ? 'checked' : ''} aria-label="Marktliste mit Mengen"><i></i></label></div>
    </div>
    <h3>Zusätzliche Mahlzeiten</h3>
    <div class="box stack">${['LUNCH', 'CAKE'].map(l => `<div><b>${l === 'LUNCH' ? 'Mittagessen an' : 'Kuchen an'}</b>
      <div class="chips">${[1, 2, 3, 4, 5, 6, 0].map(d => `<button class="chip" data-act="laneday" data-arg="${l}|${d}" aria-pressed="${laneDays(l).includes(d)}">${['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'][d]}</button>`).join('')}</div></div>`).join('')}
      <p class="hint" style="margin:0">Mittagessen und Kuchen kommen zusätzlich zum Hauptgericht dazu und haben jeweils eine eigene Rotation.</p></div>
    <h3>Verwalten</h3>
    <div class="box"><button class="item" data-act="to" data-arg="sources"><span class="nm">Einkaufsorte<span class="hint" style="display:block;margin:0">Was du auf dem Markt und was im Supermarkt kaufst</span></span>${unreviewedCount() ? `<span class="countbadge">${unreviewedCount()}</span>` : ''}</button>
      <button class="item" data-act="to" data-arg="ingredients"><span class="nm">Zutaten</span><span class="amt">${EP.live(db.ingredients).length}</span></button>
      <button class="item" data-act="to" data-arg="rotation"><span class="nm">Rotation ansehen</span></button>
      <button class="item" data-act="to" data-arg="sync"><span class="nm">Geräteabgleich<span class="hint" style="display:block;margin:0">${syncTxt}</span></span></button></div>
    <h3>Datensicherung</h3>
    <div class="box stack">
      <label class="row" style="gap:10px"><input type="checkbox" id="s-img" style="width:22px;height:22px"> Bilder mit sichern (größere Datei)</label>
      <button class="btn" data-act="export">Als Datei sichern</button>
      <button class="btn" data-act="import">Sicherung einlesen</button>
      <input type="file" id="s-file" accept=".json,application/json" class="hidden">
      ${liveRecipes().length ? '' : '<button class="btn" data-act="seed">Beispielrezepte laden</button>'}
    </div>
    <h3>Haushalt ${esc(db.household ? db.household.name : '')}</h3>
    <div class="box stack"><button class="btn" data-act="chpw">Passwort ändern</button><button class="btn danger" data-act="logout">Abmelden</button></div>`;
}

/* ---------- Einkaufsorte ---------- */
const SRC = [['MARKT', 'Markt'], ['SUPERMARKT', 'Supermarkt'], ['VORRAT', 'Vorrat']];
function srcSeg(act, id, cur, extraCls) {
  return `<div class="seg srcseg ${extraCls || ''}">${SRC.map(([k, l]) => `<button data-act="${act}" data-arg="${id}|${k}" aria-pressed="${cur === k}">${l}</button>`).join('')}</div>`;
}
function vSources() {
  const s = db.settings;
  const ings = EP.live(db.ingredients).sort((a, b) => a.name.localeCompare(b.name, 'de'));
  const fresh = ings.filter(i => i.reviewed === false);
  const row = i => `<div class="srcrow"><div class="row"><span class="grow nm">${esc(i.name)}</span>
      <span class="amt">${esc((EP.CAT[i.category] || EP.CAT.SONSTIGES).label)}${i.shoppingSource ? ' · angepasst' : ''}</span></div>
      ${srcSeg('src', i.id, EP.sourceOf(i, s))}</div>`;
  return `<p class="sub">Lege fest, was du auf dem Markt kaufst und was im Supermarkt. „Vorrat“ heißt: meist zu Hause, nur prüfen.</p>
    ${fresh.length ? `<h3>Neu hinzugekommen (${fresh.length})</h3><div class="box newbox">${fresh.map(row).join('')}
      <button class="btn primary" data-act="srcok" style="margin-top:12px">${fresh.length === 1 ? 'Passt so' : 'Alle passen so'}</button></div>` : ''}
    <h3>Nach Kategorie</h3>
    <p class="hint" style="margin-top:0">Gilt für alle Zutaten der Kategorie, die du nicht einzeln geändert hast.</p>
    <div class="box">${EP.CATEGORIES.map(c => `<div class="srcrow"><div class="row"><span class="grow nm">${esc(c.label)}</span></div>
      ${srcSeg('catsrc', c.key, EP.categorySource(c.key, s))}</div>`).join('')}</div>
    <h3>Einzelne Zutaten</h3>
    ${ings.length ? EP.CATEGORIES.map(c => {
      const list = ings.filter(i => i.category === c.key && i.reviewed !== false);
      return list.length ? `<details class="box srcgroup"><summary>${esc(c.label)} <span class="amt">${list.length}</span></summary>${list.map(row).join('')}</details>` : '';
    }).join('') : '<p class="empty">Noch keine Zutaten.</p>'}`;
}

/* ---------- Geräteabgleich ---------- */
let pendingJoin = '';
const pwField = id => `<label class="field"><span>Dein Haushaltspasswort</span><input class="in" id="${id}" type="password" autocomplete="current-password"></label>`;
function pbJoinForm() {
  return `<h3>Schon auf einem anderen Gerät eingerichtet</h3>
    <label class="field"><span>Link vom anderen Gerät</span><input class="in" id="pb-in" value="${esc(pendingJoin)}" placeholder="…/essensplanung.html#join=…" autocapitalize="off" autocomplete="off" spellcheck="false"></label>
    ${pwField('pb-pw3')}
    <p class="hint">Die Daten dieses Geräts werden mit dem verbundenen Haushalt zusammengeführt.</p>
    <div class="btns"><button class="btn${pendingJoin ? ' primary' : ''}" data-act="pbjoinhere">Verbinden</button></div>`;
}
function vSync() {
  const on = Sync.enabled(), r = Sync.repo;
  const last = Sync.lastSync ? new Date(Sync.lastSync).toLocaleString('de-DE', { dateStyle: 'short', timeStyle: 'short' }) : 'noch nie';
  const status = `<p class="hint">Letzter Abgleich: ${last}${Sync.msg ? `<br><span class="warn">${esc(Sync.msg)}</span>` : ''}</p>
      <div class="btns two"><button class="btn primary" data-act="syncnow">Jetzt abgleichen</button><button class="btn danger" data-act="syncoff">Trennen</button></div>`;
  if (on && Sync.isPB) return `<div class="box"><p><b>Verbunden</b> mit deinem Pi. Eure Daten liegen dort verschlüsselt.</p>${status}</div>
    <h3>Weiteres Gerät verbinden</h3>
    <p class="sub">Öffne diesen Link auf dem anderen Gerät oder füge ihn dort unter „Mit bestehendem Haushalt verbinden“ ein. Danach wird das Haushaltspasswort abgefragt.</p>
    <div class="box stack"><input class="in" id="pb-link" readonly value="${esc(PB.link(r.pb, Auth.token))}" aria-label="Verbindungslink">
      <div class="btns${navigator.share ? ' two' : ''}"><button class="btn primary" data-act="pbcopy">Link kopieren</button>${navigator.share ? '<button class="btn" data-act="pbshare">Senden …</button>' : ''}</div></div>
    <p class="hint">Wer den Link hat, kann eure Daten entschlüsseln. Gib ihn nur an Personen im Haushalt weiter.</p>`;
  if (on) return `<div class="box"><p><b>Verbunden</b> mit dem GitHub-Repository ${esc(r.owner)}/${esc(r.name)}.</p>${status}</div>
    <h3>Auf deinen Pi umziehen</h3>
    <p class="sub">Die Daten liegen dann verschlüsselt auf deinem Pi statt bei GitHub. Tokens werden nicht mehr gebraucht, die Bilder ziehen mit um.</p>
    ${pwField('pb-pw2')}
    <div class="btns"><button class="btn primary" data-act="pbmigrate">Jetzt umziehen</button></div>
    <p class="hint">Danach verbindest du die anderen Geräte mit dem neuen Link. Das GitHub-Repository bleibt unverändert und kann später gelöscht werden.</p>
    ${pbJoinForm()}`;
  return `<p class="sub">Damit alle Geräte im Haushalt denselben Stand haben, speichert die App eure Daten verschlüsselt auf deinem Pi. Ohne Einrichtung bleiben die Daten nur auf diesem Gerät.</p>
    ${pendingJoin ? '' : `<h3>Dieses Gerät ist das erste</h3>${pwField('pb-pw1')}<div class="btns"><button class="btn primary" data-act="pbcreate">Abgleich einrichten</button></div>`}
    ${pbJoinForm()}
    <details class="box ghalt" style="margin-top:22px"><summary>Alternativ: GitHub-Repository (alt)</summary>
      <label class="field"><span>GitHub-Benutzername</span><input class="in" id="g-o" autocapitalize="off" autocomplete="off"></label>
      <label class="field"><span>Repository</span><input class="in" id="g-r" value="essensplanung-daten" autocapitalize="off" autocomplete="off"></label>
      <label class="field"><span>Token</span><input class="in" id="g-t" type="password" autocomplete="off" placeholder="github_pat_…"></label>
      ${pwField('g-p')}
      <div class="btns"><button class="btn" data-act="syncsetup">Mit GitHub verbinden</button></div></details>`;
}
async function pbCreate(pw) {
  if (!(await Crypt.check(pw, db.household.verifier))) return notify('Das Passwort stimmt nicht.');
  notify('Richte den Abgleich ein …');
  try {
    const secret = PB.newSecret();
    const rec = await PB.create(secret, db);
    await Auth.storeToken(pw, secret, { pb: rec.id });
    Sync.sha = rec.updated; Sync.remoteRev = 1; Sync.dirty = false; await Sync.saveMeta();
    await Store.set('imgq', Images.allKeys()); await Store.set('imgdel', []);
    await Sync.run({ force: true }); Sync.startPolling();
    rerender(); notify('Abgleich eingerichtet. Den Link für weitere Geräte findest du hier.');
  } catch (e) { notify(e.message || 'Einrichten fehlgeschlagen.'); }
}
async function pbMigrate() {
  const pw = $('#pb-pw2').value;
  if (!(await Crypt.check(pw, db.household.verifier))) return notify('Das Passwort stimmt nicht.');
  notify('Hole den aktuellen Stand von GitHub …');
  await Sync.run({ force: true });
  if (Sync.state !== 'ok') return notify('GitHub ist gerade nicht erreichbar: ' + (Sync.msg || 'bitte später erneut versuchen.'));
  for (const key of Images.allKeys()) { await Images.get(key, false); await Images.get(key, true); }   // alle Bilder lokal holen
  await pbCreate(pw);
}
async function pbJoinHere() {
  const j = PB.parseLink($('#pb-in').value), pw = $('#pb-pw3').value;
  if (!j) return notify('Das sieht nicht nach einem Verbindungslink aus.');
  if (!pw) return notify('Bitte das Haushaltspasswort eingeben.');
  try {
    const f = await PB.fetchHousehold(j.id, j.secret);
    if (!(await Crypt.check(pw, f.remote.household && f.remote.household.verifier))) return notify('Das Passwort passt nicht zu diesem Haushalt.');
    const keys = Images.allKeys();
    db = repairDb(EP.mergeDb(db, f.remote)); EP.normalizePlan(db);
    await Store.set('db', db);
    await Auth.storeToken(pw, j.secret, { pb: j.id });
    Sync.sha = f.updated; Sync.remoteRev = f.rev; Sync.dirty = Sync.canon(db) !== Sync.canon(f.remote); await Sync.saveMeta();
    await Store.set('imgq', keys);
    pendingJoin = '';
    await Sync.run({ force: true }); Sync.startPolling();
    rerender(); notify('Verbunden.');
  } catch (e) { notify(e.message || 'Verbinden fehlgeschlagen.'); }
}
async function setupSync() {
  const o = $('#g-o').value.trim(), n = $('#g-r').value.trim(), t = $('#g-t').value.trim(), pw = $('#g-p').value;
  if (!o || !n || !t || !pw) return notify('Bitte alle Felder ausfüllen.');
  if (!(await Crypt.check(pw, db.household.verifier))) return notify('Das Passwort stimmt nicht.');
  try {
    await Sync.checkRepo(o, n, t);
    await Auth.storeToken(pw, t, { owner: o, name: n });
    Sync.sha = null; Sync.dirty = true; await Sync.saveMeta();
    notify('Verbunden – gleiche ab …');
    await Sync.run({ force: true });
    Sync.startPolling();
    rerender();
  } catch (e) { notify(e.message); }
}

/* ---------- Ereignisse ---------- */
const ACT = {
  back: () => back(),
  tab: a => go(a),
  tabkind: a => { recipeFilter.kind = a; go('recipes'); },
  slane: a => { suggestLane = a; rerender(); },
  rkind: a => { recipeFilter.kind = a; recipeFilter.tag = ''; rerender(); },
  seedlane: async lane => {
    const res = await importData({ data: seedToDb(LANE_SAMPLES[lane], EP) }, 'merge');
    change(`${res.added} ${lane === 'CAKE' ? 'Kuchen' : 'Mittagsgerichte'} geladen.`);
  },
  lane: a => { const [d, l] = a.split('|'); laneActions(d, l); },
  shopwk: n => { const f = EP.addDays(EP.weekStart(shopRange.from), +n); shopRange = { from: f, to: EP.addDays(f, 6) }; rerender(); },
  ekind: k => { readEditForm(); const r = editState.r; if (EP.laneOf(r) === k) return; r.kind = k; if (k === 'CAKE' && r.servings <= 4) r.servings = 12; if (k !== 'CAKE' && r.servings > 8 && editState.isNew) r.servings = db.settings.portionsPerDay; editState.dirty = true; rerender(); },
  emonth: m => { readEditForm(); m = +m; const r = editState.r; const set = new Set(r.seasonMonths || []); set.has(m) ? set.delete(m) : set.add(m); r.seasonMonths = [...set].sort((a, b) => a - b); editState.dirty = true; rerender(); },
  laneday: a => {
    const [l, d] = a.split('|'); const days = new Set(laneDays(l)); days.has(+d) ? days.delete(+d) : days.add(+d);
    db.settings.lanes = Object.assign({}, db.settings.lanes, { [l]: { days: [...days] } }); EP.touch(db.settings); change();
  },
  src: a => {
    const [id, v] = a.split('|'); const i = ingById(id);
    i.shoppingSource = v === EP.categorySource(i.category, db.settings) ? null : v; i.reviewed = true; EP.touch(i); change();
  },
  catsrc: a => {
    const [cat, v] = a.split('|');
    db.settings.categorySources = Object.assign({}, db.settings.categorySources, { [cat]: v }); EP.touch(db.settings);
    // einzelne Abweichungen, die jetzt der Kategorie entsprechen, aufheben
    EP.live(db.ingredients).filter(i => i.category === cat && i.shoppingSource === v).forEach(i => { i.shoppingSource = null; EP.touch(i); });
    change();
  },
  srcok: () => { EP.live(db.ingredients).filter(i => i.reviewed === false).forEach(i => { i.reviewed = true; EP.touch(i); }); change('Einkaufsorte übernommen.'); },
  to: a => go(a),
  seed: async () => {
    const res = await importData({ data: seedToDb(SEED_DATA, EP) }, 'merge');
    change(`${res.added} Beispielrezepte geladen.`);
  },
  /* Vorschlag */
  accept: id => {
    const e = rotById(null, id), r = recipeById(e.recipeId), lane = EP.laneOf(e);
    if (lane !== 'MAIN') return laneDateSheet('Übernehmen', r, lane, firstLaneDay(lane, EP.todayISO()), 'Übernehmen', d => { placeLane(d, lane, r.id, e.id); change('Eingeplant am ' + EP.fmtShort(d) + '.'); });
    dateSheet('Übernehmen', r, firstFreeFrom(EP.todayISO()), 'Übernehmen', d => { placeBlock(d, { recipeId: r.id, rotationEntryId: e.id }); change('Eingeplant ab ' + EP.fmtShort(d) + '.'); });
  },
  postpone: id => { EP.postpone(db, rotById(null, id)); change('Kommt später wieder dran.'); },
  skip: id => {
    const e = rotById(null, id), r = recipeById(e.recipeId);
    confirmSheet('Diesmal auslassen?', `„${r.name}“ wird in diesem Durchlauf übersprungen und kommt erst im nächsten wieder.`, 'Auslassen', 'Zurück', () => { EP.skipEntry(e); change('Ausgelassen.'); });
  },
  pickself: () => recipePickSheet('Selbst wählen', id => {
    const r = recipeById(id), e = EP.manualPickEntry(db, id), lane = suggestLane;
    if (lane !== 'MAIN') return laneDateSheet('Einplanen', r, lane, firstLaneDay(lane, EP.todayISO()), 'Einplanen', d => { placeLane(d, lane, id, e ? e.id : null); change('Eingeplant am ' + EP.fmtShort(d) + '.'); });
    dateSheet('Einplanen', r, firstFreeFrom(EP.todayISO()), 'Einplanen', d => { placeBlock(d, { recipeId: id, rotationEntryId: e ? e.id : null }); change('Eingeplant ab ' + EP.fmtShort(d) + '.'); });
  }, suggestLane),
  /* Woche */
  wk: a => { const n = +a; weekStartISO = n === 0 ? EP.weekStart(EP.todayISO()) : EP.addDays(weekStartISO, n); rerender(); },
  day: d => dayActions(d),
  fill: () => {
    if (!EP.activeRecipes(db).length) return notify('Keine Rezepte in der Rotation.');
    startDraft(weekStartISO); rerender();
  },
  discard: () => { draft = null; rerender(); notify('Entwurf verworfen.'); },
  commit: () => { commitDraft(); change('Plan übernommen.'); Sync.run(); },
  toshop: () => { shopRange = { from: weekStartISO, to: EP.addDays(weekStartISO, 6) }; go('shop'); },
  /* Einkauf */
  addextra: () => {
    const inp = $('#extra'); const t = inp.value.trim(); if (!t) return;
    shopState(shopRange.from, shopRange.to).extraItems.push({ text: t, checked: false }); EP.touch(db.shopping);
    change().then(() => { const i = $('#extra'); if (i) i.focus(); });
  },
  delextra: i => { const st = shopState(shopRange.from, shopRange.to); st.extraItems.splice(+i, 1); EP.touch(st); change(); },
  copyshop: () => {
    const t = shopText();
    (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => notify('Einkaufsliste kopiert.')).catch(() => notify('Kopieren nicht möglich.'));
  },
  shareshop: () => navigator.share({ title: 'Einkaufsliste', text: shopText() }).catch(() => {}),
  printshop: () => window.print(),
  /* Rezepte */
  qa: () => {
    const inp = $('#qa'); const v = inp.value.trim(); if (!v) return;
    const res = quickAdd([v], recipeFilter.kind);
    inp.value = '';
    change(res.added ? 'Angelegt.' : res.restored ? 'Wiederhergestellt.' : 'Dieses Rezept gibt es schon.').then(() => { const i = $('#qa'); if (i) i.focus(); });
  },
  rimport: () => importSheet(),
  rstatus: a => { recipeFilter.status = a; rerender(); },
  rtag: a => { recipeFilter.tag = recipeFilter.tag === a ? '' : a; rerender(); },
  w: a => { const [id, d] = a.split('|'); const r = recipeById(id); setWeight(r, r.weight + (+d)); change(); },
  edit: id => openEdit(id),
  cook: id => openCook(id),
  closecook: () => closeCook(),
  /* Editor */
  serv: d => { readEditForm(); editState.r.servings = Math.max(1, Math.min(99, editState.r.servings + (+d))); editState.dirty = true; rerender(); },
  ew: d => { readEditForm(); editState.r.weight = Math.max(1, Math.min(5, editState.r.weight + (+d))); editState.dirty = true; rerender(); },
  rowadd: () => { readEditForm(); editState.rows.push({ name: '', qty: '', unit: '', note: '', cat: 'SONSTIGES' }); editState.dirty = true; rerender();
    const rows = $$('[data-row]'); const last = rows[rows.length - 1]; if (last) $('[data-f=qty]', last).focus(); },
  rowdel: i => { readEditForm(); editState.rows.splice(+i, 1); editState.dirty = true; rerender(); },
  rowup: i => { readEditForm(); i = +i; if (i > 0) [editState.rows[i - 1], editState.rows[i]] = [editState.rows[i], editState.rows[i - 1]]; editState.dirty = true; rerender(); },
  rowdown: i => { readEditForm(); i = +i; if (i < editState.rows.length - 1) [editState.rows[i + 1], editState.rows[i]] = [editState.rows[i], editState.rows[i + 1]]; editState.dirty = true; rerender(); },
  save: () => saveEdit(),
  archive: () => confirmSheet('Rezept löschen?', 'Es verschwindet aus dem Fundus und der Rotation. Bereits geplante Tage bleiben sichtbar.', 'Löschen', 'Behalten', () => {
    const r = recipeById(editState.r.id); archiveRecipe(r); editState = null; route = stack.pop() || { name: 'recipes' }; change('Gelöscht.');
  }, true),
  imgadd: () => { readEditForm(); $('#e-file').click(); },
  img: key => {
    readEditForm();
    const imgs = editState.r.images;
    optionsSheet('Bild', '', [
      { label: 'Als Titelbild verwenden', run: () => { imgs.forEach(i => i.isCover = i.fileKey === key); editState.dirty = true; rerender(); } },
      { label: 'Bild entfernen', danger: true, run: () => {
        const i = imgs.findIndex(x => x.fileKey === key); const wasCover = imgs[i].isCover;
        imgs.splice(i, 1); if (wasCover && imgs[0]) imgs[0].isCover = true;
        Images.remove(key); editState.dirty = true; rerender();
      } },
    ]);
  },
  /* Zutaten, Rotation */
  ingnew: () => ingredientSheet(null),
  ing: id => ingredientSheet(id),
  rpost: id => { EP.postpone(db, rotById(null, id)); change('Ans Ende verschoben.'); },
  rskip: id => { EP.skipEntry(rotById(null, id)); change('Ausgelassen.'); },
  rreset: () => confirmSheet('Rotation neu starten?', 'Alle offenen Einträge werden verworfen und für Hauptgerichte, Mittag und Kuchen neu gemischt. Bereits geplante Tage bleiben erhalten.', 'Neu starten', 'Abbrechen', () => { EP.LANES.forEach(l => EP.resetRotation(db, rng, l.key, EP.monthOf(EP.todayISO()))); change('Neuer Durchlauf gestartet.'); }, true),
  sortup: id => moveSort(id, -1),
  sortdown: id => moveSort(id, 1),
  /* Einstellungen */
  ppd: d => { db.settings.portionsPerDay = Math.max(1, Math.min(12, db.settings.portionsPerDay + (+d))); EP.touch(db.settings); change(); },
  set: a => { const [k, v] = a.split('|'); db.settings[k] = v; EP.touch(db.settings); change(); },
  export: async () => {
    const txt = await exportData($('#s-img') && $('#s-img').checked);
    const blob = new Blob([txt], { type: 'application/json' });
    const name = `essensplanung-${EP.todayISO()}.json`;
    const file = typeof File !== 'undefined' ? new File([blob], name, { type: 'application/json' }) : null;
    if (file && navigator.canShare && navigator.canShare({ files: [file] })) { navigator.share({ files: [file], title: 'Essensplanung-Sicherung' }).catch(() => {}); return; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  },
  import: () => $('#s-file').click(),
  chpw: () => changePasswordSheet(),
  logout: () => confirmSheet('Abmelden?', 'Die Daten bleiben auf diesem Gerät gespeichert. Zum Öffnen brauchst du wieder dein Passwort.', 'Abmelden', 'Abbrechen', () => { Auth.logout(); location.reload(); }),
  syncsetup: () => setupSync(),
  pbcreate: () => pbCreate($('#pb-pw1').value),
  pbmigrate: () => pbMigrate(),
  pbjoinhere: () => pbJoinHere(),
  pbcopy: async () => { const l = $('#pb-link'); try { await navigator.clipboard.writeText(l.value); notify('Link kopiert.'); } catch (e) { l.focus(); l.select(); notify('Link markiert – jetzt kopieren.'); } },
  pbshare: () => navigator.share({ title: 'Essensplanung verbinden', url: $('#pb-link').value }).catch(() => {}),
  syncnow: () => Sync.run({ force: true }).then(rerender),
  syncoff: () => confirmSheet('Abgleich trennen?', 'Die Daten bleiben auf diesem Gerät. Andere Geräte gleichen sich weiterhin untereinander ab.', 'Trennen', 'Abbrechen', async () => {
    const c = Auth.cfg; c.tokenEnc = null; c.repo = null; Auth.cfg = c; Auth.token = null;
    const s = LS.get('ep_session'); if (s) { s.tokenEnc = null; LS.set('ep_session', s); }
    Sync.setState('off'); rerender(); notify('Abgleich getrennt.');
  }, true),
};
function moveSort(id, dir) {
  const act = EP.activeRecipes(db).sort((a, b) => a.sortOrder - b.sortOrder);
  const i = act.findIndex(r => r.id === id), j = i + dir;
  if (j < 0 || j >= act.length) return;
  [act[i], act[j]] = [act[j], act[i]];
  act.forEach((r, k) => { if (r.sortOrder !== k + 1) { r.sortOrder = k + 1; EP.touch(r); } });
  change();
}
function changePasswordSheet() {
  openSheet(`<h2>Passwort ändern</h2>
    <label class="field"><span>Bisheriges Passwort</span><input class="in" type="password" id="p0" autocomplete="current-password"></label>
    <label class="field"><span>Neues Passwort</span><input class="in" type="password" id="p1" autocomplete="new-password"></label>
    <label class="field"><span>Neues Passwort wiederholen</span><input class="in" type="password" id="p2" autocomplete="new-password"></label>
    <p class="hint">Gilt für alle Geräte des Haushalts.</p>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Ändern</button></div>`, el => {
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = async () => {
      const p0 = $('#p0', el).value, p1 = $('#p1', el).value, p2 = $('#p2', el).value;
      if (!(await Crypt.check(p0, db.household.verifier))) return notify('Das bisherige Passwort stimmt nicht.');
      if (p1.length < 6) return notify('Das neue Passwort braucht mindestens 6 Zeichen.');
      if (p1 !== p2) return notify('Die neuen Passwörter stimmen nicht überein.');
      db.household.verifier = await Crypt.verifier(p1); EP.touch(db.household);
      if (Auth.token) await Auth.storeToken(p1, Auth.token, Sync.repo);
      closeSheet(); change('Passwort geändert.');
    };
  });
}

/* Bindungen je Ansicht (Eingabefelder) */
const BIND = {
  shop: m => {
    const setRange = () => {
      const f = $('#sf', m).value, t = $('#st', m).value;
      if (f && t && f <= t) { shopRange = { from: f, to: t }; rerender(); }
    };
    $('#sf', m).onchange = setRange; $('#st', m).onchange = setRange;
    $$('[data-check]', m).forEach(c => c.onchange = () => {
      const st = shopState(shopRange.from, shopRange.to), k = c.dataset.check;
      st.checkedKeys = c.checked ? [...new Set(st.checkedKeys.concat(k))] : st.checkedKeys.filter(x => x !== k);
      EP.touch(st); persist(); c.closest('.item').classList.toggle('checked', c.checked);
    });
    $$('[data-extra]', m).forEach(c => c.onchange = () => {
      const st = shopState(shopRange.from, shopRange.to);
      st.extraItems[+c.dataset.extra].checked = c.checked; EP.touch(st); persist(); c.closest('.item').classList.toggle('checked', c.checked);
    });
    const ex = $('#extra', m); if (ex) ex.onkeydown = e => { if (e.key === 'Enter') ACT.addextra(); };
  },
  recipes: m => {
    const qa = $('#qa', m);
    qa.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); ACT.qa(); } };
    qa.addEventListener('paste', e => {
      const t = (e.clipboardData || window.clipboardData).getData('text');
      if (!/\n/.test(t)) return;
      e.preventDefault();
      const res = quickAdd(t.split(/\r?\n/), recipeFilter.kind);
      change(`${res.added} angelegt${res.restored ? `, ${res.restored} wiederhergestellt` : ''}${res.skipped ? `, ${res.skipped} schon vorhanden` : ''}.`);
    });
    const rq = $('#rq', m);
    if (rq) rq.oninput = () => {
      recipeFilter.q = rq.value; const pos = rq.selectionStart; rerender();
      const n = $('#rq'); if (n) { n.focus(); n.setSelectionRange(pos, pos); }
    };
    $$('[data-rot]', m).forEach(c => c.onchange = () => { setInRotation(recipeById(c.dataset.rot), c.checked); change(c.checked ? 'In Rotation.' : 'Pausiert.'); });
  },
  edit: m => {
    $$('input,textarea,select', m).forEach(el => el.addEventListener('input', () => { if (editState) editState.dirty = true; }));
    const refreshRow = el => {
      const rowEl = el.closest('[data-row]');
      const name = $('[data-f=name]', rowEl).value.trim();
      const ing = name ? findIngredient(name) : null;
      $('.newcat', rowEl).classList.toggle('hidden', !name || !!ing);
      const cat = $('[data-f=cat]', rowEl);
      if (!ing && name && !cat.dataset.touched) cat.value = EP.guessCategory(name); // Kategorie vorschlagen
      const unit = $('[data-f=unit]', rowEl);
      if (ing && !unit.value && $('[data-f=qty]', rowEl).value.trim()) unit.value = ing.defaultUnit;
    };
    $$('[data-f=name]', m).forEach(el => { el.addEventListener('change', () => refreshRow(el)); el.addEventListener('input', () => refreshRow(el)); });
    $$('[data-f=qty]', m).forEach(el => el.addEventListener('change', () => refreshRow(el)));
    $$('[data-f=cat]', m).forEach(el => el.addEventListener('change', () => { el.dataset.touched = '1'; }));
    const ay = $('#e-allyear', m);
    if (ay) ay.onchange = () => {
      readEditForm();
      editState.r.seasonMonths = ay.checked ? null : [EP.monthOf(EP.todayISO())];
      editState.dirty = true; rerender();
    };
    const days = $('#e-days', m);
    if (days) days.oninput = () => {
      const d = parseInt(days.value, 10); editState.r.daysOverride = d > 0 ? d : null;
      $('#e-live').textContent = liveDaysText(editState.r);
      $('#e-hint').textContent = EP.daysHint(editState.r, db.settings);
    };
    $('#e-file', m).onchange = async e => {
      readEditForm();
      const files = [...e.target.files];
      for (const f of files) {
        try {
          const p = await Images.process(f);
          const key = EP.uuid();
          await Images.put(key, p.full, p.thumb);
          const imgs = editState.r.images;
          imgs.push({ fileKey: key, width: p.width, height: p.height, sortOrder: imgs.length + 1, isCover: !imgs.some(i => i.isCover) });
          editState.dirty = true;
        } catch (err) { notify(err.message); }
      }
      rerender();
    };
  },
  ingredients: m => {
    const q = $('#iq', m);
    q.oninput = () => { ingQuery = q.value; const pos = q.selectionStart; rerender(); const n = $('#iq'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } };
  },
  settings: m => {
    $('#s-mq', m).onchange = e => { db.settings.marketListShowQuantities = e.target.checked; EP.touch(db.settings); change(); };
    $('#s-file', m).onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      let json;
      try { json = JSON.parse(await f.text()); } catch (err) { return notify('Die Datei ist keine gültige Sicherung.'); }
      const d = json.data || json;
      const n = (d.recipes || []).filter(r => !r.deleted && !r.archivedAt).length;
      optionsSheet('Sicherung einlesen', `Die Datei enthält ${n} Rezepte.`, [
        { label: 'Zusammenführen', hint: 'Neue Rezepte ergänzen, gleichnamige aktualisieren', run: async () => { const r = await importData(json, 'merge'); change(`${r.added} ergänzt, ${r.updated} aktualisiert.`); } },
        { label: 'Alles ersetzen', danger: true, hint: 'Rezepte, Zutaten, Rotation und Plan werden durch die Sicherung ersetzt', run: () =>
          confirmSheet('Wirklich alles ersetzen?', 'Der aktuelle Stand geht dabei verloren – auch auf verbundenen Geräten.', 'Ersetzen', 'Abbrechen', async () => { await importData(json, 'replace'); change('Sicherung eingelesen.'); }, true) },
      ]);
      e.target.value = '';
    };
  },
};

/* ---------- Anmeldung, Einrichtung ---------- */
function showAuth(html, bind) {
  $('#shell').classList.add('hidden');
  const a = $('#auth'); a.classList.remove('hidden');
  a.innerHTML = `<div class="auth"><div class="mark" aria-hidden="true"></div>${html}
    <p style="text-align:center;margin-top:28px"><a class="backlink" href="index.html">Zurück zur Übersicht</a></p></div>`;
  if (bind) bind(a);
}
function authWelcome() {
  showAuth(`<h1>Essensplanung</h1><p class="lead">Rezepte sammeln, der Reihe nach kochen, Woche planen und einkaufen.</p>
    <div class="btns" style="margin-top:28px"><button class="btn primary" data-x="new">Neuen Haushalt einrichten</button>
    <button class="btn" data-x="join">Mit bestehendem Haushalt verbinden</button></div>
    <p class="hint" style="text-align:center">Verbinden, wenn die Essensplanung schon auf einem anderen Gerät eingerichtet ist.</p>`, a => {
    $('[data-x=new]', a).onclick = authSetup;
    $('[data-x=join]', a).onclick = () => authJoin(pendingJoin);
  });
}
function authSetup() {
  showAuth(`<h1>Neuer Haushalt</h1>
    <label class="field"><span>Name des Haushalts</span><input class="in" id="a-n" placeholder="z. B. Familie Muster"></label>
    <label class="field"><span>Passwort</span><input class="in" type="password" id="a-p1" autocomplete="new-password"></label>
    <label class="field"><span>Passwort wiederholen</span><input class="in" type="password" id="a-p2" autocomplete="new-password"></label>
    <p class="hint">Mit diesem Passwort öffnest du die Essensplanung auf allen Geräten. Den Abgleich zwischen Geräten richtest du danach in den Einstellungen ein.</p>
    <div class="btns"><button class="btn primary" data-x="ok">Einrichten</button><button class="btn quiet" data-x="back">Zurück</button></div>`, a => {
    $('[data-x=back]', a).onclick = authWelcome;
    $('[data-x=ok]', a).onclick = async () => {
      const n = $('#a-n', a).value.trim(), p1 = $('#a-p1', a).value, p2 = $('#a-p2', a).value;
      if (!n) return notify('Bitte einen Namen eingeben.');
      if (p1.length < 6) return notify('Das Passwort braucht mindestens 6 Zeichen.');
      if (p1 !== p2) return notify('Die Passwörter stimmen nicht überein.');
      db = emptyDb();
      db.household = EP.touch({ name: n, verifier: await Crypt.verifier(p1) });
      await Store.set('db', db);
      await Auth.startSession(null);
      enterApp();
    };
  });
}
function authJoin(prefill) {
  showAuth(`<h1>Verbinden</h1><p class="lead">Auf dem Gerät, auf dem die Essensplanung schon läuft: Einstellungen → Geräteabgleich → „Link kopieren“. Den Link hier einfügen oder direkt auf diesem Gerät öffnen.</p>
    <label class="field"><span>Verbindungslink</span><input class="in" id="jl-l" value="${esc(prefill || '')}" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="…/essensplanung.html#join=…"></label>
    <label class="field"><span>Haushaltspasswort</span><input class="in" type="password" id="jl-p" autocomplete="current-password"></label>
    <div class="btns"><button class="btn primary" data-x="ok">Verbinden</button><button class="btn quiet" data-x="back">Zurück</button></div>
    <p style="text-align:center;margin-top:18px"><button class="btn quiet" data-x="gh">Über GitHub-Repository verbinden (alt)</button></p>`, a => {
    $('[data-x=back]', a).onclick = authWelcome;
    $('[data-x=gh]', a).onclick = authJoinGH;
    $('[data-x=ok]', a).onclick = async () => {
      const j = PB.parseLink($('#jl-l', a).value), pw = $('#jl-p', a).value;
      if (!j) return notify('Das sieht nicht nach einem Verbindungslink aus.');
      if (!pw) return notify('Bitte das Haushaltspasswort eingeben.');
      try {
        const f = await PB.fetchHousehold(j.id, j.secret);
        if (!(await Crypt.check(pw, f.remote.household && f.remote.household.verifier))) return notify('Das Passwort passt nicht zu diesem Haushalt.');
        db = f.remote; Sync.sha = f.updated; Sync.remoteRev = f.rev; Sync.dirty = false; Sync.lastSync = Date.now();
        await Store.set('db', db); await Sync.saveMeta();
        await Auth.startSession(j.secret);
        await Auth.storeToken(pw, j.secret, { pb: j.id });
        pendingJoin = '';
        enterApp();
      } catch (e) { notify(e.message || 'Verbinden fehlgeschlagen.'); }
    };
  });
}
function authJoinGH() {
  showAuth(`<h1>Verbinden</h1><p class="lead">Die Daten liegen im privaten GitHub-Repository, das du beim ersten Gerät eingerichtet hast.</p>
    <label class="field"><span>GitHub-Benutzername</span><input class="in" id="j-o" autocapitalize="off" autocomplete="off"></label>
    <label class="field"><span>Repository</span><input class="in" id="j-r" value="essensplanung-daten" autocapitalize="off" autocomplete="off"></label>
    <label class="field"><span>Token</span><input class="in" type="password" id="j-t" autocomplete="off" placeholder="github_pat_…"></label>
    <label class="field"><span>Haushaltspasswort</span><input class="in" type="password" id="j-p" autocomplete="current-password"></label>
    <div class="btns"><button class="btn primary" data-x="ok">Verbinden</button><button class="btn quiet" data-x="back">Zurück</button></div>`, a => {
    $('[data-x=back]', a).onclick = () => authJoin();
    $('[data-x=ok]', a).onclick = async () => {
      const o = $('#j-o', a).value.trim(), n = $('#j-r', a).value.trim(), t = $('#j-t', a).value.trim(), pw = $('#j-p', a).value;
      if (!o || !n || !t || !pw) return notify('Bitte alle Felder ausfüllen.');
      try {
        await Sync.checkRepo(o, n, t);
        Auth.token = t; Auth.cfg = Object.assign(Auth.cfg, { repo: { owner: o, name: n } });
        const f = await Sync.getFile('data.json');
        if (!f) { Auth.token = null; Auth.cfg = {}; return notify('Im Repository liegt noch kein Haushalt. Richte ihn zuerst auf einem Gerät ein und verbinde dort den Abgleich.'); }
        const remote = repairDb(JSON.parse(b64ToUtf8(f.b64)));
        if (!(await Crypt.check(pw, remote.household && remote.household.verifier))) { Auth.token = null; Auth.cfg = {}; return notify('Das Passwort passt nicht zu diesem Haushalt.'); }
        db = remote; Sync.sha = f.sha; Sync.dirty = false; Sync.lastSync = Date.now();
        await Store.set('db', db); await Sync.saveMeta();
        await Auth.startSession(t);
        await Auth.storeToken(pw, t, { owner: o, name: n });
        enterApp();
      } catch (e) { Auth.token = null; notify(e.message); }
    };
  });
}
function authLogin() {
  showAuth(`<h1>${esc(db.household.name)}</h1><p class="lead">Mit dem Haushaltspasswort öffnen.</p>
    <label class="field"><span>Passwort</span><input class="in" type="password" id="l-p" autocomplete="current-password" enterkeyhint="go"></label>
    <p class="hint warn" id="l-e"></p>
    <div class="btns"><button class="btn primary" data-x="ok">Öffnen</button></div>`, a => {
    const go = async () => {
      const mins = Auth.locked();
      if (mins) { $('#l-e', a).textContent = `Zu viele Versuche. Bitte in ${mins} ${mins === 1 ? 'Minute' : 'Minuten'} erneut versuchen.`; return; }
      const pw = $('#l-p', a).value;
      if (!(await Crypt.check(pw, db.household.verifier))) { Auth.failed(); $('#l-e', a).textContent = 'Das Passwort stimmt nicht.'; return; }
      const tok = await Auth.tokenFromPassword(pw);
      await Auth.startSession(tok || null);
      if (tok === undefined) notify('Das Passwort wurde auf einem anderen Gerät geändert. Bitte den Abgleich-Zugang in den Einstellungen neu eintragen.');
      enterApp();
    };
    $('[data-x=ok]', a).onclick = go;
    $('#l-p', a).onkeydown = e => { if (e.key === 'Enter') go(); };
  });
}

/* ---------- Start ---------- */
async function enterApp() {
  $('#auth').classList.add('hidden');
  $('#shell').classList.remove('hidden');
  db = repairDb(db);
  if (housekeeping()) await persist();
  route = { name: 'suggest' }; stack = [];
  rerender();
  if (Sync.enabled()) { Sync.run(); Sync.startPolling(); }
  if (pendingJoin) {
    const j = PB.parseLink(pendingJoin);
    if (j && Sync.isPB && Sync.repo.pb === j.id) pendingJoin = '';
    else go('sync');
  }
}
async function boot() {
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-act],[data-tab]');
    if (!t) return;
    if (t.dataset.tab) { go(t.dataset.tab); return; }
    const fn = ACT[t.dataset.act];
    if (fn) { e.preventDefault(); fn(t.dataset.arg); }
  });
  $('#syncpill').onclick = () => go('sync');
  $('#gear').onclick = () => go('settings');
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    if (Sync.enabled()) Sync.run();
    if (!$('#cookview').classList.contains('hidden')) lockScreen();
    if (db && housekeeping()) { persist(); rerender(); }
  });
  window.addEventListener('online', () => Sync.run());
  window.addEventListener('focus', () => { if (Sync.enabled()) Sync.run(); });
  if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});

  const hj = PB.parseLink(location.hash);
  if (hj) { pendingJoin = PB.link(hj.id, hj.secret); try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {} }
  db = await Store.get('db');
  await Sync.loadMeta();
  if (!db || !db.household) return pendingJoin ? authJoin(pendingJoin) : authWelcome();
  db = repairDb(db);
  if (await Auth.resume()) return enterApp();
  authLogin();
}
boot();
