/* ==========================================================================
   Essensplanung – App Teil 4: Rezepte, Einstellungen, Anmeldung, Start
   ========================================================================== */

/* ---------- Rezepte (Fundus) ---------- */
function recipeMatches(r) {
  const f = recipeFilter;
  if (EP.laneOf(r) !== f.kind) return false;
  const rot = EP.ROTATES(f.kind);
  if (rot && f.status === 'active' && !r.inRotation) return false;
  if (rot && f.status === 'paused' && r.inRotation) return false;
  if (f.tag && !(r.tags || []).includes(f.tag)) return false;
  if (f.q) {
    const q = f.q.toLowerCase();
    const inIng = r.ingredients.some(x => { const i = ingById(x.ingredientId); return i && i.name.toLowerCase().includes(q); });
    if (!r.name.toLowerCase().includes(q) && !(r.tags || []).some(t => t.toLowerCase().includes(q)) && !inIng) return false;
  }
  return true;
}
let favPinned = null;
/* Stern für Favoriten */
function favBtn(r) {
  return `<button class="favbtn" data-act="fav" data-arg="${r.id}" aria-pressed="${!!r.favorite}" aria-label="${r.favorite ? 'Kein Favorit mehr' : 'Als Favorit markieren'}">${r.favorite ? ICON.starOn : ICON.star}</button>`;
}
/* Sortierung der Rezeptliste – Wahl gilt auf diesem Gerät */
const SORT_MODES = {
  name: { label: 'Name (A–Z)', short: 'A–Z', sub: 'Favoriten oben' },
  new: { label: 'Zuletzt hinzugefügt', short: 'Neueste' },
  cooked: { label: 'Zuletzt gekocht', short: 'Zuletzt' },
  long: { label: 'Lange nicht gekocht', short: 'Lange nicht', sub: 'Nie gekochte zuerst' },
  often: { label: 'Am häufigsten gekocht', short: 'Häufig' },
  quick: { label: 'Schnellste zuerst', short: 'Schnell', sub: 'Nach Zubereitungszeit' },
};
function recipeSortMode() { let m = recipeFilter.sort; if (!m) { try { m = localStorage.getItem('ep_rsort'); } catch (e) {} } return SORT_MODES[m] ? m : 'name'; }
function setRecipeSort(m) { recipeFilter.sort = m; try { localStorage.setItem('ep_rsort', m); } catch (e) {} }
/* je Rezept: letzter Kochtag (bis heute) und Anzahl Kochtage */
function cookStats() {
  const today = EP.todayISO(), m = new Map();
  EP.live(db.plan).forEach(p => {
    if (p.type !== 'COOK' || !p.recipeId || (p.dayIndex || 1) !== 1 || p.date > today) return;
    const o = m.get(p.recipeId) || { last: '', n: 0 };
    o.n++; if (p.date > o.last) o.last = p.date; m.set(p.recipeId, o);
  });
  return m;
}
function recipeSorter(mode, stats) {
  const byName = (a, b) => a.name.localeCompare(b.name, 'de');
  const st = r => (stats && stats.get(r.id)) || { last: '', n: 0 };
  switch (mode) {
    case 'new': return (a, b) => (b.createdAt || 0) - (a.createdAt || 0) || (b.sortOrder || 0) - (a.sortOrder || 0) || byName(a, b);
    case 'cooked': return (a, b) => st(b).last.localeCompare(st(a).last) || byName(a, b);
    case 'long': return (a, b) => st(a).last.localeCompare(st(b).last) || byName(a, b);
    case 'often': return (a, b) => st(b).n - st(a).n || st(b).last.localeCompare(st(a).last) || byName(a, b);
    case 'quick': return (a, b) => (a.prepTimeMinutes || 1e9) - (b.prepTimeMinutes || 1e9) || byName(a, b);
    default: return (a, b) => (favPinned.has(b.id) - favPinned.has(a.id)) || byName(a, b);
  }
}
function agoLabel(iso) {
  const d = Math.round((EP.parseISO(EP.todayISO()) - EP.parseISO(iso)) / 864e5);
  if (d <= 0) return 'heute'; if (d === 1) return 'gestern'; if (d < 14) return `vor ${d} Tagen`;
  if (d < 60) return `vor ${Math.round(d / 7)} Wochen`; const mo = Math.round(d / 30); return mo < 12 ? `vor ${mo} Monaten` : 'vor über einem Jahr';
}
function sortMeta(r, mode, stats) {
  if (mode === 'quick') return r.prepTimeMinutes ? `<br>${r.prepTimeMinutes} min` : '';
  if (mode === 'new') return r.createdAt ? `<br>Hinzugefügt ${agoLabel(EP.iso(new Date(r.createdAt)))}` : '';
  if (!stats) return '';
  const o = stats.get(r.id);
  if (!o) return '<br>Noch nie gekocht';
  return mode === 'often' ? `<br>${o.n}× gekocht, zuletzt ${agoLabel(o.last)}` : `<br>Zuletzt gekocht ${agoLabel(o.last)}`;
}
function sortSheet() {
  const cur = recipeSortMode();
  openSheet(`<h2>Sortieren</h2>
    ${Object.entries(SORT_MODES).map(([k, o]) => `<button class="opt sortopt" data-m="${k}" aria-pressed="${k === cur}"><span class="grow">${esc(o.label)}${o.sub ? `<small>${esc(o.sub)}</small>` : ''}</span><span class="sortchk" aria-hidden="true">${k === cur ? COOK_ICON.check : ''}</span></button>`).join('')}`, el => {
    $$('[data-m]', el).forEach(b => b.onclick = () => { setRecipeSort(b.dataset.m); closeSheet(); rerender(); });
  });
}
function vRecipes() {
  const kind = recipeFilter.kind;
  const all = liveRecipes().filter(r => EP.laneOf(r) === kind);
  const tags = [...new Set(all.flatMap(r => r.tags || []))].sort((a, b) => a.localeCompare(b, 'de'));
  // Favoriten oben – Reihenfolge erst beim nächsten Öffnen anpassen, damit ein angetippter Stern nicht wegspringt
  if (!favPinned) favPinned = new Set(all.filter(r => r.favorite).map(r => r.id));
  const mode = recipeSortMode(), stats = mode === 'name' || mode === 'new' || mode === 'quick' ? null : cookStats();
  const list = all.filter(recipeMatches).sort(recipeSorter(mode, stats));
  const pp = db.settings.portionsPerDay;
  const seg = (k, l) => `<button data-act="rstatus" data-arg="${k}" aria-pressed="${recipeFilter.status === k}">${l}</button>`;
  const ph = { MAIN: 'Rezeptname eingeben', LUNCH: 'z. B. Nudelsuppe', CAKE: 'z. B. Apfelkuchen', SIDE: 'z. B. Gurkensalat', SPECIAL: 'z. B. Rinderrouladen' }[kind];
  const rot = EP.ROTATES(kind);
  return `${laneSeg(kind, 'rkind', EP.KINDS)}
    <div class="quick" style="margin-top:12px"><input class="in" id="qa" placeholder="${ph}" enterkeyhint="done" autocomplete="off">
      <button class="btn primary" data-act="qa" aria-label="Rezept anlegen">+</button></div>
    <div class="impbtns"><button class="btn quiet small impbtn" data-act="rimport">Rezepte aus JSON importieren</button><button class="btn quiet small impbtn" data-act="rexport">Rezepte als JSON exportieren</button></div>
    ${all.length ? `<div class="rqrow"><input class="in" id="rq" placeholder="Suchen: Name, Tag, Zutat" value="${esc(recipeFilter.q)}">
      <button class="btn rsortbtn" data-act="rsort" aria-label="Sortierung: ${esc(SORT_MODES[mode].label)}">${ICON.sort}<span>${esc(SORT_MODES[mode].short)}</span></button></div>
    ${rot ? `<div class="seg" style="margin-top:10px">${seg('all', 'Alle')}${seg('active', 'In Rotation')}${seg('paused', 'Pausiert')}</div>` : ''}
    ${tags.length ? `<div class="chips">${tags.map(t => `<button class="chip" data-act="rtag" data-arg="${esc(t)}" aria-pressed="${recipeFilter.tag === t}">${esc(t)}</button>`).join('')}</div>` : ''}` : ''}
    <div class="rlist">${list.map(r => {
      const n = daysOf(r), ck = coverKey(r);
      return `<div class="rcard ${r.inRotation || !rot ? '' : 'paused'}">
        <div class="rtop"><button class="head" data-act="edit" data-arg="${r.id}">
          ${ck ? `<img class="thumb" data-img="${ck}" data-thumb="1" alt="">` : ''}
          <span class="grow"><span class="nm" style="display:block">${esc(r.name)}</span>
          <span class="meta" style="display:block">${kind === 'MAIN' ? `${r.servings} Portionen = ${daysLabel(n)}${r.daysOverride ? ' (fest)' : ''}` : `${r.servings} ${kind === 'CAKE' ? 'Stücke' : 'Portionen'}`}${r.ingredients.length ? `, ${r.ingredients.length} Zutaten` : ''}${EP.seasonLabel(r) ? `<br>Saison: ${EP.seasonLabel(r)}` : ''}${sortMeta(r, mode, stats)}</span></span>
        </button>${favBtn(r)}</div>
        ${rot ? `<div class="ctrl">
          <label><span class="switch"><input type="checkbox" data-rot="${r.id}" ${r.inRotation ? 'checked' : ''} aria-label="In Rotation"><i></i></span>${r.inRotation ? 'In Rotation' : 'Pausiert'}</label>
          <div class="wstep"><button data-act="w" data-arg="${r.id}|-1" aria-label="Seltener">−</button><output>×${r.weight}</output><button data-act="w" data-arg="${r.id}|1" aria-label="Häufiger">+</button></div>
        </div>` : ''}</div>`;
    }).join('') || (all.length ? '<p class="empty">Keine Treffer.</p>' : `<div class="empty"><p class="serif">${{ MAIN: 'Dein Fundus ist leer', LUNCH: 'Noch keine Mittagsgerichte', CAKE: 'Noch keine Kuchen', SIDE: 'Noch keine Beilagen', SPECIAL: 'Noch nichts Besonderes' }[kind]}</p>
      <p>${{ MAIN: 'Tipp oben einen Gerichtnamen ein – Portionen, Zutaten und Anleitung kannst du später ergänzen.', LUNCH: 'Kleine Gerichte fürs Wochenende mit eigener Rotation.', CAKE: 'Kuchen kommen zusätzlich zum Essen dazu und haben ihre eigene Rotation.', SIDE: 'Salate, Soßen, Brot … ohne Rotation – du fügst sie selbst zu einem Tag hinzu.', SPECIAL: 'Aufwendige Gerichte für Sonntage und Festtage – gesammelt, aber nie in der Rotation.' }[kind]}</p>
      <div class="btns">${kind === 'SIDE' || kind === 'SPECIAL' ? '' : kind === 'MAIN' ? (liveRecipes().some(r => EP.laneOf(r) === 'MAIN') ? '' : '<button class="btn" data-act="seed">Beispielrezepte laden</button>')
        : `<button class="btn" data-act="seedlane" data-arg="${kind}">${kind === 'LUNCH' ? '6 Mittagsgerichte als Vorschlag laden' : '7 Kuchen als Vorschlag laden'}</button>`}</div></div>`)}</div>
    ${all.length && rot ? `<p class="hint" style="text-align:center">${all.filter(r => r.inRotation).length} von ${all.length} in Rotation${kind === 'MAIN' ? `, ${pp} Portionen pro Tag` : ''}</p>` : ''}`;
}

/* Hinweis auf ähnliche vorhandene Rezepte vor dem Anlegen */
function similarSheet(name, sim) {
  openSheet(`<h2>Ähnliches Rezept vorhanden</h2>
    <p class="sub" style="margin-top:6px">„${esc(name)}“ ähnelt ${sim.length === 1 ? 'diesem Rezept' : 'diesen Rezepten'}:</p>
    ${sim.slice(0, 5).map(r => `<button class="opt tone-rim" data-id="${r.id}"><span class="oic">${ICON.osearch}</span><span class="grow">${esc(r.name)}<small>${DISH_LABEL[EP.laneOf(r)]} · öffnen</small></span></button>`).join('')}
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Trotzdem anlegen</button></div>`, el => {
    $$('[data-id]', el).forEach(b => b.onclick = () => { closeSheet(); $('#qa').value = ''; openEdit(b.dataset.id); });
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { closeSheet(); ACT.qa(true); };
  });
}

/* ---------- Rezept-Export (gleiches Format wie der Import) ---------- */
function exportSheet() {
  const lanes = EP.KINDS.map(k => [k.key, esc(LANE_LABEL[k.key])]);
  const all = liveRecipes().filter(r => !r.archivedAt);
  if (!all.length) return notify('Noch keine Rezepte vorhanden.');
  const cur = recipeFilter.kind;
  const groups = lanes.map(([k, l]) => {
    const rs = all.filter(r => EP.laneOf(r) === k).sort((a, b) => a.name.localeCompare(b.name, 'de'));
    if (!rs.length) return '';
    return `<h3 class="exph">${l} <button class="btn quiet small" data-x="grp" data-k="${k}">alle</button></h3>`
      + rs.map(r => `<label class="imphead"><input type="checkbox" data-exp="${r.id}" data-k="${k}" ${k === cur ? 'checked' : ''}><span class="nm">${esc(r.name)}</span></label>`).join('');
  }).join('');
  openSheet(`<h2>Rezepte exportieren</h2>
    
    <div class="btns two"><button class="btn" data-x="all">Alle wählen</button><button class="btn" data-x="none">Keine</button></div>
    <div class="explist">${groups}</div>
    <p class="hint" id="expn"></p>
    <div class="btns two"><button class="btn" data-x="copy">Text kopieren</button><button class="btn primary" data-x="file">Als Datei</button></div>`, el => {
    const boxes = () => [...el.querySelectorAll('[data-exp]')];
    const chosen = () => boxes().filter(b => b.checked).map(b => b.dataset.exp);
    const upd = () => { const n = chosen().length; $('#expn', el).textContent = n ? `${n} ${n === 1 ? 'Rezept' : 'Rezepte'} ausgewählt` : 'Nichts ausgewählt';
      el.querySelectorAll('[data-x=copy],[data-x=file]').forEach(b => b.disabled = !n); };
    el.addEventListener('change', upd);
    $('[data-x=all]', el).onclick = () => { boxes().forEach(b => b.checked = true); upd(); };
    $('[data-x=none]', el).onclick = () => { boxes().forEach(b => b.checked = false); upd(); };
    el.querySelectorAll('[data-x=grp]').forEach(g => g.onclick = () => {
      const bs = boxes().filter(b => b.dataset.k === g.dataset.k), on = !bs.every(b => b.checked);
      bs.forEach(b => b.checked = on); upd();
    });
    const text = () => JSON.stringify(EP.buildRecipeExport(db, chosen()), null, 1);
    $('[data-x=copy]', el).onclick = async () => {
      try { await navigator.clipboard.writeText(text()); notify('Rezepte kopiert.'); closeSheet(); }
      catch (e) { notify('Kopieren nicht erlaubt – bitte „Als Datei“ nutzen.'); }
    };
    $('[data-x=file]', el).onclick = () => {
      const n = chosen().length, blob = new Blob([text()], { type: 'application/json' });
      const name = `rezepte-${n}-${EP.todayISO()}.json`;
      const file = typeof File !== 'undefined' ? new File([blob], name, { type: 'application/json' }) : null;
      closeSheet();
      if (file && navigator.canShare && navigator.canShare({ files: [file] })) { navigator.share({ files: [file], title: 'Rezepte' }).catch(() => {}); return; }
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
    };
    upd();
  });
}

/* ---------- Rezept-Import (Antwort aus dem Scanner-Chat) ---------- */
/* Schnellweg am Handy: ein Tipp auf „Importieren“ liest direkt die Zwischenablage (iOS fragt einmal „Einsetzen“).
   Steht dort ein gültiger Rezeptblock, geht es sofort zur Vorschau – sonst öffnet sich das Eingabeblatt. */
async function quickImport() {
  const touch = typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches;
  if (!touch || !(navigator.clipboard && navigator.clipboard.readText)) return importSheet();
  let t = '';
  try { t = (await navigator.clipboard.readText()) || ''; } catch (e) { return importSheet(); }
  let recs = null;
  try { recs = t.trim() ? EP.parseRecipeImport(t) : null; } catch (e) { recs = null; }
  if (recs) return importPreview(recs, t);
  importSheet();
}
function importSheet(prefill) {
  const canRead = !!(navigator.clipboard && navigator.clipboard.readText);
  openSheet(`<h2>Rezepte importieren</h2>
    
    <textarea class="in" id="imp-t" placeholder="{ &quot;format&quot;: &quot;essensplanung-import&quot;, … }" autocapitalize="off" autocorrect="off" spellcheck="false" style="margin-top:12px;min-height:150px;font-size:16px">${esc(prefill || '')}</textarea>
    <p class="warn hidden" id="imp-err" role="alert" style="font-size:14px;margin-top:8px"></p>
    <div class="btns two">${canRead ? '<button class="btn" data-x="paste">Einfügen</button>' : ''}<button class="btn" data-x="file" ${canRead ? '' : 'style="grid-column:1/-1"'}>Datei wählen</button></div>
    <input type="file" id="imp-f" accept=".json,.txt,application/json,text/plain" class="hidden">
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Weiter</button></div>`, el => {
    const ta = $('#imp-t', el), err = $('#imp-err', el);
    const fail = m => { err.textContent = m; err.classList.remove('hidden'); };
    const tryPreview = t => { try { const recs = EP.parseRecipeImport(t); importPreview(recs, t); return true; } catch (e) { return false; } };
    const next = () => {
      const t = ta.value.trim();
      if (!t) return fail('Bitte zuerst die Antwort aus dem Chat einfügen.');
      let recs;
      try { recs = EP.parseRecipeImport(t); } catch (e) { return fail(e.message); }
      importPreview(recs, t);
    };
    ta.oninput = () => err.classList.add('hidden');
    // Lange tippen → „Einsetzen“: gültiger Block springt direkt zur Vorschau
    ta.addEventListener('paste', () => setTimeout(() => { const t = ta.value.trim(); if (t) tryPreview(t); }, 0));
    const p = $('[data-x=paste]', el);
    if (p) p.onclick = async () => {
      try { const t = await navigator.clipboard.readText(); if (!t) return fail('Die Zwischenablage ist leer.'); ta.value = t; err.classList.add('hidden'); next(); }
      catch (e) { fail('Kein Zugriff auf die Zwischenablage. Tippe lange ins Feld und wähle „Einsetzen“.'); }
    };
    $('[data-x=file]', el).onclick = () => $('#imp-f', el).click();
    $('#imp-f', el).onchange = async e => { const f = e.target.files[0]; if (!f) return; ta.value = await f.text(); e.target.value = ''; next(); };
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = next;
  });
}
function importPreview(recs, rawText) {
  const items = recs.map(rec => {
    const ex = findRecipeByName(rec.name);
    const dup = !!(ex && !ex.archivedAt);
    const sim = !ex ? EP.similarRecipes(db, rec.name, rec.kind)[0] || null : null;
    return { rec, kind: rec.kind, dup, sim, include: true, mode: dup ? 'skip' : ex ? 'replace' : 'new' };
  });
  const segBtn = (i, attr, val, cur, label) => `<button data-x="${attr}" data-i="${i}" data-v="${val}" aria-pressed="${cur === val}">${label}</button>`;
  const card = (it, i) => {
    const r = it.rec, newIngs = r.ingredients.filter(x => !findIngredient(x.name)).length;
    const steps = r.instructions ? r.instructions.split('\n').filter(l => l.trim()).length : 0;
    const meta = [`${r.servings} ${it.kind === 'CAKE' ? 'Stücke' : 'Portionen'}`, `${r.ingredients.length} Zutaten${newIngs ? ` (${newIngs} neu)` : ''}`,
      `${steps} ${steps === 1 ? 'Schritt' : 'Schritte'}`, r.prepTimeMinutes ? r.prepTimeMinutes + ' Min.' : ''].filter(Boolean).join(', ');
    return `<div class="rcard impcard" data-card="${i}">
      <label class="imphead"><input type="checkbox" data-inc="${i}" checked aria-label="${esc(r.name)} importieren"><span class="nm">${esc(r.name)}</span></label>
      <p class="meta">${meta}</p>
      <div class="seg lane-seg seg5" style="margin-top:10px">${EP.KINDS.map(l => segBtn(i, 'kind', l.key, it.kind, segLbl(LANE_LABEL[l.key]))).join('')}</div>
      ${it.dup ? `<p class="hint warn" style="margin-top:10px">„${esc(r.name)}“ gibt es schon.</p>
        <div class="seg" style="margin-top:6px">${segBtn(i, 'mode', 'skip', it.mode, 'Überspringen')}${segBtn(i, 'mode', 'replace', it.mode, 'Ersetzen')}${segBtn(i, 'mode', 'copy', it.mode, 'Als Kopie')}</div>
        <p class="hint" data-modehint="${i}"></p>` : ''}
      ${it.sim ? `<p class="hint warn" style="margin-top:10px">Ähnlich zu „${esc(it.sim.name)}“ – ist das dasselbe Rezept?</p>
        <div class="seg" style="margin-top:6px">${segBtn(i, 'mode', 'new', it.mode, 'Neu anlegen')}${segBtn(i, 'mode', 'replace', it.mode, 'Vorhandenes ersetzen')}${segBtn(i, 'mode', 'skip', it.mode, 'Überspringen')}</div>
        <p class="hint" data-modehint="${i}"></p>` : ''}
      ${r.warnings.length ? `<ul class="box warnbox" style="margin-top:10px">${r.warnings.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}
      <details class="impdetails"><summary>Zutaten und Anleitung ansehen</summary>
        <ul class="impings">${r.ingredients.map(x => `<li><b>${x.quantity == null ? '' : esc(EP.fmtNum(x.quantity) + ' ' + (x.unit ? EP.UNITS[x.unit][x.quantity > 1 && EP.UNITS[x.unit].p ? 'p' : 's'] : ''))}</b> ${esc(x.name)}${x.note ? `<small>, ${esc(x.note)}</small>` : ''}</li>`).join('') || '<li>Keine Zutaten</li>'}</ul>
        ${r.instructions ? `<div class="md">${renderMd(r.instructions).intro}<ol class="impsteps">${renderMd(r.instructions).steps.map(t => `<li>${t}</li>`).join('')}</ol></div>` : ''}
        ${r.notes ? `<p class="hint">${esc(r.notes)}</p>` : ''}
      </details>
    </div>`;
  };
  const MODE_HINT = { skip: 'Das vorhandene Rezept bleibt unverändert.', replace: 'Zutaten, Portionen und Anleitung werden ersetzt. Bilder, Gewichtung und Rotation bleiben.', copy: 'Wird mit Zusatz „(2)“ im Namen angelegt.' };
  openSheet(`<h2>${items.length === 1 ? '1 Rezept gefunden' : items.length + ' Rezepte gefunden'}</h2>
    
    ${items.map(card).join('')}
    <div class="btns two"><button class="btn" data-x="back">Zurück</button><button class="btn primary" data-x="yes"></button></div>`, el => {
    const count = () => items.filter(it => it.include && it.mode !== 'skip').length;
    const refresh = () => {
      const n = count(), b = $('[data-x=yes]', el);
      b.textContent = n ? (n === 1 ? '1 Rezept importieren' : n + ' Rezepte importieren') : 'Nichts ausgewählt';
      b.disabled = !n;
      items.forEach((it, i) => {
        const h = $(`[data-modehint="${i}"]`, el);
        if (h) h.textContent = it.sim ? { new: 'Wird als eigenes Rezept angelegt.', replace: `„${it.sim.name}“ bekommt Zutaten, Portionen und Anleitung aus dem Import. Name, Bilder und Rotation bleiben.`, skip: 'Wird nicht importiert.' }[it.mode] : MODE_HINT[it.mode];
        $(`[data-card="${i}"]`, el).classList.toggle('off', !it.include || it.mode === 'skip');
      });
    };
    $$('[data-inc]', el).forEach(c => c.onchange = () => {
      const it = items[+c.dataset.inc]; it.include = c.checked;
      if (c.checked && it.dup && it.mode === 'skip') { it.mode = 'copy'; $$(`[data-x=mode][data-i="${c.dataset.inc}"]`, el).forEach(b => b.setAttribute('aria-pressed', b.dataset.v === 'copy')); }
      refresh();
    });
    $$('[data-x=kind],[data-x=mode]', el).forEach(b => b.onclick = () => {
      const i = +b.dataset.i, key = b.dataset.x;
      items[i][key] = b.dataset.v;
      if (key === 'kind' && b.dataset.v === 'CAKE' && items[i].rec.servings <= 4) items[i].rec.servings = 12;
      $$(`[data-x=${key}][data-i="${i}"]`, el).forEach(x => x.setAttribute('aria-pressed', x === b));
      if (key === 'mode' && b.dataset.v !== 'skip') { items[i].include = true; $(`[data-inc="${i}"]`, el).checked = true; }
      if (key === 'kind') { const m = $(`[data-card="${i}"] .meta`, el); m.textContent = m.textContent.replace(/^\d+ (Stücke|Portionen)/, `${items[i].rec.servings} ${b.dataset.v === 'CAKE' ? 'Stücke' : 'Portionen'}`); }
      refresh();
    });
    $('[data-x=back]', el).onclick = () => importSheet(rawText);
    $('[data-x=yes]', el).onclick = () => {
      const chosen = items.filter(it => it.include && it.mode !== 'skip');
      if (!chosen.length) return;
      closeSheet();
      const res = importRecipes(chosen.map(it => it.sim && it.mode === 'replace' ? Object.assign({ targetId: it.sim.id }, it) : it));
      recipeFilter = Object.assign(recipeFilter, { kind: chosen[0].kind, q: '', tag: '', status: 'all' });
      const parts = [res.added ? `${res.added} importiert` : '', res.replaced ? `${res.replaced} ersetzt` : ''].filter(Boolean).join(', ');
      const msg = `${parts || 'Nichts geändert'}.${res.newIngredients ? ` ${res.newIngredients} neue Zutaten – Einkaufsorte unter ⚙ prüfen.` : ''}`;
      if (res.ids.length === 1) {   // ein einzelnes Rezept: gleich im Editor öffnen, um Werte und Notizen anzupassen
        persist().then(() => { openEdit(res.ids[0]); notify(msg + ' Du kannst es jetzt anpassen.'); });
      } else change(msg);
    };
    refresh();
  });
}

/* ---------- Rezept bearbeiten ---------- */
let editState = null;
function openEdit(id, kind) {
  const r = id ? recipeById(id) : newRecipe('', kind);
  editState = { isNew: !id, dirty: false, r: deep(r),
    rows: r.ingredients.slice().sort((a, b) => a.sortOrder - b.sortOrder).map(x => {
      const i = ingById(x.ingredientId);
      return { name: i ? i.name : '', qty: x.quantity == null ? '' : EP.fmtNum(x.quantity), unit: x.unit || '', note: x.note || '', cat: i ? i.category : 'SONSTIGES' };
    }) };
  go('edit');
}
function vEdit() {
  if (!editState) return '<p class="empty">Kein Rezept geöffnet.</p>';
  const r = editState.r, s = db.settings;
  const hint = EP.daysHint(r, s), kind = EP.laneOf(r), isMain = kind === 'MAIN' || kind === 'SPECIAL', rotates = EP.ROTATES(kind);
  const allYear = !r.seasonMonths || !r.seasonMonths.length || r.seasonMonths.length >= 12;
  const unitOpts = sel => `<option value="" ${!sel ? 'selected' : ''}>—</option>` + EP.UNIT_ORDER.map(u => `<option value="${u}" ${sel === u ? 'selected' : ''}>${EP.UNITS[u].s}</option>`).join('');
  const catOpts = sel => EP.CATEGORIES.map(c => `<option value="${c.key}" ${sel === c.key ? 'selected' : ''}>${c.label}</option>`).join('');
  const rows = editState.rows.map((x, i) => {
    const known = !x.name.trim() || !!findIngredient(x.name);
    return `<div class="ingrow" data-row="${i}">
      <div class="l1">
        <input class="in" data-f="qty" value="${esc(x.qty)}" inputmode="decimal" placeholder="Menge" aria-label="Menge">
        <select class="in" data-f="unit" aria-label="Einheit">${unitOpts(x.unit)}</select>
        <input class="in" data-f="name" value="${esc(x.name)}" list="inglist" placeholder="Zutat" aria-label="Zutat" autocomplete="off">
        <button class="x" data-act="rowdel" data-arg="${i}" aria-label="Zutat entfernen">✕</button>
      </div>
      <div class="l2">
        <input class="in" data-f="note" value="${esc(x.note)}" placeholder="Notiz, z. B. fein gewürfelt" aria-label="Notiz">
        <button class="x" data-act="rowup" data-arg="${i}" aria-label="Nach oben">▲</button>
        <button class="x" data-act="rowdown" data-arg="${i}" aria-label="Nach unten">▼</button>
      </div>
      <div class="newcat ${known ? 'hidden' : ''}">Neue Zutat – Kategorie: <select class="in" data-f="cat">${catOpts(x.cat)}</select></div>
    </div>`;
  }).join('');
  const imgs = (r.images || []).slice().sort((a, b) => a.sortOrder - b.sortOrder);
  return `<datalist id="inglist">${EP.live(db.ingredients).sort((a, b) => a.name.localeCompare(b.name, 'de')).map(i => `<option value="${esc(i.name)}">`).join('')}</datalist>
    <label class="field" style="margin-top:0"><span>Name</span><input class="in nameinput" id="e-name" value="${esc(r.name)}" maxlength="120" placeholder="z. B. Linsensuppe"></label>
    <div class="field"><div class="row"><span class="grow" style="margin:0;color:var(--ink);font-weight:600">Favorit</span>
      <label class="switch"><input type="checkbox" id="e-fav" ${r.favorite ? 'checked' : ''} aria-label="Favorit"><i></i></label></div></div>
    <div class="field"><span>Art</span>
      <div class="seg seg5">${EP.KINDS.map(l => `<button data-act="ekind" data-arg="${l.key}" aria-pressed="${kind === l.key}">${segLbl(DISH_LABEL[l.key])}</button>`).join('')}</div>
</div>
    ${kind === 'CAKE' ? `<div class="field"><span>Backform</span><button class="in panfield" data-act="epan">${r.pan ? esc(EP.panLabel(r.pan)) : 'Nicht angegeben – antippen'}</button>
</div>` : ''}
    <div class="field"><span>${kind === 'CAKE' ? 'Stücke' : 'Portionen pro Zubereitung'}</span>
      <div class="stepper"><button data-act="serv" data-arg="-1" aria-label="Weniger">−</button><output id="e-serv">${r.servings}</output><button data-act="serv" data-arg="1" aria-label="Mehr">+</button></div>
      ${isMain ? `<p class="live" id="e-live">${liveDaysText(r)}</p><p class="hint" id="e-hint">${esc(hint)}</p>` : ''}</div>
    ${isMain ? `<label class="field"><span>Tage fest vorgeben (optional)</span><input class="in" id="e-days" inputmode="numeric" value="${r.daysOverride || ''}" placeholder="leer = aus den Portionen berechnen"></label>` : ''}
    <div class="field"><div class="row"><span class="grow" style="margin:0;color:var(--ink);font-weight:600">Ganzjährig vorschlagen</span>
      <label class="switch"><input type="checkbox" id="e-allyear" ${allYear ? 'checked' : ''} aria-label="Ganzjährig vorschlagen"><i></i></label></div>
      ${allYear ? '' : `<p class="hint" style="margin:8px 0 6px">Nur in diesen Monaten vorschlagen:</p>
      <div class="months">${EP.MONTHS.map((m, i) => `<button class="chip" data-act="emonth" data-arg="${i + 1}" aria-pressed="${r.seasonMonths.includes(i + 1)}">${m}</button>`).join('')}</div>`}
    </div>
    ${!rotates ? '' : `<div class="field"><span>Wie oft pro Durchlauf</span>
      <div class="stepper"><button data-act="ew" data-arg="-1" aria-label="Seltener">−</button><output>×${r.weight}</output><button data-act="ew" data-arg="1" aria-label="Häufiger">+</button></div></div>
    <div class="field"><div class="row"><span class="grow" style="margin:0;color:var(--ink);font-weight:600">In Rotation</span>
      <label class="switch"><input type="checkbox" id="e-rot" ${r.inRotation ? 'checked' : ''} aria-label="In Rotation"><i></i></label></div></div>`}

    <h3>Zutaten</h3>
    ${rows}
    <button class="btn" data-act="rowadd" style="margin-top:10px">Zutat hinzufügen</button>

    <div class="inshead"><h3>Anleitung</h3><button class="btn quiet small" data-act="estepmode">${editState.insText ? 'Einzelne Schritte' : 'Als Text bearbeiten'}</button></div>
    ${editState.insText ? `<textarea class="in" id="e-ins" placeholder="Eine Zeile pro Schritt, z. B.&#10;1. Zwiebeln fein würfeln&#10;2. In Olivenöl anschwitzen">${esc(r.instructions)}</textarea>` : stepEditor()}
    <div class="row" style="gap:10px">
      <label class="field grow"><span>Zubereitungszeit (min)</span><input class="in" id="e-time" inputmode="numeric" value="${r.prepTimeMinutes || ''}"></label>
      <label class="field grow"><span>Tags</span><input class="in" id="e-tags" value="${esc((r.tags || []).join(', '))}" placeholder="vegetarisch, schnell"></label>
    </div>
    <label class="field"><span>Notizen</span><textarea class="in" id="e-notes" style="min-height:70px">${esc(r.notes)}</textarea></label>

    <h3>${kind === 'SIDE' ? 'Weitere Beilagen dazu' : 'Passende Beilagen'}</h3>

    <div class="chips sidelinks">${EP.linkedSides(db, r).map(s => `<button class="chip" data-act="esidedel" data-arg="${s.id}" aria-label="${esc(s.name)} nicht mehr verknüpfen">${esc(s.name)} <span aria-hidden="true">✕</span></button>`).join('')}
      <button class="chip addchip" data-act="esideadd">+ Beilage verknüpfen</button></div>
    ${(() => { const f = EP.linkedFrom(db, r); return f.length ? `<p class="hint">Passt zu: ${f.map(x => esc(x.name)).join(', ')}</p>` : ''; })()}

    <h3>Bilder</h3>
    <div class="gallery">${imgs.map(im => `<button data-act="img" data-arg="${im.fileKey}" aria-label="Bild bearbeiten"><img data-img="${im.fileKey}" data-thumb="1" alt="">${im.isCover ? '<span class="cover">Titelbild</span>' : ''}</button>`).join('')}
      <button class="add" data-act="imgadd" aria-label="Bild hinzufügen">+</button></div>
    <input type="file" id="e-file" accept="image/*" multiple class="hidden">

    <div class="btns">
      <button class="btn primary" data-act="save">Rezept speichern</button>
      ${editState.isNew ? '' : `<button class="btn" data-act="cook" data-arg="${r.id}">Kochansicht</button>
      <button class="btn danger" data-act="archive">Rezept löschen</button>`}
    </div>`;
}
/* Anleitung in einzelne Schritte zerlegen („1. …“-Zeilen; Folgezeilen gehören zum Schritt davor) und wieder zusammensetzen */
function splitSteps(text) {
  const intro = [], steps = [];
  const lines = String(text || '').split('\n').map(l => l.trim()).filter(Boolean);
  if (!lines.some(l => /^\d+[.)]\s+/.test(l))) return { intro: '', steps: lines };
  lines.forEach(l => { const m = l.match(/^\d+[.)]\s+(.*)$/); if (m) steps.push(m[1]); else if (steps.length) steps[steps.length - 1] += ' ' + l; else intro.push(l); });
  return { intro: intro.join('\n'), steps };
}
function joinSteps(intro, steps) {
  const st = (steps || []).map(t => String(t).replace(/\s*\n+\s*/g, ' ').trim()).filter(Boolean);
  return [String(intro || '').trim()].filter(Boolean).concat(st.map((t, i) => `${i + 1}. ${t}`)).join('\n');
}
function stepEditor() {
  if (!editState.steps) { const sp = splitSteps(editState.r.instructions); editState.steps = sp.steps.length ? sp.steps : ['']; editState.intro = sp.intro; }
  const st = editState.steps;
  return `${editState.intro ? `<label class="field"><span>Vorab</span><textarea class="in stepin" id="e-intro" rows="2">${esc(editState.intro)}</textarea></label>` : ''}
    <div id="e-steps" class="steplist">${st.map((t, i) => `<div class="stepedit">
      <div class="stephead"><span class="spill">Schritt ${i + 1}</span>
        <button class="stepbtn" data-act="estepmv" data-arg="${i}|-1" ${i ? '' : 'disabled'} aria-label="Schritt ${i + 1} nach oben">↑</button>
        <button class="stepbtn" data-act="estepmv" data-arg="${i}|1" ${i < st.length - 1 ? '' : 'disabled'} aria-label="Schritt ${i + 1} nach unten">↓</button>
        <button class="stepbtn del" data-act="estepdel" data-arg="${i}" aria-label="Schritt ${i + 1} löschen">✕</button></div>
      <textarea class="in stepin" data-step="${i}" rows="2" placeholder="${i ? '' : 'z. B. Zwiebeln fein würfeln'}">${esc(t)}</textarea></div>`).join('')}</div>
    <button class="btn" data-act="estepadd" style="margin-top:10px">Schritt hinzufügen</button>`;
}
function stepFocus(i) { setTimeout(() => { const t = $(`#e-steps [data-step="${i}"]`); if (t) { t.focus(); t.setSelectionRange(t.value.length, t.value.length); } }, 30); }
function growSteps() { $$('#main .stepin').forEach(t => { const g = () => { t.style.height = 'auto'; t.style.height = Math.max(64, t.scrollHeight + 2) + 'px'; }; g(); t.addEventListener('input', g); }); }
function liveDaysText(r) {
  return `= ${daysLabel(EP.daysFor(r, db.settings))} bei ${db.settings.portionsPerDay} Portionen/Tag${r.daysOverride ? ' (fest vorgegeben)' : ''}`;
}
function readEditForm() {
  const r = editState.r;
  const v = id => ($('#' + id) || {}).value;
  if ($('#e-name')) r.name = v('e-name');
  if ($('#e-days')) { const d = parseInt(v('e-days'), 10); r.daysOverride = d > 0 ? d : null; }
  if ($('#e-rot')) r.inRotation = $('#e-rot').checked;
  if ($('#e-fav')) r.favorite = $('#e-fav').checked;
  if ($('#e-ins')) r.instructions = v('e-ins') || '';
  else if ($('#e-steps')) {
    editState.steps = $$('#e-steps [data-step]').map(t => t.value);
    if ($('#e-intro')) editState.intro = v('e-intro');
    r.instructions = joinSteps(editState.intro, editState.steps);
  }
  const t = parseInt(v('e-time'), 10); r.prepTimeMinutes = t > 0 ? t : null;
  r.tags = (v('e-tags') || '').split(',').map(x => x.trim()).filter(Boolean);
  r.notes = v('e-notes') || '';
  $$('[data-row]').forEach(el => {
    const row = editState.rows[+el.dataset.row]; if (!row) return;
    $$('[data-f]', el).forEach(f => { row[f.dataset.f] = f.value; });
  });
}
function saveEdit() {
  readEditForm();
  const e = editState, r = e.r;
  r.name = r.name.trim();
  if (!r.name) return notify('Bitte einen Namen eingeben.');
  if (r.seasonMonths && (!r.seasonMonths.length || r.seasonMonths.length >= 12)) r.seasonMonths = null;
  if (EP.laneOf(r) !== 'MAIN' && EP.laneOf(r) !== 'SPECIAL') r.daysOverride = null;
  r.sides = (r.sides || []).filter(id => id !== r.id && recipeById(id));
  const dup = findRecipeByName(r.name);
  if (dup && dup.id !== r.id && !dup.archivedAt) return notify('Ein Rezept mit diesem Namen gibt es schon.');
  // Zutaten auflösen, unbekannte anlegen
  const ings = [];
  e.rows.forEach((x, k) => {
    if (!x.name.trim()) return;
    const qty = parseQty(x.qty);
    let ing = findIngredient(x.name);
    if (!ing) ing = createIngredient(x.name, x.cat || 'SONSTIGES', x.unit || 'STUECK');
    ings.push({ ingredientId: ing.id, quantity: qty, unit: qty == null ? null : (x.unit || ing.defaultUnit || 'STUECK'), note: x.note.trim(), sortOrder: k + 1 });
  });
  r.ingredients = ings;
  const old = recipeById(r.id);
  if (old) Object.assign(old, r); else db.recipes.push(r);
  const target = old || r;
  EP.touch(target);
  EP.syncRecipeIntoCycles(db, target, rng);
  editState = null;
  route = stack.pop() || { name: 'recipes' };
  change('Gespeichert.');
}

/* ---------- Kochansicht (Phase 3) ---------- */
/* Bildschirm wach halten: Wake-Lock-API, sonst (ältere iOS / Home-Bildschirm) ein stummes Endlos-Video */
let wakeLock = null, wakeVideo = null;
const WAKE_MP4 = 'data:video/mp4;base64,AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAapbW9vdgAAAGxtdmhkAAAAAAAAAAAAAAAAAAAD6AAAB9AAAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAuJ0cmFrAAAAXHRraGQAAAADAAAAAAAAAAAAAAABAAAAAAAAB9AAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAABAAAAAQAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAAfQAAAQAAABAAAAAAJabWRpYQAAACBtZGhkAAAAAAAAAAAAAAAAAAAoAAAAUABVxAAAAAAALWhkbHIAAAAAAAAAAHZpZGUAAAAAAAAAAAAAAABWaWRlb0hhbmRsZXIAAAACBW1pbmYAAAAUdm1oZAAAAAEAAAAAAAAAAAAAACRkaW5mAAAAHGRyZWYAAAAAAAAAAQAAAAx1cmwgAAAAAQAAAcVzdGJsAAAAwXN0c2QAAAAAAAAAAQAAALFhdmMxAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAABAAEABIAAAASAAAAAAAAAABFUxhdmM2MC4zMS4xMDIgbGlieDI2NAAAAAAAAAAAAAAAGP//AAAAN2F2Y0MBZAAK/+EAGWdkAAqscgRewEQAAAMABAAAAwAoPEiWEYABAAdo6EOBlLIs/fj4AAAAABBwYXNwAAAAAQAAAAEAAAAUYnRydAAAAAAAAAzkAAAM5AAAABhzdHRzAAAAAAAAAAEAAAAKAAAIAAAAABRzdHNzAAAAAAAAAAEAAAABAAAAOGN0dHMAAAAAAAAABQAAAAEAABAAAAAAAQAAUAAAAAABAAAgAAAAAAMAAAAAAAAABAAACAAAAAAoc3RzYwAAAAAAAAACAAAAAQAAAAIAAAABAAAAAgAAAAEAAAABAAAAPHN0c3oAAAAAAAAAAAAAAAoAAALEAAAADQAAAA0AAAANAAAADQAAAA0AAAANAAAADQAAAA0AAAANAAAANHN0Y28AAAAAAAAACQAABtkAAAm/AAAJ1AAACekAAAn6AAAKDwAACiAAAAo1AAAKRgAAAvF0cmFrAAAAXHRraGQAAAADAAAAAAAAAAAAAAACAAAAAAAAB9AAAAAAAAAAAAAAAAEBAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAAfQAAAEAAABAAAAAAJpbWRpYQAAACBtZGhkAAAAAAAAAAAAAAAAAAAfQAAAQoBVxAAAAAAALWhkbHIAAAAAAAAAAHNvdW4AAAAAAAAAAAAAAABTb3VuZEhhbmRsZXIAAAACFG1pbmYAAAAQc21oZAAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAAB2HN0YmwAAAB+c3RzZAAAAAAAAAABAAAAbm1wNGEAAAAAAAAAAQAAAAAAAAAAAAEAEAAAAAAfQAAAAAAANmVzZHMAAAAAA4CAgCUAAgAEgICAF0AVAAAAAAAfQAAAAT8FgICABRWIVuUABoCAgAECAAAAFGJ0cnQAAAAAAAAfQAAAAT8AAAAgc3R0cwAAAAAAAAACAAAAEAAABAAAAAABAAACgAAAAHBzdHNjAAAAAAAAAAgAAAABAAAAAQAAAAEAAAACAAAAAgAAAAEAAAAEAAAAAQAAAAEAAAAFAAAAAgAAAAEAAAAGAAAAAQAAAAEAAAAHAAAAAgAAAAEAAAAIAAAAAQAAAAEAAAAJAAAABQAAAAEAAABYc3RzegAAAAAAAAAAAAAAEQAAABUAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAANHN0Y28AAAAAAAAACQAACaoAAAnMAAAJ4QAACfYAAAoHAAAKHAAACi0AAApCAAAKUwAAABpzZ3BkAQAAAHJvbGwAAAACAAAAAf//AAAAHHNiZ3AAAAAAcm9sbAAAAAEAAAARAAAAAQAAAGJ1ZHRhAAAAWm1ldGEAAAAAAAAAIWhkbHIAAAAAAAAAAG1kaXJhcHBsAAAAAAAAAAAAAAAALWlsc3QAAAAlqXRvbwAAAB1kYXRhAAAAAQAAAABMYXZmNjAuMTYuMTAwAAAACGZyZWUAAAOWbWRhdAAAAq8GBf//q9xF6b3m2Ui3lizYINkj7u94MjY0IC0gY29yZSAxNjQgcjMxMDggMzFlMTlmOSAtIEguMjY0L01QRUctNCBBVkMgY29kZWMgLSBDb3B5bGVmdCAyMDAzLTIwMjMgLSBodHRwOi8vd3d3LnZpZGVvbGFuLm9yZy94MjY0Lmh0bWwgLSBvcHRpb25zOiBjYWJhYz0xIHJlZj0xNiBkZWJsb2NrPTE6MDowIGFuYWx5c2U9MHgzOjB4MTMzIG1lPXVtaCBzdWJtZT0xMCBwc3k9MSBwc3lfcmQ9MS4wMDowLjAwIG1peGVkX3JlZj0xIG1lX3JhbmdlPTI0IGNocm9tYV9tZT0xIHRyZWxsaXM9MiA4eDhkY3Q9MSBjcW09MCBkZWFkem9uZT0yMSwxMSBmYXN0X3Bza2lwPTEgY2hyb21hX3FwX29mZnNldD0tMiB0aHJlYWRzPTEgbG9va2FoZWFkX3RocmVhZHM9MSBzbGljZWRfdGhyZWFkcz0wIG5yPTAgZGVjaW1hdGU9MSBpbnRlcmxhY2VkPTAgYmx1cmF5X2NvbXBhdD0wIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz04IGJfcHlyYW1pZD0yIGJfYWRhcHQ9MiBiX2JpYXM9MCBkaXJlY3Q9MyB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTIga2V5aW50PTI1MCBrZXlpbnRfbWluPTUgc2NlbmVjdXQ9NDAgaW50cmFfcmVmcmVzaD0wIHJjX2xvb2thaGVhZD02MCByYz1jcmYgbWJ0cmVlPTEgY3JmPTUxLjAgcWNvbXA9MC42MCBxcG1pbj0wIHFwbWF4PTY5IHFwc3RlcD00IGlwX3JhdGlvPTEuNDAgYXE9MToxLjAwAIAAAAANZYiBAAJ//ES8CjvPgQAAAAlBmgktiH//04DeAgBMYXZjNjAuMzEuMTAyAAIwQA4AAAAJQZ4QhxBL/+yBARggBwEYIAcAAAAJAZ4YJoh//++AARggBwEYIAcAAAAJAZ4YRoh//++BARggBwAAAAkBnhhmiH//74EBGCAHARggBwAAAAkBnhitSH//74EBGCAHAAAACQGeGM1If//vgQEYIAcBGCAHAAAACQGeGO1If//vgAEYIAcAAAAJAZ4ZDUh//++AARggBwEYIAcBGCAHARggBwEYIAc=';
async function lockScreen() {
  try {
    if ('wakeLock' in navigator) {
      wakeLock = await navigator.wakeLock.request('screen');
      wakeLock.addEventListener && wakeLock.addEventListener('release', () => { wakeLock = null; });
      return;
    }
  } catch (e) { wakeLock = null; }
  try {
    if (!wakeVideo) {
      wakeVideo = document.createElement('video');
      wakeVideo.setAttribute('playsinline', ''); wakeVideo.setAttribute('muted', ''); wakeVideo.muted = true; wakeVideo.loop = true;
      wakeVideo.setAttribute('aria-hidden', 'true');
      wakeVideo.style.cssText = 'position:fixed;width:1px;height:1px;opacity:0.01;left:0;bottom:0;pointer-events:none';
      wakeVideo.src = WAKE_MP4;
      document.body.appendChild(wakeVideo);
    }
    const pr = wakeVideo.play(); if (pr && pr.catch) pr.catch(() => {});
  } catch (e) {}
}
function unlockScreen() {
  if (wakeLock) { wakeLock.release().catch(() => {}); wakeLock = null; }
  if (wakeVideo) { try { wakeVideo.pause(); } catch (e) {} }
}
const cookOpen = () => cookState && !$('#cookview').classList.contains('hidden');
document.addEventListener('visibilitychange', () => {   // iOS gibt die Sperre beim Wechsel der App frei
  if (document.visibilityState === 'visible') { if (cookOpen()) lockScreen(); Timers.tick(); }
});

/* ---------- Küchen-Timer (laufen weiter, auch wenn die Kochansicht zu ist) ---------- */
const Timers = {
  list: [], iv: null, ctx: null, el: null,
  /* Klingelton als WAV (drei Pieptöne). Ein <audio>-Element spielt auf dem iPhone auch bei
     Stummschalter, Web Audio dagegen nicht – deshalb beides, das Element zuerst. */
  wav() {
    const rate = 22050, n = Math.round(rate * 0.8), b = new DataView(new ArrayBuffer(44 + n * 2));
    const str = (o, t) => [...t].forEach((ch, i) => b.setUint8(o + i, ch.charCodeAt(0)));
    str(0, 'RIFF'); b.setUint32(4, 36 + n * 2, true); str(8, 'WAVEfmt '); b.setUint32(16, 16, true); b.setUint16(20, 1, true); b.setUint16(22, 1, true);
    b.setUint32(24, rate, true); b.setUint32(28, rate * 2, true); b.setUint16(32, 2, true); b.setUint16(34, 16, true); str(36, 'data'); b.setUint32(40, n * 2, true);
    for (let i = 0; i < n; i++) {
      const t = i / rate, k = t % 0.28, on = k < 0.22;
      const env = on ? Math.min(1, k / 0.01, (0.22 - k) / 0.03) : 0;
      b.setInt16(44 + i * 2, Math.round(Math.sin(2 * Math.PI * 880 * t) * env * 0.6 * 32767), true);
    }
    return URL.createObjectURL(new Blob([b], { type: 'audio/wav' }));
  },
  audio() {   // muss aus einem Tipp heraus entsperrt werden (iOS)
    try { if (navigator.audioSession) navigator.audioSession.type = 'playback'; } catch (e) {}   // Ton auch bei Stummschalter (Safari 17+)
    try {
      if (!this.el) { this.el = new Audio(this.wav()); this.el.preload = 'auto'; this.el.setAttribute('playsinline', ''); }
      if (!this._unlocked) {
        const a = this.el; a.muted = true;
        const p = a.play(); if (p && p.then) p.then(() => { a.pause(); a.currentTime = 0; a.muted = false; this._unlocked = true; }).catch(() => { a.muted = false; });
        else { a.muted = false; }
      }
    } catch (e) {}
    try {
      if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      if (this.ctx.state !== 'running') this.ctx.resume();
      const buf = this.ctx.createBuffer(1, 1, 22050), src = this.ctx.createBufferSource();   // stiller Ton entsperrt Web Audio
      src.buffer = buf; src.connect(this.ctx.destination); src.start(0);
    } catch (e) {}
  },
  beep() {
    try { navigator.vibrate && navigator.vibrate([200, 100, 200]); } catch (e) {}
    const a = this.el;
    if (a) {
      try { a.muted = false; a.currentTime = 0; const p = a.play(); if (p && p.catch) p.catch(() => this.webBeep()); return; } catch (e) {}
    }
    this.webBeep();
  },
  webBeep() {
    const c = this.ctx; if (!c) return;
    try { if (c.state !== 'running') c.resume(); } catch (e) {}
    try {
      [0, 0.28, 0.56].forEach(t => {
        const o = c.createOscillator(), g = c.createGain();
        o.frequency.value = 880; o.connect(g); g.connect(c.destination);
        const s = c.currentTime + t;
        g.gain.setValueAtTime(0.0001, s); g.gain.exponentialRampToValueAtTime(0.5, s + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, s + 0.22);
        o.start(s); o.stop(s + 0.24);
      });
    } catch (e) {}
  },
  /* Mitteilung vom Pi, falls die App im Hintergrund oder das Display aus ist */
  push(t) {
    if (typeof Push === 'undefined') return;
    const tag = 'timer-' + t.id;
    if (t.done || t.left != null) { Push.cancel(tag); return; }
    const r = recipeById(t.recipeId);
    Push.schedule(tag, t.end, 'timer', 'Timer abgelaufen', (r ? r.name + ' · ' : '') + 'Schritt ' + (t.step + 1) + (t.label ? ' · ' + String(t.label).split('|')[0] : ''), 'essensplanung.html');
  },
  start(recipeId, step, sec, label) {
    this.audio();
    if (this.list.some(t => t.recipeId === recipeId && t.step === step && t.sec === sec && !t.done)) return notify('Dieser Timer läuft schon.');
    const t = { id: EP.uuid(), recipeId, step, sec, label, end: Date.now() + sec * 1000, left: null, done: false, rang: 0 };
    this.list.push(t);
    this.run(); this.push(t);
  },
  toggle(id) {
    const t = this.list.find(x => x.id === id); if (!t || t.done) return;
    this.audio();
    if (t.left != null) { t.end = Date.now() + t.left; t.left = null; } else { t.left = t.end - Date.now(); }
    this.render(); this.push(t);
  },
  plus(id) { const t = this.list.find(x => x.id === id); if (!t) return; this.audio(); if (t.done) { t.done = false; t.rang = 0; t.end = Date.now(); } if (t.left != null) t.left += 60000; else t.end += 60000; this.run(); this.push(t); },
  stop(id) { const t = this.list.find(x => x.id === id); this.list = this.list.filter(x => x.id !== id); this.run(); if (t && !t.done && typeof Push !== 'undefined') Push.cancel('timer-' + t.id); },
  run() { if (!this.iv && this.list.length) this.iv = setInterval(() => this.tick(), 500); if (!this.list.length && this.iv) { clearInterval(this.iv); this.iv = null; } this.render(); },
  tick() {
    const now = Date.now();
    this.list.forEach(t => {
      if (t.left != null) return;
      if (!t.done && t.end <= now) { t.done = true; t.rang = 0; }
      if (t.done && t.rang < 15 && now - t.end >= t.rang * 4000) { t.rang++; this.beep(); }   // eine Minute lang alle 4 s
    });
    this.render();
  },
  render() {
    let bar = $('#timerbar');
    if (!bar) { bar = document.createElement('div'); bar.id = 'timerbar'; bar.className = 'timerbar'; bar.setAttribute('role', 'status'); document.body.appendChild(bar); }
    document.body.classList.toggle('has-timers', this.list.length > 0);
    document.body.classList.toggle('cooking', !!cookOpen());
    const now = Date.now();
    // nur bei geänderter Struktur neu aufbauen – sonst gehen Tipps verloren, während die Zeit läuft
    const sig = this.list.map(t => t.id + (t.done ? 'd' : '') + (t.left != null ? 'p' : '')).join();
    if (sig === this._sig && bar.childElementCount === this.list.length) {
      this.list.forEach((t, i) => { const tm = bar.children[i].querySelector('time'); const v = t.done ? 'Fertig!' : EP.fmtClock((t.left != null ? t.left : t.end - now) / 1000); if (tm.textContent !== v) tm.textContent = v; });
      return;
    }
    this._sig = sig;
    bar.innerHTML = this.list.map(t => {
      const r = recipeById(t.recipeId), rem = t.left != null ? t.left : t.end - now;
      return `<div class="tmr ${t.done ? 'ring' : ''} ${t.left != null ? 'paused' : ''}">
        <button class="tlbl" data-t="open" data-id="${t.id}"><time>${t.done ? 'Fertig!' : EP.fmtClock(rem / 1000)}</time><small>${esc((r ? r.name + ' · ' : '') + 'Schritt ' + (t.step + 1) + ' · ' + t.label)}</small></button>
        ${t.done ? '' : `<button data-t="toggle" data-id="${t.id}" aria-label="${t.left != null ? 'Weiter' : 'Pause'}">${t.left != null ? '▶' : '❚❚'}</button>`}
        <button data-t="plus" data-id="${t.id}" aria-label="Eine Minute mehr">+1</button>
        <button data-t="stop" data-id="${t.id}" aria-label="Timer beenden">✕</button></div>`;
    }).join('');
    $$('[data-t]', bar).forEach(b => b.onclick = e => {
      e.stopPropagation(); const id = b.dataset.id, t = this.list.find(x => x.id === id);
      if (b.dataset.t === 'open') { if (t && t.done) return this.stop(id); if (t && !cookOpen()) openCook(t.recipeId); return; }
      this[b.dataset.t](id);
    });
  },
};

/* „Heute“-Knopf in der Wochenansicht nur zeigen, wenn der heutige Tag aus dem Bild gescrollt ist */
function weekScroll() {
  const b = $('#todaybtn'); if (!b || route.name !== 'week') return;
  const t = $('.day.today'); let off = true;
  if (t) { const r = t.getBoundingClientRect(); off = r.bottom < 80 || r.top > window.innerHeight - 90; }
  b.classList.toggle('hidden', !off);
}
window.addEventListener('scroll', () => { if (route && route.name === 'week') weekScroll(); }, { passive: true });

/* ---------- Mitteilungen (Web-Push über den Pi) ---------- */
const Notes = {
  /* geteilter Haushalt als Konto-Ding – nur mit Pi-Abgleich */
  item() { return Sync.isPB && Auth.token ? { app: 'essen', id: Sync.repo.pb, secret: Auth.token } : null; },
  who() { return typeof Konto !== 'undefined' && Konto.loggedIn() ? Konto.user() : ''; },
  /* Einkaufsliste: mehrere Artikel kurz hintereinander → eine Mitteilung */
  extras: [], exTimer: null,
  extraAdded(t) {
    if (typeof Push === 'undefined' || !this.item()) return;
    this.extras.push(t); clearTimeout(this.exTimer);
    const wait = Math.min(Math.max(+(Push.prefs().einkaufWait) || 15, 5), 600);   // Einstellung im Hauptmenü → Mitteilungen
    this.exTimer = setTimeout(() => this.flushExtras(), wait * 1000);
  },
  flushExtras() {
    clearTimeout(this.exTimer); this.exTimer = null;
    const list = this.extras.splice(0), it = this.item(); if (!list.length || !it) return;
    const what = list.length === 1 ? `„${list[0]}“` : list.length <= 4 ? list.map(x => `„${x}“`).join(', ') : `${list.length} Artikel`, w = this.who();
    Push.notify(it, 'einkauf', 'Einkaufsliste', `${w ? w + ' hat ' : ''}${what} hinzugefügt`.replace(/^./, c => c.toUpperCase()), 'essensplanung.html');
  },
  /* Wochenplan übernommen */
  planCommitted(ws) {
    const it = this.item(); if (typeof Push === 'undefined' || !it) return;
    const days = EP.weekDays(ws), m = planByDate(db), names = [];
    days.forEach(d => { const p = m.get(d); const r = p && p.type === 'COOK' && (p.dayIndex || 1) === 1 && recipeById(p.recipeId); if (r) names.push(EP.weekday(d) + ' ' + r.name); });
    const w = this.who();
    Push.notify(it, 'plan', 'Wochenplan ab ' + EP.fmtShort(ws), (w ? w + ' hat geplant: ' : '') + (names.join(' · ') || 'Neue Woche geplant'), 'essensplanung.html');
  },
  /* Kocherinnerung: die nächsten 7 Tage zur eingestellten Uhrzeit auf diesem Gerät */
  remindText(d) {
    const parts = [], main = planByDate(db).get(d);
    const name = p => p && p.type === 'COOK' && (p.dayIndex || 1) === 1 && recipeById(p.recipeId) ? recipeById(p.recipeId).name : '';
    if (name(main)) parts.push(name(main));
    [['LUNCH', 'Mittag'], ['CAKE', 'Kuchen']].forEach(([l, lbl]) => { const n = name(laneAt(db, d, l)); if (n) parts.push(lbl + ': ' + n); });
    return parts.join(' · ');
  },
  remindPlan() {
    const out = {}; if (!db) return out;
    const p = Push.prefs(), [hh, mm] = String(p.remindTime || '16:30').split(':').map(Number), now = Date.now();
    for (let i = 0; i < 7; i++) {
      const d = EP.addDays(EP.todayISO(), i), txt = this.remindText(d); if (!txt) continue;
      const at = EP.parseISO(d); at.setHours(hh || 0, mm || 0, 0, 0);
      if (at.getTime() > now + 60000) out['remind-' + d] = { at: at.getTime(), txt };
    }
    return out;
  },
  rTimer: null,
  later() { clearTimeout(this.rTimer); this.rTimer = setTimeout(() => this.syncRemind(), 3000); },
  rRun: null, rAgain: false,
  syncRemind() {   // nie zwei Abgleiche gleichzeitig; Wünsche währenddessen werden danach nachgeholt
    if (this.rRun) { this.rAgain = true; return this.rRun; }
    this.rRun = this._syncRemind().catch(() => {}).finally(() => { this.rRun = null; if (this.rAgain) { this.rAgain = false; this.syncRemind(); } });
    return this.rRun;
  },
  async _syncRemind() {
    if (typeof Push === 'undefined') return;
    let old = {}; try { old = JSON.parse(localStorage.getItem('ep-remind') || '{}'); } catch (e) {}
    const want = Push.enabled() && Push.prefs().remind ? this.remindPlan() : {}, next = {};
    for (const tag of Object.keys(old)) {
      if (want[tag]) continue;
      if (old[tag].at > Date.now() && !(await Push.cancel(tag))) next[tag] = old[tag];   // später erneut versuchen
    }
    for (const [tag, v] of Object.entries(want)) {
      const o = old[tag];
      if (o && o.at === v.at && o.txt === v.txt) { next[tag] = o; continue; }
      if (await Push.schedule(tag, v.at, 'remind', 'Heute kochen', v.txt, 'essensplanung.html')) next[tag] = v;
    }
    try { localStorage.setItem('ep-remind', JSON.stringify(next)); } catch (e) {}
  },
};
if (typeof Push !== 'undefined') Push.onChange(() => { Notes.later(); if (route && route.name === 'settings') rerender(); });   // „An/Aus“ in den Einstellungen aktuell halten
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') Notes.later(); else if (Notes.exTimer) Notes.flushExtras(); });

/* Kochfortschritt (abgehakte Zutaten/Schritte, Portionen) 12 Stunden je Rezept merken */
const PROG_KEY = 'ep_cookprog';
function saveCookProgress() {
  if (!cookState) return;
  const all = LS.get(PROG_KEY) || {}, now = Date.now();
  Object.keys(all).forEach(k => { if (now - all[k].t > 12 * 3600e3) delete all[k]; });
  if (cookState.done.size || cookState.n !== (cookState.r.servings || 2) || cookState.pan) all[cookState.r.id] = { done: [...cookState.done], n: cookState.n, pan: cookState.pan || null, t: now };
  else delete all[cookState.r.id];
  LS.set(PROG_KEY, all);
}
function loadCookProgress(id) {
  const p = (LS.get(PROG_KEY) || {})[id];
  return p && Date.now() - p.t < 12 * 3600e3 ? p : null;
}
function renderMd(md) {
  const lines = String(md || '').split('\n');
  const steps = [], notes = [];
  lines.forEach(l => {
    const t = l.trim(); if (!t) return;
    const m = t.match(/^(\d+)[.)]\s+(.*)$/);
    if (m) steps.push(m[2]); else if (steps.length) steps[steps.length - 1] += ' ' + t; else notes.push(t);
  });
  const fmt = s => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  if (!steps.length) return { steps: notes.map(fmt), intro: '' };
  return { steps: steps.map(fmt), intro: notes.map(n => `<p>${fmt(n)}</p>`).join('') };
}
/* ---------- Backformen (Kuchen): Größe wählen, Mengen über die Fläche umrechnen ---------- */
const panShort = p => { p = EP.cleanPan(p); if (!p) return ''; const c = n => String(n).replace('.', ',');
  return p.shape === 'ROUND' ? `Ø ${c(p.d)} cm` : p.shape === 'RING' ? `Gugelhupf Ø ${c(p.d)}` : p.shape === 'LOAF' ? `Kasten ${c(p.l)} cm` : `${p.shape === 'TRAY' ? 'Blech ' : ''}${c(p.w)}×${c(p.l)} cm`; };
const fmtFactor = f => Math.abs(f - 1) < 0.005 ? 'wie im Rezept' : '×' + f.toFixed(2).replace('.', ',').replace(/0$/, '');
/* o = { title, sub, cur, orig, onPick(pan), reset: Text für „Originalform“ } */
function panSheet(o) {
  let shape = (o.cur && o.cur.shape) || (o.orig && o.orig.shape) || 'ROUND';
  const cur = EP.cleanPan(o.cur) || {};
  const dims = () => {
    const f = (id, lbl, v) => `<label class="field grow" style="margin:0"><span>${lbl}</span><input class="in" id="${id}" inputmode="decimal" value="${v ? String(v).replace('.', ',') : ''}" placeholder="cm"></label>`;
    return shape === 'ROUND' || shape === 'RING' ? f('p-d', 'Durchmesser (cm)', cur.shape === shape ? cur.d : '')
      : shape === 'LOAF' ? f('p-l', 'Länge (cm)', cur.shape === shape ? cur.l : '')
      : `<div class="row" style="gap:10px">${f('p-w', 'Breite (cm)', cur.shape === shape ? cur.w : '')}${f('p-l', 'Länge (cm)', cur.shape === shape ? cur.l : '')}</div>`;
  };
  openSheet(`<h2>${esc(o.title)}</h2>${o.sub ? `<p class="sub" style="margin-top:6px">${esc(o.sub)}</p>` : ''}
    <div class="panchips">${EP.PAN_PRESETS.map((p, i) => `<button class="chip panchip" data-pi="${i}" aria-pressed="${EP.samePan(p, o.cur)}">${esc(panShort(p))}${o.orig ? `<small>${fmtFactor(EP.panFactor(o.orig, p))}</small>` : ''}</button>`).join('')}</div>
    <h3 style="margin:18px 0 8px">Eigene Größe</h3>
    <label class="field" style="margin:0 0 10px"><span>Form</span><select class="in" id="p-shape">${EP.PAN_SHAPES.map(([k, l]) => `<option value="${k}" ${k === shape ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
    <div id="p-dims">${dims()}</div>
    <p class="hint" id="p-hint" style="min-height:1.4em"></p>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Übernehmen</button></div>
    ${o.reset ? `<div class="btns"><button class="btn quiet" data-x="reset">${esc(o.reset)}</button></div>` : ''}`, el => {
    const read = () => EP.cleanPan({ shape, d: ($('#p-d', el) || {}).value, w: ($('#p-w', el) || {}).value, l: ($('#p-l', el) || {}).value });
    const hint = () => { const p = read(); $('#p-hint', el).textContent = p ? EP.panLabel(p) + (o.orig ? ' · Zutaten ' + fmtFactor(EP.panFactor(o.orig, p)) : '') : ''; };
    const bindDims = () => $$('#p-dims input', el).forEach(i => { i.oninput = hint; i.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); $('[data-x=yes]', el).click(); } }; });
    $('#p-shape', el).onchange = e => { shape = e.target.value; $('#p-dims', el).innerHTML = dims(); bindDims(); hint(); };
    bindDims(); hint();
    $$('[data-pi]', el).forEach(b => b.onclick = () => { closeSheet(); o.onPick(EP.cleanPan(EP.PAN_PRESETS[+b.dataset.pi])); });
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { const p = read(); if (!p) { const i = $('#p-dims input', el); if (i) i.focus(); $('#p-hint', el).textContent = 'Bitte die Größe in cm eingeben.'; return; } closeSheet(); o.onPick(p); };
    const rs = $('[data-x=reset]', el); if (rs) rs.onclick = () => { closeSheet(); o.onPick(null); };
  });
}
/* Originalform eines Rezepts festlegen (nötig, bevor umgerechnet werden kann) */
function recipePanSheet(r, then) {
  panSheet({ title: 'Backform des Rezepts', sub: `Für welche Form sind die Mengen von „${r.name}“ gedacht? Danach kannst du auf jede andere Größe umrechnen.`, cur: r.pan,
    onPick: p => { r.pan = p; EP.touch(r); persist(); notify('Originalform: ' + EP.panLabel(p)); if (then) then(p); } });
}
/* Backform für einen geplanten Kuchen (Mengen und Einkaufsliste passen sich an) */
function planPanSheet(shown, r) {
  const x = EP.live(db.plan).find(p => p.id === shown.id) || shown;   // Anzeige-Kopie → gespeicherter Planeintrag
  const go2 = () => panSheet({ title: 'Backform für diesen Kuchen', sub: `Rezept: ${EP.panLabel(r.pan)}. Die Zutaten und die Einkaufsliste werden umgerechnet.`,
    cur: x.pan || r.pan, orig: r.pan, reset: `Originalform (${EP.panLabel(r.pan)})`,
    onPick: p => { x.pan = p && !EP.samePan(p, r.pan) ? p : null; EP.touch(x); change(x.pan ? `Backform: ${EP.panLabel(x.pan)} (Zutaten ${fmtFactor(EP.panFactor(r.pan, x.pan))})` : 'Originalform des Rezepts'); } });
  if (!r.pan) recipePanSheet(r, () => go2()); else go2();
}

/* ---------- Kochansicht (Karten wie in Rezept-Apps: Kopf, Zutaten mit Portionen-Umschalter, Schritte zum Abhaken) ---------- */
let cookState = null;
const COOK_ICON = {
  time: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  people: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5"/><circle cx="17" cy="9" r="2.5"/><path d="M15.5 14.2c2.4.2 4.2 1.8 4.7 4.8"/></svg>',
  leaf: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 19c0-8 5-13 14-14-1 9-6 14-14 14z"/><path d="M5 19l7-7"/></svg>',
  basket: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 10h16l-1.6 8.2a2 2 0 0 1-2 1.8H7.6a2 2 0 0 1-2-1.8z"/><path d="M8 10l3-5M16 10l-3-5"/></svg>',
  knife: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21l9.5-9.5"/><path d="M12.5 11.5 19 5a2.1 2.1 0 0 1 3 3l-6.5 6.5c-1 1-2.6 1-3.6 0l-.4-.4c-1-1-1-2.6 0-3.6z"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
};
/* Menge für n Portionen, sinnvoll gerundet; bei der Originalportion unverändert */
function cookAmount(x, factor) {
  if (x.quantity == null) return 'nach Geschmack';
  let q = x.quantity * factor;
  if (factor !== 1) {
    const dim = EP.dimOf(x.unit);
    if (dim === 'MASS' || dim === 'VOLUME') {
      const base = q * ((EP.UNITS[x.unit] && EP.UNITS[x.unit].f) || 1);
      const r = base >= 100 ? 5 : base >= 10 ? 1 : 0.1;
      q = Math.round(base / r) * r / ((EP.UNITS[x.unit] && EP.UNITS[x.unit].f) || 1);
    } else q = Math.max(0.25, Math.round(q * 4) / 4);
  }
  return EP.sumAmounts([{ quantity: q, unit: x.unit }]).text
    .replace(/(\d+),5\b/g, (m, d) => (d === '0' ? '' : d) + '½').replace(/(\d+),25\b/g, (m, d) => (d === '0' ? '' : d) + '¼').replace(/(\d+),75\b/g, (m, d) => (d === '0' ? '' : d) + '¾');
}
function cookIngredients() {
  const r = cookState.r;
  const list = r.ingredients.slice().sort((a, b) => a.sortOrder - b.sortOrder).map(x => {
    const i = ingById(x.ingredientId);
    return { x, name: i ? i.name : '', spice: !!(i && i.category === 'GEWUERZE'), key: (i ? i.name : '').split(/[(,/]/)[0].trim().toLowerCase() };
  }).filter(o => o.name);
  return list.filter(o => !o.spice).concat(list.filter(o => o.spice));   // Gewürze immer zuletzt
}
const isCake = r => EP.laneOf(r) === 'CAKE' || r.kind === 'CAKE';
function cookFactor() {
  const r = cookState.r;
  if (isCake(r) && r.pan && cookState.pan) return EP.panFactor(r.pan, cookState.pan);
  return cookState.n / (r.servings || cookState.n || 1);
}
function cookIngRows() {
  const f = cookFactor();
  return cookIngredients().map((o, k) => `<li data-ci="${k}" class="${cookState.done.has('i' + k) ? 'done' : ''}"><span class="q">${esc(cookAmount(o.x, f))}</span>
    <span class="nm">${esc(o.name)}${o.x.note ? `<small>${esc(o.x.note)}</small>` : ''}</span></li>`).join('');
}
const cookStem = w => w.replace(/(en|n|e|s)$/, '');
const cookSame = (w, k) => w === k || w === k + 'n' || w === k + 'en' || w === k + 'e' || w === k + 's' || w === k + 'er';
/* Passt das Wort w (klein) zur Zutat key? Ganze Wörter, Mehrzahl (Tomate → Tomaten), Wortenden (Reis → Milchreis)
   und Wortanfänge (Knoblauch → Knoblauchzehen), aber nicht Milch in „Milchreis“, wenn Milchreis selbst Zutat ist */
function wordMatches(w, key, others) {
  const taken = (others || []).some(o => o !== key && o.split(/\s+/).some(k => cookSame(w, k)));
  return key.split(/\s+/).filter(k => k.length >= 3).some(k =>
    cookSame(w, k) || (w.length >= 4 && k.endsWith(w)) || (cookStem(w).length >= 4 && k.endsWith(cookStem(w))) ||
    (k.length >= 4 && w.startsWith(k) && !taken));
}
const cookWords = text => text.replace(/<[^>]+>/g, ' ').toLowerCase().split(/[^a-zäöüß]+/).filter(Boolean);
function mentions(text, key, others) { return cookWords(text).some(w => wordMatches(w, key, others)); }
/* Position der ersten Erwähnung im Text (für die Reihenfolge innerhalb eines Schritts) */
function mentionPos(text, key, others) { const i = cookWords(text).findIndex(w => wordMatches(w, key, others)); return i < 0 ? 1e9 : i; }
/* In welchem Schritt wird welche Zutat zum ersten Mal gebraucht? (-1 = nie erwähnt) */
function cookPlan(steps) {
  const all = cookIngredients(), keys = all.map(o => o.key);
  const first = all.map(o => o.key ? steps.findIndex(t => mentions(t, o.key, keys)) : -1);
  return { all, keys, first };
}
/* Hebt im Schritttext die erste Stelle jeder hier neu gebrauchten Zutat hervor */
function markFirstUse(html, ings, keys) {
  const open = new Set(ings.map(o => o.key));
  return html.split(/(<[^>]+>)/).map(part => part.startsWith('<') ? part : part.replace(/[A-Za-zÄÖÜäöüß]+/g, w => {
    const hit = [...open].find(k => wordMatches(w.toLowerCase(), k, keys));
    if (!hit) return w;
    open.delete(hit);
    return `<mark class="ning">${w}</mark>`;
  })).join('');
}
/* Vorbereiten: je Zutat, was zu tun ist (aus der Zutat-Notiz und den Satzteilen der Anleitung) */
const PREP_SKIP = new Set(['GEWUERZE', 'OELE_ESSIG', 'GETRAENKE']);
function cookPrepItems(steps) {
  const all = cookIngredients(), keys = all.map(o => o.key);
  const cuttable = all.filter(o => { const ing = ingById(o.x.ingredientId); return o.key && !o.spice && ing && !PREP_SKIP.has(ing.category); });
  const found = new Map();
  steps.forEach(t => EP.prepAssign(t, c => cuttable.filter(o => mentions(c, o.key, keys)).map(o => o.key))
    .forEach((ph, k) => found.set(k, [...new Set((found.get(k) || []).concat(ph))])));
  return all.map((o, idx) => {
    const skip = !cuttable.includes(o);
    const fromNote = o.x.note ? EP.prepPhrases(o.x.note) : [];
    const fromSteps = skip ? [] : found.get(o.key) || [];
    let tasks = [...new Set(fromNote.concat(fromSteps))];
    if (!tasks.length && o.x.note && !skip) tasks = [o.x.note];
    const first = o.key ? steps.findIndex(t => mentions(t, o.key, keys)) : -1;
    return { o, idx, tasks, first };
  });
}
function prepCard(md, f) {
  const items = cookPrepItems(md.steps);
  const order = (a, b) => (a.first < 0 ? 1e9 : a.first) - (b.first < 0 ? 1e9 : b.first);
  const work = items.filter(x => x.tasks.length).sort(order);
  const rest = items.filter(x => !x.tasks.length && !x.o.spice).sort(order), spices = items.filter(x => !x.tasks.length && x.o.spice);
  const row = (x, big) => `<li data-ci="${x.idx}" class="${big ? 'pwork' : ''}${cookState.done.has('i' + x.idx) ? ' done' : ''}">
    <span class="pchk" aria-hidden="true">${COOK_ICON.check}</span>
    <span class="pbody"><span class="nm"><b>${esc(cookAmount(x.o.x, f))}</b> ${esc(x.o.name)}</span>
    ${big ? `<span class="ptasks">${x.tasks.map(t => `<span>${esc(t)}</span>`).join('')}</span>${x.first >= 0 ? `<small>Schritt ${x.first + 1}</small>` : ''}` : ''}</span></li>`;
  const open = work.filter(x => !cookState.done.has('i' + x.idx)).length;
  return `<section class="ccard prepcard"><h2>Vorbereiten</h2>
    ${work.length ? `<p class="pcount" id="prep-n">${open ? `Noch ${open} von ${work.length}` : 'Alles vorbereitet'}</p><ul class="prep">${work.map(x => row(x, true)).join('')}</ul>`
      : '<p class="pcount">In der Anleitung steht nichts zum Schneiden.</p>'}
    ${rest.length ? `<h3>Bereitstellen</h3><ul class="prep small">${rest.map(x => row(x, false)).join('')}</ul>` : ''}
    ${spices.length ? `<h3>Gewürze</h3><ul class="prep small">${spices.map(x => row(x, false)).join('')}</ul>` : ''}
    <div class="btns"><button class="btn primary" data-act="cookprep">Fertig – zur Anleitung</button></div></section>`;
}
const ingLine = (o, f) => `<li class="${o.spice ? 'spice' : ''}">${esc(cookAmount(o.x, f))} ${esc(o.name)}</li>`;
function openCook(id) {
  const r = recipeById(id); if (!r) return;
  const prog = loadCookProgress(id);
  // Backform: gespeicherter Kochstand, sonst der nächste geplante Termin dieses Kuchens
  const planned = EP.live(db.plan).filter(p => p.recipeId === id && p.pan && p.date >= EP.todayISO()).sort((a, b) => a.date.localeCompare(b.date))[0];
  // Gäste: nächster geplanter Kochtag dieses Gerichts mit abweichender Personenzahl
  const g = EP.live(db.plan).filter(p => p.recipeId === id && p.type === 'COOK' && (p.guests || p.portions) && p.date >= EP.todayISO()).sort((a, b) => a.date.localeCompare(b.date))[0];
  const gn = g ? Math.round((r.servings || 2) * EP.guestFactor(g, r, db.settings)) : null;
  cookState = { prep: false, r, n: prog ? prog.n : (gn || r.servings || 2), done: new Set(prog ? prog.done : []), pan: prog && prog.pan !== undefined ? prog.pan : (planned ? planned.pan : null) };
  const el = $('#cookview');
  el.classList.remove('hidden');
  renderCook();
  lockScreen();
  Timers.render();
  const cur = $('#cookview li.cur');   // weitermachen, wo man aufgehört hat
  if (prog && cur) cur.scrollIntoView({ block: 'center' });
}
function renderCook() {
  const r = cookState.r, el = $('#cookview');
  const ck = coverKey(r), md = renderMd(r.instructions), ings = cookIngredients();
  const unit = EP.laneOf(r) === 'CAKE' ? 'Stücke' : 'Portionen';
  const meta = [
    r.prepTimeMinutes ? `<span>${COOK_ICON.time}${r.prepTimeMinutes} min</span>` : '',
    `<span>${COOK_ICON.people}${r.servings} ${unit}</span>`,
    EP.seasonLabel(r) ? `<span>${COOK_ICON.leaf}${esc(EP.seasonLabel(r))}</span>` : '',
  ].filter(Boolean).join('');
  const empty = !ings.length && !md.steps.length && !String(r.instructions || '').trim();
  const prep = cookState.prep && ings.length;
  el.innerHTML = `<div class="inner${ings.length && md.steps.length && !prep ? ' two' : ''}${prep ? ' preping' : ''}">
    <div class="cooktop"><button class="cookx" data-act="closecook" aria-label="Schließen"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button></div>
    ${ck ? `<img class="hero" data-img="${ck}" data-thumb="0" alt="">` : ''}
    <section class="ccard chead"><h1>${esc(r.name)}</h1>
      <div class="cmeta">${meta}</div>
      ${(r.tags || []).length ? `<div class="ctags">${r.tags.map(t => `<span>${esc(t)}</span>`).join('')}</div>` : ''}
      ${(() => { const a = EP.linkedSides(db, r), b = EP.linkedFrom(db, r).filter(x => !a.some(y => y.id === x.id));
        return a.length || b.length ? `<div class="csides">${a.length ? `<span>Dazu:</span>${a.map(s => `<button class="chip small" data-act="cookside" data-arg="${s.id}">${esc(s.name)} ›</button>`).join('')}` : ''}
          ${b.length ? `<span>Passt zu:</span>${b.map(s => `<button class="chip small" data-act="cookside" data-arg="${s.id}">${esc(s.name)} ›</button>`).join('')}` : ''}</div>` : ''; })()}
      ${ings.length ? `<button class="btn prepbtn${prep ? ' on' : ''}" data-act="cookprep" aria-pressed="${!!prep}">${COOK_ICON.knife}${prep ? 'Zurück zur Anleitung' : 'Vorbereiten'}</button>` : ''}</section>
    ${prep ? `${isCake(r) && r.pan ? '' : `<div class="cstep prepstep" role="group" aria-label="${unit}"><button data-act="cookpp" data-arg="-1" aria-label="Weniger ${unit}">−</button><output id="cook-n">${cookState.n} ${unit}</output><button data-act="cookpp" data-arg="1" aria-label="Mehr ${unit}">+</button></div>`}${prepCard(md, cookFactor())}` : ''}
    ${ings.length && !prep ? `<section class="ccard cingcard"><h2>Zutaten</h2>
      ${isCake(r) ? `<button class="panbtn" data-act="cookpan">${r.pan ? `<span>Backform</span><b>${esc(EP.panLabel(cookState.pan || r.pan))} ▾</b>${cookState.pan ? `<small>Zutaten ${fmtFactor(cookFactor())} · ca. ${Math.max(1, Math.round((r.servings || 12) * cookFactor()))} Stücke</small>` : ''}` : '<span>Backform</span><b>Größe angeben ▾</b><small>dann auf andere Formen umrechnen</small>'}</button>` : ''}
      ${isCake(r) && r.pan ? '' : `<div class="cstep" role="group" aria-label="${unit}"><button data-act="cookpp" data-arg="-1" aria-label="Weniger ${unit}">−</button><output id="cook-n">${cookState.n} ${unit}</output><button data-act="cookpp" data-arg="1" aria-label="Mehr ${unit}">+</button></div>`}
      <ul class="cing" id="cook-ing">${cookIngRows()}</ul></section>` : ''}
    ${md.steps.length && !prep ? (() => {
      const plan = cookPlan(md.steps), f = cookFactor();
      const unused = plan.all.filter((o, k) => plan.first[k] < 0);
      const prep = unused.filter(o => !o.spice), spices = unused.filter(o => o.spice);
      return `<section class="ccard cstepcard"><h2>Zubereitung</h2>${md.intro ? `<div class="md cintro">${md.intro}</div>` : ''}
      ${prep.length ? `<div class="cextra" id="cook-prep"><b>Außerdem bereitlegen</b><ul>${prep.map(o => ingLine(o, f)).join('')}</ul></div>` : ''}
      <ol class="steps-big">${md.steps.map((t, k) => {
        const here = plan.all.filter((o, j) => plan.first[j] === k)
          .sort((a, b) => (a.spice - b.spice) || (mentionPos(t, a.key, plan.keys) - mentionPos(t, b.key, plan.keys)));
        const tms = EP.parseTimers(t);
        return `<li data-cs="${k}" class="${cookState.done.has('s' + k) ? 'done' : ''}"><div class="shead"><span class="spill">Schritt ${k + 1}</span><span class="scheck" aria-hidden="true">${COOK_ICON.check}</span></div>
          ${here.length ? `<div class="sing">${COOK_ICON.basket}<ul>${here.map(o => ingLine(o, f)).join('')}</ul></div>` : ''}<div class="stxt">${markFirstUse(t, here, plan.keys)}</div>
          ${tms.length ? `<div class="tchips">${tms.map(o => `<button class="tchip" data-tm="${k}|${o.sec}|${esc(o.label)}">${COOK_ICON.time}Timer ${esc(o.label)}</button>`).join('')}</div>` : ''}</li>`;
      }).join('')}</ol>
      ${spices.length ? `<div class="cextra spices" id="cook-spices"><b>Zum Würzen und Abschmecken</b><ul>${spices.map(o => ingLine(o, f)).join('')}</ul></div>` : ''}</section>`;
    })() : ''}
    ${r.notes && !prep ? `<section class="ccard cnotecard"><h2>Notizen</h2><p class="cnotes">${esc(r.notes)}</p></section>` : ''}
    ${empty ? `<section class="ccard"><p style="font-size:18px;margin:0 0 12px">Für dieses Gericht sind noch keine Zutaten und keine Anleitung hinterlegt.</p>
      <button class="btn primary" data-act="cookedit" data-arg="${r.id}">Rezept ergänzen</button></section>` : ''}
    ${cookState.done.size && !prep ? '<div class="btns"><button class="btn quiet" data-act="cookreset">Abhaken zurücksetzen</button></div>' : ''}
</div>`;
  bindCook();
  Images.hydrate(el);
}
/* aktueller Schritt = erster nicht abgehakter */
function markCurrentStep() {
  const lis = $$('#cookview [data-cs]');
  const cur = lis.find(li => !li.classList.contains('done'));
  lis.forEach(li => li.classList.toggle('cur', li === cur && lis.some(x => x.classList.contains('done'))));
  return cur;
}
/* Durchstreichen sicher an- und ausschalten: Safari (iOS) zeichnet geerbtes text-decoration nach dem Entfernen
   einer Klasse am Elternelement manchmal nicht neu – deshalb zusätzlich direkt an den Textelementen setzen. */
function strikeRow(item, on, cls) {
  if (!item) return;
  item.classList.toggle(cls || 'checked', on);
  item.querySelectorAll('.nm, .amt, .xname, .stxt, .sing').forEach(e => {
    e.style.textDecorationLine = on ? 'line-through' : 'none';
    if (!on) e.style.color = ''; void e.offsetWidth;   // Neuzeichnen erzwingen
  });
}
function bindCook() {
  const el = $('#cookview');
  const flip = (li, k) => { const on = !cookState.done.has(k); on ? cookState.done.add(k) : cookState.done.delete(k); strikeRow(li, on, 'done'); saveCookProgress(); };
  $$('[data-ci]', el).forEach(li => li.onclick = () => { flip(li, 'i' + li.dataset.ci); if (cookState.prep) prepCount(); });
  $$('[data-cs]', el).forEach(li => li.onclick = () => {
    flip(li, 's' + li.dataset.cs);
    const cur = markCurrentStep();
    if (li.classList.contains('done') && cur) {   // nächsten Schritt ins Bild holen, falls er unten herausragt
      const b = cur.getBoundingClientRect();
      if (b.top > window.innerHeight * 0.6) cur.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  });
  $$('[data-tm]', el).forEach(b => b.onclick = e => {
    e.stopPropagation();
    const [k, sec, ...lbl] = b.dataset.tm.split('|');
    Timers.start(cookState.r.id, +k, +sec, lbl.join('|'));
  });
  markCurrentStep();
}
function prepCount() {
  const n = $('#prep-n'); if (!n) return;
  const all = $$('#cookview .prep li.pwork'), open = all.filter(li => !li.classList.contains('done')).length;
  n.textContent = open ? `Noch ${open} von ${all.length}` : 'Alles vorbereitet';
}
function cookPrepToggle() {
  if (!cookState) return;
  cookState.prep = !cookState.prep;
  renderCook();
  $('#cookview').scrollTop = 0;
}
function cookPortions(d) {
  if (!cookState) return;
  cookState.n = Math.max(1, Math.min(99, cookState.n + d));
  saveCookProgress();
  const el = $('#cookview'), y = el.scrollTop;
  renderCook();       // Abhak-Zustand bleibt in cookState.done
  el.scrollTop = y;
}
function cookPan() {
  if (!cookState) return;
  const r = cookState.r, redraw = () => { const el = $('#cookview'), y = el.scrollTop; renderCook(); el.scrollTop = y; };
  if (!r.pan) return recipePanSheet(r, () => { cookState.pan = null; saveCookProgress(); redraw(); });
  panSheet({ title: 'Backform', sub: `Rezept: ${EP.panLabel(r.pan)}. Die Mengen werden über die Fläche umgerechnet.`, cur: cookState.pan || r.pan, orig: r.pan,
    reset: `Originalform (${EP.panLabel(r.pan)})`,
    onPick: p => { cookState.pan = p && !EP.samePan(p, r.pan) ? p : null; saveCookProgress(); redraw(); } });
}
function closeCook() {
  $('#cookview').classList.add('hidden');
  unlockScreen();
  Timers.render();
}

/* ---------- Zutaten (Stammdaten) ---------- */
let ingQuery = '';
function vIngredients() {
  const all = EP.live(db.ingredients).filter(i => !ingQuery || i.name.toLowerCase().includes(ingQuery.toLowerCase()));
  const srcLabel = { MARKT: 'Markt', SUPERMARKT: 'Supermarkt', DROGERIE: 'Drogerie', VORRAT: 'Vorrat' };
  return `<input class="in" id="iq" placeholder="Zutat suchen" value="${esc(ingQuery)}">
    <button class="btn" data-act="ingnew" style="margin-top:10px">Neue Zutat</button>
    ${EP.CATEGORIES.map(c => {
      const items = all.filter(i => i.category === c.key).sort((a, b) => a.name.localeCompare(b.name, 'de'));
      if (!items.length) return '';
      return `<h3>${esc(c.label)}</h3><div class="box">${items.map(i => `<button class="item" data-act="ing" data-arg="${i.id}">
        <span class="nm">${esc(i.name)}</span><span class="amt">${EP.neverShop(i) ? 'Nie kaufen' : srcLabel[EP.sourceOf(i, db.settings)] + (i.shoppingSource ? ' (angepasst)' : '')}</span></button>`).join('')}</div>`;
    }).join('') || '<p class="empty">Noch keine Zutaten. Sie entstehen automatisch, wenn du sie in einem Rezept einträgst.</p>'}`;
}
function ingredientSheet(id) {
  const i = id ? ingById(id) : { name: '', category: 'GEMUESE', shoppingSource: null, defaultUnit: 'STUECK' };
  const used = id ? ingredientUsage(id) : 0;
  const others = EP.live(db.ingredients).filter(x => x.id !== id).sort((a, b) => a.name.localeCompare(b.name, 'de'));
  openSheet(`<h2>${id ? 'Zutat bearbeiten' : 'Neue Zutat'}</h2>
    <label class="field"><span>Name (Einzahl)</span><input class="in" id="in-n" value="${esc(i.name)}"></label>
    <label class="field"><span>Kategorie</span><select class="in" id="in-c">${EP.CATEGORIES.map(c => `<option value="${c.key}" ${c.key === i.category ? 'selected' : ''}>${c.label}</option>`).join('')}</select></label>
    <label class="field"><span>Einkaufsort</span><select class="in" id="in-s">
      <option value="" ${!i.shoppingSource ? 'selected' : ''}>Wie Kategorie</option>
      <option value="MARKT" ${i.shoppingSource === 'MARKT' ? 'selected' : ''}>Markt</option>
      <option value="SUPERMARKT" ${i.shoppingSource === 'SUPERMARKT' ? 'selected' : ''}>Supermarkt</option>
      <option value="DROGERIE" ${i.shoppingSource === 'DROGERIE' ? 'selected' : ''}>Drogerie</option>
      <option value="VORRAT" ${i.shoppingSource === 'VORRAT' ? 'selected' : ''}>Vorrat</option></select></label>
    <div class="field"><div class="row"><span class="grow" style="margin:0;color:var(--ink);font-weight:600">Nie auf die Einkaufsliste</span>
      <label class="switch"><input type="checkbox" id="in-ns" ${EP.neverShop(i) ? 'checked' : ''} aria-label="Nie auf die Einkaufsliste"><i></i></label></div></div>
    <label class="field"><span>Standardeinheit</span><select class="in" id="in-u">${EP.UNIT_ORDER.map(u => `<option value="${u}" ${u === i.defaultUnit ? 'selected' : ''}>${EP.UNITS[u].s}</option>`).join('')}</select></label>
    ${id ? `<p class="hint">In ${used} ${used === 1 ? 'Rezept' : 'Rezepten'} verwendet.</p>` : ''}
    <div class="btns"><button class="btn primary" data-x="save">Speichern</button>
    ${id && others.length ? `<label class="field"><span>Zusammenführen in</span><select class="in" id="in-m"><option value="">Zutat wählen</option>${others.map(o => `<option value="${o.id}">${esc(o.name)}</option>`).join('')}</select></label>
      <button class="btn" data-x="merge">Zusammenführen</button>` : ''}
    ${id ? `<button class="btn danger" data-x="del" ${used ? 'disabled style="opacity:.5"' : ''}>${used ? 'Löschen nicht möglich (in Verwendung)' : 'Zutat löschen'}</button>` : ''}
    <button class="btn quiet" data-x="no">Abbrechen</button></div>`, el => {
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=save]', el).onclick = () => {
      const name = $('#in-n', el).value.trim();
      if (!name) return notify('Bitte einen Namen eingeben.');
      const ex = findIngredient(name);
      if (ex && ex.id !== id) return notify('Diese Zutat gibt es schon – nutze „Zusammenführen“.');
      const tgt = id ? ingById(id) : createIngredient(name);
      Object.assign(tgt, { name, category: $('#in-c', el).value, shoppingSource: $('#in-s', el).value || null, defaultUnit: $('#in-u', el).value });
      const ns = $('#in-ns', el).checked;   // nur speichern, wenn es von der Automatik abweicht
      tgt.noShop = ns === EP.neverShop(Object.assign({}, tgt, { noShop: undefined })) ? undefined : ns;
      if (tgt.noShop === undefined) delete tgt.noShop;
      EP.touch(tgt); closeSheet(); change('Gespeichert.');
    };
    const m = $('[data-x=merge]', el);
    if (m) m.onclick = () => {
      const to = $('#in-m', el).value; if (!to) return notify('Bitte eine Zielzutat wählen.');
      mergeIngredient(id, to); closeSheet(); change('Zusammengeführt.');
    };
    const d = $('[data-x=del]', el);
    if (d && !used) d.onclick = () => { EP.tomb(ingById(id)); closeSheet(); change('Gelöscht.'); };
  });
}

/* ---------- Rotation ---------- */
function vRotation() {
  const sig = () => db.rotation.length + ':' + db.rotation.filter(e => e.deleted).length + ':' + db.rotation.filter(e => e.status === 'SKIPPED').length;
  const before = sig();
  EP.LANES.forEach(l => EP.nextEntries(db, 1, null, rng, l.key, EP.monthOf(EP.todayISO())));
  if (sig() !== before) persist();
  // nur Rezepte, die es noch gibt: keine gelöschten/archivierten, pausierte nur solange sie noch eingeplant sind
  const shownE = e => { const r = recipeById(e.recipeId); return r && !r.deleted && !r.archivedAt && (r.inRotation || e.status === 'PLANNED'); };
  const stLabel = { PENDING: ['Offen', ''], PLANNED: ['Geplant', 'cook'], DONE: ['Gekocht', 'done'], SKIPPED: ['Ausgelassen', 'block'] };
  const fixed = db.settings.rotationMode === 'FIXED';
  const actives = EP.activeRecipes(db).sort((a, b) => a.sortOrder - b.sortOrder);
  const allCycles = EP.LANES.flatMap(l => EP.openCycles(db, l.key).map(c => [l.key, c]));
  return (allCycles.length ? allCycles.map(([lane, c]) => {
    const all = EP.cycleEntries(db, c, lane).filter(shownE);
    const season = all.filter(e => e.status === 'SKIPPED' && e.skipReason === 'SEASON');
    const es = all.filter(e => !season.includes(e));
    const seasonNames = [...new Set(season.map(e => recipeById(e.recipeId).name))];
    return `<h3>${LANE_LABEL[lane]} · Durchlauf ${c}</h3><div class="box">${es.map(e => {
      const r = recipeById(e.recipeId), [l, cls] = stLabel[e.status];
      return `<div class="item"><span class="nm serif" style="font-size:17px">${esc(r ? r.name : '–')}${r && r.weight > 1 ? ` <span class="sub">(${e.occurrence}/${r.weight})</span>` : ''}</span>
        <span class="badge ${cls}">${l}</span>
        ${e.status === 'PENDING' ? `<button class="btn quiet small" data-act="rpost" data-arg="${e.id}">Später</button><button class="btn quiet small" data-act="rskip" data-arg="${e.id}">Auslassen</button>` : ''}</div>`;
    }).join('')}</div>${seasonNames.length ? `<p class="hint">Gerade keine Saison, in diesem Durchlauf ausgelassen: ${esc(seasonNames.join(', '))}</p>` : ''}`;
  }).join('') : '<p class="empty">Keine offenen Durchläufe – leg Rezepte an und nimm sie in die Rotation.</p>')
  + (fixed && actives.length ? `<h3>Feste Reihenfolge</h3><p class="hint" style="margin-top:0">Gilt ab dem nächsten Durchlauf.</p><div class="box">${actives.map((r, i) => `<div class="item">
      <span class="nm serif">${esc(r.name)}</span>
      <button class="btn quiet small" data-act="sortup" data-arg="${r.id}" ${i === 0 ? 'disabled' : ''} aria-label="Nach oben">▲</button>
      <button class="btn quiet small" data-act="sortdown" data-arg="${r.id}" ${i === actives.length - 1 ? 'disabled' : ''} aria-label="Nach unten">▼</button></div>`).join('')}</div>` : '')
  + `<div class="btns"><button class="btn danger" data-act="rreset">Rotation neu starten</button></div>`;
}

/* ---------- Einstellungen ---------- */
/* Einstellungen im Stil der iOS-Einstellungen: farbige Symbolkacheln links, Wert/Schalter rechts */
const SI = {
  people: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5"/><circle cx="17" cy="9" r="2.4"/><path d="M16 14.2c2.4-.2 4 1.4 4.5 4.3"/></svg>',
  round: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17h16M7 17V9M12 17V5M17 17v-5"/></svg>',
  shuffle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7h3.5c4 0 5 10 9 10H21M18 14l3 3-3 3M3 17h3.5c1.7 0 2.8-1.8 3.8-4M13.7 11c1-2.2 2.1-4 3.8-4H21M18 4l3 3-3 3"/></svg>',
  scale: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h14l-2 16H7z"/><path d="M9 9h6M9 13h6"/></svg>',
  lunch: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 11h17a8.5 8.5 0 0 1-17 0z"/><path d="M9 7c0-1.5 1-2 1-3.5M13 7c0-1.5 1-2 1-3.5"/></svg>',
  cake: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16v-7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2z"/><path d="M4 15c2 1.5 4 1.5 6 0s4-1.5 6 0 2.7 1 4 .5M12 11V7"/><path d="M12 3.5c.9 1 .9 2 0 3-.9-1-.9-2 0-3z"/></svg>',
  cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2.5l2.2 11h10.6l2-7.5H6.4"/><circle cx="9.5" cy="19" r="1.4"/><circle cx="17" cy="19" r="1.4"/></svg>',
  leaf: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 19c0-8 5-13 14-14-1 9-6 14-14 14z"/><path d="M5 19l7-7"/></svg>',
  cycle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 0 1-14 5.3M4 12a8 8 0 0 1 14-5.3"/><path d="M18 3v4h-4M6 21v-4h4"/></svg>',
  sync: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 18a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 8a4 4 0 0 1-.5 10"/><path d="M12 12v8M9 15l3-3 3 3"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M20.5 16l-5-5-8 8"/></svg>',
  down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>',
  up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15V4M7 9l5-5 5 5M5 20h14"/></svg>',
  book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4.5h11a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/></svg>',
  key: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="15" r="4"/><path d="M11 12l8-8M16 7l2 2M14 9l2 2"/></svg>',
  bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>',
  shop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l1.5-5h15L21 9"/><path d="M4 9v11h16V9"/><path d="M3 9h18"/><path d="M9 20v-6h6v6"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg>',
  cal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
  pencil: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4"/></svg>',
  out: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4M10 16l-4-4 4-4M6 12h10"/></svg>',
};
const CHEV = '<svg class="gchev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>';
/* eine Zeile: tag = 'button' (antippbar, mit Pfeil) oder 'div' (mit Bedienelement rechts) */
function gRow({ icon, color, label, sub, value, right, act, arg, id, danger, chevron }) {
  const btn = !!act;
  const inner = `<span class="gic" style="--c:${color}">${SI[icon]}</span><span class="gbody"><span class="glbl${danger ? ' danger' : ''}">${label}${sub ? `<small>${sub}</small>` : ''}</span>
    ${value != null ? `<span class="gval">${value}</span>` : ''}${right || ''}${btn && chevron !== false ? CHEV : ''}</span>`;
  return btn ? `<button class="gi" data-act="${act}"${arg != null ? ` data-arg="${esc(String(arg))}"` : ''}${id ? ` id="${id}"` : ''}>${inner}</button>` : `<div class="gi">${inner}</div>`;
}
const gGroup = (title, rows, foot) => `${title ? `<h3 class="ghead">${title}</h3>` : ''}<div class="glist">${rows.filter(Boolean).join('')}</div>${foot ? `<p class="gfoot">${foot}</p>` : ''}`;
const DAYN = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
function specialDaysText() { const d = EP.specialDays(db.settings); return d.length ? [1, 2, 3, 4, 5, 6, 0].filter(x => d.includes(x)).map(x => DAYN[x]).join(', ') : 'Keine'; }
function specialDaysSheet() {
  const cur = () => EP.specialDays(db.settings);
  openSheet(`<h2>Besondere Tage</h2>

    <div class="chips daypick">${[1, 2, 3, 4, 5, 6, 0].map(d => `<button class="chip" data-sd="${d}" aria-pressed="${cur().includes(d)}">${DAYN[d]}</button>`).join('')}</div>
    <div class="btns"><button class="btn primary" data-x="no">Fertig</button></div>`, el => {
    $$('[data-sd]', el).forEach(b => b.onclick = () => {
      const d = +b.dataset.sd, c = cur();
      db.settings.specialDays = c.includes(d) ? c.filter(x => x !== d) : c.concat(d); EP.touch(db.settings);
      b.setAttribute('aria-pressed', String(db.settings.specialDays.includes(d))); persist();
    });
    $('[data-x=no]', el).onclick = () => { closeSheet(); change(); };
  });
}
/* eigene Namen für die Rezept-Arten */
function kindNamesSheet() {
  const kn = db.settings.kindNames || {};
  openSheet(`<h2>Bezeichnungen</h2>
    <p class="sub" style="margin-top:6px">Leer = Standard</p>
    <div class="kindnames">${EP.KINDS.map(k => `<label class="field"><span>${esc(k.short)}</span><input class="in" data-kn="${k.key}" maxlength="24" value="${esc(kn[k.key] || '')}" placeholder="${esc(k.short)}" autocomplete="off"></label>`).join('')}</div>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Speichern</button></div>`, el => {
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => {
      const o = {}; $$('[data-kn]', el).forEach(i => { const v = i.value.trim(); if (v) o[i.dataset.kn] = v; });
      db.settings.kindNames = o; EP.touch(db.settings); closeSheet(); change('Gespeichert.');
    };
  });
}
function daysText(l) { const d = laneDays(l); return d.length ? [1, 2, 3, 4, 5, 6, 0].filter(x => d.includes(x)).map(x => DAYN[x]).join(', ') : 'Aus'; }
function vSettings() {
  const s = db.settings;
  const sw = (id, on, lbl) => `<label class="switch"><input type="checkbox" id="${id}" ${on ? 'checked' : ''} aria-label="${lbl}"><i></i></label>`;
  const syncVal = Sync.enabled() ? (Sync.isPB ? 'Pi' : 'GitHub') : 'Aus';
  const nNew = unreviewedCount();
  return gGroup('', [
      gRow({ icon: 'people', color: '#0A84FF', label: 'Portionen pro Tag',
        right: `<div class="stepper small"><button data-act="ppd" data-arg="-1" aria-label="Weniger">−</button><output>${s.portionsPerDay}</output><button data-act="ppd" data-arg="1" aria-label="Mehr">+</button></div>` }),
      gRow({ icon: 'round', color: '#FF9500', label: 'Krumme Portionen', value: s.roundingMode === 'FLOOR' ? 'Abrunden' : 'Aufrunden', act: 'setpick', arg: 'roundingMode' }),
      gRow({ icon: 'shuffle', color: '#AF52DE', label: 'Reihenfolge der Rotation', value: s.rotationMode === 'FIXED' ? 'Fest' : 'Neu mischen', act: 'setpick', arg: 'rotationMode' }),
      gRow({ icon: 'scale', color: '#34C759', label: 'Marktliste mit Mengen', right: sw('s-mq', s.marketListShowQuantities, 'Marktliste mit Mengen') }),
    ])
    + gGroup('Zusätzliche Mahlzeiten', [
      gRow({ icon: 'lunch', color: '#30B158', label: esc(laneWhat('LUNCH')), value: daysText('LUNCH'), act: 'lanedays', arg: 'LUNCH' }),
      gRow({ icon: 'cake', color: '#FF6B4A', label: esc(laneWhat('CAKE')), value: daysText('CAKE'), act: 'lanedays', arg: 'CAKE' }),
    ])
    + gGroup(esc(LANE_LABEL.SPECIAL), [
      gRow({ icon: 'star', color: '#8E44AD', label: 'Besondere Tage', value: specialDaysText(), act: 'specialdays' }),
      gRow({ icon: 'cal', color: '#8E44AD', label: 'Beim Füllen freihalten', right: sw('s-spfree', s.specialKeepFree !== false, 'Beim Füllen freihalten') }),
      gRow({ icon: 'pencil', color: '#636366', label: 'Bezeichnungen', value: Object.values(s.kindNames || {}).some(x => x) ? 'Eigene' : 'Standard', act: 'kindnames' }),
    ])
    + gGroup('Verwalten', [
      gRow({ icon: 'cart', color: '#30B0C7', label: 'Einkaufsorte', right: nNew ? `<span class="countbadge">${nNew}</span>` : '', act: 'to', arg: 'sources' }),
      gRow({ icon: 'shop', color: '#FF9500', label: 'Geschäfte', value: EP.liveStores(db.settings).length || 'Keine', act: 'to', arg: 'stores' }),
      gRow({ icon: 'cal', color: '#34C759', label: 'Markttage', value: marketDaysText(), act: 'marketdays' }),
      gRow({ icon: 'cart', color: '#5856D6', label: 'Einkaufsliste anordnen', act: 'shoplayout' }),
      gRow({ icon: 'bell', color: '#AF52DE', label: 'Siri-Kurzbefehl', value: db.settings.inbox ? 'An' : 'Aus', act: 'inbox' }),
      gRow({ icon: 'leaf', color: '#34C759', label: 'Zutaten', value: EP.live(db.ingredients).length, act: 'to', arg: 'ingredients' }),
      gRow({ icon: 'cycle', color: '#5856D6', label: 'Rotation ansehen', act: 'to', arg: 'rotation' }),
      gRow({ icon: 'sync', color: '#0A84FF', label: 'Geräteabgleich', value: syncVal, act: 'to', arg: 'sync' }),
      gRow({ icon: 'bell', color: '#FF3B30', label: 'Mitteilungen', value: typeof Push !== 'undefined' && Push.enabled() ? 'An' : 'Aus', act: 'mitteilungen' }),
    ])
    + gGroup('Datensicherung', [
      gRow({ icon: 'image', color: '#FF2D55', label: 'Bilder mit sichern', right: `<label class="switch"><input type="checkbox" id="s-img" aria-label="Bilder mit sichern"><i></i></label>` }),
      gRow({ icon: 'down', color: '#8E8E93', label: 'Als Datei sichern', act: 'export' }),
      gRow({ icon: 'up', color: '#8E8E93', label: 'Sicherung einlesen', act: 'import' }),
      liveRecipes().length ? '' : gRow({ icon: 'book', color: '#FF9500', label: 'Beispielrezepte laden', act: 'seed' }),
    ])
    + `<input type="file" id="s-file" accept=".json,application/json" class="hidden">`
    + gGroup(`Haushalt ${esc(db.household ? db.household.name : '')}`, Konto.loggedIn() ? [
      gRow({ icon: 'people', color: '#0A84FF', label: 'Konto', value: esc(Konto.user()), act: 'konto' }),
    ] : [
      gRow({ icon: 'people', color: '#8E8E93', label: 'Konto', sub: 'Im Hauptmenü anmelden', value: 'Aus', act: 'konto' }),
      gRow({ icon: 'key', color: '#8E8E93', label: 'Passwort ändern', act: 'chpw' }),
      gRow({ icon: 'out', color: '#FF3B30', label: 'Abmelden', act: 'logout', danger: true, chevron: false }),
    ]);
}
/* Wochentage für Mittag / Kuchen */
function laneDaysSheet(l) {
  openSheet(`<h2>${esc(laneWhat(l))} an</h2>

    <div class="chips daypick">${[1, 2, 3, 4, 5, 6, 0].map(d => `<button class="chip" data-act="laneday" data-arg="${l}|${d}" aria-pressed="${laneDays(l).includes(d)}">${DAYN[d]}</button>`).join('')}</div>
    <div class="btns"><button class="btn primary" data-x="no">Fertig</button></div>`, el => { $('[data-x=no]', el).onclick = closeSheet; });
}

/* ---------- Siri-Kurzbefehl: Briefkasten auf dem Pi ----------
   Der Kurzbefehl schickt Text an …/push/inbox/add; der Pi verschlüsselt ihn sofort mit dem öffentlichen
   Schlüssel dieses Haushalts. Die App holt ab, entschlüsselt (privater Schlüssel in db.settings.inbox,
   gleicht verschlüsselt mit ab), bestätigt und trägt die Artikel ein. */
const Inbox = (() => {
  const DEFAULT = 'https://kostenpi.tail281e3e.ts.net/push';
  const server = () => { try { return localStorage.getItem('push-server') || DEFAULT; } catch (e) { return DEFAULT; } };
  const b64e = u8 => { let s = ''; u8.forEach(b => { s += String.fromCharCode(b); }); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
  const b64d = str => { str = String(str).replace(/-/g, '+').replace(/_/g, '/'); while (str.length % 4) str += '='; const b = atob(str), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
  const rnd = n => b64e(crypto.getRandomValues(new Uint8Array(n)));
  const cfg = () => db && db.settings && db.settings.inbox && db.settings.inbox.box ? db.settings.inbox : null;
  const post = async (path, body) => {
    const r = await fetch(server() + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(j.error || 'HTTP ' + r.status), { status: r.status });
    return j;
  };
  async function setup(newToken) {
    const old = cfg();
    let c = old;
    if (!c) {
      const kp = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
      c = { box: rnd(18), admin: rnd(24), token: rnd(18), priv: await crypto.subtle.exportKey('jwk', kp.privateKey), pub: b64e(new Uint8Array(await crypto.subtle.exportKey('raw', kp.publicKey))) };
    } else if (newToken) c = Object.assign({}, c, { token: rnd(18) });
    await post('/inbox/setup', { box: c.box, admin: c.admin, pub: c.pub, token: c.token });
    db.settings.inbox = c; EP.touch(db.settings); persist();
    return c;
  }
  async function off() {
    const c = cfg(); if (!c) return;
    try { await post('/inbox/off', { box: c.box, admin: c.admin }); } catch (e) {}
    db.settings.inbox = null; EP.touch(db.settings); persist();
  }
  const url = () => { const c = cfg(); return c ? `${server()}/inbox/add?plain=1&key=${c.box}.${c.token}` : ''; };
  async function open(c, m) {
    const priv = await crypto.subtle.importKey('jwk', c.priv, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
    const eph = await crypto.subtle.importKey('raw', b64d(m.e), { name: 'ECDH', namedCurve: 'P-256' }, false, []);
    const shared = await crypto.subtle.deriveBits({ name: 'ECDH', public: eph }, priv, 256);
    const hk = await crypto.subtle.importKey('raw', shared, 'HKDF', false, ['deriveKey']);
    const key = await crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: new TextEncoder().encode('einkauf-inbox-v1'), info: new TextEncoder().encode('enc') }, hk, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
    return new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64d(m.iv) }, key, b64d(m.c)));
  }
  /* „Milch, 2 Gurken und Brot“ → drei Artikel */
  const split = t => String(t).split(/\s*(?:,|;|\bund\b|\bsowie\b|\n)\s*/i).map(x => x.replace(/[.!?]+$/, '').trim()).filter(Boolean);
  let busy = false;
  async function pull() {
    const c = cfg(); if (!c || busy || !navigator.onLine) return 0;
    busy = true;
    try {
      const { msgs } = await post('/inbox/fetch', { box: c.box, admin: c.admin });
      if (!msgs || !msgs.length) return 0;
      await post('/inbox/ack', { box: c.box, admin: c.admin, ids: msgs.map(m => m.id) });   // zuerst bestätigen: ein zweites Gerät holt sie dann nicht noch einmal
      const added = [];
      for (const m of msgs.sort((a, b) => a.t - b.t)) {
        let t; try { t = await open(c, m); } catch (e) { continue; }
        split(t).forEach(x => { const r = addExtraItem(x); if (r) added.push(r.amount ? `${r.name} (${r.amount})` : r.name); });
      }
      if (added.length) { persist(); rerender(); notify('Per Siri: ' + added.join(', ')); }
      return added.length;
    } catch (e) { return 0; } finally { busy = false; }
  }
  return { setup, off, url, pull, cfg, split };
})();
function inboxSheet() {
  const draw = el => {
    const c = Inbox.cfg();
    $('#ibx', el).innerHTML = c ? `
      <ol class="ibsteps">
        <li>App <b>Kurzbefehle</b> → <b>+</b></li>
        <li>Aktion <b>Text diktieren</b></li>
        <li>Aktion <b>Inhalte von URL abrufen</b>: Link unten einfügen, Methode <b>POST</b>, Hauptteil <b>JSON</b>, Feld <b>text</b> = <i>Diktierter Text</i></li>
        <li>Aktion <b>Text sprechen</b> (Inhalte der URL)</li>
        <li>Kurzbefehl z. B. „Einkauf“ nennen → „Hey Siri, Einkauf“</li>
      </ol>
      <label class="field"><span>Link für den Kurzbefehl</span><input class="in" id="ib-url" readonly value="${esc(Inbox.url())}"></label>
      <div class="btns"><button class="btn primary" data-x="copy">Link kopieren</button></div>
      <div class="btns two"><button class="btn" data-x="renew">Neuer Link</button><button class="btn danger" data-x="off">Ausschalten</button></div>`
      : `<p class="sub">Artikel per Siri auf die Einkaufsliste, ohne die App zu öffnen.</p>
      <div class="btns"><button class="btn primary" data-x="on">Einrichten</button></div>`;
    const b = x => $(`[data-x=${x}]`, el);
    const run = async (fn, ok) => { try { await fn(); if (ok) notify(ok); } catch (e) { notify('Pi nicht erreichbar.'); } draw(el); rerender(); };
    if (b('on')) b('on').onclick = () => run(() => Inbox.setup(), 'Eingerichtet.');
    if (b('renew')) b('renew').onclick = () => run(() => Inbox.setup(true), 'Neuer Link – im Kurzbefehl ersetzen.');
    if (b('off')) b('off').onclick = () => run(() => Inbox.off(), 'Ausgeschaltet.');
    if (b('copy')) b('copy').onclick = async () => { try { await navigator.clipboard.writeText(Inbox.url()); notify('Link kopiert.'); } catch (e) { $('#ib-url', el).select(); notify('Bitte markieren und kopieren.'); } };
  };
  openSheet(`<h2>Siri-Kurzbefehl</h2><div id="ibx"></div><div class="btns"><button class="btn quiet" data-x="no">Fertig</button></div>`, el => { draw(el); $('[data-x=no]', el).onclick = closeSheet; });
}
/* Markttage: an anderen Tagen steht Markt-Ware beim Supermarkt */
const marketDaysOf = () => Array.isArray(db.settings.marketDays) ? db.settings.marketDays : [0, 1, 2, 3, 4, 5, 6];
function marketDaysText() {
  const d = marketDaysOf();
  return d.length === 7 ? 'Jeden Tag' : !d.length ? 'Nie' : [1, 2, 3, 4, 5, 6, 0].filter(x => d.includes(x)).map(x => DAYN[x]).join(', ');
}
function marketDaysSheet() {
  openSheet(`<h2>Markttage</h2>
    <div class="chips daypick">${[1, 2, 3, 4, 5, 6, 0].map(d => `<button class="chip" data-act="marketday" data-arg="${d}" aria-pressed="${marketDaysOf().includes(d)}">${DAYN[d]}</button>`).join('')}</div>
    <div class="btns"><button class="btn primary" data-x="no">Fertig</button></div>`, el => { $('[data-x=no]', el).onclick = closeSheet; });
}
/* ---------- Einkaufsorte ---------- */
const SRC = [['MARKT', 'Markt'], ['SUPERMARKT', 'Supermarkt'], ['DROGERIE', 'Drogerie'], ['VORRAT', 'Vorrat']];
function srcSeg(act, id, cur, extraCls) {
  return `<div class="seg srcseg ${extraCls || ''}">${SRC.map(([k, l]) => `<button data-act="${act}" data-arg="${id}|${k}" aria-pressed="${cur === k}">${l}</button>`).join('')}</div>`;
}
/* Einkaufsort eigener Artikel (je Begriff gemerkt, z. B. Croissants → Markt) */
const XSRC = [['MARKT', 'Markt'], ['SUPERMARKT', 'Supermarkt'], ['DROGERIE', 'Drogerie']];
function extraSourceOf(name) {
  const n = EP.normExtra(name), own = (db.settings.extraSrc || {})[n];
  if (own) return own;
  const s = EP.categorySource(EP.extraCategory(name, db.settings.extraCats), db.settings);
  return s === 'VORRAT' ? 'SUPERMARKT' : s;
}
function setExtraSource(name, src) {
  const n = EP.normExtra(name), cat = EP.categorySource(EP.extraCategory(name, db.settings.extraCats), db.settings);
  const o = Object.assign({}, db.settings.extraSrc);
  if (src === (cat === 'VORRAT' ? 'SUPERMARKT' : cat)) delete o[n]; else o[n] = src;   // nur Abweichungen merken
  db.settings.extraSrc = o; EP.touch(db.settings);
}
const xsrcSeg = name => `<div class="seg srcseg xsrcseg">${XSRC.map(([k, l]) => `<button data-act="xsrc" data-arg="${esc(EP.normExtra(name) + '|' + k)}" data-name="${esc(name)}" aria-pressed="${extraSourceOf(name) === k}">${l}</button>`).join('')}</div>`;
/* ---------- Zusätzliche Artikel auf der Einkaufsliste ---------- */
/* Verlauf der zusätzlichen Artikel; beim ersten Mal aus vorhandenen Einträgen und „zuletzt verwendet“ aufbauen */
function extraStats() {
  if (db.settings.extraStats) return db.settings.extraStats;
  let st = {};
  (shopState().extras || []).forEach(x => { if (x && x.text) st = EP.recordExtra(st, EP.extraParts(x).name, x.date || EP.todayISO()); });
  (db.settings.recentExtras || []).slice().reverse().forEach(t => { if (!st[EP.normExtra(t)]) st = EP.recordExtra(st, t, EP.todayISO()); });
  return st;
}
/* Artikel hinzufügen; Menge wird erkannt („4 Packungen Feta“). Steht derselbe Artikel schon offen auf der Liste,
   wird die Menge dazugezählt. Liefert { name, amount, merged, exists } für die Meldung. */
function addExtraItem(t) {
  const p = EP.parseExtra(t); if (!p.name) return null;
  const st = shopState(), r = curShopRange(), today = EP.todayISO(), now = Date.now();
  const date = r.to >= today ? (r.from > today ? r.from : today) : r.from;   // gehört zum gezeigten Zeitraum
  const n = EP.normExtra(p.name), same = u => (u || 'STUECK') === (p.unit || 'STUECK');
  const ex = st.extras.find(x => x && !x.del && !x.checked && x.date >= r.from && x.date <= r.to && EP.normExtra(x.text) === n
    && (EP.extraParts(x).qty == null || p.qty == null || same(EP.extraParts(x).unit)));
  let res;
  if (ex) {
    const q = EP.extraParts(ex);
    if (p.qty == null) return { name: q.name, amount: EP.extraAmount(q), exists: true };
    const qty = q.qty == null ? p.qty : Math.round((q.qty + p.qty) * 1000) / 1000;
    Object.assign(ex, { text: q.name, qty, unit: q.qty == null ? p.unit : q.unit }); EP.touch(ex); EP.touch(st);
    res = { name: q.name, amount: EP.extraAmount(EP.extraParts(ex)), merged: true };
  } else {
    st.extras.push({ id: EP.uuid(), text: p.name, qty: p.qty, unit: p.unit, date, checked: false, category: null, addedAt: now, updatedAt: now }); EP.touch(st);
    res = { name: p.name, amount: EP.extraAmount(p) };
  }
  const rec = (db.settings.recentExtras || []).filter(x => EP.normExtra(x) !== n);
  db.settings.recentExtras = [p.name].concat(rec).slice(0, 12);   // ältere App-Fassungen lesen noch diese Liste
  db.settings.extraStats = EP.recordExtra(extraStats(), p.name, today); EP.touch(db.settings);
  Notes.extraAdded(res.amount ? `${res.name} (${res.amount})` : res.name);
  return res;
}
/* Kategorie eines Zusatzartikels ändern – wird für diesen Begriff gemerkt */
function extraCatSheet(i) {
  const st = shopState(), x = st.extras.find(e => e.id === i); if (!x) return;
  const nm = EP.extraParts(x).name;
  const cur = x.category || EP.extraCategory(nm, db.settings.extraCats);
  let src = EP.categorySource(cur, db.settings); if (src === 'VORRAT') src = 'SUPERMARKT';
  const store = EP.storeFor(db.settings, src, st), nx = EP.normExtra(nm), inSec = store && store.assign && store.assign[nx];
  const unSec = () => { if (inSec) { const a = Object.assign({}, store.assign); delete a[nx]; store.assign = a; EP.touch(db.settings); } };
  const secOpts = store ? (store.sections || []).map(sec => ({ label: sec.name, hint: `Bereich in „${store.name}“`, icon: inSec === sec.id ? 'check' : 'bowl', tone: inSec === sec.id ? 'basil' : 'speckle', group: 0,
    run: () => { store.assign = Object.assign({}, store.assign, { [nx]: sec.id }); EP.touch(db.settings); change(`${nm} → ${sec.name}`); } })) : [];
  const editOpt = { label: 'Bearbeiten', icon: 'pencil', tone: 'rim', group: -1, run: () => extraEditSheet(i) };
  const curSrc = extraSourceOf(nm);
  const srcOpts = XSRC.map(([k, l]) => ({ label: `Einkaufen: ${l}`, icon: k === curSrc ? 'check' : 'cart', tone: k === curSrc ? 'basil' : 'rim', group: -1,
    run: () => { setExtraSource(nm, k); change(`${nm} → ${l}`); } }));
  optionsSheet(`„${nm}“`, '', [editOpt].concat(srcOpts).concat(secOpts).concat(EP.CATEGORIES.map(c => ({
    label: c.label, hint: { MARKT: 'Markt', SUPERMARKT: 'Supermarkt', DROGERIE: 'Drogerie', VORRAT: 'Vorrat' }[EP.categorySource(c.key, db.settings)],
    icon: c.key === cur ? 'check' : 'bowl', tone: c.key === cur ? 'basil' : 'speckle', group: 0,
    run: () => {
      x.category = c.key; EP.touch(x); EP.touch(st); unSec();
      db.settings.extraCats = Object.assign({}, db.settings.extraCats, { [EP.normExtra(nm)]: c.key }); EP.touch(db.settings);
      change(`${nm} → ${c.label}`);
    } }))).concat([{ label: 'Entfernen', danger: true, run: () => ACT.delextra(i) }]));
}
/* Zusatzartikel umbenennen (Tippfehler): Text ändern, Kategorie neu erkennen, Vorschläge mitziehen */
function extraEditSheet(i) {
  const st = shopState(), x = st.extras.find(e => e.id === i); if (!x) return;
  const cur = EP.extraParts(x);
  textSheet('Eintrag bearbeiten', '', EP.extraEditText(cur), 'Speichern', v => {
    const p = EP.parseExtra(v.slice(0, 80)), old = cur.name;
    if (!p.name) return;
    if (p.name === old && p.qty === cur.qty && (p.unit || null) === (cur.unit || null)) return;
    Object.assign(x, { text: p.name, qty: p.qty, unit: p.unit }); v = p.name;
    if (x.category && !(db.settings.extraCats || {})[EP.normExtra(old)]) x.category = null;   // automatisch erkannte Kategorie neu bestimmen
    EP.touch(x); EP.touch(st);
    const dt = EP.iso(new Date(x.addedAt || Date.now()));
    if (db.settings.extraStats) db.settings.extraStats = EP.renameExtra(db.settings.extraStats, old, v, dt);
    const no = EP.normExtra(old);
    if (db.settings.recentExtras) db.settings.recentExtras = db.settings.recentExtras.map(t => EP.normExtra(t) === no ? v : t);
    EP.touch(db.settings);
    change(`Geändert: ${EP.extraEditText(p)}`);
  });
}
/* ---------- Geschäfte (Regal-Reihenfolge) ---------- */
const KIND_LABEL = Object.fromEntries(EP.STORE_KINDS);
const KIND_COLOR = { SUPERMARKT: '#30B0C7', MARKT: '#34C759', DROGERIE: '#AF52DE' };
const curStore = () => EP.storeById(db.settings, route.params && route.params.id);
function storesSave(msg) { EP.touch(db.settings); return change(msg); }
function vStores() {
  const all = EP.liveStores(db.settings), def = db.settings.storeDefault || {};
  return ''
    + EP.STORE_KINDS.map(([k, l]) => gGroup(l, all.filter(x => x.kind === k).map(x => gRow({ icon: 'shop', color: KIND_COLOR[k], label: esc(x.name),
        sub: def[k] === x.id ? 'Standard' : '', act: 'storeopen', arg: x.id }))
      .concat([gRow({ icon: 'plus', color: '#8E8E93', label: `${l} hinzufügen`, act: 'storeadd', arg: k })]))).join('');
}
function vStore() {
  const s = curStore();
  if (!s) return `<p class="sub">Dieses Geschäft gibt es nicht mehr.</p>`;
  const kl = KIND_LABEL[s.kind], isDef = (db.settings.storeDefault || {})[s.kind] === s.id;
  const order = EP.storeOrder(s, db.settings);
  const nAssigned = id => Object.values(s.assign || {}).filter(x => x === id).length;
  const rows = order.map((o, i) => `<div class="gi ordrow"><span class="ordnr">${i + 1}</span>
      ${o.section ? `<button class="ordlbl" data-act="secopen" data-arg="${o.id}">${esc(o.label)}<small>Eigener Bereich · ${nAssigned(o.id)} Artikel</small></button>` : `<span class="ordlbl">${esc(o.label)}</span>`}
      <button class="ordbtn" data-act="storemv" data-arg="${o.key}|-1" ${i ? '' : 'disabled'} aria-label="${esc(o.label)} nach oben">▲</button>
      <button class="ordbtn" data-act="storemv" data-arg="${o.key}|1" ${i < order.length - 1 ? '' : 'disabled'} aria-label="${esc(o.label)} nach unten">▼</button></div>`).join('');
  return gGroup('', [
      gRow({ icon: 'shop', color: KIND_COLOR[s.kind], label: 'Name', value: esc(s.name), act: 'storename' }),
      gRow({ icon: 'cart', color: '#8E8E93', label: 'Einkaufsort', value: kl, act: 'storekind' }),
      gRow({ icon: 'star', color: '#FFCC00', label: `Standard für ${kl}`,
        right: `<label class="switch"><input type="checkbox" id="st-def" ${isDef ? 'checked' : ''} aria-label="Standard für ${kl}"><i></i></label>` }),
    ])
    + `<h3 class="ghead">Reihenfolge im Laden</h3><div class="glist ordlist">${rows}</div>
`
    + gGroup('', [gRow({ icon: 'plus', color: '#34C759', label: 'Bereich hinzufügen', act: 'secadd' })])
    + gGroup('', [gRow({ icon: 'trash', color: '#FF3B30', label: 'Geschäft löschen', act: 'storedel', danger: true, chevron: false })]);
}
function storeAddSheet(kind) {
  textSheet('Neues Geschäft', 'Name, z. B. „Rewe Hauptstraße“ oder „dm“.', '', 'Anlegen', (name, k) => {
    const st = { id: EP.uuid(), name, kind: k || kind || 'SUPERMARKT', order: [], sections: [], assign: {} };
    db.settings.stores = (db.settings.stores || []).concat([st]);
    const d = Object.assign({}, db.settings.storeDefault);
    if (!EP.storeById(db.settings, d[st.kind])) d[st.kind] = st.id;   // erstes Geschäft dieser Art wird Standard
    db.settings.storeDefault = d;
    EP.touch(db.settings); persist();
    go('store', { id: st.id });
  }, { list: EP.STORE_KINDS, cur: kind || 'SUPERMARKT' });
}
/* eigener Bereich: Artikel zuordnen, umbenennen, löschen */
function sectionSheet(secId) {
  const s = curStore(), sec = s && (s.sections || []).find(x => x.id === secId); if (!sec) return;
  const ingNames = EP.live(db.ingredients).map(i => i.name).concat(db.settings.recentExtras || []);
  const nice = new Map(ingNames.map(n => [EP.normExtra(n), n]));
  const items = Object.entries(s.assign || {}).filter(([, v]) => v === secId).map(([k]) => k).sort((a, b) => a.localeCompare(b, 'de'));
  openSheet(`<h2>${esc(sec.name)}</h2><p class="sub" style="margin-top:6px">Bereich in „${esc(s.name)}“</p>
    <div class="quick" style="margin-top:12px"><input class="in" id="sec-in" list="sec-dl" placeholder="Artikel, z. B. Hafermilch" autocomplete="off" enterkeyhint="done"><button class="btn primary" data-x="add" aria-label="Artikel zuordnen">+</button></div>
    <datalist id="sec-dl">${[...new Set(ingNames)].sort((a, b) => a.localeCompare(b, 'de')).map(n => `<option value="${esc(n)}">`).join('')}</datalist>
    <div class="secitems">${items.length ? items.map(k => `<div class="secitem"><span class="grow">${esc(nice.get(k) || k)}</span><button class="btn quiet small" data-del="${esc(k)}" aria-label="${esc(nice.get(k) || k)} entfernen">✕</button></div>`).join('') : '<p class="hint">Noch keine Artikel zugeordnet.</p>'}</div>
    <div class="btns two"><button class="btn" data-x="ren">Umbenennen</button><button class="btn danger" data-x="del">Bereich löschen</button></div>
    <div class="btns"><button class="btn primary" data-x="no">Fertig</button></div>`, el => {
    const inp = $('#sec-in', el);
    const add = () => {
      const v = inp.value.trim(); if (!v) return inp.focus();
      s.assign = Object.assign({}, s.assign, { [EP.normExtra(v)]: secId });
      storesSave(); sectionSheet(secId);
    };
    $('[data-x=add]', el).onclick = add;
    inp.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); add(); } };
    $$('[data-del]', el).forEach(b => b.onclick = () => { const a = Object.assign({}, s.assign); delete a[b.dataset.del]; s.assign = a; storesSave(); sectionSheet(secId); });
    $('[data-x=ren]', el).onclick = () => textSheet('Bereich umbenennen', '', sec.name, 'Speichern', v => { sec.name = v; storesSave(); });
    $('[data-x=del]', el).onclick = () => confirmSheet(`Bereich „${sec.name}“ löschen?`, 'Die zugeordneten Artikel stehen dann wieder in ihrer Kategorie.', 'Löschen', 'Abbrechen', () => {
      s.sections = s.sections.filter(x => x.id !== secId);
      s.order = (s.order || []).filter(k => k !== 'S:' + secId);
      s.assign = Object.fromEntries(Object.entries(s.assign || {}).filter(([, v]) => v !== secId));
      storesSave(`Bereich „${sec.name}“ gelöscht`);
    }, true);
    $('[data-x=no]', el).onclick = closeSheet;
  });
}
/* Geschäft für einen Einkaufsort in dieser Einkaufsliste wählen */
function storePickSheet(kind) {
  const st = shopState(), cur = EP.storeFor(db.settings, kind, st);
  const def = (db.settings.storeDefault || {})[kind];
  const set = v => { st.stores = Object.assign({}, st.stores, { [kind]: v }); EP.touch(st); change(); };
  const opts = EP.liveStores(db.settings).filter(x => x.kind === kind).map(x => ({ label: x.name, hint: x.id === def ? 'Standard' : '',
    icon: cur && cur.id === x.id ? 'check' : 'bowl', tone: cur && cur.id === x.id ? 'basil' : 'speckle', group: 0, run: () => set(x.id) }));
  const has = opts.length > 0;
  opts.push({ label: 'Ohne Geschäft', hint: 'Kategorien in der üblichen Reihenfolge', icon: !cur ? 'check' : 'bowl', tone: !cur ? 'basil' : 'speckle', group: 1, run: () => set('none') });
  opts.push(has ? { label: 'Geschäfte verwalten', hint: 'Reihenfolge der Regale, eigene Bereiche', group: 2, run: () => go('stores') }
    : { label: 'Geschäft anlegen', hint: `z. B. Rewe, Aldi, dm`, group: 2, run: () => storeAddSheet(kind) });
  optionsSheet(`${KIND_LABEL[kind]}: Geschäft`, 'Gilt für diese Einkaufsliste. Die Reihenfolge der Regale stellst du beim Geschäft ein.', opts);
}

let srcQuery = '';   // Suche bei den Einkaufsorten
const srcNorm = t => String(t || '').toLowerCase().replace(/ä/g, 'a').replace(/ö/g, 'o').replace(/ü/g, 'u').replace(/ß/g, 'ss');
function srcResults(q) {
  const s = db.settings, n = srcNorm(q.trim());
  if (!n) return '';
  const hits = EP.live(db.ingredients).filter(i => srcNorm(i.name).includes(n))
    .sort((a, b) => (srcNorm(a.name).startsWith(n) ? 0 : 1) - (srcNorm(b.name).startsWith(n) ? 0 : 1) || a.name.localeCompare(b.name, 'de')).slice(0, 60);
  const xh = extraNames().filter(t => srcNorm(t).includes(n));
  if (!hits.length && !xh.length) return `<p class="empty">Keine Zutat mit „${esc(q.trim())}“.</p>`;
  return (hits.length ? `<h3>${hits.length === 1 ? '1 Zutat' : hits.length + ' Zutaten'}</h3><div class="box">${hits.map(i => srcRow(i, s)).join('')}</div>` : '')
    + (xh.length ? `<h3>Eigene Artikel</h3><div class="box">${xh.map(xsrcRow).join('')}</div>` : '');
}
/* eigene Artikel: aus dem Verlauf und der aktuellen Liste, ohne Rezept-Zutaten gleichen Namens */
function extraNames() {
  const seen = new Map();
  Object.values(db.settings.extraStats || {}).forEach(e => { if (e && e.t) seen.set(EP.normExtra(e.t), e.t); });
  (shopState().extras || []).filter(x => x && !x.del).forEach(x => { const p = EP.extraParts(x); if (p.name) seen.set(EP.normExtra(p.name), p.name); });
  const ingNames = new Set(EP.live(db.ingredients).map(i => EP.normExtra(i.name)));
  return [...seen.entries()].filter(([k]) => !ingNames.has(k)).map(([, t]) => t).sort((a, b) => a.localeCompare(b, 'de'));
}
const xsrcRow = t => `<div class="srcrow"><div class="row"><span class="grow nm">${esc(t)}</span><span class="amt">eigener Artikel${(db.settings.extraSrc || {})[EP.normExtra(t)] ? ' · angepasst' : ''}</span></div>${xsrcSeg(t)}</div>`;
const srcRow = (i, s) => `<div class="srcrow"><div class="row"><span class="grow nm">${esc(i.name)}</span>
      <span class="amt">${esc((EP.CAT[i.category] || EP.CAT.SONSTIGES).label)}${i.shoppingSource ? ' · angepasst' : ''}</span></div>
      ${srcSeg('src', i.id, EP.sourceOf(i, s))}</div>`;
const srcOpen = new Set();   // aufgeklappte Kategorien bleiben beim Ändern offen
function vSources() {
  const s = db.settings;
  const ings = EP.live(db.ingredients).sort((a, b) => a.name.localeCompare(b.name, 'de'));
  const fresh = ings.filter(i => i.reviewed === false);
  const row = i => srcRow(i, s);
  return `
    <div class="srcsearch"><input class="in" id="srcq" type="search" placeholder="Zutat suchen, z. B. Feta" value="${esc(srcQuery)}" autocomplete="off" enterkeyhint="search" aria-label="Zutat suchen">
      <button class="iconbtn ${srcQuery ? '' : 'hidden'}" id="srcx" aria-label="Suche löschen">✕</button></div>
    <div id="srcres">${srcResults(srcQuery)}</div>
    <div id="srcrest" class="${srcQuery.trim() ? 'hidden' : ''}">
    ${fresh.length ? `<h3>Neu hinzugekommen (${fresh.length})</h3><div class="box newbox">${fresh.map(row).join('')}
      <button class="btn primary" data-act="srcok" style="margin-top:12px">${fresh.length === 1 ? 'Passt so' : 'Alle passen so'}</button></div>` : ''}
    <h3>Nach Kategorie</h3>
    <div class="box">${EP.CATEGORIES.map(c => `<div class="srcrow"><div class="row"><span class="grow nm">${esc(c.label)}</span></div>
      ${srcSeg('catsrc', c.key, EP.categorySource(c.key, s))}</div>`).join('')}</div>
    ${(() => { const xs = extraNames(); return xs.length ? `<details class="box srcgroup" data-cat="__x" ${srcOpen.has('__x') ? 'open' : ''}><summary>Eigene Artikel <span class="amt">${xs.length}</span></summary>${xs.map(xsrcRow).join('')}</details>` : ''; })()}
    <h3>Einzelne Zutaten</h3>
    ${ings.length ? EP.CATEGORIES.map(c => {
      const list = ings.filter(i => i.category === c.key && i.reviewed !== false);
      if (!list.length) return '';
      const cur = EP.categorySource(c.key, s), mixed = list.some(i => EP.sourceOf(i, s) !== cur);
      return `<details class="box srcgroup" data-cat="${c.key}" ${srcOpen.has(c.key) ? 'open' : ''}><summary>${esc(c.label)} <span class="amt">${list.length}</span></summary>
        <div class="srcrow srcall"><div class="row"><span class="grow nm">Alle ${esc(c.label)}${mixed ? ' <small class="hint" style="display:inline;margin:0">(teils abweichend)</small>' : ''}</span></div>
        ${srcSeg('catall', c.key, mixed ? '' : cur)}</div>${list.map(row).join('')}</details>`;
    }).join('') : '<p class="empty">Noch keine Zutaten.</p>'}
    </div>`;
}

/* ---------- Einladungen für den Haushalt ---------- */
async function renderInvites() {
  const box = $('#inv-list'); if (!box || !Sync.isPB) return;
  let list = [];
  try { list = (await Konto.sentList('essen')).filter(x => x.key === 'essen:' + Sync.repo.pb); } catch (e) {}
  if (!$('#inv-list')) return;
  const st = x => x.status === 'offen' ? `offen bis ${EP.fmtShort(x.expiresAt.slice(0, 10))}` : x.status === 'abgelaufen' ? 'abgelaufen' : x.status === 'erledigt' ? 'angenommen oder abgelehnt' : 'Stand unbekannt';
  box.innerHTML = list.length ? `<h3>Einladungen</h3><div class="glist">${list.map(x => `<div class="gi"><span class="gic" style="--c:${x.status === 'offen' ? '#0A84FF' : '#8E8E93'}">${SI.people}</span>
    <span class="gbody"><span class="glbl">${esc(x.to)}<small>${st(x)}</small></span>
    ${x.status === 'offen' ? `<button class="btn small danger" data-act="invw" data-arg="${x.iid}">Zurückziehen</button>` : `<button class="btn small quiet" data-act="invf" data-arg="${x.iid}">Entfernen</button>`}</span></div>`).join('')}</div>` : '';
}

/* ---------- Geräteabgleich ---------- */
let pendingJoin = '';
const pwField = id => `<label class="field"><span>Dein Haushaltspasswort</span><input class="in" id="${id}" type="password" autocomplete="current-password"></label>`;
function pbJoinForm() {
  return `<h3>Schon auf einem anderen Gerät eingerichtet</h3>
    <label class="field"><span>Link vom anderen Gerät</span><input class="in" id="pb-in" value="${esc(pendingJoin)}" placeholder="…/essensplanung.html#join=…" autocapitalize="off" autocomplete="off" spellcheck="false"></label>
    ${pwField('pb-pw3')}
    
    <div class="btns"><button class="btn${pendingJoin ? ' primary' : ''}" data-act="pbjoinhere">Verbinden</button></div>`;
}
function vSync() {
  const on = Sync.enabled(), r = Sync.repo;
  const last = Sync.lastSync ? new Date(Sync.lastSync).toLocaleString('de-DE', { dateStyle: 'short', timeStyle: 'short' }) : 'noch nie';
  const status = `<p class="hint">Letzter Abgleich: ${last}${Sync.msg ? `<br><span class="warn">${esc(Sync.msg)}</span>` : ''}</p>
      <div class="btns two"><button class="btn primary" data-act="syncnow">Jetzt abgleichen</button><button class="btn danger" data-act="syncoff">Trennen</button></div>`;
  if (on && Sync.isPB) return `<div class="box"><p><b>Verbunden</b> mit deinem Pi.</p>${status}</div>
    <h3>Weiteres Gerät verbinden</h3>
    
    <div class="box stack"><input class="in" id="pb-link" readonly value="${esc(PB.link(r.pb, Auth.token))}" aria-label="Verbindungslink">
      <div class="btns${navigator.share ? ' two' : ''}"><button class="btn primary" data-act="pbcopy">Link kopieren</button>${navigator.share ? '<button class="btn" data-act="pbshare">Senden …</button>' : ''}</div></div>
    <p class="hint">Nur an Personen im Haushalt weitergeben.</p>
    ${Konto.loggedIn() ? `<h3>Per Benutzername einladen</h3>
    <div class="box stack"><input class="in" id="inv-n" placeholder="Benutzername" autocapitalize="off" autocorrect="off" spellcheck="false" autocomplete="off" enterkeyhint="send" aria-label="Benutzername">
      <p class="hint" id="inv-s" style="margin:0">Gültig ${Konto.inviteDays} Tage.</p>
      <div class="btns"><button class="btn primary" data-act="invsend">Einladen</button></div></div>
    <div id="inv-list"></div>` : `<p class="hint">Mit Konto kannst du andere per Benutzername einladen – <a href="index.html#konto">im Hauptmenü anmelden</a>.</p>`}`;
  if (on) return `<div class="box"><p><b>Verbunden</b> mit dem GitHub-Repository ${esc(r.owner)}/${esc(r.name)}.</p>${status}</div>
    <h3>Auf deinen Pi umziehen</h3>
    <p class="sub">Die Daten liegen dann verschlüsselt auf deinem Pi statt bei GitHub. Tokens werden nicht mehr gebraucht, die Bilder ziehen mit um.</p>
    ${pwField('pb-pw2')}
    <div class="btns"><button class="btn primary" data-act="pbmigrate">Jetzt umziehen</button></div>
    <p class="hint">Danach verbindest du die anderen Geräte mit dem neuen Link. Das GitHub-Repository bleibt unverändert und kann später gelöscht werden.</p>
    ${pbJoinForm()}`;
  return `<p class="sub">Damit alle Geräte im Haushalt denselben Stand haben, speichert die App eure Daten verschlüsselt auf deinem Pi. Ohne Einrichtung bleiben die Daten nur auf diesem Gerät.</p>
    ${pendingJoin ? '' : `<h3>Dieses Gerät ist das erste</h3>${pwField('pb-pw1')}<div class="btns"><button class="btn primary" data-act="pbcreate">Abgleich einrichten</button></div>`}
    ${pbJoinForm()}
    <details class="box ghalt" style="margin-top:22px"><summary>Alternativ: GitHub-Repository (alt)</summary>
      <label class="field"><span>GitHub-Benutzername</span><input class="in" id="g-o" autocapitalize="off" autocomplete="off"></label>
      <label class="field"><span>Repository</span><input class="in" id="g-r" value="essensplanung-daten" autocapitalize="off" autocomplete="off"></label>
      <label class="field"><span>Token</span><input class="in" id="g-t" type="password" autocomplete="off" placeholder="github_pat_…"></label>
      ${pwField('g-p')}
      <div class="btns"><button class="btn" data-act="syncsetup">Mit GitHub verbinden</button></div></details>`;
}
async function pbCreate(pw) {
  if (!(await Crypt.check(pw, db.household.verifier))) return notify('Das Passwort stimmt nicht.');
  notify('Richte den Abgleich ein …');
  try {
    const secret = PB.newSecret();
    const rec = await PB.create(secret, db);
    await Auth.storeToken(pw, secret, { pb: rec.id });
    Sync.sha = rec.updated; Sync.remoteRev = 1; Sync.dirty = false; await Sync.saveMeta();
    await Store.set('imgq', Images.allKeys()); await Store.set('imgdel', []);
    await Sync.run({ force: true }); Sync.startPolling();
    rerender(); notify('Abgleich eingerichtet. Den Link für weitere Geräte findest du hier.'); kontoEnsure();
  } catch (e) { notify(e.message || 'Einrichten fehlgeschlagen.'); }
}
async function pbMigrate() {
  const pw = $('#pb-pw2').value;
  if (!(await Crypt.check(pw, db.household.verifier))) return notify('Das Passwort stimmt nicht.');
  notify('Hole den aktuellen Stand von GitHub …');
  await Sync.run({ force: true });
  if (Sync.state !== 'ok') return notify('GitHub ist gerade nicht erreichbar: ' + (Sync.msg || 'bitte später erneut versuchen.'));
  for (const key of Images.allKeys()) { await Images.get(key, false); await Images.get(key, true); }   // alle Bilder lokal holen
  await pbCreate(pw);
}
async function pbJoinHere() {
  const j = PB.parseLink($('#pb-in').value), pw = $('#pb-pw3').value;
  if (!j) return notify('Das sieht nicht nach einem Verbindungslink aus.');
  if (!pw) return notify('Bitte das Haushaltspasswort eingeben.');
  try {
    const f = await PB.fetchHousehold(j.id, j.secret);
    if (!(await Crypt.check(pw, f.remote.household && f.remote.household.verifier))) return notify('Das Passwort passt nicht zu diesem Haushalt.');
    const keys = Images.allKeys();
    db = repairDb(EP.mergeDb(db, f.remote)); EP.normalizePlan(db);
    await Store.set('db', db);
    await Auth.storeToken(pw, j.secret, { pb: j.id });
    Sync.sha = f.updated; Sync.remoteRev = f.rev; Sync.dirty = Sync.canon(db) !== Sync.canon(f.remote); await Sync.saveMeta();
    await Store.set('imgq', keys);
    pendingJoin = '';
    await Sync.run({ force: true }); Sync.startPolling();
    rerender(); notify('Verbunden.');
  } catch (e) { notify(e.message || 'Verbinden fehlgeschlagen.'); }
}
async function setupSync() {
  const o = $('#g-o').value.trim(), n = $('#g-r').value.trim(), t = $('#g-t').value.trim(), pw = $('#g-p').value;
  if (!o || !n || !t || !pw) return notify('Bitte alle Felder ausfüllen.');
  if (!(await Crypt.check(pw, db.household.verifier))) return notify('Das Passwort stimmt nicht.');
  try {
    await Sync.checkRepo(o, n, t);
    await Auth.storeToken(pw, t, { owner: o, name: n });
    Sync.sha = null; Sync.dirty = true; await Sync.saveMeta();
    notify('Verbunden – gleiche ab …');
    await Sync.run({ force: true });
    Sync.startPolling();
    rerender();
  } catch (e) { notify(e.message); }
}

/* ---------- Ereignisse ---------- */
const ACT = {
  back: () => back(),
  tab: a => go(a),
  tabkind: a => { recipeFilter.kind = a; go('recipes'); },
  slane: a => { suggestLane = a; rerender(); },
  rkind: a => { favPinned = null; recipeFilter.kind = a; recipeFilter.tag = ''; rerender(); },
  seedlane: async lane => {
    const res = await importData({ data: seedToDb(LANE_SAMPLES[lane], EP) }, 'merge');
    change(`${res.added} ${lane === 'CAKE' ? 'Kuchen' : 'Mittagsgerichte'} geladen.`);
  },
  lane: a => { const [d, l] = a.split('|'); weekStartISO = EP.weekStart(d); laneActions(d, l); },
  extra: id => { const x = EP.live((draft ? draft.clone : db).plan).find(p => p.id === id) || EP.live(db.plan).find(p => p.id === id); if (x) weekStartISO = EP.weekStart(x.date); extraActions(id); },
  shopwk: n => { const f = EP.addDays(EP.weekStart(curShopRange().from), +n); shopRange = { mode: 'week', from: f, to: EP.addDays(f, 6) }; rerender(); },
  estepadd: () => { readEditForm(); editState.steps.push(''); editState.dirty = true; rerender(); stepFocus(editState.steps.length - 1); },
  estepdel: i => { readEditForm(); editState.steps.splice(+i, 1); if (!editState.steps.length) editState.steps.push(''); editState.r.instructions = joinSteps(editState.intro, editState.steps); editState.dirty = true; rerender(); },
  estepmv: a => { readEditForm(); const [i, d] = a.split('|').map(Number), j = i + d, st = editState.steps; if (j < 0 || j >= st.length) return; [st[i], st[j]] = [st[j], st[i]]; editState.r.instructions = joinSteps(editState.intro, st); editState.dirty = true; const y = scrollY; rerender(); scrollTo(0, y); },
  estepmode: () => { readEditForm(); editState.insText = !editState.insText; if (!editState.insText) editState.steps = null; rerender(); },
  ekind: k => { readEditForm(); const r = editState.r; if (EP.laneOf(r) === k) return; if (!EP.ROTATES(EP.laneOf(r))) r.inRotation = true; if (!EP.ROTATES(k)) r.inRotation = false; if (k !== 'MAIN' && k !== 'SPECIAL') r.daysOverride = null; r.kind = k; if (k === 'CAKE' && r.servings <= 4) r.servings = 12; if (k !== 'CAKE' && r.servings > 8 && editState.isNew) r.servings = db.settings.portionsPerDay; editState.dirty = true; rerender(); },
  esideadd: () => {
    readEditForm();
    const r = editState.r, has = new Set(r.sides || []);
    recipePickSheet('Beilage verknüpfen', id => {
      if (id === r.id) return notify('Das ist dasselbe Rezept.');
      if (has.has(id)) return notify('Ist schon verknüpft.');
      r.sides = (r.sides || []).concat(id); editState.dirty = true; rerender();
    }, 'SIDE', { kinds: ['SIDE', 'MAIN', 'LUNCH', 'SPECIAL', 'CAKE'] });
  },
  esidedel: id => { readEditForm(); const r = editState.r; r.sides = (r.sides || []).filter(x => x !== id); editState.dirty = true; rerender(); },
  sideadd: a => { const [d, id] = a.split('|'); const s = recipeById(id); undoable(() => { const more = addSide(d, id); return `${s ? s.name : 'Beilage'} dazu eingeplant${sideMoreMsg(more)}.`; }); },
  sideoff: d => { weekStartISO = EP.weekStart(d); undoable(() => { dismissSides(weekEntries(EP.weekStart(d)), d); return 'Diesmal ohne Beilage.'; }); },
  cookside: id => { closeCook(); openCook(id); },
  emonth: m => { readEditForm(); m = +m; const r = editState.r; const set = new Set(r.seasonMonths || []); set.has(m) ? set.delete(m) : set.add(m); r.seasonMonths = [...set].sort((a, b) => a - b); editState.dirty = true; rerender(); },
  marketdays: () => marketDaysSheet(),
  inbox: () => inboxSheet(),
  shoplayout: () => shopLayoutSheet(),
  marketday: a => {
    const days = new Set(marketDaysOf()); days.has(+a) ? days.delete(+a) : days.add(+a);
    db.settings.marketDays = days.size === 7 ? null : [...days].sort(); EP.touch(db.settings); change();
    $$(`#scrim [data-act=marketday][data-arg="${a}"]`).forEach(b => b.setAttribute('aria-pressed', days.has(+a)));
  },
  laneday: a => {
    const [l, d] = a.split('|'); const days = new Set(laneDays(l)); days.has(+d) ? days.delete(+d) : days.add(+d);
    db.settings.lanes = Object.assign({}, db.settings.lanes, { [l]: { days: [...days] } }); EP.touch(db.settings); change();
    $$(`#scrim [data-act=laneday][data-arg="${a}"]`).forEach(b => b.setAttribute('aria-pressed', days.has(+d)));
  },
  lanedays: l => laneDaysSheet(l),
  specialdays: () => specialDaysSheet(),
  kindnames: () => kindNamesSheet(),
  special: d => { weekStartISO = EP.weekStart(d); specialPick(d); },
  setpick: k => {
    const o = { roundingMode: ['Bei krummen Portionen', [['FLOOR', 'Abrunden', '5 Portionen bei 2 pro Tag = 2 Tage, 1 Portion bleibt übrig'], ['CEIL', 'Aufrunden', '5 Portionen bei 2 pro Tag = 3 Tage, am letzten Tag nur 1 Portion']]],
      rotationMode: ['Reihenfolge der Rotation', [['SHUFFLE', 'Jedes Mal neu mischen', 'Jeder Durchlauf in anderer Reihenfolge'], ['FIXED', 'Feste Reihenfolge', 'Immer dieselbe Abfolge']]] }[k];
    optionsSheet(o[0], '', o[1].map(([v, l, h]) => ({ label: l, hint: h, icon: db.settings[k] === v ? 'check' : 'bowl', tone: db.settings[k] === v ? 'basil' : 'speckle', group: 0,
      run: () => { db.settings[k] = v; EP.touch(db.settings); change(); } })));
  },
  xsrc: (a, el) => { const k = a.split('|').pop(), name = el && el.dataset.name || a.split('|')[0]; setExtraSource(name, k); change(); },
  src: a => {
    const [id, v] = a.split('|'); const i = ingById(id);
    i.shoppingSource = v === EP.categorySource(i.category, db.settings) ? null : v; i.reviewed = true; EP.touch(i); change();
  },
  catsrc: a => {
    const [cat, v] = a.split('|');
    db.settings.categorySources = Object.assign({}, db.settings.categorySources, { [cat]: v }); EP.touch(db.settings);
    // einzelne Abweichungen, die jetzt der Kategorie entsprechen, aufheben
    EP.live(db.ingredients).filter(i => i.category === cat && i.shoppingSource === v).forEach(i => { i.shoppingSource = null; EP.touch(i); });
    change();
  },
  catall: a => {   // ganze Kategorie auf einen Einkaufsort setzen, einzelne Abweichungen aufheben
    const [cat, v] = a.split('|');
    db.settings.categorySources = Object.assign({}, db.settings.categorySources, { [cat]: v }); EP.touch(db.settings);
    EP.live(db.ingredients).filter(i => i.category === cat).forEach(i => { if (i.shoppingSource || i.reviewed === false) { i.shoppingSource = null; i.reviewed = true; EP.touch(i); } });
    change(`Alle ${(EP.CAT[cat] || {}).label || ''}: ${{ MARKT: 'Markt', SUPERMARKT: 'Supermarkt', DROGERIE: 'Drogerie', VORRAT: 'Vorrat' }[v]}.`);
  },
  srcok: () => { EP.live(db.ingredients).filter(i => i.reviewed === false).forEach(i => { i.reviewed = true; EP.touch(i); }); change('Einkaufsorte übernommen.'); },
  to: a => { if (a === 'sources') srcQuery = ''; go(a); },
  seed: async () => {
    const res = await importData({ data: seedToDb(SEED_DATA, EP) }, 'merge');
    change(`${res.added} Beispielrezepte geladen.`);
  },
  /* Vorschlag */
  accept: id => {   // auf den in der Tagesleiste gewählten Tag; danach weiter zum nächsten freien Tag
    const e = rotById(null, id), r = recipeById(e.recipeId), lane = EP.laneOf(e), t = suggestTarget(lane, r);
    undoable(() => {
      if (lane !== 'MAIN') {
        placeLane(t.date, lane, r.id, e.id);
        suggestPick[lane] = { date: firstLaneDay(lane, EP.addDays(t.date, 1)), replace: null };
        return `${r.name}: ${shortRange([t.date])}`;
      }
      if (t.replace) removeBlock(t.replace, true);
      const ds = placeBlock(t.date, { recipeId: r.id, rotationEntryId: e.id });
      suggestPick.MAIN = { date: firstFreeFrom(EP.addDays(ds[ds.length - 1], 1)), replace: null };
      return `${r.name}: ${shortRange(ds)}`;
    });
  },
  sday: d => {   // Tag in der Tagesleiste antippen
    const lane = suggestLane, p = suggestBusy(lane, d), set = (date, replace) => { suggestPick[lane] = { date, replace: replace || null }; rerender(); };
    if (!p) return set(d);
    const title = `${EP.weekdayLong(d)}, ${EP.fmtShort(d)}`;
    const nextFree = () => set(lane === 'MAIN' ? firstFreeFrom(EP.addDays(d, 1)) : firstLaneDay(lane, EP.addDays(d, 1)));
    if (p.type === 'BLOCKED') return optionsSheet(title, `Gesperrt: ${esc(p.note || 'kein Kochen')}`, [
      { label: 'Tag freigeben und hier planen', icon: 'unpin', run: () => { unblockDay(d); suggestPick[lane] = { date: d, replace: null }; change('Tag freigegeben.'); } },
      { label: 'Nächster freier Tag danach', icon: 'move', run: nextFree }]);
    const r = recipeById(p.recipeId);
    if (p.status === 'DONE') return optionsSheet(title, esc(r ? r.name : ''), [{ label: 'Nächster freier Tag danach', icon: 'move', run: nextFree }]);
    optionsSheet(title, `Hier steht schon „${esc(r ? r.name : 'ein Gericht')}“.`, [
      { label: `„${r ? r.name : 'Gericht'}“ ersetzen`, hint: p.dayCount > 1 && lane === 'MAIN' ? 'Ersetzt das Gericht samt Resttagen' : 'Der Vorschlag kommt an diesen Tag', icon: 'swap', run: () => set(d, p.blockId) },
      { label: 'Nächster freier Tag danach', icon: 'move', run: nextFree }]);
  },
  postpone: id => { EP.postpone(db, rotById(null, id)); change('Kommt später wieder dran.'); },
  skip: id => {
    const e = rotById(null, id), r = recipeById(e.recipeId);
    confirmSheet('Diesmal auslassen?', `„${r.name}“ wird in diesem Durchlauf übersprungen und kommt erst im nächsten wieder.`, 'Auslassen', 'Zurück', () => { EP.skipEntry(e); change('Ausgelassen.'); });
  },
  pickself: () => recipePickSheet('Selbst wählen', id => {
    const r = recipeById(id), lane = suggestLane;
    const place = (d, fn) => pickCheck(id, d, null, o => undoable(() => {
      if (o) removeOther(o);
      const e = EP.manualPickEntry(db, id), m = pickMsg(id, e, o); fn(d, e); return m.replace(/^Eingeplant/, 'Eingeplant am ' + EP.fmtShort(d));
    }));
    const t = suggestTarget(lane, r);   // gleicher Zieltag wie in der Tagesleiste
    if (lane !== 'MAIN') return place(t.date, (d2, e) => { placeLane(d2, lane, id, e ? e.id : null); suggestPick[lane] = { date: firstLaneDay(lane, EP.addDays(d2, 1)), replace: null }; });
    place(t.date, (d2, e) => {
      if (t.replace) removeBlock(t.replace, true);
      const ds = placeBlock(d2, { recipeId: id, rotationEntryId: e ? e.id : null });
      suggestPick.MAIN = { date: firstFreeFrom(EP.addDays(ds[ds.length - 1], 1)), replace: null };
    });
  }, suggestLane),
  /* Woche */
  wk: a => {
    const n = +a; weekStartISO = n === 0 ? EP.weekStart(EP.todayISO()) : EP.addDays(weekStartISO, n);
    rerender(); if (n === 0) scrollToToday(); else scrollToWeek(weekStartISO);
  },
  wkmore: () => { if (!weekRange || weekRange.weeks >= 60) return; weekRange.weeks += 4; const y = window.scrollY; rerender(); window.scrollTo(0, y); },
  wkearlier: () => {   // eine Woche davor einblenden und zeigen
    weekRange.from = EP.addDays(weekRange.from, -7); weekRange.weeks++;
    rerender(); scrollToWeek(weekRange.from);
  },
  day: d => { weekStartISO = EP.weekStart(d); dayActions(d); },
  fill: ws => {
    if (!EP.activeRecipes(db).length) return notify('Keine Rezepte in der Rotation.');
    if (ws) weekStartISO = ws;
    startDraft(weekStartISO); rerender(); scrollToWeek(weekStartISO);
  },
  discard: () => { draft = null; rerender(); notify('Entwurf verworfen.'); },
  commit: async () => { const ws = draft && draft.ws; commitDraft(); await change('Plan übernommen.'); try { await Sync.run(); } catch (e) {} if (ws) Notes.planCommitted(ws); },
  toshop: ws => { const f = ws || weekStartISO; shopRange = { mode: 'week', from: f, to: EP.addDays(f, 6) }; go('shop'); },
  /* Einkauf */
  addextra: () => {
    const inp = $('#extra'); const t = inp.value.trim(); if (!t) return;
    const res = addExtraItem(t); if (!res) return;
    const cat = EP.extraCategory(res.name, db.settings.extraCats), lbl = (EP.CAT[cat] || EP.CAT.SONSTIGES).label;
    const msg = res.exists ? `${res.name} steht schon auf der Liste.` : res.merged ? `${res.name}: jetzt ${res.amount}` : `${res.name}${res.amount ? ` (${res.amount})` : ''} → ${lbl}`;
    change(msg).then(() => { const i = $('#extra'); if (i) i.focus(); });
  },
  recentx: t => { const res = addExtraItem(t); change(res && res.exists ? `${res.name} steht schon auf der Liste.` : `${t} hinzugefügt`); },
  recentedit: () => { recentEdit = !recentEdit; rerender(); },
  suggfold: () => { setSuggFolded(!suggFolded()); recentEdit = false; const y = scrollY; rerender(); scrollTo(0, y); },
  storepick: k => storePickSheet(k),
  storeadd: k => storeAddSheet(k),
  storeopen: id => go('store', { id }),
  storename: () => { const s = curStore(); if (s) textSheet('Geschäft umbenennen', '', s.name, 'Speichern', v => { s.name = v; storesSave(); }); },
  storekind: () => {
    const s = curStore(); if (!s) return;
    optionsSheet('Einkaufsort', `Wofür nutzt du „${s.name}“?`, EP.STORE_KINDS.map(([k, l]) => ({ label: l, icon: k === s.kind ? 'check' : 'bowl', tone: k === s.kind ? 'basil' : 'speckle', group: 0,
      run: () => {
        if (k === s.kind) return;
        const d = Object.assign({}, db.settings.storeDefault);
        if (d[s.kind] === s.id) delete d[s.kind];
        if (!EP.storeById(db.settings, d[k])) d[k] = s.id;
        db.settings.storeDefault = d; s.kind = k; s.order = (s.order || []).filter(x => x.startsWith('S:'));
        storesSave(`${s.name}: ${l}`);
      } })));
  },
  storemv: a => {
    const s = curStore(); if (!s) return;
    const [key, dir] = a.split('|'), keys = EP.storeOrder(s, db.settings).map(o => o.key), i = keys.indexOf(key), j = i + +dir;
    if (i < 0 || j < 0 || j >= keys.length) return;
    [keys[i], keys[j]] = [keys[j], keys[i]]; s.order = keys; storesSave();
  },
  secadd: () => {
    const s = curStore(); if (!s) return;
    textSheet('Neuer Bereich', `Eigener Bereich in „${s.name}“, z. B. „Bio-Regal“. Danach Artikel zuordnen und an die richtige Stelle schieben.`, '', 'Anlegen', v => {
      const sec = { id: EP.uuid().slice(0, 8), name: v };
      s.sections = (s.sections || []).concat([sec]); storesSave(); sectionSheet(sec.id);
    });
  },
  secopen: id => sectionSheet(id),
  storedel: () => {
    const s = curStore(); if (!s) return;
    confirmSheet(`„${s.name}“ löschen?`, 'Die Reihenfolge und die eigenen Bereiche dieses Geschäfts gehen verloren.', 'Löschen', 'Abbrechen', () => {
      s.deleted = true;
      const d = Object.assign({}, db.settings.storeDefault);
      if (d[s.kind] === s.id) { const other = EP.liveStores(db.settings).find(x => x.kind === s.kind); if (other) d[s.kind] = other.id; else delete d[s.kind]; }
      db.settings.storeDefault = d; EP.touch(db.settings); persist();
      back(); notify(`${s.name} gelöscht`);
    }, true);
  },
  recentdel: t => {
    const n = EP.normExtra(t);
    db.settings.recentExtras = (db.settings.recentExtras || []).filter(x => EP.normExtra(x) !== n);
    const st = Object.assign({}, extraStats()); if (st[n]) st[n] = Object.assign({}, st[n], { hidden: true });   // bis zum nächsten Eintragen ausgeblendet
    db.settings.extraStats = st; EP.touch(db.settings);
    if (!EP.extraSuggestions(st, EP.todayISO(), null, 1).length) recentEdit = false;
    change(`${t} aus den Vorschlägen entfernt`);
  },
  xcat: i => extraCatSheet(i),
  xedit: i => extraEditSheet(i),
  clearchecked: () => {   // abgehakte Einträge ausblenden, zusätzliche Artikel löschen – mit Rückgängig
    const st = shopState(), rows = shopRows(curShopList()).filter(r => r.checked);
    const units = [].concat(...rows.filter(r => r.extra == null).map(r => r.units));
    const xs = st.extras.filter(x => rows.some(r => r.extra === x.id || (r.extras || []).includes(x.id)));
    const all = rows.length === shopRows(curShopList()).length, prevFloor = st.carryFrom;
    EP.shopMark(db, 'removed', units, true);
    xs.forEach(x => { x.del = true; EP.touch(x); });
    if (all) st.carryFrom = EP.todayISO();   // Liste komplett geleert: Älteres taucht nie wieder als Übertrag auf
    EP.touch(st);
    const n = rows.length;
    persist().then(() => { rerender(); notify(`${n} entfernt`, () => {
      EP.shopMark(db, 'removed', units, false); xs.forEach(x => { x.del = false; EP.touch(x); }); st.carryFrom = prevFloor; EP.touch(st); change('Wiederhergestellt');
    }); });
  },
  showremoved: () => {
    const r = curShopRange(), st = shopState();
    EP.shopMark(db, 'removed', EP.shopUnits(db, r.from, r.to).units.map(u => u.key), false);   // auch vom verschobenen Vorgänger geerbte
    change('Wieder eingeblendet');
  },
  shopparts: k => { shopOpen.has(k) ? shopOpen.delete(k) : shopOpen.add(k); const y = scrollY; rerender(); scrollTo(0, y); },
  delextra: i => { const st = shopState(), x = st.extras.find(e => e.id === i); if (!x) return; x.del = true; EP.touch(x); EP.touch(st); change(); },
  shopmode: m => {
    if (m === 'all') shopRange = { mode: 'all' };
    else { const f = EP.weekStart(EP.todayISO()); shopRange = { mode: 'week', from: f, to: EP.addDays(f, 6) }; }
    rerender();
  },
  copyshop: () => {
    const t = shopText();
    (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => notify('Einkaufsliste kopiert.')).catch(() => notify('Kopieren nicht möglich.'));
  },
  shareshop: () => navigator.share({ title: 'Einkaufsliste', text: shopText() }).catch(() => {}),
  printshop: () => window.print(),
  /* Rezepte */
  qa: (force) => {
    const inp = $('#qa'); const v = inp.value.trim(); if (!v) return;
    const sim = force === true || findRecipeByName(v) ? [] : EP.similarRecipes(db, v, recipeFilter.kind);
    if (sim.length) return similarSheet(v, sim);
    const res = quickAdd([v], recipeFilter.kind);
    inp.value = '';
    change(res.added ? 'Angelegt.' : res.restored ? 'Wiederhergestellt.' : 'Dieses Rezept gibt es schon.').then(() => { const i = $('#qa'); if (i) i.focus(); });
  },
  rimport: () => quickImport(),
  rexport: () => exportSheet(),
  rstatus: a => { recipeFilter.status = a; rerender(); },
  rsort: () => sortSheet(),
  rtag: a => { recipeFilter.tag = recipeFilter.tag === a ? '' : a; rerender(); },
  w: a => { const [id, d] = a.split('|'); const r = recipeById(id); setWeight(r, r.weight + (+d)); change(); },
  edit: id => openEdit(id),
  cook: id => openCook(id),
  cookpan: () => cookPan(),
  epan: () => { readEditForm(); const r = editState.r; panSheet({ title: 'Backform des Rezepts', sub: 'Für diese Form sind die Mengen gedacht.', cur: r.pan, reset: r.pan ? 'Keine Angabe' : '',
    onPick: p => { r.pan = p; editState.dirty = true; rerender(); } }); },
  fav: id => { const r = recipeById(id); if (!r) return; r.favorite = !r.favorite; EP.touch(r); change(r.favorite ? '★ Favorit.' : 'Kein Favorit mehr.'); },
  cookreset: () => { cookState.done.clear(); saveCookProgress(); const el = $('#cookview'), y = el.scrollTop; renderCook(); el.scrollTop = y; },
  closecook: () => closeCook(),
  cookprep: () => cookPrepToggle(),
  cookpp: d => cookPortions(+d),
  cookedit: id => { closeCook(); ACT.edit(id); },
  /* Editor */
  serv: d => { readEditForm(); editState.r.servings = Math.max(1, Math.min(99, editState.r.servings + (+d))); editState.dirty = true; rerender(); },
  ew: d => { readEditForm(); editState.r.weight = Math.max(1, Math.min(5, editState.r.weight + (+d))); editState.dirty = true; rerender(); },
  rowadd: () => { readEditForm(); editState.rows.push({ name: '', qty: '', unit: '', note: '', cat: 'SONSTIGES' }); editState.dirty = true; rerender();
    const rows = $$('[data-row]'); const last = rows[rows.length - 1]; if (last) $('[data-f=qty]', last).focus(); },
  rowdel: i => { readEditForm(); editState.rows.splice(+i, 1); editState.dirty = true; rerender(); },
  rowup: i => { readEditForm(); i = +i; if (i > 0) [editState.rows[i - 1], editState.rows[i]] = [editState.rows[i], editState.rows[i - 1]]; editState.dirty = true; rerender(); },
  rowdown: i => { readEditForm(); i = +i; if (i < editState.rows.length - 1) [editState.rows[i + 1], editState.rows[i]] = [editState.rows[i], editState.rows[i + 1]]; editState.dirty = true; rerender(); },
  save: () => saveEdit(),
  archive: () => confirmSheet('Rezept löschen?', 'Es verschwindet aus dem Fundus und der Rotation. Bereits geplante Tage bleiben sichtbar.', 'Löschen', 'Behalten', () => {
    const r = recipeById(editState.r.id); archiveRecipe(r); editState = null; route = stack.pop() || { name: 'recipes' }; change('Gelöscht.');
  }, true),
  imgadd: () => { readEditForm(); $('#e-file').click(); },
  img: key => {
    readEditForm();
    const imgs = editState.r.images;
    optionsSheet('Bild', '', [
      { label: 'Als Titelbild verwenden', run: () => { imgs.forEach(i => i.isCover = i.fileKey === key); editState.dirty = true; rerender(); } },
      { label: 'Bild entfernen', danger: true, run: () => {
        const i = imgs.findIndex(x => x.fileKey === key); const wasCover = imgs[i].isCover;
        imgs.splice(i, 1); if (wasCover && imgs[0]) imgs[0].isCover = true;
        Images.remove(key); editState.dirty = true; rerender();
      } },
    ]);
  },
  /* Zutaten, Rotation */
  ingnew: () => ingredientSheet(null),
  ing: id => ingredientSheet(id),
  rpost: id => { EP.postpone(db, rotById(null, id)); change('Ans Ende verschoben.'); },
  rskip: id => { EP.skipEntry(rotById(null, id)); change('Ausgelassen.'); },
  rreset: () => confirmSheet('Rotation neu starten?', 'Alle offenen Einträge werden verworfen und für Hauptgerichte, Mittag und Kuchen neu gemischt. Bereits geplante Tage bleiben erhalten.', 'Neu starten', 'Abbrechen', () => { EP.LANES.forEach(l => EP.resetRotation(db, rng, l.key, EP.monthOf(EP.todayISO()))); change('Neuer Durchlauf gestartet.'); }, true),
  sortup: id => moveSort(id, -1),
  sortdown: id => moveSort(id, 1),
  /* Einstellungen */
  ppd: d => { db.settings.portionsPerDay = Math.max(1, Math.min(12, db.settings.portionsPerDay + (+d))); EP.touch(db.settings); change(); },
  set: a => { const [k, v] = a.split('|'); db.settings[k] = v; EP.touch(db.settings); change(); },
  export: async () => {
    const txt = await exportData($('#s-img') && $('#s-img').checked);
    const blob = new Blob([txt], { type: 'application/json' });
    const name = `essensplanung-${EP.todayISO()}.json`;
    const file = typeof File !== 'undefined' ? new File([blob], name, { type: 'application/json' }) : null;
    if (file && navigator.canShare && navigator.canShare({ files: [file] })) { navigator.share({ files: [file], title: 'Essensplanung-Sicherung' }).catch(() => {}); return; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  },
  import: () => $('#s-file').click(),
  chpw: () => changePasswordSheet(),
  konto: () => { location.href = 'index.html#konto'; },
  mitteilungen: () => { location.href = 'index.html#mitteilungen'; },
  logout: () => confirmSheet('Abmelden?', 'Die Daten bleiben auf diesem Gerät gespeichert. Zum Öffnen brauchst du wieder dein Passwort.', 'Abmelden', 'Abbrechen', () => { Auth.logout(); location.reload(); }),
  syncsetup: () => setupSync(),
  pbcreate: () => pbCreate($('#pb-pw1').value),
  pbmigrate: () => pbMigrate(),
  pbjoinhere: () => pbJoinHere(),
  invsend: async () => {
    const inp = $('#inv-n'), name = inp.value.trim(); if (!name) return notify('Bitte einen Benutzernamen eingeben.');
    const b = $('[data-act=invsend]'); b.disabled = true; b.textContent = 'Sende …';
    try {
      const r = await Konto.invite(name, 'essen:' + Sync.repo.pb, { app: 'essen', id: Sync.repo.pb, secret: Auth.token, label: db.household.name });
      inp.value = ''; $('#inv-s').textContent = '';
      notify(`Einladung an ${r.to} gesendet – gültig bis ${EP.weekday(r.expiresAt.slice(0, 10))} ${EP.fmtShort(r.expiresAt.slice(0, 10))}`);
      renderInvites();
    } catch (e) { notify(e.offline ? 'Keine Verbindung zum Server.' : e.message); }
    finally { b.disabled = false; b.textContent = 'Einladen'; }
  },
  invw: iid => confirmSheet('Einladung zurückziehen?', 'Die Person sieht die Einladung danach nicht mehr.', 'Zurückziehen', 'Abbrechen', async () => {
    try { await Konto.withdraw(iid); notify('Zurückgezogen.'); } catch (e) { notify(e.message); } renderInvites();
  }, true),
  invf: iid => { Konto.forget(iid); renderInvites(); },
  pbcopy: async () => { const l = $('#pb-link'); try { await navigator.clipboard.writeText(l.value); notify('Link kopiert.'); } catch (e) { l.focus(); l.select(); notify('Link markiert – jetzt kopieren.'); } },
  pbshare: () => navigator.share({ title: 'Essensplanung verbinden', url: $('#pb-link').value }).catch(() => {}),
  syncnow: () => Sync.run({ force: true }).then(rerender),
  syncoff: () => confirmSheet('Abgleich trennen?', 'Die Daten bleiben auf diesem Gerät. Andere Geräte gleichen sich weiterhin untereinander ab.', 'Trennen', 'Abbrechen', async () => {
    const c = Auth.cfg; c.tokenEnc = null; c.repo = null; Auth.cfg = c; Auth.token = null;
    const s = LS.get('ep_session'); if (s) { s.tokenEnc = null; LS.set('ep_session', s); }
    Sync.setState('off'); rerender(); notify('Abgleich getrennt.');
  }, true),
};
function moveSort(id, dir) {
  const act = EP.activeRecipes(db).sort((a, b) => a.sortOrder - b.sortOrder);
  const i = act.findIndex(r => r.id === id), j = i + dir;
  if (j < 0 || j >= act.length) return;
  [act[i], act[j]] = [act[j], act[i]];
  act.forEach((r, k) => { if (r.sortOrder !== k + 1) { r.sortOrder = k + 1; EP.touch(r); } });
  change();
}
function changePasswordSheet() {
  openSheet(`<h2>Passwort ändern</h2>
    <label class="field"><span>Bisheriges Passwort</span><input class="in" type="password" id="p0" autocomplete="current-password"></label>
    <label class="field"><span>Neues Passwort</span><input class="in" type="password" id="p1" autocomplete="new-password"></label>
    <label class="field"><span>Neues Passwort wiederholen</span><input class="in" type="password" id="p2" autocomplete="new-password"></label>
    
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Ändern</button></div>`, el => {
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = async () => {
      const p0 = $('#p0', el).value, p1 = $('#p1', el).value, p2 = $('#p2', el).value;
      if (!(await Crypt.check(p0, db.household.verifier))) return notify('Das bisherige Passwort stimmt nicht.');
      if (p1.length < 6) return notify('Das neue Passwort braucht mindestens 6 Zeichen.');
      if (p1 !== p2) return notify('Die neuen Passwörter stimmen nicht überein.');
      db.household.verifier = await Crypt.verifier(p1); EP.touch(db.household);
      if (Auth.token) await Auth.storeToken(p1, Auth.token, Sync.repo);
      closeSheet(); change('Passwort geändert.');
    };
  });
}

/* Bindungen je Ansicht (Eingabefelder) */
const BIND = {
  sync: m => {
    const inp = $('#inv-n', m); if (!inp) return;
    renderInvites();
    let t = null;
    inp.oninput = () => {
      clearTimeout(t); const v = inp.value.trim(), h = $('#inv-s', m);
      if (!v) { h.textContent = ''; return; }
      t = setTimeout(async () => {
        try {
          const p = await Konto.findUser(v);
          if (inp.value.trim() !== v) return;
          h.textContent = !p ? 'Kein Konto mit diesem Namen' : p.user.toLowerCase() === Konto.user().toLowerCase() ? 'Das bist du selbst' : `✓ ${p.user} gefunden`;
          h.classList.toggle('warn', !p);
        } catch (e) { h.textContent = ''; }
      }, 500);
    };
    inp.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); ACT.invsend(); } };
  },
  store: m => {
    const c = $('#st-def', m), s = curStore(); if (!c || !s) return;
    c.onchange = () => {
      const d = Object.assign({}, db.settings.storeDefault);
      if (c.checked) d[s.kind] = s.id; else if (d[s.kind] === s.id) delete d[s.kind];
      db.settings.storeDefault = d; storesSave(c.checked ? `${s.name} ist Standard` : '');
    };
  },
  suggest: m => { const s = $('.dstrip .start', m); if (s && s.scrollIntoView) { const st = $('.dstrip', m); st.scrollLeft = Math.max(0, s.offsetLeft - st.clientWidth / 2 + s.offsetWidth / 2); } },
  week: m => {
    const top = $('.top'); if (top) document.documentElement.style.setProperty('--toph', top.offsetHeight + 'px');
    weekScroll();
    const more = $('#wkmore', m);
    if (more && 'IntersectionObserver' in window) {
      const io = new IntersectionObserver(es => { if (es.some(e => e.isIntersecting) && route.name === 'week') { io.disconnect(); ACT.wkmore(); } }, { rootMargin: '400px 0px' });
      io.observe(more);
    }
  },
  sources: m => {
    $$('details[data-cat]', m).forEach(d => d.addEventListener('toggle', () => { d.open ? srcOpen.add(d.dataset.cat) : srcOpen.delete(d.dataset.cat); }));
    const q = $('#srcq', m), x = $('#srcx', m);
    const upd = () => { srcQuery = q.value; $('#srcres', m).innerHTML = srcResults(srcQuery); $('#srcrest', m).classList.toggle('hidden', !!srcQuery.trim()); x.classList.toggle('hidden', !srcQuery); };
    q.oninput = upd;
    q.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); q.blur(); } };
    x.onclick = () => { q.value = ''; upd(); q.focus(); };
  },
  shop: m => {
    const setRange = () => {
      const f = $('#sf', m).value, t = $('#st', m).value;
      if (f && t && f <= t) { shopRange = { mode: 'custom', from: f, to: t }; rerender(); }
    };
    if ($('#sf', m)) { $('#sf', m).onchange = setRange; $('#st', m).onchange = setRange; }
    const updClean = () => {   // Knopf „Abgehakte entfernen“ ohne Neuaufbau (Scrollposition bleibt)
      const n = $$('[data-check]:checked, [data-extra]:checked', m).length, b = $('[data-act=clearchecked]', m), w = $('.shopclean', m);
      b.textContent = `Abgehakte entfernen (${n})`; b.classList.toggle('hidden', !n);
      w.classList.toggle('hidden', !n && !$('[data-act=showremoved]', m));
    };
    $$('[data-check]', m).forEach(c => c.onchange = () => {
      const row = shopRows(curShopList()).find(r => r.key === c.dataset.check); if (!row) return;
      EP.shopMark(db, 'bought', row.units, c.checked);
      if (row.extras && row.extras.length) { const st = shopState(); st.extras.filter(x => row.extras.includes(x.id)).forEach(x => { x.checked = c.checked; EP.touch(x); }); EP.touch(st); }
      persist(); strikeRow(c.closest('.item'), c.checked); updClean();
      if (shopOpen.has(row.key)) { const y = scrollY; rerender(); scrollTo(0, y); }
    });
    $$('[data-extra]', m).forEach(c => c.onchange = () => {
      const st = shopState(), x = st.extras.find(e => e.id === c.dataset.extra); if (!x) return;
      x.checked = c.checked; EP.touch(x); EP.touch(st); persist(); strikeRow(c.closest('.item'), c.checked); updClean();
    });
    const ex = $('#extra', m); if (ex) ex.onkeydown = e => { if (e.key === 'Enter') ACT.addextra(); };
  },
  recipes: m => {
    const qa = $('#qa', m);
    qa.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); ACT.qa(); } };
    qa.addEventListener('paste', e => {
      const t = (e.clipboardData || window.clipboardData).getData('text');
      if (!/\n/.test(t)) return;
      e.preventDefault();
      const res = quickAdd(t.split(/\r?\n/), recipeFilter.kind);
      change(`${res.added} angelegt${res.restored ? `, ${res.restored} wiederhergestellt` : ''}${res.skipped ? `, ${res.skipped} schon vorhanden` : ''}.`);
    });
    const rq = $('#rq', m);
    if (rq) rq.oninput = () => {
      recipeFilter.q = rq.value; const pos = rq.selectionStart; rerender();
      const n = $('#rq'); if (n) { n.focus(); n.setSelectionRange(pos, pos); }
    };
    $$('[data-rot]', m).forEach(c => c.onchange = () => { setInRotation(recipeById(c.dataset.rot), c.checked); change(c.checked ? 'In Rotation.' : 'Pausiert.'); });
  },
  edit: m => {
    $$('input,textarea,select', m).forEach(el => el.addEventListener('input', () => { if (editState) editState.dirty = true; }));
    growSteps();
    const refreshRow = el => {
      const rowEl = el.closest('[data-row]');
      const name = $('[data-f=name]', rowEl).value.trim();
      const ing = name ? findIngredient(name) : null;
      $('.newcat', rowEl).classList.toggle('hidden', !name || !!ing);
      const cat = $('[data-f=cat]', rowEl);
      if (!ing && name && !cat.dataset.touched) cat.value = EP.guessCategory(name); // Kategorie vorschlagen
      const unit = $('[data-f=unit]', rowEl);
      if (ing && !unit.value && $('[data-f=qty]', rowEl).value.trim()) unit.value = ing.defaultUnit;
    };
    $$('[data-f=name]', m).forEach(el => { el.addEventListener('change', () => refreshRow(el)); el.addEventListener('input', () => refreshRow(el)); });
    $$('[data-f=qty]', m).forEach(el => el.addEventListener('change', () => refreshRow(el)));
    $$('[data-f=cat]', m).forEach(el => el.addEventListener('change', () => { el.dataset.touched = '1'; }));
    const ay = $('#e-allyear', m);
    if (ay) ay.onchange = () => {
      readEditForm();
      editState.r.seasonMonths = ay.checked ? null : [EP.monthOf(EP.todayISO())];
      editState.dirty = true; rerender();
    };
    const days = $('#e-days', m);
    if (days) days.oninput = () => {
      const d = parseInt(days.value, 10); editState.r.daysOverride = d > 0 ? d : null;
      $('#e-live').textContent = liveDaysText(editState.r);
      $('#e-hint').textContent = EP.daysHint(editState.r, db.settings);
    };
    $('#e-file', m).onchange = async e => {
      readEditForm();
      const files = [...e.target.files];
      for (const f of files) {
        try {
          const p = await Images.process(f);
          const key = EP.uuid();
          await Images.put(key, p.full, p.thumb);
          const imgs = editState.r.images;
          imgs.push({ fileKey: key, width: p.width, height: p.height, sortOrder: imgs.length + 1, isCover: !imgs.some(i => i.isCover) });
          editState.dirty = true;
        } catch (err) { notify(err.message); }
      }
      rerender();
    };
  },
  ingredients: m => {
    const q = $('#iq', m);
    q.oninput = () => { ingQuery = q.value; const pos = q.selectionStart; rerender(); const n = $('#iq'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } };
  },
  settings: m => {
    $('#s-mq', m).onchange = e => { db.settings.marketListShowQuantities = e.target.checked; EP.touch(db.settings); change(); };
    const spf = $('#s-spfree', m); if (spf) spf.onchange = e => { db.settings.specialKeepFree = e.target.checked; EP.touch(db.settings); change(); };
    $('#s-file', m).onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      let json;
      try { json = JSON.parse(await f.text()); } catch (err) { return notify('Die Datei ist keine gültige Sicherung.'); }
      const d = json.data || json;
      const n = (d.recipes || []).filter(r => !r.deleted && !r.archivedAt).length;
      optionsSheet('Sicherung einlesen', `Die Datei enthält ${n} Rezepte.`, [
        { label: 'Zusammenführen', hint: 'Neue Rezepte ergänzen, gleichnamige aktualisieren', run: async () => { const r = await importData(json, 'merge'); change(`${r.added} ergänzt, ${r.updated} aktualisiert.`); } },
        { label: 'Alles ersetzen', danger: true, hint: 'Rezepte, Zutaten, Rotation und Plan werden durch die Sicherung ersetzt', run: () =>
          confirmSheet('Wirklich alles ersetzen?', 'Der aktuelle Stand geht dabei verloren – auch auf verbundenen Geräten.', 'Ersetzen', 'Abbrechen', async () => { await importData(json, 'replace'); change('Sicherung eingelesen.'); }, true) },
      ]);
      e.target.value = '';
    };
  },
};

/* ---------- Anmeldung, Einrichtung ---------- */
function showAuth(html, bind) {
  $('#shell').classList.add('hidden');
  const a = $('#auth'); a.classList.remove('hidden');
  a.innerHTML = `<div class="auth"><div class="mark" aria-hidden="true"></div>${html}
    <p style="text-align:center;margin-top:28px"><a class="backlink" href="index.html">Zurück zur Übersicht</a></p></div>`;
  if (bind) bind(a);
}
function authWelcome() {
  showAuth(`<h1>Essensplanung</h1><p class="lead">Rezepte sammeln, der Reihe nach kochen, Woche planen und einkaufen.</p>
    <div class="btns" style="margin-top:28px"><button class="btn primary" data-x="new">Neuen Haushalt einrichten</button>
    <button class="btn" data-x="join">Mit bestehendem Haushalt verbinden</button></div>
    <p class="hint" style="text-align:center">Verbinden, wenn die Essensplanung schon auf einem anderen Gerät eingerichtet ist.</p>`, a => {
    $('[data-x=new]', a).onclick = authSetup;
    $('[data-x=join]', a).onclick = () => authJoin(pendingJoin);
  });
}
function authSetup() {
  showAuth(`<h1>Neuer Haushalt</h1>
    <label class="field"><span>Name des Haushalts</span><input class="in" id="a-n" placeholder="z. B. Familie Muster"></label>
    ${Konto.loggedIn() ? `<p class="hint">Der Haushalt wird mit deinem Konto <b>${esc(Konto.user())}</b> verknüpft und erscheint automatisch auf deinen anderen Geräten – kein eigenes Passwort nötig.</p>` : `<label class="field"><span>Passwort</span><input class="in" type="password" id="a-p1" autocomplete="new-password"></label>
    <label class="field"><span>Passwort wiederholen</span><input class="in" type="password" id="a-p2" autocomplete="new-password"></label>
    <p class="hint">Mit diesem Passwort öffnest du die Essensplanung auf allen Geräten. Den Abgleich zwischen Geräten richtest du danach in den Einstellungen ein. Tipp: Mit einem Konto (im Hauptmenü) geht es ohne eigenes Passwort.</p>`}
    <div class="btns"><button class="btn primary" data-x="ok">Einrichten</button><button class="btn quiet" data-x="back">Zurück</button></div>`, a => {
    $('[data-x=back]', a).onclick = authWelcome;
    $('[data-x=ok]', a).onclick = async () => {
      const k = Konto.loggedIn(), rnd = k ? PB.newSecret() : '';
      const n = $('#a-n', a).value.trim(), p1 = k ? rnd : $('#a-p1', a).value, p2 = k ? rnd : $('#a-p2', a).value;
      if (!n) return notify('Bitte einen Namen eingeben.');
      if (p1.length < 6) return notify('Das Passwort braucht mindestens 6 Zeichen.');
      if (p1 !== p2) return notify('Die Passwörter stimmen nicht überein.');
      db = emptyDb();
      db.household = EP.touch({ name: n, verifier: await Crypt.verifier(p1) });
      await Store.set('db', db);
      await Auth.startSession(null);
      enterApp(); kontoEnsure();
    };
  });
}
function authJoin(prefill) {
  showAuth(`<h1>Verbinden</h1><p class="lead">Auf dem Gerät, auf dem die Essensplanung schon läuft: Einstellungen → Geräteabgleich → „Link kopieren“. Den Link hier einfügen oder direkt auf diesem Gerät öffnen.</p>
    <label class="field"><span>Verbindungslink</span><input class="in" id="jl-l" value="${esc(prefill || '')}" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="…/essensplanung.html#join=…"></label>
    <label class="field"><span>Haushaltspasswort</span><input class="in" type="password" id="jl-p" autocomplete="current-password"></label>
    <div class="btns"><button class="btn primary" data-x="ok">Verbinden</button><button class="btn quiet" data-x="back">Zurück</button></div>
    <p style="text-align:center;margin-top:18px"><button class="btn quiet" data-x="gh">Über GitHub-Repository verbinden (alt)</button></p>`, a => {
    $('[data-x=back]', a).onclick = authWelcome;
    $('[data-x=gh]', a).onclick = authJoinGH;
    $('[data-x=ok]', a).onclick = async () => {
      const j = PB.parseLink($('#jl-l', a).value), pw = $('#jl-p', a).value;
      if (!j) return notify('Das sieht nicht nach einem Verbindungslink aus.');
      if (!pw) return notify('Bitte das Haushaltspasswort eingeben.');
      try {
        const f = await PB.fetchHousehold(j.id, j.secret);
        if (!(await Crypt.check(pw, f.remote.household && f.remote.household.verifier))) return notify('Das Passwort passt nicht zu diesem Haushalt.');
        db = f.remote; Sync.sha = f.updated; Sync.remoteRev = f.rev; Sync.dirty = false; Sync.lastSync = Date.now();
        await Store.set('db', db); await Sync.saveMeta();
        await Auth.startSession(j.secret);
        await Auth.storeToken(pw, j.secret, { pb: j.id });
        pendingJoin = '';
        enterApp(); kontoEnsure();
      } catch (e) { notify(e.message || 'Verbinden fehlgeschlagen.'); }
    };
  });
}
function authJoinGH() {
  showAuth(`<h1>Verbinden</h1><p class="lead">Die Daten liegen im privaten GitHub-Repository, das du beim ersten Gerät eingerichtet hast.</p>
    <label class="field"><span>GitHub-Benutzername</span><input class="in" id="j-o" autocapitalize="off" autocomplete="off"></label>
    <label class="field"><span>Repository</span><input class="in" id="j-r" value="essensplanung-daten" autocapitalize="off" autocomplete="off"></label>
    <label class="field"><span>Token</span><input class="in" type="password" id="j-t" autocomplete="off" placeholder="github_pat_…"></label>
    <label class="field"><span>Haushaltspasswort</span><input class="in" type="password" id="j-p" autocomplete="current-password"></label>
    <div class="btns"><button class="btn primary" data-x="ok">Verbinden</button><button class="btn quiet" data-x="back">Zurück</button></div>`, a => {
    $('[data-x=back]', a).onclick = () => authJoin();
    $('[data-x=ok]', a).onclick = async () => {
      const o = $('#j-o', a).value.trim(), n = $('#j-r', a).value.trim(), t = $('#j-t', a).value.trim(), pw = $('#j-p', a).value;
      if (!o || !n || !t || !pw) return notify('Bitte alle Felder ausfüllen.');
      try {
        await Sync.checkRepo(o, n, t);
        Auth.token = t; Auth.cfg = Object.assign(Auth.cfg, { repo: { owner: o, name: n } });
        const f = await Sync.getFile('data.json');
        if (!f) { Auth.token = null; Auth.cfg = {}; return notify('Im Repository liegt noch kein Haushalt. Richte ihn zuerst auf einem Gerät ein und verbinde dort den Abgleich.'); }
        const remote = repairDb(JSON.parse(b64ToUtf8(f.b64)));
        if (!(await Crypt.check(pw, remote.household && remote.household.verifier))) { Auth.token = null; Auth.cfg = {}; return notify('Das Passwort passt nicht zu diesem Haushalt.'); }
        db = remote; Sync.sha = f.sha; Sync.dirty = false; Sync.lastSync = Date.now();
        await Store.set('db', db); await Sync.saveMeta();
        await Auth.startSession(t);
        await Auth.storeToken(pw, t, { owner: o, name: n });
        enterApp();
      } catch (e) { Auth.token = null; notify(e.message); }
    };
  });
}
function authLogin() {
  showAuth(`<h1>${esc(db.household.name)}</h1><p class="lead">Mit dem Haushaltspasswort öffnen.</p>
    <label class="field"><span>Passwort</span><input class="in" type="password" id="l-p" autocomplete="current-password" enterkeyhint="go"></label>
    <p class="hint warn" id="l-e"></p>
    <div class="btns"><button class="btn primary" data-x="ok">Öffnen</button></div>`, a => {
    const go = async () => {
      const mins = Auth.locked();
      if (mins) { $('#l-e', a).textContent = `Zu viele Versuche. Bitte in ${mins} ${mins === 1 ? 'Minute' : 'Minuten'} erneut versuchen.`; return; }
      const pw = $('#l-p', a).value;
      if (!(await Crypt.check(pw, db.household.verifier))) { Auth.failed(); $('#l-e', a).textContent = 'Das Passwort stimmt nicht.'; return; }
      const tok = await Auth.tokenFromPassword(pw);
      await Auth.startSession(tok || null);
      if (tok === undefined) notify('Das Passwort wurde auf einem anderen Gerät geändert. Bitte den Abgleich-Zugang in den Einstellungen neu eintragen.');
      enterApp(); kontoEnsure();
    };
    $('[data-x=ok]', a).onclick = go;
    $('#l-p', a).onkeydown = e => { if (e.key === 'Enter') go(); };
  });
}

/* ---------- Zentrales Konto (Anmeldung im Hauptmenü) ----------
   Angemeldet: kein Haushaltspasswort nötig. Der Haushalt (Datensatz auf dem Pi + Geheimnis)
   steht im Konto und wird auf jedem Gerät automatisch verbunden. */
const kontoItem = () => { const pb = Sync.isPB && Sync.repo.pb; const l = Konto.items('essen'); return l.find(x => x.id === pb) || l.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''))[0] || null; };
/* Haushalt ins Konto eintragen – ist er noch nicht auf dem Pi, wird er dort angelegt */
async function kontoEnsure() {
  if (!Konto.loggedIn() || !db || !db.household) return;
  try {
    if (!Sync.isPB) {
      if (Sync.enabled()) return;   // alter GitHub-Abgleich: erst in den Einstellungen umziehen
      const secret = PB.newSecret();
      const rec = await PB.create(secret, db);
      Auth.cfg = Object.assign(Auth.cfg, { repo: { pb: rec.id } });
      await Auth.startSession(secret);
      Sync.sha = rec.updated; Sync.remoteRev = 1; Sync.dirty = false; await Sync.saveMeta();
      await Store.set('imgq', Images.allKeys()); await Store.set('imgdel', []);
      Sync.run({ force: true }); Sync.startPolling();
    }
    const other = Konto.items('essen').filter(x => x.id !== (Sync.isPB && Sync.repo.pb));
    if (other.length && Sync.isPB && !Konto.items('essen').some(x => x.id === Sync.repo.pb)) { location.reload(); return; }   // Wechsel → beim Neustart übernehmen
    if (Sync.isPB && Auth.token) Konto.put('essen:' + Sync.repo.pb, { app: 'essen', id: Sync.repo.pb, secret: Auth.token, label: db.household.name });
  } catch (e) { /* offline – beim nächsten Start erneut */ }
}
/* Start mit Konto: true = erledigt, false = normaler Ablauf */
async function kontoBoot() {
  if (!Konto.loggedIn()) return false;
  let it = kontoItem();
  if (!it) { try { await Konto.sync(); } catch (e) {} it = kontoItem(); }
  if (db && db.household) {
    if (it && Sync.isPB && it.id === Sync.repo.pb) { await Auth.startSession(it.secret); enterApp(); return true; }
    if (it && Sync.isPB && it.id !== Sync.repo.pb) {   // im Konto wurde zu einem anderen Haushalt gewechselt (Einladung angenommen)
      try { await kontoJoin(it, true, true); notify(`Du bist jetzt im Haushalt „${it.label || 'neu'}“. Deine Rezepte wurden übernommen.`); return true; } catch (e) { /* offline: alter Stand */ }
    }
    if (it && !Sync.enabled()) {   // lokaler Haushalt ohne Abgleich, im Konto gibt es schon einen: dorthin verbinden
      try { await kontoJoin(it, true); return true; } catch (e) { return false; }
    }
    if (await Auth.resume()) { enterApp(); kontoEnsure(); return true; }
    return false;   // einmal Haushaltspasswort, danach steht er im Konto
  }
  if (it) { try { await kontoJoin(it, false); return true; } catch (e) { notify(e.message || 'Haushalt aus dem Konto nicht erreichbar.'); } }
  return false;
}
async function kontoJoin(it, mergeLocal, keepRemoteName) {
  const f = await PB.fetchHousehold(it.id, it.secret);
  db = mergeLocal && db ? repairDb(EP.mergeDb(db, f.remote)) : f.remote;
  if (mergeLocal && f.remote.household) db.household = f.remote.household;   // Name/Passwort des beigetretenen Haushalts gelten
  if (mergeLocal) { EP.normalizePlan(db); }
  Sync.sha = f.updated; Sync.remoteRev = f.rev; Sync.dirty = !!mergeLocal; Sync.lastSync = Date.now();
  await Store.set('db', db); await Sync.saveMeta();
  Auth.cfg = Object.assign(Auth.cfg, { repo: { pb: it.id } });
  await Auth.startSession(it.secret);
  enterApp();
}

/* iOS: Solange die Tastatur offen ist, hängt eine feste Leiste unten an der Seite statt am Bildschirm und wandert beim
   Scrollen mit nach oben. Deshalb beim Tippen ausblenden und nach dem Schließen der Tastatur die Lage neu berechnen lassen. */
const isTyping = el => !!el && (el.tagName === 'TEXTAREA' || el.isContentEditable || (el.tagName === 'INPUT' && !/^(checkbox|radio|button|submit|file|range|color|hidden)$/i.test(el.type)));
const kbdOpen = () => !!window.visualViewport && visualViewport.height < window.innerHeight * 0.85;   // Bildschirmtastatur sichtbar
function kbdCheck() {
  const on = isTyping(document.activeElement) && kbdOpen(), was = document.documentElement.classList.contains('typing');
  document.documentElement.classList.toggle('typing', on);
  if (was && !on) window.scrollTo(window.scrollX, window.scrollY);   // Safari ordnet feste Elemente danach wieder am Bildschirm aus
}
document.addEventListener('focusin', () => { kbdCheck(); setTimeout(kbdCheck, 350); });
document.addEventListener('focusout', () => setTimeout(kbdCheck, 80));
if (window.visualViewport) visualViewport.addEventListener('resize', kbdCheck);

/* ---------- Start ---------- */
async function enterApp() {
  $('#auth').classList.add('hidden');
  $('#shell').classList.remove('hidden');
  db = repairDb(db);
  if (housekeeping()) await persist();
  route = { name: HOME }; stack = [];
  rerender();
  Inbox.pull();
  if (HOME === 'week') scrollToToday();
  BackNav.arm();
  if (Sync.enabled()) { Sync.run(); Sync.startPolling(); }
  if (pendingJoin) {
    const j = PB.parseLink(pendingJoin);
    if (j && Sync.isPB && Sync.repo.pb === j.id) pendingJoin = '';
    else go('sync');
  }
}
async function boot() {
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-act],[data-tab]');
    if (!t) return;
    if (t.dataset.tab) { go(t.dataset.tab); return; }
    const fn = ACT[t.dataset.act];
    if (fn) { e.preventDefault(); fn(t.dataset.arg, t); }
  });
  $('#syncpill').onclick = () => go('sync');
  $('#gear').onclick = () => go('settings');
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    if (Sync.enabled()) Sync.run();
    Inbox.pull();
    if (!$('#cookview').classList.contains('hidden')) lockScreen();
    if (db && housekeeping()) { persist(); rerender(); }
    if (Konto.loggedIn() && db && db.household) Konto.sync().then(kontoEnsure).catch(() => {});
  });
  window.addEventListener('online', () => { Sync.run(); Inbox.pull(); });
  setInterval(() => { if (document.visibilityState === 'visible') Inbox.pull(); }, 30000);
  window.addEventListener('focus', () => { if (Sync.enabled()) Sync.run(); });
  if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});

  const hj = PB.parseLink(location.hash);
  if (hj) { pendingJoin = PB.link(hj.id, hj.secret); try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {} }
  db = await Store.get('db');
  await Sync.loadMeta();
  if (db && db.household) db = repairDb(db);
  if (!pendingJoin && await kontoBoot()) return;
  if (!db || !db.household) return pendingJoin ? authJoin(pendingJoin) : authWelcome();
  if (await Auth.resume()) { enterApp(); kontoEnsure(); return; }
  authLogin();
}
boot();
