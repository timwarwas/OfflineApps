const EP = require('./domain.js');
const seedToDb = require('./seed.js');
const seed = require('./seed.json');
const fs = require('fs');

let pass = 0, fail = 0;
function check(name, cond, info) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (info ? '  → ' + info : '')); }
}
const fresh = () => seedToDb(JSON.parse(JSON.stringify(seed)), EP);
const rid = (db, name) => db.recipes.find(r => r.name === name).id;
const rname = (db, id) => db.recipes.find(r => r.id === id).name;

/* ---------- T1 Durchlauf-Zusammensetzung ---------- */
console.log('T1 Durchlauf-Zusammensetzung');
{
  const db = fresh();
  const c = EP.buildCycle(db.recipes, db.settings, 1, null, EP.seededRng(1));
  const cnt = n => c.filter(e => e.recipeId === rid(db, n)).length;
  check('genau 6 Einträge', c.length === 6, c.length);
  check('Bolognese 2×', cnt('Spaghetti Bolognese') === 2);
  check('übrige aktive je 1×', ['Tortillas mit Chili sin Carne', 'Gemüsecurry', 'Pfannkuchen', 'Linsensuppe'].every(n => cnt(n) === 1));
  check('Kürbissuppe 0×', cnt('Kürbissuppe') === 0);
}

/* ---------- T2 Verteilung ---------- */
console.log('T2 Verteilung (1.000 Seeds)');
{
  const db = fresh(); const b = rid(db, 'Spaghetti Bolognese');
  let bad = 0;
  for (let s = 1; s <= 1000; s++) {
    const c = EP.buildCycle(db.recipes, db.settings, 1, null, EP.seededRng(s));
    for (let i = 1; i < c.length; i++) if (c[i].recipeId === b && c[i - 1].recipeId === b) bad++;
  }
  check('Bolognese nie direkt hintereinander', bad === 0, bad + ' Verstöße');
}

/* ---------- T3 Durchlaufgrenze ---------- */
console.log('T3 Durchlaufgrenze (1.000 Seeds)');
{
  let bad = 0;
  for (let s = 1; s <= 1000; s++) {
    const db = fresh(); const rng = EP.seededRng(s);
    EP.appendCycle(db, rng); EP.appendCycle(db, rng);
    const c1 = EP.cycleEntries(db, 1), c2 = EP.cycleEntries(db, 2);
    if (c1[c1.length - 1].recipeId === c2[0].recipeId) bad++;
  }
  check('letzter Eintrag ≠ erster Eintrag des Folgedurchlaufs', bad === 0, bad + ' Verstöße');
}

/* ---------- T4 Unvermeidbarer Fall ---------- */
console.log('T4 Unvermeidbarer Fall');
{
  const db = fresh();
  db.recipes.forEach(r => { r.inRotation = r.name === 'Spaghetti Bolognese'; });
  const c = EP.buildCycle(db.recipes, db.settings, 1, rid(db, 'Spaghetti Bolognese'), EP.seededRng(3));
  check('2 Einträge, keine Endlosschleife', c.length === 2);
}

/* ---------- T5 daysFor ---------- */
console.log('T5 daysFor');
{
  const F = { portionsPerDay: 2, roundingMode: 'FLOOR' }, C = { portionsPerDay: 2, roundingMode: 'CEIL' };
  const t = [[6, 3, 3], [4, 2, 2], [5, 2, 3], [2, 1, 1], [1, 1, 1]];
  check('Tabelle 5.1 (FLOOR/CEIL)', t.every(([s, f, c]) => EP.daysFor({ servings: s }, F) === f && EP.daysFor({ servings: s }, C) === c));
  check('Override hat Vorrang', EP.daysFor({ servings: 6, daysOverride: 5 }, F) === 5);
  check('Hinweis bei 5 Portionen', EP.daysHint({ servings: 5 }, F) === '1 Portion bleibt übrig' && EP.daysHint({ servings: 5 }, C) === 'letzter Tag nur 1 Portion');
}

/* ---------- T6 Pausieren im laufenden Durchlauf ---------- */
console.log('T6 Pausieren im laufenden Durchlauf');
{
  const db = fresh(); const rng = EP.seededRng(7);
  EP.appendCycle(db, rng);
  const b = db.recipes.find(r => r.name === 'Spaghetti Bolognese');
  const bs = EP.cycleEntries(db, 1).filter(e => e.recipeId === b.id);
  EP.planEntry(bs[0]);
  b.inRotation = false; EP.syncRecipeIntoCycles(db, b, rng);
  const after = EP.cycleEntries(db, 1).filter(e => e.recipeId === b.id);
  check('PENDING-Einträge entfernt', !after.some(e => e.status === 'PENDING'));
  check('PLANNED bleibt', after.length === 1 && after[0].status === 'PLANNED');
}

/* ---------- T7 Neues Rezept im laufenden Durchlauf ---------- */
console.log('T7 Neues Rezept im laufenden Durchlauf');
{
  const db = fresh(); const rng = EP.seededRng(11);
  EP.appendCycle(db, rng);
  EP.planEntry(EP.cycleEntries(db, 1)[0]);
  const r = EP.touch({ id: EP.uuid(), name: 'Risotto', inRotation: true, weight: 2, servings: 2, sortOrder: 99, ingredients: [], images: [], deleted: false });
  db.recipes.push(r); EP.syncRecipeIntoCycles(db, r, rng);
  const mine = EP.cycleEntries(db, 1).filter(e => e.recipeId === r.id);
  check('erscheint im selben Durchlauf genau weight-mal', mine.length === 2 && mine.every(e => e.status === 'PENDING'));
  check('kein neuer Durchlauf erzeugt', EP.maxCycle(db) === 1);
  const es = EP.cycleEntries(db, 1);
  let adj = 0; for (let i = 1; i < es.length; i++) if (es[i].recipeId === es[i - 1].recipeId) adj++;
  check('R5 eingehalten', adj === 0);
}

/* ---------- T8 postpone / release ---------- */
console.log('T8 postpone / release');
{
  const db = fresh(); const rng = EP.seededRng(5);
  EP.appendCycle(db, rng);
  const first = EP.pendingSorted(db)[0];
  EP.postpone(db, first);
  const es = EP.cycleEntries(db, 1);
  check('postpone: bleibt PENDING, steht am Ende', first.status === 'PENDING' && es[es.length - 1].id === first.id);
  const n = EP.nextEntries(db, 1, null, rng)[0];
  EP.planEntry(n);
  EP.release(db, n);
  check('release: ist der nächste Vorschlag', EP.nextEntries(db, 1, null, rng)[0].id === n.id && n.status === 'PENDING');
}

/* ---------- T9 Wochenplan ---------- */
console.log('T9 Wochenplan (Beispiel 5.4)');
function buildT9() {
  const db = fresh();
  const order = ['Spaghetti Bolognese', 'Gemüsecurry', 'Tortillas mit Chili sin Carne', 'Linsensuppe', 'Spaghetti Bolognese', 'Pfannkuchen'];
  let occ = {};
  db.rotation = order.map((n, i) => { const id = rid(db, n); occ[id] = (occ[id] || 0) + 1;
    return EP.touch({ id: 'e' + (i + 1), cycleNumber: 1, recipeId: id, occurrence: occ[id], position: (i + 1) * 1000, status: 'PENDING', deleted: false }); });
  db.plan = [EP.touch({ id: 'blk', date: '2026-10-02', type: 'BLOCKED', recipeId: null, blockId: null, note: 'Auswärts essen', deleted: false })];
  const days = EP.weekDays('2026-09-28');
  const occupied = new Set(EP.live(db.plan).map(p => p.date));
  const rng = EP.seededRng(1);
  const drafts = EP.fillWeek({ days, occupied, nextFn: ex => EP.nextEntries(db, 1, ex, rng)[0],
    recipeOf: id => db.recipes.find(r => r.id === id), settings: db.settings, today: '2026-09-21' });
  return { db, drafts };
}
{
  const { db, drafts } = buildT9();
  const got = drafts.map(d => `${d.date} ${rname(db, d.recipeId)} ${d.type === 'COOK' ? 'Kochtag' : 'Reste'} (${d.dayIndex}/${d.dayCount})`);
  const exp = [
    '2026-09-28 Spaghetti Bolognese Kochtag (1/2)', '2026-09-29 Spaghetti Bolognese Reste (2/2)',
    '2026-09-30 Gemüsecurry Kochtag (1/2)', '2026-10-01 Gemüsecurry Reste (2/2)',
    '2026-10-03 Tortillas mit Chili sin Carne Kochtag (1/3)', '2026-10-04 Tortillas mit Chili sin Carne Reste (2/3)',
    '2026-10-05 Tortillas mit Chili sin Carne Reste (3/3)',
  ];
  check('Beispiel exakt reproduziert inkl. Übertrag 05.10.', JSON.stringify(got) === JSON.stringify(exp), '\n' + got.join('\n'));
  // Übernehmen → nächster Vorschlag ist Linsensuppe
  drafts.forEach(d => db.plan.push(EP.touch(Object.assign({ id: EP.uuid(), deleted: false }, d))));
  [...new Set(drafts.map(d => d.rotationEntryId))].forEach(id => EP.planEntry(db.rotation.find(e => e.id === id)));
  check('nächster Vorschlag nach Übernahme: Linsensuppe', rname(db, EP.nextEntries(db, 1, null, EP.seededRng(1))[0].recipeId) === 'Linsensuppe');
}

/* ---------- T10 Einkaufsliste ---------- */
console.log('T10 Einkaufsliste (Anhang B)');
{
  const { db, drafts } = buildT9();
  drafts.forEach(d => db.plan.push(EP.touch(Object.assign({ id: EP.uuid(), deleted: false }, d))));
  const list = EP.buildShoppingList(db, '2026-09-28', '2026-10-04');
  const txt = EP.shoppingText(list, db.settings);
  const exp = fs.readFileSync(__dirname + '/anhang_b.txt', 'utf8');
  check('Textexport exakt wie Anhang B (neu: nur Zutaten)', txt === exp, '\n--- erhalten ---\n' + txt);
  const off = EP.shoppingText(list, Object.assign({}, db.settings, { marketListShowQuantities: false }));
  check('ohne Marktmengen: keine Klammern im Markt-Abschnitt', off.startsWith('Avocado\nBlattspinat') && /Mais \(1 Dose\)$/.test(off));
}

/* ---------- T11 Einheiten ---------- */
console.log('T11 Einheiten');
{
  const s = items => EP.sumAmounts(items).text;
  check('800 g + 400 g → 1,2 kg', s([{ quantity: 800, unit: 'G' }, { quantity: 400, unit: 'G' }]) === '1,2 kg');
  check('1 Stück + 200 g', s([{ quantity: 1, unit: 'STUECK' }, { quantity: 200, unit: 'G' }]) === '1 Stück + 200 g');
  check('3 EL bleiben 3 EL', s([{ quantity: 3, unit: 'EL' }]) === '3 EL');
  check('1500 ml → 1,5 l', s([{ quantity: 1500, unit: 'ML' }]) === '1,5 l');
  check('Plural: 5 Zehen, 1 Dose', s([{ quantity: 5, unit: 'ZEHE' }]) === '5 Zehen' && s([{ quantity: 1, unit: 'DOSE' }]) === '1 Dose');
  check('kg + g gemischt', s([{ quantity: 0.5, unit: 'KG' }, { quantity: 700, unit: 'G' }]) === '1,2 kg');
}

/* ---------- T12 Nur Kochtage ---------- */
console.log('T12 Nur Kochtage');
{
  const db = fresh();
  const b = rid(db, 'Spaghetti Bolognese'), l = rid(db, 'Linsensuppe');
  db.plan = [
    EP.touch({ id: 'p1', date: '2026-09-27', type: 'COOK', recipeId: b, blockId: 'x', dayIndex: 1, dayCount: 2, deleted: false }),
    EP.touch({ id: 'p2', date: '2026-09-28', type: 'LEFTOVER', recipeId: b, blockId: 'x', dayIndex: 2, dayCount: 2, deleted: false }),
    EP.touch({ id: 'p3', date: '2026-09-29', type: 'COOK', recipeId: l, blockId: 'y', dayIndex: 1, dayCount: 2, deleted: false }),
  ];
  const list = EP.buildShoppingList(db, '2026-09-28', '2026-10-04', { today: '2026-01-01' });
  check('Resttage erzeugen keine Zutaten', list.market.length === 0 && list.supermarket.length === 0 && list.pantry.length === 0);
  check('Hinweis für Rezept ohne Zutaten', list.warnings.length === 1 && list.warnings[0].includes('Linsensuppe'));
}

/* ---------- Zusatz: Geräteabgleich ---------- */
console.log('Zusatz: Geräteabgleich (Zusammenführen)');
{
  const base = fresh();
  const a = JSON.parse(JSON.stringify(base)), b = JSON.parse(JSON.stringify(base));
  let t = Date.now();
  EP.setClock(() => (t += 10));
  const ra = a.recipes.find(r => r.name === 'Pfannkuchen'); ra.servings = 4; EP.touch(ra);          // Gerät A ändert
  const rb = b.recipes.find(r => r.name === 'Linsensuppe'); rb.weight = 3; EP.touch(rb);            // Gerät B ändert anderes Rezept
  b.recipes.push(EP.touch({ id: 'neu', name: 'Risotto', inRotation: true, weight: 1, servings: 2, sortOrder: 9, ingredients: [], images: [], deleted: false }));
  const gone = a.recipes.find(r => r.name === 'Kürbissuppe'); EP.tomb(gone);                        // Gerät A löscht
  const m = EP.mergeDb(a, b);
  const g = n => m.recipes.find(r => r.name === n);
  check('Änderung von Gerät A bleibt erhalten', g('Pfannkuchen').servings === 4);
  check('Änderung von Gerät B bleibt erhalten', g('Linsensuppe').weight === 3);
  check('neues Rezept von B übernommen', !!g('Risotto'));
  check('Löschung von A bleibt gelöscht', g('Kürbissuppe').deleted === true);
  const rb2 = b.recipes.find(r => r.name === 'Pfannkuchen'); rb2.servings = 6; EP.touch(rb2);         // späterer Konflikt
  check('bei Konflikt gewinnt die neuere Änderung', EP.mergeDb(a, b).recipes.find(r => r.name === 'Pfannkuchen').servings === 6);
  EP.setClock(() => Date.now());
}


/* ---------- Neu: getrennte Spuren (Mittag, Kuchen) ---------- */
console.log('Neu: getrennte Rotationen für Mittag und Kuchen');
{
  const db = fresh(); const rng = EP.seededRng(21);
  const add = (name, kind, extra) => { const r = EP.touch(Object.assign({ id: EP.uuid(), name, kind, inRotation: true, weight: 1, servings: 2, sortOrder: 50 + db.recipes.length, ingredients: [], images: [], deleted: false }, extra || {})); db.recipes.push(r); return r; };
  ['Brot mit Spinat und Ei', 'Nudelsuppe', 'Tomatensuppe'].forEach(n => add(n, 'LUNCH'));
  ['Apfelkuchen', 'Marmorkuchen'].forEach(n => add(n, 'CAKE'));
  const main = EP.nextEntries(db, 6, null, rng, 'MAIN');
  const lunch = EP.nextEntries(db, 3, null, rng, 'LUNCH');
  const cake = EP.nextEntries(db, 2, null, rng, 'CAKE');
  const kinds = (es) => [...new Set(es.map(e => EP.laneOf(db.recipes.find(r => r.id === e.recipeId))))];
  check('Hauptgerichte-Rotation enthält nur Hauptgerichte', kinds(main).join() === 'MAIN' && main.length === 6);
  check('Mittag-Rotation enthält nur Mittagsgerichte', kinds(lunch).join() === 'LUNCH' && lunch.length === 3);
  check('Kuchen-Rotation enthält nur Kuchen', kinds(cake).join() === 'CAKE' && cake.length === 2);
  check('Durchläufe je Spur unabhängig nummeriert', EP.maxCycle(db, 'MAIN') === 1 && EP.maxCycle(db, 'LUNCH') === 1 && EP.maxCycle(db, 'CAKE') === 1);
  EP.planEntry(lunch[0]);
  const p0 = EP.cycleProgress(db, 'MAIN'), p1 = EP.cycleProgress(db, 'LUNCH');
  check('Fortschritt je Spur getrennt', p0.current === 1 && p1.current === 2 && p1.total === 3);
  // Art ändern: Nudelsuppe wird Hauptgericht
  const ns = db.recipes.find(r => r.name === 'Nudelsuppe'); ns.kind = 'MAIN'; EP.touch(ns); EP.syncRecipeIntoCycles(db, ns, rng);
  const nsEntries = EP.live(db.rotation).filter(e => e.recipeId === ns.id && e.status === 'PENDING');
  check('Art geändert: Eintrag wechselt die Spur', nsEntries.length === 1 && EP.laneOf(nsEntries[0]) === 'MAIN');
  // Plan: gleiches Datum in zwei Spuren ist erlaubt
  db.plan = [
    EP.touch({ id: 'a', date: '2026-10-03', lane: 'MAIN', type: 'COOK', recipeId: main[0].recipeId, deleted: false }),
    EP.touch({ id: 'b', date: '2026-10-03', lane: 'LUNCH', type: 'COOK', recipeId: lunch[1].recipeId, deleted: false }),
    EP.touch({ id: 'c', date: '2026-10-03', lane: 'CAKE', type: 'COOK', recipeId: cake[0].recipeId, deleted: false }),
  ];
  EP.normalizePlan(db);
  check('Hauptgericht, Mittag und Kuchen am selben Tag bleiben erhalten', EP.live(db.plan).length === 3);
  const list = EP.buildShoppingList(db, '2026-10-03', '2026-10-03');
  check('Einkaufsliste nennt alle drei Gerichte', list.recipes.length === 3, list.recipes.join(', '));
}

/* ---------- Neu: Saison ---------- */
console.log('Neu: Saison');
{
  const db = fresh(); const rng = EP.seededRng(4);
  db.recipes.forEach(r => { if (r.name !== 'Pfannkuchen') r.inRotation = false; });
  const lins = db.recipes.find(r => r.name === 'Linsensuppe'); lins.inRotation = true;
  const spargel = EP.touch({ id: 'sp', name: 'Spargel', inRotation: true, weight: 1, servings: 2, sortOrder: 99, seasonMonths: [4, 5, 6], ingredients: [], images: [], deleted: false });
  db.recipes.push(spargel);
  const cSept = EP.buildCycle(db.recipes, db.settings, 1, null, rng, 'MAIN', 9);
  const cMay = EP.buildCycle(db.recipes, db.settings, 1, null, rng, 'MAIN', 5);
  check('außerhalb der Saison nicht im Durchlauf (September)', !cSept.some(e => e.recipeId === 'sp') && cSept.length === 2);
  check('in der Saison im Durchlauf (Mai)', cMay.some(e => e.recipeId === 'sp') && cMay.length === 3);
  check('ohne Saisonangabe ganzjährig', EP.inSeason({ seasonMonths: null }, 1) && EP.inSeason({ seasonMonths: [] }, 7));
  // Offener Eintrag, dessen Saison vorbei ist, wird beim Vorschlagen ausgelassen
  db.rotation = cMay;
  const firstSept = EP.nextEntries(db, 3, null, rng, 'MAIN', 9);
  const sp = db.rotation.find(e => e.recipeId === 'sp');
  check('Saison vorbei: Eintrag wird übersprungen, nicht vorgeschlagen', !firstSept.some(e => e.recipeId === 'sp') && sp.status === 'SKIPPED' && sp.skipReason === 'SEASON');
  check('Saison-Beschriftung', EP.seasonLabel(spargel) === 'Apr–Jun' && EP.seasonLabel({ seasonMonths: [12, 1, 2] }) === 'Dez–Feb');
}

/* ---------- Neu: Einkaufsorte ---------- */
console.log('Neu: Einkaufsorte');
{
  const s0 = { categorySources: { GEWUERZE: 'SUPERMARKT', OELE_ESSIG: 'SUPERMARKT' } };
  check('Gemüse und Obst standardmäßig Markt', EP.sourceOf({ category: 'GEMUESE' }, s0) === 'MARKT' && EP.sourceOf({ category: 'OBST' }, s0) === 'MARKT');
  check('Gewürze standardmäßig Supermarkt', EP.sourceOf({ category: 'GEWUERZE' }, s0) === 'SUPERMARKT');
  check('Einstellung je Zutat hat Vorrang', EP.sourceOf({ category: 'GEMUESE', shoppingSource: 'SUPERMARKT' }, s0) === 'SUPERMARKT');
  check('Kategorie-Erkennung', ['Kartoffel', 'Paprikapulver', 'Tomatenmark', 'Olivenöl', 'Eier', 'Rhabarber', 'Weizentortillas'].map(EP.guessCategory).join() ===
    'GEMUESE,GEWUERZE,KONSERVEN,OELE_ESSIG,EIER,OBST,BACKWAREN');
}

/* ---------- Neu: Timer aus dem Anleitungstext ---------- */
console.log('Neu: Timer aus dem Anleitungstext');
{
  const T = x => EP.parseTimers(x).map(o => o.sec).join();
  check('„10 Minuten köcheln“', T('Alles 10 Minuten köcheln lassen.') === '600');
  check('Spanne nimmt den kleineren Wert', T('5–7 Min. anbraten') === '300' && T('20 bis 25 Minuten backen') === '1200');
  check('Stunden und halbe Stunden', T('1 Std. ruhen lassen') === '3600' && T('eine halbe Stunde ziehen lassen') === '1800' && T('1 ½ Stunden schmoren') === '5400' && T('1,5 Stunden') === '5400');
  check('Sekunden', T('30 Sekunden pürieren') === '30');
  check('mehrere Zeiten in einem Schritt', T('3 Minuten anbraten, dann 20 Minuten köcheln') === '180,1200');
  check('keine Fehltreffer', T('200 g Mehl, 2 Eier, Minze hacken') === '' && T('Zimtstangen 2 Min') === '120');
  check('Uhr-Format', EP.fmtClock(605) === '10:05' && EP.fmtClock(3725) === '1:02:05' && EP.fmtClock(-3) === '00:00');
}

/* ---------- Neu: ähnliche Rezeptnamen ---------- */
console.log('Neu: ähnliche Rezeptnamen');
{
  const S = EP.nameSimilar;
  check('Schreibweisen', S('Linsensuppe', 'Linsen-Suppe') && S('Lasagne', 'Lasagna') && S('Käsespätzle', 'Kaesespaetzle') && S('Spagetti Bolognese', 'Spaghetti Bolognese'));
  check('Zusätze', S('Spaghetti Bolognese', 'Spaghetti Bolognese mit Parmesan') && S('Tomatensuppe', 'Tomatensuppe mit Baguette') && S('Nudeln mit Pesto', 'Nudel mit Pesto'));
  check('verschiedene Gerichte nicht', !S('Kartoffelsuppe', 'Kartoffelsalat') && !S('Gemüsecurry', 'Curry mit Reis') && !S('Nudelsuppe', 'Nudeln mit Pesto')
    && !S('Apfelkuchen', 'Käsekuchen') && !S('Spaghetti Bolognese', 'Spaghetti Carbonara') && !S('Gurkensalat', 'Tomatensalat'));
  const db = fresh();
  check('similarRecipes findet Tippfehler, nicht den exakten Namen', EP.similarRecipes(db, 'Spagetti Bolognese').map(r => r.name).join() === 'Spaghetti Bolognese'
    && EP.similarRecipes(db, 'Spaghetti Bolognese').length === 0);
  const exp = EP.buildRecipeExport(Object.assign(db, { recipes: db.recipes.map(r => r.name === 'Linsensuppe' ? Object.assign(r, { favorite: true }) : r) }), [rid(db, 'Linsensuppe')]);
  check('Favorit im Export und Import', exp.rezepte[0].favorit === true && EP.parseRecipeImport(exp)[0].favorite === true);
}

/* ---------- Neu: Export nur offene Zutaten, ohne Überschriften ---------- */
console.log('Neu: Export der Einkaufsliste');
{
  const L = { from: '2026-10-05', to: '2026-10-11', recipes: ['Linsensuppe'], warnings: ['x'],
    market: [{ name: 'Tomaten', amount: '1 kg', checked: true }, { name: 'Gurke', amount: '2 Stück', checked: false }],
    supermarket: [{ label: 'Nudeln', items: [{ name: 'Spaghetti', amount: '500 g', checked: true }] }, { label: 'Milchprodukte', items: [{ name: 'Sahne', amount: '200 ml', checked: false }] }],
    pantry: [{ name: 'Pfeffer', checked: false }], extraItems: [{ text: 'Spülmittel', checked: true }, { text: 'Kaffee', checked: false }] };
  const t = EP.shoppingText(L, { marketListShowQuantities: false });
  check('nur offene Zutaten, eine pro Zeile', t === 'Gurke\nSahne (200 ml)\nKaffee', JSON.stringify(t));
  check('Marktmengen nach Einstellung', EP.shoppingText(L, { marketListShowQuantities: true }).startsWith('Gurke (2 Stück)'));
  check('keine Überschrift, Gerichte, Kategorien, Vorrat', !/Einkaufsliste|Linsensuppe|Milchprodukte|MARKT|Pfeffer/.test(t));
  const db = fresh(); const from = '2026-09-21', to = '2026-09-27';
  const r0 = db.recipes.find(r => r.ingredients.length);
  db.plan.push({ id: 'p1', date: from, lane: 'MAIN', type: 'COOK', recipeId: r0.id, status: 'PLANNED' });
  const l1 = EP.buildShoppingList(db, from, to); const all = l1.market.concat(...l1.supermarket.map(g => g.items), l1.pantry);
  db.shopping = null; EP.shopMark(db, 'removed', all[0].units, true);
  const l2 = EP.buildShoppingList(db, from, to); const all2 = l2.market.concat(...l2.supermarket.map(g => g.items), l2.pantry);
  check('entfernte Einträge fehlen in der Liste', all2.length === all.length - 1 && !all2.some(r => r.key === all[0].key) && l2.removedCount === 1);
}

/* ---------- Neu: Zusatzartikel einsortieren ---------- */
console.log('Neu: Zusatzartikel werden einsortiert');
{
  const G = t => EP.extraCategory(t, {});
  check('Drogerie', ['Zahnpasta', 'Shampoo', 'Toilettenpapier', '2 Duschgel'].every(t => G(t) === 'DROGERIE'), ['Zahnpasta', 'Shampoo', 'Toilettenpapier', '2 Duschgel'].map(G).join());
  check('Haushalt', ['Spülmittel', 'Müllbeutel', 'Backpapier', 'Spülmaschinentabs'].every(t => G(t) === 'HAUSHALT'));
  check('Getränke / Süßes / Tiefkühl', G('Mineralwasser') === 'GETRAENKE' && G('Chips') === 'SUESSES' && G('Tiefkühlpizza') === 'TIEFKUEHL' && G('Kaffee') === 'GETRAENKE');
  check('Lebensmittel wie bisher', G('Milch') === 'MILCHPRODUKTE' && G('Äpfel') === 'OBST' && G('Wassermelone') === 'OBST' && G('Balsamico') === 'OELE_ESSIG');
  check('gelernte Zuordnung hat Vorrang', EP.extraCategory('Kaffee', { kaffee: 'TROCKENWAREN' }) === 'TROCKENWAREN');
  const db = fresh(); const from = '2026-09-21', to = '2026-09-27';
  db.shopping = { from, to, checkedKeys: [], extraItems: [{ text: 'Zahnpasta', checked: false }, { text: 'Spülmittel', checked: true }, { text: 'Salz', checked: false }, { text: 'Tomaten', checked: false }] };
  const l = EP.buildShoppingList(db, from, to);
  const where = n => { for (const [k, gs] of [['S', l.supermarket], ['D', l.drogerie]]) for (const g of gs) if (g.items.some(r => r.name === n)) return k + ':' + g.category; if (l.market.some(r => r.name === n)) return 'M'; if (l.pantry.some(r => r.name === n)) return 'P'; return '-'; };
  check('Zusatzartikel landen in Gruppen', where('Zahnpasta') === 'D:DROGERIE' && where('Spülmittel') === 'S:HAUSHALT' && where('Tomaten') === 'M', [where('Zahnpasta'), where('Spülmittel'), where('Tomaten')].join());
  check('Vorrats-Artikel als Zusatz → Supermarkt statt Vorrat', where('Salz') === 'S:GEWUERZE');
  const t = EP.shoppingText(l, db.settings);
  check('Export: Zusatzartikel genau einmal, abgehakte nicht', t.split('\n').filter(x => x === 'Zahnpasta').length === 1 && !t.includes('Spülmittel'), t);
}

console.log('Neu: Geschäfte mit Regal-Reihenfolge');
{
  const db = fresh(); const from = '2026-09-21', to = '2026-09-27';
  db.shopping = { from, to, checkedKeys: [], extraItems: ['Milch', 'Spülmittel', 'Brot', 'Hafermilch', 'Zahnpasta', 'Äpfel', 'Tomaten'].map(text => ({ text, checked: false })) };
  const base = EP.buildShoppingList(db, from, to);
  check('ohne Geschäft: Standard-Reihenfolge wie bisher', base.supermarket.map(g => g.category).join() === EP.CATEGORIES.map(c => c.key).filter(k => base.supermarket.some(g => g.category === k)).join() && !base.stores.SUPERMARKT);
  const rewe = { id: 'r1', name: 'Rewe', kind: 'SUPERMARKT', order: ['HAUSHALT', 'BACKWAREN', 'S:bio'], sections: [{ id: 'bio', name: 'Bio-Regal' }], assign: { hafermilch: 'bio' } };
  const markt = { id: 'm1', name: 'Wochenmarkt', kind: 'MARKT', order: ['OBST', 'GEMUESE'], sections: [], assign: {} };
  db.settings.stores = [rewe, markt, { id: 'x', name: 'Alt', kind: 'SUPERMARKT', deleted: true }];
  db.settings.storeDefault = { SUPERMARKT: 'r1', MARKT: 'm1' };
  const l = EP.buildShoppingList(db, from, to);
  const cats = l.supermarket.map(g => g.category);
  check('Standard-Geschäft wird gewählt', l.stores.SUPERMARKT === rewe && l.stores.MARKT === markt && !l.stores.DROGERIE);
  check('Gruppen in der Reihenfolge des Geschäfts', cats[0] === 'HAUSHALT' && cats[1] === 'BACKWAREN' && cats[2] === 'S:bio', cats.join());
  check('eigener Bereich holt den Artikel aus seiner Kategorie', l.supermarket[2].label === 'Bio-Regal' && l.supermarket[2].items.map(r => r.name).join() === 'Hafermilch'
    && !l.supermarket.find(g => g.category === 'MILCHPRODUKTE').items.some(r => r.name === 'Hafermilch'));
  check('übrige Kategorien folgen danach', cats.indexOf('MILCHPRODUKTE') > 2);
  check('Markt nach Geschäft gruppiert (Obst vor Gemüse)', l.marketGroups && l.marketGroups[0].category === 'OBST' && l.market[0].name === 'Äpfel' && l.market.map(r => r.name).includes('Tomaten'));
  check('Drogerie ohne Geschäft unverändert', l.drogerie.length === 1 && l.drogerie[0].category === 'DROGERIE');
  const t = EP.shoppingText(l, db.settings).split('\n');
  check('Export folgt der Laden-Reihenfolge', t.indexOf('Spülmittel') < t.indexOf('Brot') && t.indexOf('Brot') < t.indexOf('Hafermilch') && t.indexOf('Hafermilch') < t.indexOf('Milch'), t.join(' | '));
  db.shopping.stores = { SUPERMARKT: 'none' };
  check('„Ohne Geschäft“ für diese Liste', !EP.buildShoppingList(db, from, to).stores.SUPERMARKT);
  db.shopping.stores = { SUPERMARKT: 'x' };
  check('gelöschtes Geschäft → zurück zum Standard', EP.buildShoppingList(db, from, to).stores.SUPERMARKT === rewe);
  const ord = EP.storeOrder(rewe, db.settings).map(o => o.key);
  check('Reihenfolge enthält alle Supermarkt-Kategorien genau einmal, ohne Markt/Vorrat', new Set(ord).size === ord.length && ord.includes('TIEFKUEHL') && ord.includes('SONSTIGES') && !ord.includes('OBST') && !ord.includes('GEWUERZE'));
  check('Bereich ohne Platz in der Reihenfolge wird angehängt', EP.storeOrder(Object.assign({}, rewe, { order: [] }), db.settings).slice(-1)[0].key === 'S:bio');
  const merged = EP.mergeDb ? EP.mergeDb(db, JSON.parse(JSON.stringify(db))) : null;
  check('Geschäfte reisen mit den Einstellungen (Abgleich)', !merged || (merged.settings.stores || []).length === 3);
}

console.log('Neu: Rotation räumt gelöschte/pausierte Rezepte auf');
{
  const db = fresh(); const rng = () => 0.5;
  EP.nextEntries(db, 1, null, rng, 'MAIN');
  const act = EP.activeRecipes(db, 'MAIN');
  const del = act[0], paused = act[1], keep = act[2];
  // wie nach einem Abgleich: Rezept anderswo gelöscht/pausiert, ohne dass die Rotation angepasst wurde
  del.deleted = true; paused.inRotation = false;
  const ghost = { id: 'weg', lane: 'MAIN', cycleNumber: 1, recipeId: 'gibt-es-nicht', occurrence: 1, position: 99999, status: 'PENDING', deleted: false };
  db.rotation.push(ghost);
  const n = EP.cleanRotation(db);
  const pend = EP.pendingSorted(db, 'MAIN');
  check('offene Einträge gelöschter, pausierter und fehlender Rezepte entfernt', n >= 3 && !pend.some(e => [del.id, paused.id, 'gibt-es-nicht'].includes(e.recipeId)), n);
  check('andere Rezepte bleiben', pend.some(e => e.recipeId === keep.id));
  check('Vorschlag zeigt nie gelöschte Rezepte', EP.nextEntries(db, 6, null, rng, 'MAIN').every(e => e.recipeId !== del.id && e.recipeId !== 'gibt-es-nicht'));
  check('zweiter Aufruf ändert nichts', EP.cleanRotation(db) === 0);
}

console.log('Neu: Einkauf über Wochen (gekauft je Kochtag, Übernahme in die nächste Woche)');
{
  const db = fresh();
  const rs = db.recipes.filter(r => r.ingredients.length >= 2).slice(0, 3);
  const mk = (id, date, r) => db.plan.push({ id, date, lane: 'MAIN', type: 'COOK', recipeId: r.id, status: 'PLANNED', updatedAt: 1 });
  // Vorwoche (KW 40: 28.09.–04.10.), diese Woche (KW 41: 05.10.–11.10.), nächste Woche
  mk('pa', '2026-10-01', rs[0]); mk('pb', '2026-10-07', rs[1]); mk('pc', '2026-10-14', rs[2]);
  const today = '2026-10-06', O = { today };
  const rows = l => l.market.concat(...l.supermarket.map(g => g.items), ...l.drogerie.map(g => g.items), l.pantry);
  const ingsOf = r => new Set(r.ingredients.map(x => x.ingredientId));
  const wk = EP.buildShoppingList(db, '2026-10-05', '2026-10-11', O);
  check('aktuelle Woche: nicht Gekauftes der Vorwoche wird übernommen', rows(wk).some(r => r.carry && ingsOf(rs[0]).has(r.ingId)) && wk.carried > 0);
  check('übernommene Rezepte stehen nicht unter „Für:“', !wk.recipes.includes(rs[0].name) && wk.recipes.includes(rs[1].name));
  const nx = EP.buildShoppingList(db, '2026-10-12', '2026-10-18', O);
  check('zukünftige Woche: keine Übernahme', !rows(nx).some(r => r.carry));
  const pw = EP.buildShoppingList(db, '2026-09-28', '2026-10-04', O);
  check('vergangene Woche zeigt ihre Zutaten ohne Übernahme', rows(pw).length > 0 && !rows(pw).some(r => r.carry));
  // in der Vorwoche alles abhaken → keine Übernahme mehr
  EP.shopMark(db, 'bought', [].concat(...rows(pw).map(r => r.units)), true);
  const wk2 = EP.buildShoppingList(db, '2026-10-05', '2026-10-11', O);
  check('in der Vorwoche Gekauftes wird nicht übernommen', !rows(wk2).some(r => r.carry) && wk2.carried === 0);
  check('Abhaken gilt in jeder Ansicht (Vorwoche bleibt abgehakt)', rows(EP.buildShoppingList(db, '2026-09-28', '2026-10-04', O)).every(r => r.checked));
  // „alles Kommende“: ab heute bis zum letzten Kochtag, Teil-Abhaken über Wochen
  const all = EP.buildShoppingList(db, today, '2026-10-14', O);
  check('„alles Kommende“ enthält diese und nächste Woche', all.recipes.includes(rs[1].name) && all.recipes.includes(rs[2].name));
  const w1 = rows(EP.buildShoppingList(db, '2026-10-05', '2026-10-11', O)).filter(r => !r.carry);
  EP.shopMark(db, 'bought', [].concat(...w1.map(r => r.units)), true);
  const all2 = rows(EP.buildShoppingList(db, today, '2026-10-14', O));
  const onlyW1 = [...ingsOf(rs[1])].filter(i => !ingsOf(rs[2]).has(i));
  check('in der Woche Abgehaktes ist auch in „alles Kommende“ abgehakt', onlyW1.every(i => (all2.find(r => r.ingId === i) || { checked: true }).checked));
  check('nur Zutaten der nächsten Woche bleiben offen', all2.filter(r => !r.checked).every(r => ingsOf(rs[2]).has(r.ingId)));
  // Zusatzartikel: offene wandern mit, abgehakte nicht
  const st = EP.ensureShopping(db);
  st.extras.push({ id: 'e1', text: 'Spülmittel', date: '2026-09-30', checked: false }, { id: 'e2', text: 'Kaffee', date: '2026-09-30', checked: true }, { id: 'e3', text: 'Sekt', date: '2026-10-13', checked: false });
  const wk3 = EP.buildShoppingList(db, '2026-10-05', '2026-10-11', O);
  check('offener Zusatzartikel von früher wird übernommen, erledigter nicht', wk3.extraItems.map(x => x.id).join() === 'e1');
  check('Zusatzartikel für nächste Woche erscheint erst dort', EP.buildShoppingList(db, '2026-10-12', '2026-10-18', O).extraItems.some(x => x.id === 'e3'));
  // Entfernen gilt je Einheit
  const r0 = rows(wk3).find(r => !r.carry && r.extra == null);
  EP.shopMark(db, 'removed', r0.units, true);
  const wk4 = EP.buildShoppingList(db, '2026-10-05', '2026-10-11', O);
  check('entfernte Zutat fehlt und wird gezählt', !rows(wk4).some(r => r.key === r0.key) || ingsOf(rs[2]).has(r0.ingId));
}
console.log('Neu: alter Einkaufsstand und Abgleich');
{
  const db = fresh(); const r = db.recipes.find(x => x.ingredients.length >= 2);
  db.plan.push({ id: 'q1', date: '2026-09-22', lane: 'MAIN', type: 'COOK', recipeId: r.id, status: 'PLANNED' });
  const ing = r.ingredients[0].ingredientId;
  const old = { from: '2026-09-21', to: '2026-09-27', checkedKeys: [ing + '|MASS'], extraItems: [{ text: 'Milch', checked: false }], updatedAt: 5 };
  const m = EP.migrateShopping(old, db);
  check('Übernahme: abgehakte Zutat bleibt abgehakt', m.v === 2 && m.bought['q1|0'] && m.bought['q1|0'].on && m.extras[0].text === 'Milch' && m.extras[0].date === '2026-09-21');
  check('Übernahme liefert auf jedem Gerät dieselben IDs', JSON.stringify(EP.migrateShopping(old, db)) === JSON.stringify(m));
  const a = JSON.parse(JSON.stringify(m)), b = JSON.parse(JSON.stringify(m));
  a.bought['q1|1'] = { on: true, t: 100 }; a.updatedAt = 100;
  b.extras.push({ id: 'zz', text: 'Brot', date: '2026-09-22', addedAt: 200, updatedAt: 200 }); b.updatedAt = 200;
  b.bought['q1|0'] = { on: false, t: 150 };
  const mg = EP.mergeShopping(a, b);
  check('Abgleich: Abhaken auf A und neuer Artikel auf B bleiben beide erhalten', mg.bought['q1|1'].on && mg.extras.some(x => x.id === 'zz'));
  check('Abgleich: neuere Änderung je Zutat gewinnt', mg.bought['q1|0'].on === false);
  const full = EP.mergeDb(Object.assign(fresh(), { shopping: old, plan: db.plan }), Object.assign(fresh(), { shopping: b, plan: db.plan }));
  check('Abgleich mit altem Gerätestand (anderes Format)', full.shopping.v === 2 && full.shopping.extras.some(x => x.id === 'zz'));
}
console.log('Neu: Rotation ohne verwaiste Einträge');
{
  const db = fresh();
  const e = db.rotation.find(x => !x.deleted) || (EP.nextEntries(db, 1, null, Math.random, 'MAIN') || [])[0];
  e.status = 'PLANNED';
  check('„Geplant“ ohne Planeintrag wird wieder offen', EP.releaseOrphans(db) >= 1 && e.status === 'PENDING');
  db.plan.push({ id: 'pp', date: '2026-10-10', lane: 'MAIN', type: 'COOK', recipeId: e.recipeId, rotationEntryId: e.id, status: 'PLANNED' });
  e.status = 'PLANNED';
  check('„Geplant“ mit Planeintrag bleibt', EP.releaseOrphans(db) === 0 && e.status === 'PLANNED');
}

console.log(`\n${pass} bestanden, ${fail} fehlgeschlagen`);
process.exit(fail ? 1 : 0);
