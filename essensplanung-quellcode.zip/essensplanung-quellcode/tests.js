const EP = require('./domain.js');
const seedToDb = require('./seed.js');
const seed = require('./seed.json');
const fs = require('fs');

let pass = 0, fail = 0;
function check(name, cond, info) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (info ? '  → ' + info : '')); }
}
const fresh = () => seedToDb(JSON.parse(JSON.stringify(seed)), EP);
const rid = (db, name) => db.recipes.find(r => r.name === name).id;
const rname = (db, id) => db.recipes.find(r => r.id === id).name;

/* ---------- T1 Durchlauf-Zusammensetzung ---------- */
console.log('T1 Durchlauf-Zusammensetzung');
{
  const db = fresh();
  const c = EP.buildCycle(db.recipes, db.settings, 1, null, EP.seededRng(1));
  const cnt = n => c.filter(e => e.recipeId === rid(db, n)).length;
  check('genau 6 Einträge', c.length === 6, c.length);
  check('Bolognese 2×', cnt('Spaghetti Bolognese') === 2);
  check('übrige aktive je 1×', ['Tortillas mit Chili sin Carne', 'Gemüsecurry', 'Pfannkuchen', 'Linsensuppe'].every(n => cnt(n) === 1));
  check('Kürbissuppe 0×', cnt('Kürbissuppe') === 0);
}

/* ---------- T2 Verteilung ---------- */
console.log('T2 Verteilung (1.000 Seeds)');
{
  const db = fresh(); const b = rid(db, 'Spaghetti Bolognese');
  let bad = 0;
  for (let s = 1; s <= 1000; s++) {
    const c = EP.buildCycle(db.recipes, db.settings, 1, null, EP.seededRng(s));
    for (let i = 1; i < c.length; i++) if (c[i].recipeId === b && c[i - 1].recipeId === b) bad++;
  }
  check('Bolognese nie direkt hintereinander', bad === 0, bad + ' Verstöße');
}

/* ---------- T3 Durchlaufgrenze ---------- */
console.log('T3 Durchlaufgrenze (1.000 Seeds)');
{
  let bad = 0;
  for (let s = 1; s <= 1000; s++) {
    const db = fresh(); const rng = EP.seededRng(s);
    EP.appendCycle(db, rng); EP.appendCycle(db, rng);
    const c1 = EP.cycleEntries(db, 1), c2 = EP.cycleEntries(db, 2);
    if (c1[c1.length - 1].recipeId === c2[0].recipeId) bad++;
  }
  check('letzter Eintrag ≠ erster Eintrag des Folgedurchlaufs', bad === 0, bad + ' Verstöße');
}

/* ---------- T4 Unvermeidbarer Fall ---------- */
console.log('T4 Unvermeidbarer Fall');
{
  const db = fresh();
  db.recipes.forEach(r => { r.inRotation = r.name === 'Spaghetti Bolognese'; });
  const c = EP.buildCycle(db.recipes, db.settings, 1, rid(db, 'Spaghetti Bolognese'), EP.seededRng(3));
  check('2 Einträge, keine Endlosschleife', c.length === 2);
}

/* ---------- T5 daysFor ---------- */
console.log('T5 daysFor');
{
  const F = { portionsPerDay: 2, roundingMode: 'FLOOR' }, C = { portionsPerDay: 2, roundingMode: 'CEIL' };
  const t = [[6, 3, 3], [4, 2, 2], [5, 2, 3], [2, 1, 1], [1, 1, 1]];
  check('Tabelle 5.1 (FLOOR/CEIL)', t.every(([s, f, c]) => EP.daysFor({ servings: s }, F) === f && EP.daysFor({ servings: s }, C) === c));
  check('Override hat Vorrang', EP.daysFor({ servings: 6, daysOverride: 5 }, F) === 5);
  check('Hinweis bei 5 Portionen', EP.daysHint({ servings: 5 }, F) === '1 Portion bleibt übrig' && EP.daysHint({ servings: 5 }, C) === 'letzter Tag nur 1 Portion');
}

/* ---------- T6 Pausieren im laufenden Durchlauf ---------- */
console.log('T6 Pausieren im laufenden Durchlauf');
{
  const db = fresh(); const rng = EP.seededRng(7);
  EP.appendCycle(db, rng);
  const b = db.recipes.find(r => r.name === 'Spaghetti Bolognese');
  const bs = EP.cycleEntries(db, 1).filter(e => e.recipeId === b.id);
  EP.planEntry(bs[0]);
  b.inRotation = false; EP.syncRecipeIntoCycles(db, b, rng);
  const after = EP.cycleEntries(db, 1).filter(e => e.recipeId === b.id);
  check('PENDING-Einträge entfernt', !after.some(e => e.status === 'PENDING'));
  check('PLANNED bleibt', after.length === 1 && after[0].status === 'PLANNED');
}

/* ---------- T7 Neues Rezept im laufenden Durchlauf ---------- */
console.log('T7 Neues Rezept im laufenden Durchlauf');
{
  const db = fresh(); const rng = EP.seededRng(11);
  EP.appendCycle(db, rng);
  EP.planEntry(EP.cycleEntries(db, 1)[0]);
  const r = EP.touch({ id: EP.uuid(), name: 'Risotto', inRotation: true, weight: 2, servings: 2, sortOrder: 99, ingredients: [], images: [], deleted: false });
  db.recipes.push(r); EP.syncRecipeIntoCycles(db, r, rng);
  const mine = EP.cycleEntries(db, 1).filter(e => e.recipeId === r.id);
  check('erscheint im selben Durchlauf genau weight-mal', mine.length === 2 && mine.every(e => e.status === 'PENDING'));
  check('kein neuer Durchlauf erzeugt', EP.maxCycle(db) === 1);
  const es = EP.cycleEntries(db, 1);
  let adj = 0; for (let i = 1; i < es.length; i++) if (es[i].recipeId === es[i - 1].recipeId) adj++;
  check('R5 eingehalten', adj === 0);
}

/* ---------- T8 postpone / release ---------- */
console.log('T8 postpone / release');
{
  const db = fresh(); const rng = EP.seededRng(5);
  EP.appendCycle(db, rng);
  const first = EP.pendingSorted(db)[0];
  EP.postpone(db, first);
  const es = EP.cycleEntries(db, 1);
  check('postpone: bleibt PENDING, steht am Ende', first.status === 'PENDING' && es[es.length - 1].id === first.id);
  const n = EP.nextEntries(db, 1, null, rng)[0];
  EP.planEntry(n);
  EP.release(db, n);
  check('release: ist der nächste Vorschlag', EP.nextEntries(db, 1, null, rng)[0].id === n.id && n.status === 'PENDING');
}

/* ---------- T9 Wochenplan ---------- */
console.log('T9 Wochenplan (Beispiel 5.4)');
function buildT9() {
  const db = fresh();
  const order = ['Spaghetti Bolognese', 'Gemüsecurry', 'Tortillas mit Chili sin Carne', 'Linsensuppe', 'Spaghetti Bolognese', 'Pfannkuchen'];
  let occ = {};
  db.rotation = order.map((n, i) => { const id = rid(db, n); occ[id] = (occ[id] || 0) + 1;
    return EP.touch({ id: 'e' + (i + 1), cycleNumber: 1, recipeId: id, occurrence: occ[id], position: (i + 1) * 1000, status: 'PENDING', deleted: false }); });
  db.plan = [EP.touch({ id: 'blk', date: '2026-10-02', type: 'BLOCKED', recipeId: null, blockId: null, note: 'Auswärts essen', deleted: false })];
  const days = EP.weekDays('2026-09-28');
  const occupied = new Set(EP.live(db.plan).map(p => p.date));
  const rng = EP.seededRng(1);
  const drafts = EP.fillWeek({ days, occupied, nextFn: ex => EP.nextEntries(db, 1, ex, rng)[0],
    recipeOf: id => db.recipes.find(r => r.id === id), settings: db.settings, today: '2026-09-21' });
  return { db, drafts };
}
{
  const { db, drafts } = buildT9();
  const got = drafts.map(d => `${d.date} ${rname(db, d.recipeId)} ${d.type === 'COOK' ? 'Kochtag' : 'Reste'} (${d.dayIndex}/${d.dayCount})`);
  const exp = [
    '2026-09-28 Spaghetti Bolognese Kochtag (1/2)', '2026-09-29 Spaghetti Bolognese Reste (2/2)',
    '2026-09-30 Gemüsecurry Kochtag (1/2)', '2026-10-01 Gemüsecurry Reste (2/2)',
    '2026-10-03 Tortillas mit Chili sin Carne Kochtag (1/3)', '2026-10-04 Tortillas mit Chili sin Carne Reste (2/3)',
    '2026-10-05 Tortillas mit Chili sin Carne Reste (3/3)',
  ];
  check('Beispiel exakt reproduziert inkl. Übertrag 05.10.', JSON.stringify(got) === JSON.stringify(exp), '\n' + got.join('\n'));
  // Übernehmen → nächster Vorschlag ist Linsensuppe
  drafts.forEach(d => db.plan.push(EP.touch(Object.assign({ id: EP.uuid(), deleted: false }, d))));
  [...new Set(drafts.map(d => d.rotationEntryId))].forEach(id => EP.planEntry(db.rotation.find(e => e.id === id)));
  check('nächster Vorschlag nach Übernahme: Linsensuppe', rname(db, EP.nextEntries(db, 1, null, EP.seededRng(1))[0].recipeId) === 'Linsensuppe');
}

/* ---------- T10 Einkaufsliste ---------- */
console.log('T10 Einkaufsliste (Anhang B)');
{
  const { db, drafts } = buildT9();
  drafts.forEach(d => db.plan.push(EP.touch(Object.assign({ id: EP.uuid(), deleted: false }, d))));
  const list = EP.buildShoppingList(db, '2026-09-28', '2026-10-04');
  const txt = EP.shoppingText(list, db.settings);
  const exp = fs.readFileSync(__dirname + '/anhang_b.txt', 'utf8');
  check('Textexport exakt wie Anhang B', txt === exp, '\n--- erhalten ---\n' + txt);
  const off = EP.shoppingText(list, Object.assign({}, db.settings, { marketListShowQuantities: false }));
  check('ohne Marktmengen: keine Klammern im Markt-Abschnitt', off.includes('- Avocado\n') && !/Avocado \(/.test(off));
}

/* ---------- T11 Einheiten ---------- */
console.log('T11 Einheiten');
{
  const s = items => EP.sumAmounts(items).text;
  check('800 g + 400 g → 1,2 kg', s([{ quantity: 800, unit: 'G' }, { quantity: 400, unit: 'G' }]) === '1,2 kg');
  check('1 Stück + 200 g', s([{ quantity: 1, unit: 'STUECK' }, { quantity: 200, unit: 'G' }]) === '1 Stück + 200 g');
  check('3 EL bleiben 3 EL', s([{ quantity: 3, unit: 'EL' }]) === '3 EL');
  check('1500 ml → 1,5 l', s([{ quantity: 1500, unit: 'ML' }]) === '1,5 l');
  check('Plural: 5 Zehen, 1 Dose', s([{ quantity: 5, unit: 'ZEHE' }]) === '5 Zehen' && s([{ quantity: 1, unit: 'DOSE' }]) === '1 Dose');
  check('kg + g gemischt', s([{ quantity: 0.5, unit: 'KG' }, { quantity: 700, unit: 'G' }]) === '1,2 kg');
}

/* ---------- T12 Nur Kochtage ---------- */
console.log('T12 Nur Kochtage');
{
  const db = fresh();
  const b = rid(db, 'Spaghetti Bolognese'), l = rid(db, 'Linsensuppe');
  db.plan = [
    EP.touch({ id: 'p1', date: '2026-09-27', type: 'COOK', recipeId: b, blockId: 'x', dayIndex: 1, dayCount: 2, deleted: false }),
    EP.touch({ id: 'p2', date: '2026-09-28', type: 'LEFTOVER', recipeId: b, blockId: 'x', dayIndex: 2, dayCount: 2, deleted: false }),
    EP.touch({ id: 'p3', date: '2026-09-29', type: 'COOK', recipeId: l, blockId: 'y', dayIndex: 1, dayCount: 2, deleted: false }),
  ];
  const list = EP.buildShoppingList(db, '2026-09-28', '2026-10-04');
  check('Resttage erzeugen keine Zutaten', list.market.length === 0 && list.supermarket.length === 0 && list.pantry.length === 0);
  check('Hinweis für Rezept ohne Zutaten', list.warnings.length === 1 && list.warnings[0].includes('Linsensuppe'));
}

/* ---------- Zusatz: Geräteabgleich ---------- */
console.log('Zusatz: Geräteabgleich (Zusammenführen)');
{
  const base = fresh();
  const a = JSON.parse(JSON.stringify(base)), b = JSON.parse(JSON.stringify(base));
  let t = Date.now();
  EP.setClock(() => (t += 10));
  const ra = a.recipes.find(r => r.name === 'Pfannkuchen'); ra.servings = 4; EP.touch(ra);          // Gerät A ändert
  const rb = b.recipes.find(r => r.name === 'Linsensuppe'); rb.weight = 3; EP.touch(rb);            // Gerät B ändert anderes Rezept
  b.recipes.push(EP.touch({ id: 'neu', name: 'Risotto', inRotation: true, weight: 1, servings: 2, sortOrder: 9, ingredients: [], images: [], deleted: false }));
  const gone = a.recipes.find(r => r.name === 'Kürbissuppe'); EP.tomb(gone);                        // Gerät A löscht
  const m = EP.mergeDb(a, b);
  const g = n => m.recipes.find(r => r.name === n);
  check('Änderung von Gerät A bleibt erhalten', g('Pfannkuchen').servings === 4);
  check('Änderung von Gerät B bleibt erhalten', g('Linsensuppe').weight === 3);
  check('neues Rezept von B übernommen', !!g('Risotto'));
  check('Löschung von A bleibt gelöscht', g('Kürbissuppe').deleted === true);
  const rb2 = b.recipes.find(r => r.name === 'Pfannkuchen'); rb2.servings = 6; EP.touch(rb2);         // späterer Konflikt
  check('bei Konflikt gewinnt die neuere Änderung', EP.mergeDb(a, b).recipes.find(r => r.name === 'Pfannkuchen').servings === 6);
  EP.setClock(() => Date.now());
}


/* ---------- Neu: getrennte Spuren (Mittag, Kuchen) ---------- */
console.log('Neu: getrennte Rotationen für Mittag und Kuchen');
{
  const db = fresh(); const rng = EP.seededRng(21);
  const add = (name, kind, extra) => { const r = EP.touch(Object.assign({ id: EP.uuid(), name, kind, inRotation: true, weight: 1, servings: 2, sortOrder: 50 + db.recipes.length, ingredients: [], images: [], deleted: false }, extra || {})); db.recipes.push(r); return r; };
  ['Brot mit Spinat und Ei', 'Nudelsuppe', 'Tomatensuppe'].forEach(n => add(n, 'LUNCH'));
  ['Apfelkuchen', 'Marmorkuchen'].forEach(n => add(n, 'CAKE'));
  const main = EP.nextEntries(db, 6, null, rng, 'MAIN');
  const lunch = EP.nextEntries(db, 3, null, rng, 'LUNCH');
  const cake = EP.nextEntries(db, 2, null, rng, 'CAKE');
  const kinds = (es) => [...new Set(es.map(e => EP.laneOf(db.recipes.find(r => r.id === e.recipeId))))];
  check('Hauptgerichte-Rotation enthält nur Hauptgerichte', kinds(main).join() === 'MAIN' && main.length === 6);
  check('Mittag-Rotation enthält nur Mittagsgerichte', kinds(lunch).join() === 'LUNCH' && lunch.length === 3);
  check('Kuchen-Rotation enthält nur Kuchen', kinds(cake).join() === 'CAKE' && cake.length === 2);
  check('Durchläufe je Spur unabhängig nummeriert', EP.maxCycle(db, 'MAIN') === 1 && EP.maxCycle(db, 'LUNCH') === 1 && EP.maxCycle(db, 'CAKE') === 1);
  EP.planEntry(lunch[0]);
  const p0 = EP.cycleProgress(db, 'MAIN'), p1 = EP.cycleProgress(db, 'LUNCH');
  check('Fortschritt je Spur getrennt', p0.current === 1 && p1.current === 2 && p1.total === 3);
  // Art ändern: Nudelsuppe wird Hauptgericht
  const ns = db.recipes.find(r => r.name === 'Nudelsuppe'); ns.kind = 'MAIN'; EP.touch(ns); EP.syncRecipeIntoCycles(db, ns, rng);
  const nsEntries = EP.live(db.rotation).filter(e => e.recipeId === ns.id && e.status === 'PENDING');
  check('Art geändert: Eintrag wechselt die Spur', nsEntries.length === 1 && EP.laneOf(nsEntries[0]) === 'MAIN');
  // Plan: gleiches Datum in zwei Spuren ist erlaubt
  db.plan = [
    EP.touch({ id: 'a', date: '2026-10-03', lane: 'MAIN', type: 'COOK', recipeId: main[0].recipeId, deleted: false }),
    EP.touch({ id: 'b', date: '2026-10-03', lane: 'LUNCH', type: 'COOK', recipeId: lunch[1].recipeId, deleted: false }),
    EP.touch({ id: 'c', date: '2026-10-03', lane: 'CAKE', type: 'COOK', recipeId: cake[0].recipeId, deleted: false }),
  ];
  EP.normalizePlan(db);
  check('Hauptgericht, Mittag und Kuchen am selben Tag bleiben erhalten', EP.live(db.plan).length === 3);
  const list = EP.buildShoppingList(db, '2026-10-03', '2026-10-03');
  check('Einkaufsliste nennt alle drei Gerichte', list.recipes.length === 3, list.recipes.join(', '));
}

/* ---------- Neu: Saison ---------- */
console.log('Neu: Saison');
{
  const db = fresh(); const rng = EP.seededRng(4);
  db.recipes.forEach(r => { if (r.name !== 'Pfannkuchen') r.inRotation = false; });
  const lins = db.recipes.find(r => r.name === 'Linsensuppe'); lins.inRotation = true;
  const spargel = EP.touch({ id: 'sp', name: 'Spargel', inRotation: true, weight: 1, servings: 2, sortOrder: 99, seasonMonths: [4, 5, 6], ingredients: [], images: [], deleted: false });
  db.recipes.push(spargel);
  const cSept = EP.buildCycle(db.recipes, db.settings, 1, null, rng, 'MAIN', 9);
  const cMay = EP.buildCycle(db.recipes, db.settings, 1, null, rng, 'MAIN', 5);
  check('außerhalb der Saison nicht im Durchlauf (September)', !cSept.some(e => e.recipeId === 'sp') && cSept.length === 2);
  check('in der Saison im Durchlauf (Mai)', cMay.some(e => e.recipeId === 'sp') && cMay.length === 3);
  check('ohne Saisonangabe ganzjährig', EP.inSeason({ seasonMonths: null }, 1) && EP.inSeason({ seasonMonths: [] }, 7));
  // Offener Eintrag, dessen Saison vorbei ist, wird beim Vorschlagen ausgelassen
  db.rotation = cMay;
  const firstSept = EP.nextEntries(db, 3, null, rng, 'MAIN', 9);
  const sp = db.rotation.find(e => e.recipeId === 'sp');
  check('Saison vorbei: Eintrag wird übersprungen, nicht vorgeschlagen', !firstSept.some(e => e.recipeId === 'sp') && sp.status === 'SKIPPED' && sp.skipReason === 'SEASON');
  check('Saison-Beschriftung', EP.seasonLabel(spargel) === 'Apr–Jun' && EP.seasonLabel({ seasonMonths: [12, 1, 2] }) === 'Dez–Feb');
}

/* ---------- Neu: Einkaufsorte ---------- */
console.log('Neu: Einkaufsorte');
{
  const s0 = { categorySources: { GEWUERZE: 'SUPERMARKT', OELE_ESSIG: 'SUPERMARKT' } };
  check('Gemüse und Obst standardmäßig Markt', EP.sourceOf({ category: 'GEMUESE' }, s0) === 'MARKT' && EP.sourceOf({ category: 'OBST' }, s0) === 'MARKT');
  check('Gewürze standardmäßig Supermarkt', EP.sourceOf({ category: 'GEWUERZE' }, s0) === 'SUPERMARKT');
  check('Einstellung je Zutat hat Vorrang', EP.sourceOf({ category: 'GEMUESE', shoppingSource: 'SUPERMARKT' }, s0) === 'SUPERMARKT');
  check('Kategorie-Erkennung', ['Kartoffel', 'Paprikapulver', 'Tomatenmark', 'Olivenöl', 'Eier', 'Rhabarber', 'Weizentortillas'].map(EP.guessCategory).join() ===
    'GEMUESE,GEWUERZE,KONSERVEN,OELE_ESSIG,EIER,OBST,BACKWAREN');
}

console.log(`\n${pass} bestanden, ${fail} fehlgeschlagen`);
process.exit(fail ? 1 : 0);
