// E2E: Markttage – an anderen Tagen steht Markt-Ware beim Supermarkt; Einstellung unter Einstellungen → Markttage.
// Aufruf: node e2e-markttage.js   (SHOTS=<ordner> für Bildschirmfotos)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');
let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const LROW = 'label.item:has(.nm:text-matches("^Lauch\\s*(für|$)"))';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };
const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' }); res.end(fs.readFileSync(f));
});
(async () => {
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log(`Durchlauf ${scheme}`);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
    const page = await ctx.newPage();
    await page.clock.install({ time: new Date('2026-11-02T10:00:00+01:00') }); await page.clock.resume();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
    const tap = async sel => { await page.locator(sel).first().click(); await sleep(250); };
    const over = () => page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    await page.goto(URL_);
    await tap('text=Neuen Haushalt einrichten');
    await page.fill('#a-n', 'Posten-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
    await tap('[data-x=ok]');
    await until(() => page.locator('#tabs button').count().then(n => n === 4));
    ok('Start im Reiter „Einkauf“', await page.locator('#tabs [data-tab=shop][aria-current=page]').count() === 1);
    await page.evaluate(() => {
      db.settings.portionsPerDay = 2;
      const ing = (n, c) => { const i = EP.touch({ id: EP.uuid(), name: n, category: c, deleted: false }); db.ingredients.push(i); return i; };
      const lauch = ing('Lauch', 'GEMUESE'), kart = ing('Kartoffel', 'GEMUESE');
      const mk = (n, items) => { const r = newRecipe(n, 'MAIN'); r.servings = 2; items.forEach(([i, q, u], k) => r.ingredients.push({ ingredientId: i.id, quantity: q, unit: u, note: '', sortOrder: k })); db.recipes.push(r); return r; };
      const a = mk('Lauchsuppe', [[lauch, 2, 'STUECK'], [kart, 500, 'G']]), b = mk('Quiche', [[lauch, 1, 'STUECK']]);
      placeBlock('2026-11-03', { recipeId: a.id }); placeBlock('2026-11-05', { recipeId: b.id });
      persist();
    });
    await tap('[data-tab=week]'); await tap('[data-tab=shop]');
    const sec = async name => page.evaluate(n => { const l = curShopList(); return l.market.some(r => r.name === n) ? 'MARKT' : l.supermarket.some(g => g.items.some(r => r.name === n)) ? 'SUPERMARKT' : '-'; }, name);
    ok('Ohne Einstellung: Lauch beim Markt', await sec('Lauch') === 'MARKT');
    await tap('#gear');
    const row = page.locator('[data-act=marketdays]');
    ok('Einstellungen: Zeile „Markttage – Jeden Tag“', /Markttage/.test(await row.innerText()) && /Jeden Tag/.test(await row.innerText()));
    await tap('[data-act=marketdays]');
    for (const d of [1, 2, 3, 4, 5, 0]) await tap(`[data-act=marketday][data-arg="${d}"]`);
    ok('Nur Sa gewählt', await page.locator('[data-act=marketday][aria-pressed=true]').count() === 1 && await page.locator('[data-act=marketday][data-arg="6"][aria-pressed=true]').count() === 1);
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/markttage-${scheme}.png` });
    await tap('#scrim [data-x=no]');
    ok('Zeile zeigt „Sa“', /\bSa\b/.test(await page.locator('[data-act=marketdays]').innerText()));
    ok('Gespeichert als [6]', JSON.stringify(await page.evaluate(() => db.settings.marketDays)) === '[6]');
    await tap('[data-tab=shop]');
    ok('Montag: Lauch und Kartoffel beim Supermarkt, kein Markt-Abschnitt', await sec('Lauch') === 'SUPERMARKT' && await sec('Kartoffel') === 'SUPERMARKT' && await page.evaluate(() => curShopList().market.length) === 0);
    ok('… unter „Gemüse“', await page.evaluate(() => curShopList().supermarket.some(g => g.category === 'GEMUESE' && g.items.some(r => r.name === 'Lauch'))));
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/markttage-liste-${scheme}.png` });
    ok('Samstag: wieder beim Markt', await page.evaluate(() => { const l = EP.buildShoppingList(db, '2026-11-02', '2026-11-08', { today: '2026-11-07' }); return l.market.some(r => r.name === 'Lauch') && l.marketToday; }));
    ok('Kein Markttag gewählt („Nie“): alles beim Supermarkt', await page.evaluate(() => { db.settings.marketDays = []; const l = EP.buildShoppingList(db, '2026-11-02', '2026-11-08', { today: '2026-11-07' }); db.settings.marketDays = [6]; return !l.market.length; }));
    ok('kein seitliches Scrollen', !(await over()));
    await ctx.close();
  }
  ok('Keine JS-Fehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})();
