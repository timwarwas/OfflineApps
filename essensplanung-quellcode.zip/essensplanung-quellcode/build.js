const fs = require('fs');
const r = f => fs.readFileSync(__dirname + '/' + f, 'utf8');
const seed = JSON.parse(r('seed.json'));
const strip = s => s.replace(/^if \(typeof module !== 'undefined'\).*$/m, '');

const html = `<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="Essensplanung">
<meta name="theme-color" content="#F6F8FB" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#0E1626" media="(prefers-color-scheme: dark)">
<meta name="color-scheme" content="light dark">
<title>Essensplanung</title>
<style>
${r('style.css')}
</style>
</head>
<body>
<div id="auth" class="hidden"></div>
<div id="shell" class="hidden">
  <header class="top">
    <span id="topleft"></span>
    <div class="ttl" id="ttl">Essensplanung</div>
    <button class="syncpill" id="syncpill" aria-label="Geräteabgleich"></button>
    <button class="iconbtn" id="gear" aria-label="Einstellungen"><span class="gearbadge hidden" id="gearbadge"></span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg></button>
  </header>
  <main id="main"></main>
  <nav class="tabs" id="tabs" aria-label="Bereiche"></nav>
</div>
<div id="cookview" class="cookscreen hidden" role="dialog" aria-label="Kochansicht"></div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<noscript><p style="padding:24px">Die Essensplanung braucht JavaScript.</p></noscript>
<script>
${strip(r('domain.js'))}
${strip(r('seed.js'))}
const SEED_DATA = ${JSON.stringify(seed)};
const LANE_SAMPLES = ${JSON.stringify(JSON.parse(r('samples.json')))};
${r('app-core.js')}
${r('app-ops.js')}
${r('app-ui.js')}
${r('app-views.js')}
</script>
</body>
</html>
`;
fs.writeFileSync(__dirname + '/essensplanung.html', html);

/* gemeinsamer Service Worker der ganzen Sammlung (Essensplanung, Kosten, Workout, Cocktails) */
const sw = `/* Service Worker der Anwendungssammlung: hält einzelne Apps für die Offline-Nutzung bereit.
   Betrifft ausschließlich die Seiten in PAGES – alle anderen Seiten bleiben unberührt.
   Strategie: erst Netz (immer aktueller Stand), ohne Netz die zuletzt geladene Version. */
const CACHE = 'essensplanung-v1';   // Name beibehalten, damit der bestehende Offline-Stand erhalten bleibt
const PAGES = ['/essensplanung.html', '/kosten.html', '/workout.html', '/cocktails.html'];
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin || !(PAGES.some(p => url.pathname.endsWith(p)))) return;
  e.respondWith(
    fetch(e.request).then(res => {
      if (res.ok) {
        const copy = res.clone();
        caches.open(CACHE).then(c => c.put(url.pathname, copy));
      }
      return res;
    }).catch(() => caches.open(CACHE).then(c => c.match(url.pathname)).then(r => r || caches.match(e.request, { ignoreSearch: true })))
  );
});
`;
fs.writeFileSync(__dirname + '/sw.js', sw);
console.log('essensplanung.html:', (html.length / 1024).toFixed(1), 'KB | sw.js:', sw.length, 'Bytes');
