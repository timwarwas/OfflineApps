const fs = require('fs');
const r = f => fs.readFileSync(__dirname + '/' + f, 'utf8');
const seed = JSON.parse(r('seed.json'));
const icon = 'data:image/png;base64,' + fs.readFileSync(__dirname + '/icon.png').toString('base64');
const strip = s => s.replace(/^if \(typeof module !== 'undefined'\).*$/m, '');

const html = `<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="Essensplan">
<link rel="apple-touch-icon" href="${icon}">
<link rel="manifest" href="essensplanung.webmanifest">
<link rel="icon" type="image/png" href="${icon}">
<meta name="theme-color" content="#F6F8FB" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#0E1626" media="(prefers-color-scheme: dark)">
<meta name="color-scheme" content="light dark">
<title>Essensplanung</title>
<style>
${r('style.css')}
</style>
</head>
<body>
<div id="auth" class="hidden"></div>
<div id="shell" class="hidden">
  <header class="top">
    <span id="topleft"></span>
    <div class="ttl" id="ttl">Essensplanung</div>
    <button class="syncpill" id="syncpill" aria-label="Geräteabgleich"></button>
    <button class="btn small primary hdrsave hidden" id="hdrsave" data-act="save">Speichern</button>
    <button class="iconbtn" id="gear" aria-label="Einstellungen"><span class="gearbadge hidden" id="gearbadge"></span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg></button>
  </header>
  <main id="main"></main>
  <nav class="tabs" id="tabs" aria-label="Bereiche"></nav>
</div>
<div id="cookview" class="cookscreen hidden" role="dialog" aria-label="Kochansicht"></div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<noscript><p style="padding:24px">Die Essensplanung braucht JavaScript.</p></noscript>
<script>
${r('konto.js')}
</script>
<script>
${r('push.js')}
</script>
<script>
${strip(r('domain.js'))}
${strip(r('seed.js'))}
const SEED_DATA = ${JSON.stringify(seed)};
const LANE_SAMPLES = ${JSON.stringify(JSON.parse(r('samples.json')))};
${r('app-core.js')}
${r('app-ops.js')}
${r('app-ui.js')}
${r('app-views.js')}
</script>
<script>
${r('sw-update.js')}</script>
</body>
</html>
`;
fs.writeFileSync(__dirname + '/essensplanung.html', html);

/* gemeinsamer Service Worker der ganzen Sammlung (Essensplanung, Kosten, Workout, Cocktails) */
const sw = `/* Service Worker der Anwendungssammlung: hält die Apps für die Offline-Nutzung bereit.
   Betrifft ausschließlich die Seiten in PAGES – alle anderen Seiten bleiben unberührt.
   Strategie (seit 23.11.2026): sofort die gespeicherte Version zeigen und im Hintergrund nachladen.
   Ist die geladene Fassung neuer, bekommt die geöffnete Seite die Nachricht {type: 'sw-update'} und
   zeigt „Neue Version · Neu laden“. Vorher wurde bei jedem Start erst die ganze Seite aus dem Netz
   geladen – bei schwachem Empfang dauerte der Start dadurch mehrere Sekunden. */
const CACHE = 'essensplanung-v1';   // Name beibehalten, damit der bestehende Offline-Stand erhalten bleibt
const PAGES = ['/index.html', '/essensplanung.html', '/kosten.html', '/workout.html', '/cocktails.html', '/spiele.html', '/verstecken.html'];
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
const pause = ms => new Promise(r => setTimeout(r, ms));
const stamp = r => r && (r.headers.get('etag') || r.headers.get('last-modified'));
async function isNewer(cached, fresh) {
  if (stamp(cached) && stamp(fresh)) return stamp(cached) !== stamp(fresh);
  try { return (await cached.clone().text()) !== (await fresh.clone().text()); } catch (e) { return false; }
}
async function tell(clientId, page) {   // die gerade geöffnete Seite benachrichtigen (sie lädt evtl. noch)
  for (let i = 0; i < 20; i++) {
    const c = clientId && await self.clients.get(clientId);
    if (c) { c.postMessage({ type: 'sw-update', page }); return; }
    await pause(500);
  }
}
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (url.origin === location.origin && url.pathname.endsWith('/')) url.pathname += 'index.html';   // Aufruf des Ordners = Hauptmenü
  if (e.request.method !== 'GET' || url.origin !== location.origin || !(PAGES.some(p => url.pathname.endsWith(p)))) return;
  const page = PAGES.find(p => url.pathname.endsWith(p));
  let finish; e.waitUntil(new Promise(r => { finish = r; }));   // Hintergrund-Laden darf zu Ende laufen
  e.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(url.pathname);
    const update = fetch(e.request).then(async res => {
      if (res.ok) {
        const newer = cached && await isNewer(cached, res);
        await cache.put(url.pathname, res.clone());
        if (newer) await tell(e.resultingClientId || e.clientId, page);
      }
      return res;
    });
    update.catch(() => {}).then(finish);
    if (cached) return cached.clone();   // sofort starten (Kopie: das Original wird danach mit der neuen Fassung verglichen)
    return update.catch(() => caches.match(e.request, { ignoreSearch: true }));   // erster Start: Netz
  })().catch(err => { finish(); throw err; }));
});
`;
fs.writeFileSync(__dirname + '/sw.js', sw + '\n' + r('sw-push.js'));
console.log('essensplanung.html:', (html.length / 1024).toFixed(1), 'KB | sw.js:', sw.length, 'Bytes');
