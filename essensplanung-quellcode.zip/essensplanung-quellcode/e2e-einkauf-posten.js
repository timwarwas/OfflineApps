// E2E: Start in der Einkaufsliste; gleiche Zutat aus mehreren Gerichten + selbst hinzugefügt = eine Zeile mit aufklappbaren Einzelposten.
// Aufruf: node e2e-einkauf-posten.js   (SHOTS=<ordner> für Bildschirmfotos)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');
let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const LROW = 'label.item:has(.nm:text-matches("^Lauch\\s*(für|$)"))';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };
const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' }); res.end(fs.readFileSync(f));
});
(async () => {
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log(`Durchlauf ${scheme}`);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
    const page = await ctx.newPage();
    await page.clock.install({ time: new Date('2026-11-02T10:00:00+01:00') }); await page.clock.resume();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
    const tap = async sel => { await page.locator(sel).first().click(); await sleep(250); };
    const over = () => page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    await page.goto(URL_);
    await tap('text=Neuen Haushalt einrichten');
    await page.fill('#a-n', 'Posten-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
    await tap('[data-x=ok]');
    await until(() => page.locator('#tabs button').count().then(n => n === 4));
    ok('Start im Reiter „Einkauf“', await page.locator('#tabs [data-tab=shop][aria-current=page]').count() === 1);
    await page.evaluate(() => {
      db.settings.portionsPerDay = 2;
      const ing = (n, c) => { const i = EP.touch({ id: EP.uuid(), name: n, category: c, deleted: false }); db.ingredients.push(i); return i; };
      const lauch = ing('Lauch', 'GEMUESE'), kart = ing('Kartoffel', 'GEMUESE');
      const mk = (n, items) => { const r = newRecipe(n, 'MAIN'); r.servings = 2; items.forEach(([i, q, u], k) => r.ingredients.push({ ingredientId: i.id, quantity: q, unit: u, note: '', sortOrder: k })); db.recipes.push(r); return r; };
      const a = mk('Lauchsuppe', [[lauch, 2, 'STUECK'], [kart, 500, 'G']]), b = mk('Quiche', [[lauch, 1, 'STUECK']]);
      placeBlock('2026-11-03', { recipeId: a.id }); placeBlock('2026-11-05', { recipeId: b.id });
      persist();
    });
    await tap('[data-tab=week]'); await tap('[data-tab=shop]');
    const lauchRow = () => page.locator(LROW).first();
    ok('Lauch steht einmal, Menge summiert (3 Stück)', await page.locator(LROW).count() === 1 && /3 Stück/.test(await lauchRow().innerText()), await lauchRow().innerText());
    ok('… „für Lauchsuppe, Quiche“', /für Lauchsuppe, Quiche/.test(await lauchRow().innerText()));
    ok('Aufklappknopf mit „2“, ≥44 px', /2/.test(await page.locator('[data-act=shopparts]').first().innerText()) && (await page.locator('[data-act=shopparts]').first().boundingBox()).height >= 44);
    ok('Kartoffel (nur 1 Gericht) ohne Aufklappknopf', await page.locator('label.item:has-text("Kartoffel") [data-act=shopparts]').count() === 0);
    await page.fill('#extra', '2 Lauch'); await tap('[data-act=addextra]');
    ok('Selbst hinzugefügter Lauch in derselben Zeile', await page.locator(LROW).count() === 1 && await page.locator('.xitem:has-text("Lauch")').count() === 0);
    ok('… Menge 5 Stück, „selbst hinzugefügt“', /5 Stück/.test(await lauchRow().innerText()) && /selbst hinzugefügt/.test(await lauchRow().innerText()), await lauchRow().innerText());
    await tap('[data-act=shopparts]');
    const parts = await page.$$eval('.parts .part', els => els.map(e => e.innerText.replace(/\s+/g, ' ').trim()));
    ok('Aufgeklappt: 3 Einzelposten', parts.length === 3, JSON.stringify(parts));
    ok('… Lauchsuppe Di 03.11. 2 Stück / Quiche Do 05.11. 1 Stück / Selbst hinzugefügt 2 Stück', /Lauchsuppe Di 03\.11\. 2 Stück/.test(parts[0]) && /Quiche Do 05\.11\. 1 Stück/.test(parts[1]) && /Selbst hinzugefügt 2 Stück/.test(parts[2]), JSON.stringify(parts));
    ok('Nur der eigene Posten hat ✕', await page.locator('.parts [data-act=delextra]').count() === 1);
    ok('kein seitliches Scrollen', !(await over()));
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/posten-${scheme}.png` });
    await page.locator(LROW + ' input[type=checkbox]').check(); await sleep(250);
    ok('Haken an der Zeile hakt alle Posten ab', await page.locator('.parts .part.checked').count() === 3 && await page.evaluate(() => shopState().extras.every(x => x.del || x.checked)));
    await page.locator(LROW + ' input[type=checkbox]').uncheck(); await sleep(250);
    await tap('.parts [data-act=delextra]');
    ok('✕ löscht nur den eigenen Posten → wieder 3 Stück, 2 Posten', /3 Stück/.test(await lauchRow().innerText()) && await page.locator('.parts .part').count() === 2, await lauchRow().innerText());
    await tap('[data-act=shopparts]');
    ok('Zuklappen', await page.locator('.parts').count() === 0);
    ok('Kopieren: Lauch einmal', await page.evaluate(() => EP.shoppingText(curShopList(), db.settings).split('\n').filter(l => /^Lauch/.test(l)).length) === 1);
    await page.reload(); await until(() => page.locator('#tabs button').count().then(n => n === 4));
    ok('Nach Neustart wieder in der Einkaufsliste', await page.locator('#tabs [data-tab=shop][aria-current=page]').count() === 1 && await page.locator(LROW).count() === 1);
    await ctx.close();
  }
  ok('Keine JS-Fehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})();
