// E2E: Mitteilungen in der Essensplanung (Kochtimer, Kocherinnerung, Einkaufsliste, Wochenplan, Einstellungszeile)
// Läuft gegen den echten Push-Dienst (in diesem Prozess), Zustellung an Apple wird abgefangen.
// Aufruf: node e2e-push.js
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs'), os = require('os'), path = require('path');
process.env.PUSH_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'pd-ep-'));
process.env.PUSH_ORIGIN = '*';
const D = require(process.env.PUSH_DIENST || __dirname + '/pi/push-dienst.js');
D.sendImpl.fn = async () => ({ status: 201 });

let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 6000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };
const jobs = () => D.state().jobs;
const jobTags = () => jobs().map(j => j.tag);

const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' });
  res.end(fs.readFileSync(f));
});

function fakePush(o) {
  localStorage.setItem('push-server', o.server);
  if (!localStorage.getItem('push-state')) localStorage.setItem('push-state', JSON.stringify({ on: true }));
  const sub = { endpoint: 'https://web.push.apple.com/ep-geraet', toJSON() { return { endpoint: this.endpoint, keys: { p256dh: 'BOr4hHqY1pWQ8n2c2b1oZ8v0p8b2v0E2zq0Yb0bY9b8p5n0YqH9q3J7Wl1o4l8z5B9a2c3d4e5f6g7h8i9j0k1l2', auth: 'aGVsbG8td29ybGQtMTIz' } }; }, unsubscribe: async () => true };
  window.Notification = class { static requestPermission() { return Promise.resolve('granted'); } };
  window.Notification.permission = 'granted';
  window.PushManager = function () {};
  const reg = { pushManager: { getSubscription: async () => sub, subscribe: async () => sub } };
  Object.defineProperty(navigator, 'serviceWorker', { configurable: true, value: { getRegistration: async () => reg, register: async () => reg, ready: Promise.resolve(reg), addEventListener() {}, controller: null } });
  window.__plays = 0;
  const orig = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function () { if (!this.muted) window.__plays++; return Promise.resolve(); };
}

(async () => {
  await new Promise(r => D.server.listen(0, '127.0.0.1', r));
  const PUSH = 'http://127.0.0.1:' + D.server.address().port + '/push';
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE' });
  await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
  await ctx.addInitScript(fakePush, { server: PUSH });
  const page = await ctx.newPage();
  const errors = [], sends = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
  page.on('request', r => { if (r.method() === 'POST' && /\/push\/send$/.test(r.url())) sends.push(JSON.parse(r.postData())); });
  const tap = async sel => { await page.locator(sel).first().click(); await sleep(220); };

  console.log('Einrichtung');
  await page.goto(URL_);
  await tap('text=Neuen Haushalt einrichten');
  await page.fill('#a-n', 'Push-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
  await tap('[data-x=ok]');
  ok('App offen', await until(() => page.locator('#tabs button').count().then(n => n === 4)));
  ok('Push-Modul eingebettet und aktiv', await page.evaluate(() => typeof Push !== 'undefined' && Push.enabled()));
  await tap('[data-tab=suggest]'); await tap('[data-act=seed]');
  await page.evaluate(() => Push.sync(true));
  ok('Gerät beim Push-Dienst angemeldet', Object.keys(D.state().devices).length === 1);

  console.log('Einstellungen');
  await page.evaluate(() => go('settings')); await sleep(300);
  const row = page.locator('[data-act=mitteilungen]');
  ok('Zeile „Mitteilungen“ in den Einstellungen', await row.count() === 1 && /Mitteilungen/.test(await row.innerText()));
  ok('Wert „An“', /\bAn\b/.test(await row.locator('.gval').innerText()));
  const h = await row.boundingBox();
  ok('Zeile ≥ 44 px hoch', h && h.height >= 44, h && h.height);
  ok('kein seitliches Scrollen', await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth));

  console.log('Kochtimer');
  await page.evaluate(() => { const r = newRecipe('Timer-Suppe'); r.instructions = '1. Zwiebeln 3 Minuten anbraten\n2. Brühe dazu und 20 Minuten köcheln'; db.recipes.push(r); return persist(); });
  await page.evaluate(() => openCook(findRecipeByName('Timer-Suppe').id)); await sleep(300);
  await tap('#cookview [data-cs="0"] .tchip');
  ok('Klingelton vorbereitet (Audio-Element)', await page.evaluate(() => !!Timers.el && /^blob:/.test(Timers.el.src)));
  ok('Timer beim Pi geplant', await until(() => jobs().some(j => /^timer-/.test(j.tag) && j.kind === 'timer')), JSON.stringify(jobTags()));
  const j1 = jobs().find(j => /^timer-/.test(j.tag));
  const end1 = await page.evaluate(() => Timers.list[0].end);
  ok('Zeitpunkt = Timer-Ende', j1 && Math.abs(j1.atMs - end1) < 1500, j1 && (j1.atMs - end1));
  ok('Inhalt verschlüsselt (kein Klartext beim Pi)', !JSON.stringify(jobs()).includes('Timer-Suppe'));
  await tap('#timerbar [data-t=plus]');
  ok('+1 verschiebt die Mitteilung', await until(() => { const j = jobs().find(x => /^timer-/.test(x.tag)); return j && j.atMs - j1.atMs > 55000; }));
  ok('nur ein geplanter Timer (ersetzt, nicht doppelt)', jobs().filter(j => /^timer-/.test(j.tag)).length === 1);
  await tap('#timerbar [data-t=toggle]');
  ok('Pause nimmt die Mitteilung zurück', await until(() => !jobs().some(j => /^timer-/.test(j.tag))));
  await tap('#timerbar [data-t=toggle]');
  ok('Weiter plant sie neu', await until(() => jobs().some(j => /^timer-/.test(j.tag))));
  await tap('#timerbar [data-t=stop]');
  ok('Beenden nimmt sie zurück', await until(() => !jobs().some(j => /^timer-/.test(j.tag))));
  // Ton beim Ablauf (über das Audio-Element, das auch bei Stummschalter spielt)
  await page.evaluate(() => { Timers.start(findRecipeByName('Timer-Suppe').id, 0, 1, 'kurz'); });
  ok('abgelaufener Timer spielt den Ton über das Audio-Element', await until(() => page.evaluate(() => window.__plays > 0), 4000));
  await page.evaluate(() => { Timers.list.slice().forEach(t => Timers.stop(t.id)); closeCook && closeCook(); });

  console.log('Kocherinnerung');
  await page.evaluate(() => go('week')); await sleep(200);
  await tap('[data-tab=week]'); await tap('[data-act=fill]'); await tap('[data-act=commit]');
  const today = await page.evaluate(() => EP.todayISO());
  const cookToday = await page.evaluate(() => Notes.remindText(EP.todayISO()));
  ok('ohne Einstellung keine Kocherinnerung', !jobs().some(j => /^remind-/.test(j.tag)));
  await page.evaluate(() => Push.setPrefs({ remind: true, remindTime: '23:58' }));
  ok('Kocherinnerungen geplant', await until(() => jobs().some(j => /^remind-/.test(j.tag)), 8000), JSON.stringify(jobTags()));
  if (cookToday) ok('heute dabei (' + cookToday + ')', jobs().some(j => j.tag === 'remind-' + today));
  ok('höchstens 7 Tage im Voraus', jobs().filter(j => /^remind-/.test(j.tag)).every(j => j.atMs - Date.now() < 7 * 864e5 + 3600e3));
  ok('Uhrzeit wie eingestellt', jobs().filter(j => /^remind-/.test(j.tag)).every(j => { const d = new Date(j.atMs); return d.getHours() === 23 && d.getMinutes() === 58; }));
  const nRem = () => jobs().filter(j => /^remind-/.test(j.tag)).length;
  await until(async () => { const a = nRem(); await sleep(1500); return a === nRem(); }, 15000);
  const nRemind = nRem();
  await page.evaluate(() => Notes.syncRemind());
  ok('erneuter Abgleich plant nichts doppelt', jobs().filter(j => /^remind-/.test(j.tag)).length === nRemind);
  // Tag aus dem Plan nehmen → Erinnerung verschwindet
  const lastTag = jobs().filter(j => /^remind-/.test(j.tag)).map(j => j.tag).sort().pop();
  await page.evaluate(d => { EP.live(db.plan).filter(p => p.date === d).forEach(p => { p.deleted = true; EP.touch(p); }); return persist(); }, lastTag.slice(7));
  ok('gelöschter Plantag → Erinnerung zurückgenommen', await until(() => !jobTags().includes(lastTag), 8000));
  await page.evaluate(() => Push.setPrefs({ remind: false }));
  ok('Einstellung aus → alle Kocherinnerungen weg', await until(() => !jobs().some(j => /^remind-/.test(j.tag)), 8000));

  console.log('Einkaufsliste und Wochenplan (geteilter Haushalt)');
  await page.evaluate(() => { Notes.item = () => ({ app: 'essen', id: 'abcdefghijklmno', secret: 'x'.repeat(43) }); });
  sends.length = 0;
  await tap('[data-tab=shop]');
  for (const t of ['Milch', 'Spülmittel']) { await page.fill('#extra', t); await tap('[data-act=addextra]'); }
  ok('nicht sofort einzeln gesendet', !sends.some(s => s.kind === 'einkauf'));
  const waitMs = async v => page.evaluate(async v => {
    Push.setPrefs({ einkaufWait: v }); const o = window.setTimeout; let ms = null;
    window.setTimeout = (f, t) => { ms = t; return o(f, t); };
    Notes.extraAdded('Test'); window.setTimeout = o; Notes.extras.pop(); return ms; }, v);
  ok('Sammel-Wartezeit Standard 15 s', (await waitMs(undefined)) === 15000);
  ok('Sammel-Wartezeit aus den Einstellungen (2 Min.)', (await waitMs(120)) === 120000);
  await page.evaluate(() => Push.setPrefs({ einkaufWait: 15 }));
  await page.evaluate(() => Notes.flushExtras());
  ok('eine gesammelte Mitteilung „einkauf“', await until(() => sends.filter(s => s.kind === 'einkauf').length === 1));
  ok('an den Haushalt-Kanal, dieses Gerät ausgenommen', sends.filter(s => s.kind === 'einkauf').every(s => s.channels.length === 1 && s.exclude));
  ok('Text verschlüsselt', !JSON.stringify(sends).includes('Milch'));
  const txt = await page.evaluate(async () => { const it = Notes.item(), c = await Push._chan(it.secret, it.app + ':' + it.id); return c.id; });
  ok('Kanal aus dem Haushalts-Geheimnis abgeleitet', sends.find(s => s.kind === 'einkauf').channels[0] === txt);
  // Vorschläge „Zuletzt verwendet“: Milch/Spülmittel stehen auf der Liste → nicht als Vorschlag; nach Entfernen schon
  await page.evaluate(() => { const st = shopState(); st.extras.forEach(x => { x.del = true; EP.touch(x); }); EP.touch(st); return change(); });
  await sleep(300);
  ok('entfernte Artikel erscheinen als Vorschlag mit Erklärung', await page.locator('[data-act=recentx][data-arg="Milch"]').count() === 1 && /Zuletzt verwendet/.test(await page.locator('.recenthead').innerText()));
  await tap('[data-act=recentedit]');
  ok('Bearbeiten zeigt Entfernen-Knöpfe', await page.locator('[data-act=recentdel]').count() >= 2);
  if (process.env.SHOTS) { await page.locator('.recenthead').scrollIntoViewIfNeeded(); await page.screenshot({ path: process.env.SHOTS + '/vorschlaege-bearbeiten.png' }); }
  const rb = await page.locator('[data-act=recentedit]').boundingBox();
  ok('Bearbeiten-Knopf ≥ 44 px', rb && rb.height >= 44, rb && rb.height);
  await tap('[data-act=recentdel][data-arg="Milch"]');
  ok('Vorschlag „Milch“ entfernt und bleibt weg', await page.locator('[data-arg="Milch"]').count() === 0 && await page.evaluate(() => !db.settings.recentExtras.some(x => x === 'Milch')));
  await tap('[data-act=recentedit]');
  ok('Fertig → wieder normale Vorschläge', await page.locator('[data-act=recentx][data-arg="Spülmittel"]').count() === 1);
  ok('kein seitliches Scrollen in der Einkaufsliste', await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth));
  sends.length = 0;
  await tap('[data-tab=week]'); await tap('[data-act=wk][data-arg="7"]'); await tap('[data-act=fill]'); await tap('[data-act=commit]');
  ok('Wochenplan übernommen → Mitteilung „plan“', await until(() => sends.some(s => s.kind === 'plan')));

  console.log('Ausgeschaltet');
  await page.evaluate(() => Push.disable());
  await page.evaluate(() => go('settings')); await sleep(300);
  ok('Einstellungszeile zeigt „Aus“', /\bAus\b/.test(await page.locator('[data-act=mitteilungen] .gval').innerText()));
  // Zurück aus dem Hauptmenü (dort eingeschaltet): Seite kommt aus dem Zwischenspeicher → Zeile muss „An“ zeigen
  await page.evaluate(() => { localStorage.setItem('push-state', JSON.stringify({ on: true })); window.dispatchEvent(new PageTransitionEvent('pageshow', { persisted: true })); });
  ok('nach Rückkehr aus dem Hauptmenü zeigt die Zeile „An“', await until(() => page.locator('[data-act=mitteilungen] .gval').innerText().then(t => /\bAn\b/.test(t)), 3000));
  await page.evaluate(() => { localStorage.setItem('push-state', JSON.stringify({ on: false })); window.dispatchEvent(new PageTransitionEvent('pageshow', { persisted: true })); });
  ok('… und wieder „Aus“', await until(() => page.locator('[data-act=mitteilungen] .gval').innerText().then(t => /\bAus\b/.test(t)), 3000));
  await page.evaluate(() => { const r = findRecipeByName('Timer-Suppe'); Timers.start(r.id, 1, 1200, 'x'); });
  await sleep(500);
  ok('ohne Mitteilungen werden keine Timer geplant', !jobs().some(j => /^timer-/.test(j.tag)));
  await tap('[data-act=mitteilungen]');
  ok('Zeile öffnet index.html#mitteilungen', await until(() => /index\.html#mitteilungen$/.test(page.url())));

  ok('keine Seitenfehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close(); D.server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
