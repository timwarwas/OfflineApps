const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs'), crypto = require('crypto');

/* ---------- lokaler Webserver (localhost = sicherer Kontext wie GitHub Pages) ---------- */
const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' });
  res.end(fs.readFileSync(f));
});

/* ---------- nachgebaute GitHub-Contents-API (privates Repo) ---------- */
const repo = new Map(); // Pfad → { sha, b64 }
let puts = 0, conflicts = 0;
const TOKEN = 'github_pat_TEST';
async function github(route) {
  const req = route.request();
  const url = new URL(req.url());
  if (req.headers()['authorization'] !== 'Bearer ' + TOKEN) return route.fulfill({ status: 401, json: { message: 'Bad credentials' } });
  if (url.pathname === '/repos/tim/essensplanung-daten') return route.fulfill({ json: { private: true, default_branch: 'main' } });
  const m = url.pathname.match(/^\/repos\/tim\/essensplanung-daten\/contents\/(.+)$/);
  if (!m) return route.fulfill({ status: 404, json: { message: 'Not Found' } });
  const p = decodeURIComponent(m[1]), cur = repo.get(p);
  if (req.method() === 'GET') {
    if (!cur) return route.fulfill({ status: 404, json: { message: 'Not Found' } });
    return route.fulfill({ json: { sha: cur.sha, encoding: 'base64', content: cur.b64.replace(/(.{60})/g, '$1\n') } });
  }
  const body = JSON.parse(req.postData() || '{}');
  if (req.method() === 'PUT') {
    if (cur && body.sha !== cur.sha) { conflicts++; return route.fulfill({ status: cur && !body.sha ? 422 : 409, json: { message: 'sha does not match' } }); }
    const sha = crypto.createHash('sha1').update(body.content + Date.now() + Math.random()).digest('hex');
    repo.set(p, { sha, b64: body.content }); puts++;
    return route.fulfill({ status: cur ? 200 : 201, json: { content: { sha } } });
  }
  if (req.method() === 'DELETE') { repo.delete(p); return route.fulfill({ json: {} }); }
  route.fulfill({ status: 405, json: {} });
}
/* ---------- nachgebaute PocketBase auf dem Pi (Collection "trips" mit Tims Regeln) ---------- */
const PBURL = 'https://kostenpi.tail281e3e.ts.net';
const pbRecs = new Map(); let pbPatches = 0, pbTick = 0;
const pbTs = () => new Date().toISOString().replace('Z', '') + String(++pbTick).padStart(6, '0') + 'Z';
async function pocketbase(route) {
  const req = route.request(), u = new URL(req.url());
  const H = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' };
  const send = (status, json) => route.fulfill({ status, headers: H, json: json === undefined ? {} : json });
  if (req.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: H });
  const m = u.pathname.match(/^\/api\/collections\/trips\/records(?:\/([a-z0-9]{15}))?$/);
  if (!m) return send(404);
  const id = m[1], auth = req.headers()['x-trip-auth'];
  if (!id && req.method() === 'GET') return send(403, { message: 'Only superusers can perform this action.' });
  if (!id && req.method() === 'POST') {
    const b = JSON.parse(req.postData() || '{}');
    if (typeof b.auth !== 'string' || b.auth.length < 40 || b.auth.length > 100) return send(400, { message: 'auth' });
    if (typeof b.data === 'string' && b.data.length > 2000000) return send(400, { message: 'data too long' });
    if (b.id && (!/^[a-z0-9]{15}$/.test(b.id) || pbRecs.has(b.id))) return send(400, { message: 'id invalid or exists' });
    const nid = b.id || crypto.randomBytes(15).toString('hex').replace(/[^a-z0-9]/g, '').slice(0, 15).padEnd(15, 'a');
    const rec = { id: nid, auth: b.auth, data: b.data || '', rev: +b.rev || 0, created: pbTs(), updated: pbTs() };
    pbRecs.set(nid, rec); return send(200, rec);
  }
  const r = pbRecs.get(id);
  if (!r || r.auth !== auth) return send(404, { message: "The requested resource wasn't found." });
  if (req.method() === 'GET') return send(200, r);
  if (req.method() === 'PATCH') {
    const b = JSON.parse(req.postData() || '{}');
    if ('auth' in b && b.auth !== r.auth) return send(404);
    if ('data' in b) r.data = b.data; if ('rev' in b) r.rev = +b.rev; r.updated = pbTs(); pbPatches++;
    return send(200, r);
  }
  if (req.method() === 'DELETE') { pbRecs.delete(id); return route.fulfill({ status: 204, headers: H }); }
  send(405);
}
/* Server-Inhalt mit dem Schlüssel aus dem Link entschlüsseln (wie die App) */
async function pbDecrypt(secret, id) {
  const wc = crypto.webcrypto.subtle, te = t => new TextEncoder().encode(t), salt = te('essensplanung-v1');
  const b64d = s => Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
  const base = await wc.importKey('raw', b64d(secret), 'HKDF', false, ['deriveKey']);
  const key = await wc.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt, info: te('enc') }, base, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
  const [, iv, ct] = pbRecs.get(id).data.split('.');
  return JSON.parse(new TextDecoder().decode(await wc.decrypt({ name: 'AES-GCM', iv: b64d(iv) }, key, b64d(ct))));
}
const remoteDb = () => JSON.parse(Buffer.from(repo.get('data.json').b64, 'base64').toString('utf8'));
const liveNames = d => d.recipes.filter(r => !r.deleted && !r.archivedAt).map(r => r.name).sort();

/* ---------- Testrahmen ---------- */
let pass = 0, fail = 0;
const ok = (name, cond, info) => { if (cond) { pass++; console.log('  ✓ ' + name); } else { fail++; console.log('  ✗ ' + name + (info ? '  → ' + info : '')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function waitFor(fn, ms = 8000) { const t = Date.now(); while (Date.now() - t < ms) { try { if (await fn()) return true; } catch (e) {} await sleep(100); } return false; }

async function device(browser, label, errors) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true, locale: 'de-DE', timezoneId: 'Europe/Berlin' });
  await ctx.route('https://api.github.com/**', github);
  await ctx.route(PBURL + '/**', pocketbase);
  const page = await ctx.newPage();
  await page.clock.install({ time: new Date('2026-09-21T10:00:00+02:00') });
  await page.clock.resume();
  page.on('pageerror', e => errors.push(label + ': ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(label + ' console: ' + m.text()); });
  return { ctx, page };
}
const tap = async (page, sel) => { await page.locator(sel).first().click(); await sleep(220); };
const text = (page, sel) => page.locator(sel).first().innerText();

(async () => {
  await new Promise(r => server.listen(8765, r));
  const URL_ = 'http://localhost:8765/essensplanung.html';
  const browser = await chromium.launch();
  const errors = [];

  /* ===== Gerät A: Einrichtung ===== */
  console.log('Gerät A – Ersteinrichtung');
  const A = await device(browser, 'A', errors);
  let pa = A.page;
  await pa.goto(URL_);
  ok('Startbildschirm erscheint', await pa.locator('text=Neuen Haushalt einrichten').isVisible());
  await tap(pa, 'text=Neuen Haushalt einrichten');
  await pa.fill('#a-n', 'Familie Test');
  await pa.fill('#a-p1', 'geheim123'); await pa.fill('#a-p2', 'geheim123');
  await tap(pa, '[data-x=ok]');
  ok('App öffnet nach Einrichtung', await waitFor(() => pa.locator('#tabs button').count().then(n => n === 4)));
  ok('leerer Vorschlag lädt zu Rezepten ein', await pa.locator('text=Noch nichts in der Rotation').isVisible());
  await tap(pa, '[data-act=seed]');
  ok('Beispielrezepte geladen, Teller zeigt Gericht', await waitFor(() => pa.locator('.plate').isVisible()));
  const progress = await text(pa, '.progress');
  ok('Fortschritt „Durchlauf 1 · 1 von 6 Gerichten“', /Durchlauf 1 · 1 von 6 Gerichten/.test(progress), progress);

  console.log('Gerät A – Vorschlag');
  const first = await text(pa, '.plate');
  await tap(pa, '[data-act=postpone]');
  const second = await text(pa, '.plate');
  ok('„Später“ zeigt nächstes Gericht', first !== second, first + ' / ' + second);

  console.log('Gerät A – Wochenplan KW 40 mit gesperrtem Freitag');
  await tap(pa, '[data-tab=week]');
  await tap(pa, '[data-act=wk][data-arg="7"]');
  ok('KW 40 angezeigt', (await text(pa, '.kw b')) === 'KW 40');
  await tap(pa, '[data-act=fill]');
  ok('Entwurf erscheint', await pa.locator('.draftbar').isVisible());
  await tap(pa, '[data-act=day][data-arg="2026-10-02"]');
  await tap(pa, '.opt:has-text("Tag sperren")');
  await tap(pa, '[data-x=yes]');
  ok('Freitag im Entwurf gesperrt', /Auswärts essen/.test(await text(pa, '[data-arg="2026-10-02"]')));
  const dayTxt = await pa.locator('.day').allInnerTexts();
  ok('alle anderen Tage belegt', dayTxt.filter(t => /Frei/.test(t)).length === 0, dayTxt.join(' | '));
  // Tauschen im Entwurf
  const monBefore = await text(pa, '[data-arg="2026-09-28"] .nm');
  await tap(pa, '[data-act=day][data-arg="2026-09-28"]');
  await tap(pa, '.opt:has-text("Tauschen")');
  const monAfter = await text(pa, '[data-arg="2026-09-28"] .nm');
  ok('Tauschen im Entwurf ändert das Gericht', monBefore !== monAfter, monBefore + ' → ' + monAfter);
  await tap(pa, '[data-act=commit]');
  ok('Plan übernommen (kein Entwurf mehr)', !(await pa.locator('.draftbar').count()));
  const planA = await pa.evaluate(() => EP.live(db.plan).filter(p => p.date >= '2026-09-28' && p.date <= '2026-10-04').length);
  ok('7 Planeinträge in KW 40 gespeichert', planA === 7, planA);
  const rotOk = await pa.evaluate(() => EP.live(db.plan).filter(p => p.type === 'COOK' && p.rotationEntryId).every(p => db.rotation.find(e => e.id === p.rotationEntryId).status === 'PLANNED'));
  ok('Rotationseinträge der Kochtage sind PLANNED', rotOk);
  // übernommener Plan: Block entfernen gibt Eintrag frei
  const nextBefore = await pa.evaluate(() => recipeById(EP.nextEntries(db, 1, null, Math.random)[0].recipeId).name);
  const monName = await text(pa, '[data-arg="2026-09-28"] .nm');
  await tap(pa, '[data-act=day][data-arg="2026-09-28"]');
  await tap(pa, '.opt:has-text("Aus dem Plan entfernen")');
  const nextAfter = await pa.evaluate(() => recipeById(EP.nextEntries(db, 1, null, Math.random)[0].recipeId).name);
  ok('Entfernen: Gericht ist wieder nächster Vorschlag', nextAfter === monName, `${nextBefore} → ${nextAfter} (erwartet ${monName})`);
  await tap(pa, '[data-act=day][data-arg="2026-09-28"]');
  await tap(pa, '.opt:has-text("Nächstes aus der Rotation")');
  ok('Montag wieder belegt', !/Frei/.test(await text(pa, '[data-arg="2026-09-28"]')));

  console.log('Gerät A – Einkaufsliste');
  await tap(pa, '[data-act=toshop]');
  ok('Einkaufsliste für 28.09.–04.10.2026', /28\.09\.–04\.10\.2026/.test(await text(pa, 'main h2')));
  const hasSections = await pa.evaluate(() => [...document.querySelectorAll('.shopsec h3,summary')].map(h => h.textContent));
  ok('Abschnitte Markt / Supermarkt', ['Markt', 'Supermarkt'].every(s => hasSections.some(h => h.includes(s))), hasSections.join(','));
  ok('Gewürze standardmäßig im Supermarkt', await pa.evaluate(() => EP.sourceOf(findIngredient('Salz'), db.settings) === 'SUPERMARKT'));
  const boxes = await pa.evaluate(() => { document.querySelector('.rangebox').open = true; return [...document.querySelectorAll('.dategrid input')].map(i => { const r = i.getBoundingClientRect(); return [r.left, r.right]; }); });
  ok('Datumsfelder überlappen nicht', boxes.length === 2 && boxes[0][1] <= boxes[1][0], JSON.stringify(boxes));
  await tap(pa, '[data-act=shopwk][data-arg="7"]');
  ok('Einkauf: Woche weiterblättern', /KW 41/.test(await text(pa, '.weekhead .kw b')));
  await tap(pa, '[data-act=shopwk][data-arg="-7"]');
  const shopText = await pa.evaluate(() => shopText());
  ok('Textexport beginnt korrekt', shopText.startsWith('Einkaufsliste 28.09.–04.10.2026 (KW 40)'), shopText.split('\n')[0]);
  await pa.locator('[data-check]').first().check(); await sleep(200);
  ok('Abhaken wird gespeichert', (await pa.evaluate(() => db.shopping.checkedKeys.length)) === 1);
  await pa.fill('#extra', 'Spülmittel'); await pa.press('#extra', 'Enter'); await sleep(250);
  ok('Zusatzartikel erscheint', await pa.locator('text=Spülmittel').isVisible());

  console.log('Gerät A – Rezepte: Schnellerfassung, Einfügen, Editor');
  await tap(pa, '[data-tab=recipes]');
  await pa.fill('#qa', 'Ofengemüse'); await pa.press('#qa', 'Enter'); await sleep(250);
  ok('Schnellerfassung per Enter', await waitFor(() => pa.locator('.rcard:has-text("Ofengemüse")').isVisible()));
  ok('Eingabefeld bleibt fokussiert', await pa.evaluate(() => document.activeElement && document.activeElement.id === 'qa'));
  await pa.evaluate(() => {
    const dt = new DataTransfer(); dt.setData('text/plain', 'Risotto\nShakshuka\n\nOfengemüse');
    document.getElementById('qa').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
  });
  ok('Mehrzeiliges Einfügen legt 2 neue an, Dublette übersprungen', await waitFor(() => pa.locator('.rcard').count().then(n => n === 9)));
  const inCycle = await pa.evaluate(() => { const r = findRecipeByName('Risotto'); return EP.live(db.rotation).filter(e => e.recipeId === r.id && e.status === 'PENDING').length; });
  ok('neues Rezept sofort im laufenden Durchlauf', inCycle === 1, inCycle);
  // Gewicht
  await tap(pa, '.rcard:has-text("Risotto") [data-act=w][data-arg$="|1"]');
  ok('Gewichtung ×2', /×2/.test(await text(pa, '.rcard:has-text("Risotto") output')));
  // Suche nach Zutat
  await pa.fill('#rq', 'Kokosmilch'); await sleep(200);
  ok('Suche nach Zutat findet Gemüsecurry', await waitFor(() => pa.locator('.rcard').count().then(n => n === 1)) && /Gemüsecurry/.test(await text(pa, '.rcard')));
  await pa.fill('#rq', ''); await sleep(200);
  // Editor
  await tap(pa, '.rcard:has-text("Ofengemüse") [data-act=edit]');
  await tap(pa, '[data-act=serv][data-arg="1"]'); await tap(pa, '[data-act=serv][data-arg="1"]');
  ok('Live-Anzeige der Tage', /= 2 Tage bei 2 Portionen\/Tag/.test(await text(pa, '.live')));
  await tap(pa, '[data-act=serv][data-arg="1"]');
  ok('Hinweis bei ungerader Portionenzahl', /1 Portion bleibt übrig/.test(await text(pa, 'main')));
  await tap(pa, '[data-act=rowadd]');
  await pa.fill('[data-row="0"] [data-f=qty]', '1,5');
  await pa.selectOption('[data-row="0"] [data-f=unit]', 'KG');
  await pa.fill('[data-row="0"] [data-f=name]', 'Kartoffel');
  await pa.locator('[data-row="0"] [data-f=name]').dispatchEvent('change');
  ok('unbekannte Zutat: Kategorie-Auswahl erscheint', await waitFor(() => pa.locator('[data-row="0"] [data-f=cat]').isVisible()));
  await pa.selectOption('[data-row="0"] [data-f=cat]', 'GEMUESE');
  await tap(pa, '[data-act=rowadd]');
  await pa.fill('[data-row="1"] [data-f=name]', 'Olivenöl');
  await pa.fill('[data-row="1"] [data-f=qty]', '3');
  await pa.locator('[data-row="1"] [data-f=name]').dispatchEvent('change');
  await pa.fill('#e-ins', '1. Ofen auf 200 °C vorheizen\n2. Gemüse schneiden\nund würzen\n3. **40 Minuten** backen');
  await pa.fill('#e-tags', 'vegetarisch, einfach');
  // Bild hochladen (erzeugtes PNG)
  const png = await pa.evaluate(() => { const c = document.createElement('canvas'); c.width = 2400; c.height = 1600; const g = c.getContext('2d'); g.fillStyle = '#c84'; g.fillRect(0, 0, 2400, 1600); g.fillStyle = '#284'; g.beginPath(); g.arc(1200, 800, 500, 0, 7); g.fill(); return c.toDataURL('image/png').split(',')[1]; });
  await pa.setInputFiles('#e-file', { name: 'ofen.png', mimeType: 'image/png', buffer: Buffer.from(png, 'base64') });
  ok('Bild hochgeladen und als Titelbild markiert', await waitFor(() => pa.locator('.gallery .cover').isVisible()));
  await tap(pa, '[data-act=save]');
  const saved = await pa.evaluate(() => { const r = findRecipeByName('Ofengemüse'); return { s: r.servings, n: r.ingredients.length, u: r.ingredients.map(x => x.unit + ':' + x.quantity), tags: r.tags, img: r.images[0] }; });
  ok('Rezept gespeichert (5 Portionen, 2 Zutaten, Tags)', saved.s === 5 && saved.n === 2 && saved.tags.length === 2, JSON.stringify(saved));
  ok('Menge 1,5 kg korrekt gelesen, Standardeinheit Olivenöl = EL', saved.u.join() === 'KG:1.5,EL:3', saved.u.join());
  ok('Bild auf 1600 px verkleinert', saved.img && saved.img.width === 1600 && saved.img.height === 1067, JSON.stringify(saved.img));
  ok('Kartoffel als Gemüse → Markt', await pa.evaluate(() => EP.sourceOf(findIngredient('Kartoffel')) === 'MARKT'));
  // Kochansicht
  await tap(pa, '.rcard:has-text("Ofengemüse") [data-act=edit]');
  await tap(pa, '[data-act=cook]');
  const steps = await pa.locator('.steps-big li').allInnerTexts();
  ok('Kochansicht: 3 Schritte, Folgezeile angehängt', steps.length === 3 && /schneiden und würzen/.test(steps[1]), steps.join(' | '));
  ok('Kochansicht: Fettdruck', (await pa.locator('.steps-big li b').count()) === 1);
  await tap(pa, '[data-act=closecook]');
  await tap(pa, '[data-act=back]');


  console.log('Einkaufsorte: Zahl am Zahnrad für neue Zutat');
  const badge = await pa.evaluate(() => { const b = document.getElementById('gearbadge'); return b.classList.contains('hidden') ? '' : b.textContent; });
  ok('Zahnrad zeigt (1) für die neue Zutat Kartoffel', badge === '1', badge);
  await tap(pa, '#gear');
  ok('Einstellungen zeigen Einkaufsorte mit Zahl', /1/.test(await text(pa, '[data-arg=sources]')));
  await tap(pa, '[data-act=to][data-arg=sources]');
  ok('Kartoffel steht unter „Neu hinzugekommen“, vorbelegt mit Markt', await pa.locator('.newbox .srcrow:has-text("Kartoffel") [aria-pressed=true]:has-text("Markt")').isVisible());
  ok('Kategorie Gewürze: Supermarkt', (await pa.locator('[data-arg="GEWUERZE|SUPERMARKT"]').getAttribute('aria-pressed')) === 'true');
  await tap(pa, '.newbox .srcrow:has-text("Kartoffel") button:has-text("Supermarkt")');
  ok('Kartoffel jetzt Supermarkt', await pa.evaluate(() => EP.sourceOf(findIngredient('Kartoffel'), db.settings) === 'SUPERMARKT'));
  ok('Zahl am Zahnrad verschwindet', await pa.evaluate(() => document.getElementById('gearbadge').classList.contains('hidden')));
  await tap(pa, '[data-arg="OBST|SUPERMARKT"]');
  ok('ganze Kategorie umstellbar (Obst → Supermarkt)', await pa.evaluate(() => EP.sourceOf(findIngredient('Limette'), db.settings) === 'SUPERMARKT'));
  await tap(pa, '[data-arg="OBST|MARKT"]');
  await tap(pa, '[data-act=back]'); await tap(pa, '[data-act=back]');

  console.log('Saison im Rezept');
  await tap(pa, '[data-tab=recipes]');
  await tap(pa, '.rcard:has-text("Pfannkuchen") [data-act=edit]');
  ok('Standard: ganzjährig', await pa.locator('#e-allyear').isChecked());
  await pa.locator('#e-allyear').uncheck(); await sleep(250);
  ok('Monatsauswahl erscheint, aktueller Monat vorbelegt', await pa.locator('.months [aria-pressed=true]').count() === 1);
  await tap(pa, '.months button:has-text("Jun")');
  await tap(pa, '.months button:has-text("Sep")'); // September wieder abwählen → nur Juni
  await tap(pa, '[data-act=save]');
  ok('Saison „nur Juni“ gespeichert', await pa.evaluate(() => JSON.stringify(findRecipeByName('Pfannkuchen').seasonMonths) === '[6]'));
  ok('Rezeptkarte zeigt Saison', /Saison: Jun/.test(await text(pa, '.rcard:has-text("Pfannkuchen")')));
  const pfSuggest = await pa.evaluate(() => { const ids = EP.nextEntries(db, 12, null, Math.random, 'MAIN', 9).map(e => recipeById(e.recipeId).name); return ids.includes('Pfannkuchen'); });
  ok('Pfannkuchen wird im September nicht vorgeschlagen', !pfSuggest);

  console.log('Mittagessen und Kuchen: eigene Rotationen');
  await tap(pa, '[data-tab=suggest]');
  await tap(pa, '[data-act=slane][data-arg=LUNCH]');
  ok('Mittag leer: Vorschläge anbieten', await pa.locator('[data-act=seedlane][data-arg=LUNCH]').isVisible());
  await tap(pa, '[data-act=seedlane][data-arg=LUNCH]');
  const lunchDish = await text(pa, '.plate');
  ok('Mittagsvorschlag erscheint (grüner Teller)', await pa.locator('.plate.plate-lunch').isVisible() && lunchDish.length > 3, lunchDish);
  await tap(pa, '[data-act=slane][data-arg=CAKE]');
  await tap(pa, '[data-act=seedlane][data-arg=CAKE]');
  const cakeDish = await text(pa, '.plate');
  ok('Kuchen außerhalb der Saison werden nicht vorgeschlagen', !['Rhabarberkuchen', 'Erdbeerkuchen'].includes(cakeDish), cakeDish);
  const ingCount = await pa.evaluate(() => EP.live(db.ingredients).filter(i => i.name === 'Eier' || i.name === 'Butter').length);
  ok('gleiche Zutaten nicht doppelt angelegt (Eier, Butter)', ingCount === 2, ingCount);
  const kinds = await pa.evaluate(() => ({ L: liveRecipes().filter(r => r.kind === 'LUNCH').length, C: liveRecipes().filter(r => r.kind === 'CAKE').length }));
  ok('6 Mittagsgerichte und 7 Kuchen geladen', kinds.L === 6 && kinds.C === 7, JSON.stringify(kinds));
  await tap(pa, '[data-act=slane][data-arg=MAIN]');
  ok('Hauptgericht-Vorschlag bleibt unberührt', !(await pa.locator('.plate.plate-lunch, .plate.plate-cake').count()));

  console.log('Woche mit Mittag und Kuchen');
  await tap(pa, '[data-tab=week]');
  await pa.evaluate(() => { weekStartISO = EP.weekStart(EP.todayISO()); rerender(); });
  await tap(pa, '[data-act=wk][data-arg="7"]'); await tap(pa, '[data-act=wk][data-arg="7"]');
  ok('KW 41', (await text(pa, '.kw b')) === 'KW 41');
  await tap(pa, '[data-act=fill]');
  const lunchSat = await text(pa, '[data-arg="2026-10-10|LUNCH"]'), lunchSun = await text(pa, '[data-arg="2026-10-11|LUNCH"]'), cakeSat = await text(pa, '[data-arg="2026-10-10|CAKE"]');
  ok('Samstag und Sonntag Mittag im Entwurf gefüllt', !/Frei/.test(lunchSat) && !/Frei/.test(lunchSun), lunchSat + ' / ' + lunchSun);
  ok('Samstag Kuchen im Entwurf gefüllt', !/Frei/.test(cakeSat), cakeSat);
  ok('Mittag an Werktagen nicht vorgesehen', !(await pa.locator('[data-arg="2026-10-07|LUNCH"]').count()));
  ok('Samstag und Sonntag Mittag unterschiedlich', lunchSat !== lunchSun);
  await tap(pa, '[data-act=lane][data-arg="2026-10-10|CAKE"]');
  await tap(pa, '.opt:has-text("Tauschen")');
  ok('Kuchen im Entwurf tauschen', (await text(pa, '[data-arg="2026-10-10|CAKE"]')) !== cakeSat);
  await tap(pa, '[data-act=commit]');
  const laneCount = await pa.evaluate(() => ({ L: EP.live(db.plan).filter(p => p.lane === 'LUNCH' && p.date >= '2026-10-05' && p.date <= '2026-10-11').length,
    C: EP.live(db.plan).filter(p => p.lane === 'CAKE' && p.date >= '2026-10-05' && p.date <= '2026-10-11').length,
    M: EP.live(db.plan).filter(p => EP.laneOf(p) === 'MAIN' && p.date >= '2026-10-05' && p.date <= '2026-10-11').length }));
  ok('gespeichert: 7 Hauptgericht-Tage, 2× Mittag, 1× Kuchen', laneCount.M === 7 && laneCount.L === 2 && laneCount.C === 1, JSON.stringify(laneCount));
  await tap(pa, '[data-act=lane][data-arg="2026-10-10|CAKE"]');
  await tap(pa, '.opt:has-text("Als gebacken markieren")');
  ok('Kuchen als gebacken markiert', /Gebacken/.test(await text(pa, '[data-arg="2026-10-10|CAKE"]')));
  await tap(pa, '[data-act=toshop]');
  const shopRecipes = await text(pa, 'main .sub');
  ok('Einkaufsliste enthält Mittag und Kuchen', shopRecipes.includes(cakeSat.replace('Kuchen', '').trim()) || /kuchen/i.test(shopRecipes), shopRecipes);

  console.log('Mittagessen an einem anderen Tag, Blatt nach unten ziehen');
  await tap(pa, '[data-tab=week]');
  ok('Mittwoch hat standardmäßig keine Mittagszeile', !(await pa.locator('[data-arg="2026-10-07|LUNCH"]').count()));
  await tap(pa, '[data-act=day][data-arg="2026-10-07"]');
  ok('Tagesmenü bietet „Mittagessen hinzufügen“', await pa.locator('.opt:has-text("Mittagessen hinzufügen")').isVisible());
  ok('Tagesmenü bietet „Kuchen hinzufügen“', await pa.locator('.opt:has-text("Kuchen hinzufügen")').isVisible());
  await tap(pa, '.opt:has-text("Mittagessen hinzufügen")');
  await tap(pa, '.opt:has-text("Nächstes aus der Rotation")');
  ok('Mittagessen am Mittwoch eingeplant', await pa.locator('[data-arg="2026-10-07|LUNCH"]').isVisible() && !/Frei/.test(await text(pa, '[data-arg="2026-10-07|LUNCH"]')));
  ok('Samstag behält seine Mittag-/Kuchen-Zeilen', await pa.locator('[data-arg="2026-10-10|LUNCH"]').isVisible() && await pa.locator('[data-arg="2026-10-10|CAKE"]').isVisible());
  // echtes Wischen per Touch
  const cdp = await A.ctx.newCDPSession(pa);
  const swipe = async (dist) => {
    const g = await pa.locator('.grab').boundingBox();
    const x = g.x + g.width / 2, y = g.y + g.height / 2;
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
    for (let i = 1; i <= 8; i++) { await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x, y: y + dist * i / 8 }] }); await sleep(30); }
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await sleep(350);
  };
  await tap(pa, '[data-act=day][data-arg="2026-10-08"]');
  ok('Griff oben am Blatt sichtbar', await pa.locator('.grab').isVisible());
  await swipe(35);
  ok('kurzes Ziehen: Blatt federt zurück und bleibt offen', await pa.locator('#scrim').count() === 1);
  await swipe(220);
  ok('nach unten ziehen schließt das Blatt', await pa.locator('#scrim').count() === 0);
  await tap(pa, '[data-act=day][data-arg="2026-10-08"]');
  await tap(pa, '[data-x=no]');
  ok('„Schließen“ funktioniert weiterhin', await pa.locator('#scrim').count() === 0);
  await tap(pa, '#gear'); 
  await tap(pa, '[data-act=laneday][data-arg="CAKE|0"]');
  ok('Kuchen-Tage einstellbar (Sonntag dazu)', await pa.evaluate(() => db.settings.lanes.CAKE.days.includes(0) && db.settings.lanes.CAKE.days.includes(6)));
  await tap(pa, '[data-act=back]');

  console.log('Gerät A – Abgleich einrichten');
  await tap(pa, '#syncpill');
  ok('Abgleich-Seite bietet Pi-Einrichtung an', await pa.locator('[data-act=pbcreate]').isVisible());
  await tap(pa, 'details.ghalt summary');
  await pa.fill('#g-o', 'tim'); await pa.fill('#g-t', 'falsch'); await pa.fill('#g-p', 'geheim123');
  await tap(pa, '[data-act=syncsetup]');
  ok('falscher Token wird abgelehnt', await waitFor(() => pa.locator('#toast.on:has-text("ungültig")').isVisible()));
  await pa.fill('#g-t', TOKEN);
  await tap(pa, '[data-act=syncsetup]');
  ok('data.json im Repository angelegt', await waitFor(() => repo.has('data.json')));
  ok('Bilder im Repository (groß + Vorschau)', await waitFor(() => [...repo.keys()].filter(k => k.startsWith('images/')).length === 2), [...repo.keys()].join(','));
  ok('Anzeige „Abgeglichen“', await waitFor(() => pa.locator('#syncpill.ok').isVisible()));
  ok('Token nicht im Klartext gespeichert', await pa.evaluate(t => !JSON.stringify(localStorage).includes(t), TOKEN));
  ok('Token nicht in data.json', !Buffer.from(repo.get('data.json').b64, 'base64').toString().includes(TOKEN));

  /* ===== Gerät B ===== */
  console.log('Gerät B – mit bestehendem Haushalt verbinden');
  const B = await device(browser, 'B', errors);
  const pb = B.page;
  await pb.goto(URL_);
  await tap(pb, 'text=Mit bestehendem Haushalt verbinden');
  ok('Verbinden fragt zuerst nach dem Link', await pb.locator('#jl-l').isVisible());
  await tap(pb, '[data-x=gh]');
  await pb.fill('#j-o', 'tim'); await pb.fill('#j-t', TOKEN); await pb.fill('#j-p', 'falschesPW');
  await tap(pb, '[data-x=ok]');
  ok('falsches Passwort wird abgelehnt', await waitFor(() => pb.locator('#toast.on:has-text("passt nicht")').isVisible()));
  await pb.fill('#j-p', 'geheim123');
  await tap(pb, '[data-x=ok]');
  ok('Gerät B öffnet die App', await waitFor(() => pb.locator('#tabs button').count().then(n => n === 4)));
  const namesA = await pa.evaluate(() => liveRecipes().map(r => r.name).sort().join());
  const namesB = await pb.evaluate(() => liveRecipes().map(r => r.name).sort().join());
  ok('gleiche Rezepte auf beiden Geräten', namesA === namesB, namesB);
  await tap(pb, '[data-tab=week]'); await tap(pb, '[data-act=wk][data-arg="7"]');
  const weekB = await pb.locator('.day .nm').allInnerTexts();
  await tap(pa, '[data-tab=week]');
  await pa.evaluate(() => { weekStartISO = '2026-09-28'; rerender(); }); await sleep(200);
  const weekA = await pa.locator('.day .nm').allInnerTexts();
  ok('gleicher Wochenplan auf Gerät B', weekA.join() === weekB.join(), weekB.join(' | '));
  await tap(pb, '[data-tab=recipes]');
  await tap(pb, '.rcard:has-text("Ofengemüse") [data-act=edit]');
  ok('Bild wird auf Gerät B aus dem Repository geladen', await waitFor(() => pb.evaluate(() => { const i = document.querySelector('.gallery img'); return i && i.src.startsWith('data:image/jpeg'); })));
  await tap(pb, '[data-act=back]');

  console.log('Abgleich B → A');
  await pb.fill('#qa', 'Linsencurry'); await pb.press('#qa', 'Enter');
  ok('Änderung von B landet im Repository', await waitFor(() => liveNames(remoteDb()).includes('Linsencurry')));
  await pa.evaluate(() => Sync.run({ force: true }));
  ok('Gerät A sieht das neue Rezept von B', await waitFor(() => pa.evaluate(() => !!findRecipeByName('Linsencurry'))));

  console.log('Gleichzeitige Änderungen (Konflikt)');
  const c0 = conflicts;
  await pa.evaluate(() => { clearTimeout(Sync.timer); const r = findRecipeByName('Shakshuka'); setInRotation(r, false); return persist({ noSync: true }).then(() => { Sync.dirty = true; }); });
  await pb.evaluate(() => { clearTimeout(Sync.timer); const r = findRecipeByName('Pfannkuchen'); r.servings = 6; EP.touch(r); EP.syncRecipeIntoCycles(db, r, Math.random); return persist({ noSync: true }).then(() => { Sync.dirty = true; }); });
  // beide Geräte gleichen exakt gleichzeitig ab → einer bekommt einen Versionskonflikt
  await Promise.all([pa.evaluate(() => Sync.run({ force: true })), pb.evaluate(() => Sync.run({ force: true }))]);
  ok('Versionskonflikt ist aufgetreten und wurde aufgelöst', conflicts > c0, 'Konflikte: ' + (conflicts - c0));
  await pb.evaluate(() => Sync.run({ force: true }));
  await pa.evaluate(() => Sync.run({ force: true }));
  const fin = remoteDb();
  const g = n => fin.recipes.find(r => r.name === n);
  ok('Repository enthält beide Änderungen', g('Shakshuka').inRotation === false && g('Pfannkuchen').servings === 6);
  ok('Gerät A hat beide Änderungen', await pa.evaluate(() => !findRecipeByName('Shakshuka').inRotation && findRecipeByName('Pfannkuchen').servings === 6));
  ok('Gerät B hat beide Änderungen', await pb.evaluate(() => !findRecipeByName('Shakshuka').inRotation && findRecipeByName('Pfannkuchen').servings === 6));
  const pend = await pa.evaluate(() => { const r = findRecipeByName('Shakshuka'); return EP.live(db.rotation).filter(e => e.recipeId === r.id && e.status === 'PENDING').length; });
  ok('pausiertes Rezept hat keine offenen Einträge mehr', pend === 0, pend);

  console.log('Umzug von GitHub auf den Pi');
  await tap(pa, '#syncpill');
  ok('Umzug wird angeboten', await pa.locator('[data-act=pbmigrate]').isVisible());
  await pa.fill('#pb-pw2', 'falsch'); await tap(pa, '[data-act=pbmigrate]');
  ok('Umzug mit falschem Passwort abgelehnt', await waitFor(() => pa.locator('#toast.on:has-text("stimmt nicht")').isVisible()) && pbRecs.size === 0);
  await pa.fill('#pb-pw2', 'geheim123'); await tap(pa, '[data-act=pbmigrate]');
  ok('Haushalt auf dem Pi angelegt', await waitFor(() => pa.evaluate(() => Sync.isPB && Sync.state === 'ok'), 12000), await pa.evaluate(() => Sync.state + ' ' + Sync.msg));
  ok('Bilder auf dem Pi (groß + Vorschau)', await waitFor(() => pbRecs.size === 3), 'Datensätze: ' + pbRecs.size);
  const link = await pa.inputValue('#pb-link');
  const lm = link.match(/#join=([a-z0-9]{15})\.([A-Za-z0-9_-]{43})$/);
  ok('Verbindungslink wird angezeigt', !!lm, link);
  const mainId = lm[1], secret = lm[2];
  const rawAll = [...pbRecs.values()].map(r => r.data).join('');
  ok('Server sieht nur verschlüsselte Daten', !/Shakshuka|Pfannkuchen|geheim|data:image/.test(rawAll) && pbRecs.get(mainId).data.startsWith('v1.'));
  ok('Server-Inhalt entspricht dem Stand von A', liveNames(await pbDecrypt(secret, mainId)).join() === await pa.evaluate(() => liveRecipes().map(r => r.name).sort().join()));
  ok('Geheimnis nicht im Klartext auf dem Gerät', await pa.evaluate(s => !JSON.stringify(localStorage).includes(s), secret));
  ok('GitHub-Repository bleibt unverändert erhalten', repo.has('data.json'));

  console.log('Gerät B zieht per Link mit um');
  await tap(pb, '#syncpill');
  await pb.fill('#pb-in', link); await pb.fill('#pb-pw3', 'geheim123');
  await tap(pb, '[data-act=pbjoinhere]');
  ok('Gerät B mit dem Pi verbunden', await waitFor(() => pb.evaluate(() => Sync.isPB && Sync.state === 'ok'), 12000), await pb.evaluate(() => Sync.state + ' ' + Sync.msg));
  await tap(pb, '[data-tab=recipes]');
  await pb.fill('#qa', 'Ofenkartoffeln'); await pb.press('#qa', 'Enter');
  ok('Änderung von B landet auf dem Pi', await waitFor(async () => liveNames(await pbDecrypt(secret, mainId)).includes('Ofenkartoffeln')));
  await pa.evaluate(() => Sync.run({ force: true }));
  ok('Gerät A sieht das neue Rezept von B', await waitFor(() => pa.evaluate(() => !!findRecipeByName('Ofenkartoffeln'))));

  console.log('Gleichzeitige Änderungen über den Pi');
  await pa.evaluate(() => { clearTimeout(Sync.timer); const r = findRecipeByName('Ofenkartoffeln'); r.servings = 8; EP.touch(r); return persist({ noSync: true }).then(() => { Sync.dirty = true; Sync.gen++; }); });
  await pb.evaluate(() => { clearTimeout(Sync.timer); const r = findRecipeByName('Linsencurry'); r.notes = 'mit Kokosmilch'; EP.touch(r); return persist({ noSync: true }).then(() => { Sync.dirty = true; Sync.gen++; }); });
  await Promise.all([pa.evaluate(() => Sync.run({ force: true })), pb.evaluate(() => Sync.run({ force: true }))]);
  for (let i = 0; i < 2; i++) { await pa.evaluate(() => Sync.run({ force: true })); await pb.evaluate(() => Sync.run({ force: true })); }
  const both = d => { const a = d.recipes.find(r => r.name === 'Ofenkartoffeln'), b = d.recipes.find(r => r.name === 'Linsencurry'); return a && b && a.servings === 8 && b.notes === 'mit Kokosmilch'; };
  ok('Pi enthält beide Änderungen', both(await pbDecrypt(secret, mainId)));
  ok('Gerät A hat beide Änderungen', await pa.evaluate(() => findRecipeByName('Ofenkartoffeln').servings === 8 && findRecipeByName('Linsencurry').notes === 'mit Kokosmilch'));
  ok('Gerät B hat beide Änderungen', await pb.evaluate(() => findRecipeByName('Ofenkartoffeln').servings === 8 && findRecipeByName('Linsencurry').notes === 'mit Kokosmilch'));

  console.log('Neues Gerät C öffnet den Link');
  const C = await device(browser, 'C', errors);
  const pc = C.page;
  await pc.goto(link.replace(/^https?:\/\/[^/]+/, URL_.replace(/\/[^/]*$/, '')));
  ok('Link öffnet das Verbinden mit ausgefülltem Link', await waitFor(() => pc.locator('#jl-l').isVisible()) && (await pc.inputValue('#jl-l')).includes(mainId));
  ok('Geheimnis verschwindet aus der Adresszeile', !(await pc.evaluate(() => location.hash)));
  await pc.fill('#jl-p', 'falschesPW'); await tap(pc, '[data-x=ok]');
  ok('C: falsches Passwort wird abgelehnt', await waitFor(() => pc.locator('#toast.on:has-text("passt nicht")').isVisible()));
  await pc.fill('#jl-p', 'geheim123'); await tap(pc, '[data-x=ok]');
  ok('Gerät C öffnet die App', await waitFor(() => pc.locator('#tabs button').count().then(n => n === 4)));
  ok('C hat denselben Stand', await pc.evaluate(() => liveRecipes().map(r => r.name).sort().join()) === await pa.evaluate(() => liveRecipes().map(r => r.name).sort().join()));
  await tap(pc, '[data-tab=recipes]');
  await tap(pc, '.rcard:has-text("Ofengemüse") [data-act=edit]');
  ok('Bild wird auf C vom Pi geladen', await waitFor(() => pc.evaluate(() => { const i = document.querySelector('.gallery img'); return i && i.src.startsWith('data:image/jpeg'); })));
  await tap(pc, '[data-act=back]');

  console.log('Sitzung und Anmeldung');
  await pa.reload();
  ok('Sitzung bleibt nach Neuladen bestehen', await waitFor(() => pa.locator('#tabs button').count().then(n => n === 4)));
  await tap(pa, '#gear'); await tap(pa, '[data-act=logout]'); await tap(pa, '[data-x=yes]');
  ok('Nach Abmelden: Passwortabfrage', await waitFor(() => pa.locator('#l-p').isVisible()));
  for (let i = 0; i < 5; i++) { await pa.fill('#l-p', 'nein' + i); await tap(pa, '[data-x=ok]'); await sleep(350); }
  await pa.fill('#l-p', 'geheim123'); await tap(pa, '[data-x=ok]'); await sleep(400);
  ok('Sperre nach 5 Fehlversuchen', /Zu viele Versuche/.test(await text(pa, '#l-e')), await text(pa, '#l-e'));
  await pa.evaluate(() => localStorage.removeItem('ep_lock'));
  await pa.fill('#l-p', 'geheim123'); await tap(pa, '[data-x=ok]');
  ok('Anmeldung mit richtigem Passwort', await waitFor(() => pa.locator('#tabs button').count().then(n => n === 4)));
  ok('Abgleich nach Anmeldung wieder aktiv (Pi)', await waitFor(() => pa.evaluate(() => Sync.enabled() && Sync.isPB)));

  console.log('Reste verschieben, streichen, auswärts essen');
  await pa.evaluate(() => { const r = findRecipeByName('Tortillas mit Chili sin Carne'); placeBlock('2026-10-19', { recipeId: r.id, rotationEntryId: null }); return persist(); });
  await tap(pa, '[data-tab=week]');
  await pa.evaluate(() => { weekStartISO = '2026-10-19'; rerender(); }); await sleep(200);
  const planOf = () => pa.evaluate(() => EP.live(db.plan).filter(p => EP.laneOf(p) === 'MAIN' && p.date >= '2026-10-19' && p.date <= '2026-11-08')
    .sort((a, b) => a.date.localeCompare(b.date)).map(p => p.date.slice(5) + ':' + (p.type === 'BLOCKED' ? 'gesperrt' : p.type === 'COOK' ? 'koch' : 'rest') + (p.dayCount ? p.dayIndex + '/' + p.dayCount : '')).join(' '));
  ok('Ausgangslage: Kochtag + 2 Resttage', await planOf() === '10-19:koch1/3 10-20:rest2/3 10-21:rest3/3', await planOf());
  await tap(pa, '[data-act=day][data-arg="2026-10-20"]');
  ok('Resttag bietet „Reste verschieben“ und „Reste streichen“', await pa.locator('.opt:has-text("Reste verschieben")').isVisible() && await pa.locator('.opt:has-text("Reste streichen")').isVisible());
  await tap(pa, '.opt:has-text("Reste verschieben")');
  await pa.fill('#dv', '2026-10-19'); await pa.dispatchEvent('#dv', 'input');
  ok('Reste vor oder am Kochtag werden abgelehnt', await pa.locator('[data-x=yes]').isDisabled() && /nach dem Kochtag/.test(await text(pa, '#dp')));
  await pa.fill('#dv', '2026-10-21'); await pa.dispatchEvent('#dv', 'input');
  ok('belegter Tag wird abgelehnt', await pa.locator('[data-x=yes]').isDisabled());
  await pa.fill('#dv', '2026-10-23'); await pa.dispatchEvent('#dv', 'input');
  await tap(pa, '[data-x=yes]');
  ok('Resttag auf Freitag verschoben, Tage neu gezählt', await planOf() === '10-19:koch1/3 10-21:rest2/3 10-23:rest3/3', await planOf());
  await tap(pa, '[data-act=day][data-arg="2026-10-21"]'); await tap(pa, '.opt:has-text("Reste streichen")');
  ok('Resttag gestrichen', await planOf() === '10-19:koch1/2 10-23:rest2/2', await planOf());
  await tap(pa, '[data-act=day][data-arg="2026-10-23"]'); await tap(pa, '.opt:has-text("Tag sperren")'); await tap(pa, '[data-x=yes]');
  ok('Auswärts essen am Resttag: Reste rutschen weiter, Kochtag bleibt', await planOf() === '10-19:koch1/2 10-23:gesperrt 10-24:rest2/2', await planOf());
  // Übertrag in die Folgewoche, dort im Entwurf auswärts essen
  await pa.evaluate(() => { const r = findRecipeByName('Tortillas mit Chili sin Carne'); placeBlock('2026-11-01', { recipeId: r.id, rotationEntryId: null }); return persist(); });
  await pa.evaluate(() => { weekStartISO = '2026-11-02'; rerender(); }); await sleep(200);
  await tap(pa, '[data-act=fill]');
  await tap(pa, '[data-act=day][data-arg="2026-11-02"]');
  ok('Übertrag im Entwurf bietet „Tag sperren“ und „Reste verschieben“', await pa.locator('.opt:has-text("Tag sperren")').isVisible() && await pa.locator('.opt:has-text("Reste verschieben")').isVisible());
  await tap(pa, '.opt:has-text("Tag sperren")'); await tap(pa, '[data-x=yes]');
  const dview = await pa.locator('.day .what').allInnerTexts();
  ok('Entwurf: Montag gesperrt, Übertrag-Reste Di + Mi', /Gesperrt/.test(dview[0]) && /Tortillas.*Reste 2\/3/s.test(dview[1]) && /Tortillas.*Reste 3\/3/s.test(dview[2]), dview.slice(0, 3).join(' | '));
  ok('Entwurf füllt die übrigen Tage', dview.slice(3).every(t => !/Frei/.test(t)), dview.slice(3).join(' | '));
  await tap(pa, '[data-act=commit]');
  ok('nach Übernehmen gespeichert', await planOf().then(s => s.includes('11-02:gesperrt') && s.includes('11-03:rest2/3') && s.includes('11-04:rest3/3')), await planOf());

  console.log('Reste in der Vergangenheit (doch auswärts gegessen)');
  const pastOf = () => pa.evaluate(() => EP.live(db.plan).filter(p => EP.laneOf(p) === 'MAIN' && ((p.recipeId === findRecipeByName('Linsensuppe').id && p.date < '2026-09-28') || (p.type === 'BLOCKED' && p.date === '2026-09-19')))
    .sort((a, b) => a.date.localeCompare(b.date)).map(p => p.date.slice(5) + ':' + (p.type === 'BLOCKED' ? 'gesperrt' : p.type === 'COOK' ? 'koch' : 'rest' + p.dayIndex + '/' + p.dayCount) + (p.date >= '2026-09-21' && p.type !== 'BLOCKED' ? '(' + p.status + ')' : '')));
  await pa.evaluate(() => { const r = findRecipeByName('Linsensuppe'); r.servings = 6; EP.touch(r);
    EP.live(db.plan).filter(p => p.recipeId === r.id && p.date < '2026-09-28').forEach(p => EP.tomb(p));
    placeBlock('2026-09-18', { recipeId: r.id, rotationEntryId: null }); housekeeping(); return persist(); });
  await pa.evaluate(() => { weekStartISO = '2026-09-14'; draft = null; rerender(); }); await sleep(200);
  const p0 = await pastOf();
  ok('Ausgangslage: Linsensuppe 18.–20.09. (vergangen)', p0.join() === '09-18:koch,09-19:rest2/3,09-20:rest3/3', p0.join());
  await tap(pa, '[data-act=day][data-arg="2026-09-19"]');
  ok('vergangener Resttag bietet „Tag sperren“', await pa.locator('.opt:has-text("Tag sperren")').isVisible() && await pa.locator('.opt:has-text("Reste verschieben")').isVisible());
  await tap(pa, '.opt:has-text("Tag sperren")'); await tap(pa, '[data-x=yes]');
  const p1 = await pastOf();
  const moved = p1.filter(x => /\(PLANNED\)/.test(x));
  ok('19.09. gesperrt, 20.09. bleibt, Reste kommen auf heute oder später', p1.includes('09-19:gesperrt') && p1.some(x => x.startsWith('09-20:rest')) && moved.length === 1 && moved[0] >= '09-21', p1.join());

  console.log('Rezept-Import aus dem Scanner-Chat');
  await tap(pa, '[data-tab=recipes]');
  ok('Knopf „Rezepte aus JSON importieren“ vorhanden', await pa.locator('[data-act=rimport]').isVisible());
  await tap(pa, '[data-act=rimport]');
  await pa.fill('#imp-t', 'Hier ist das Rezept:\n```json\n{ "format": "essensplanung-import", "rezepte": [ { "name": "Kartoffelsuppe", "art": "Hauptgericht", "portionen": 4, "zutaten": [ { "name": "Kartoffel", "menge": "½", "einheit": "kg" }, { "name": "Lauch", "menge": 1, "einheit": "Stange" } ], "anleitung": ["Schälen", "Kochen"] } ] }\n```');
  await tap(pa, '#scrim [data-x=yes]');
  ok('Vorschau zeigt das Rezept', /1 Rezept gefunden/.test(await text(pa, '#scrim h2')));
  await tap(pa, '#scrim [data-x=yes]');
  ok('Rezept importiert mit Zutaten und Anleitung', await pa.evaluate(() => { const r = findRecipeByName('Kartoffelsuppe'); return r && r.ingredients.length === 2 && /1\. Schälen/.test(r.instructions); }));

  console.log('Sicherung');
  const exp = await pa.evaluate(() => exportData(true));
  const ej = JSON.parse(exp);
  ok('Export enthält Rezepte und Bilder, keine Anmeldedaten', ej.data.recipes.length > 5 && Object.keys(ej.images).length === 1 && !ej.data.household);

  console.log('Darstellung');
  await tap(pa, '[data-tab=suggest]');
  await pa.screenshot({ path: __dirname + '/shot-vorschlag.png' });
  await tap(pa, '[data-tab=week]'); await tap(pa, '[data-act=wk][data-arg="7"]');
  await pa.screenshot({ path: __dirname + '/shot-woche.png' });
  await tap(pa, '[data-act=toshop]');
  await pa.screenshot({ path: __dirname + '/shot-einkauf.png', fullPage: true });
  await pa.emulateMedia({ colorScheme: 'dark' });
  await tap(pa, '[data-tab=recipes]');
  await pa.screenshot({ path: __dirname + '/shot-rezepte-dunkel.png' });
  const overflow = await pa.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
  ok('kein seitliches Scrollen bei 390 px', !overflow);
  const small = await pa.evaluate(() => [...document.querySelectorAll('button:not(.hidden),.btn')].filter(b => { const r = b.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 32; }).map(b => b.textContent.trim().slice(0, 20)));
  ok('Bedienelemente ausreichend groß', small.length === 0, small.join(', '));

  ok('keine JavaScript-Fehler', errors.length === 0, errors.join(' || '));
  console.log(`\n${pass} bestanden, ${fail} fehlgeschlagen  (Schreibvorgänge im Repo: ${puts}, Konflikte aufgelöst: ${conflicts}, Schreibvorgänge auf dem Pi: ${pbPatches})`);
  await browser.close(); server.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('ABBRUCH:', e.message); process.exit(2); });
