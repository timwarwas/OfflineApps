// E2E: Einkaufsliste anordnen (Blöcke verschieben/ausblenden, je Gerät).
// Aufruf: node e2e-anordnen.js   (SHOTS=<ordner> für Bildschirmfotos)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');
let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const LROW = 'label.item:has(.nm:text-matches("^Lauch\\s*(für|$)"))';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };
const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' }); res.end(fs.readFileSync(f));
});
(async () => {
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log(`Durchlauf ${scheme}`);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
    const page = await ctx.newPage();
    await page.clock.install({ time: new Date('2026-11-02T10:00:00+01:00') }); await page.clock.resume();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
    const tap = async sel => { await page.locator(sel).first().click(); await sleep(250); };
    const over = () => page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    await page.goto(URL_);
    await tap('text=Neuen Haushalt einrichten');
    await page.fill('#a-n', 'Posten-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
    await tap('[data-x=ok]');
    await until(() => page.locator('#tabs button').count().then(n => n === 4));
    ok('Start im Reiter „Einkauf“', await page.locator('#tabs [data-tab=shop][aria-current=page]').count() === 1);
    await page.evaluate(() => {
      db.settings.portionsPerDay = 2;
      const ing = (n, c) => { const i = EP.touch({ id: EP.uuid(), name: n, category: c, deleted: false }); db.ingredients.push(i); return i; };
      const lauch = ing('Lauch', 'GEMUESE'), kart = ing('Kartoffel', 'GEMUESE');
      const mk = (n, items) => { const r = newRecipe(n, 'MAIN'); r.servings = 2; items.forEach(([i, q, u], k) => r.ingredients.push({ ingredientId: i.id, quantity: q, unit: u, note: '', sortOrder: k })); db.recipes.push(r); return r; };
      const a = mk('Lauchsuppe', [[lauch, 2, 'STUECK'], [kart, 500, 'G']]), b = mk('Quiche', [[lauch, 1, 'STUECK']]);
      placeBlock('2026-11-03', { recipeId: a.id }); placeBlock('2026-11-05', { recipeId: b.id });
      persist();
    });
    await tap('[data-tab=week]'); await tap('[data-tab=shop]');
    await page.fill('#extra', 'Milch'); await tap('[data-act=addextra]');
    await page.evaluate(() => { const st = shopState(); st.extras.forEach(x => { x.checked = true; }); persist(); rerender(); ACT.clearchecked(); }); await sleep(200);
    const order = () => page.evaluate(() => { const m = $('#main'), at = sel => { const e = $(sel, m); return e ? [...m.querySelectorAll('*')].indexOf(e) : -1; };
      return { period: at('.shopmode'), list: at('.shopcols'), add: at('#extra'), sugg: at('.suggbox'), actions: at('[data-act=copyshop]') }; });
    let o = await order();
    ok('Standard: Zeitraum, Liste, Hinzufügen, Vorschläge, Knöpfe', o.period < o.list && o.list < o.add && o.add < o.sugg && o.sugg < o.actions, JSON.stringify(o));
    ok('Knopf „Anordnen“ unten', await page.locator('#main [data-act=shoplayout]').count() === 1);
    await tap('#main [data-act=shoplayout]');
    ok('Blatt mit 7 Blöcken, Liste ohne Schalter', await page.locator('.layrow').count() === 7 && await page.locator('[data-show]').count() === 6);
    const up = async (k, n) => { for (let i = 0; i < n; i++) await tap(`[data-mv="${k}|-1"]`); };
    await up('add', 3);
    ok('„Artikel hinzufügen“ ganz nach oben', (await page.$$eval('.layrow .laynm', e => e.map(x => x.textContent)))[0] === 'Artikel hinzufügen');
    await page.locator('[data-show=sugg]').uncheck(); await sleep(200);
    await page.locator('[data-show=title]').uncheck(); await sleep(200);
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/anordnen-${scheme}.png` });
    const bb = await page.locator('[data-mv="list|-1"]').boundingBox();
    ok('Pfeile ≥44 px, kein seitliches Scrollen', bb.width >= 44 && bb.height >= 44 && !(await over()));
    await tap('#scrim [data-x=no]');
    o = await order();
    ok('Liste: Hinzufügen oben, Vorschläge weg', o.add >= 0 && o.add < o.period && o.add < o.list && o.sugg === -1, JSON.stringify(o));
    ok('Überschrift ausgeblendet', await page.locator('#main .printonly-h').count() === 0);
    await page.locator('[data-show=period]').count();
    await tap('#main [data-act=shoplayout]'); await page.locator('[data-show=period]').uncheck(); await sleep(200); await tap('#scrim [data-x=no]');
    ok('Zeitraum ausgeblendet ohne Fehler', await page.locator('#main .shopmode').count() === 0);
    await page.fill('#extra', 'Brot'); await tap('[data-act=addextra]');
    ok('Hinzufügen funktioniert weiter', await page.locator('.xitem:has-text("Brot")').count() === 1);
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/anordnen-liste-${scheme}.png` });
    await page.reload(); await until(() => page.locator('#tabs button').count().then(n => n === 4));
    o = await order();
    ok('Bleibt nach Neustart', o.add >= 0 && o.period === -1 && o.sugg === -1, JSON.stringify(o));
    await tap('#gear');
    ok('Einstellungen: „Einkaufsliste anordnen“', await page.locator('[data-act=shoplayout]').count() === 1);
    await tap('[data-act=shoplayout]'); await tap('#scrim [data-x=reset]'); await tap('#scrim [data-x=no]');
    await tap('[data-tab=shop]');
    o = await order();
    ok('„Standard“ stellt alles wieder her', o.period < o.list && o.list < o.add && o.sugg > o.add, JSON.stringify(o));
    await ctx.close();
  }
  ok('Keine JS-Fehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})();
