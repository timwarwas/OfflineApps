/* Wandelt die Seed-Daten aus Anhang A in das interne Datenmodell um.
   Wird in der App („Beispieldaten laden“) und in den Tests genutzt. */
function seedToDb(seed, EPref) {
  const E = EPref || EP;
  const settings = E.touch(Object.assign({ portionsPerDay: 2, roundingMode: 'FLOOR', rotationMode: 'SHUFFLE', marketListShowQuantities: true }, seed.settings || {}));
  const ingredients = (seed.ingredients || []).map(i => E.touch({
    id: E.uuid(), name: i.name, category: i.category, shoppingSource: i.shoppingSource || null,
    defaultUnit: i.defaultUnit || 'STUECK', reviewed: true, deleted: false,
  }));
  const byName = new Map(ingredients.map(i => [i.name.toLowerCase(), i]));
  const recipes = (seed.recipes || []).map((r, idx) => E.touch({
    id: E.uuid(), name: r.name, kind: r.kind || 'MAIN', seasonMonths: r.seasonMonths || null, inRotation: r.inRotation !== false, weight: r.weight || 1,
    servings: r.servings || settings.portionsPerDay, daysOverride: r.daysOverride || null,
    sortOrder: idx + 1, notes: r.notes || '', instructions: r.instructions || '',
    prepTimeMinutes: r.prepTimeMinutes || null, tags: r.tags || [], archivedAt: null, deleted: false,
    images: [],
    ingredients: (r.ingredients || []).map((x, k) => ({
      ingredientId: (byName.get(x.ingredient.toLowerCase()) || {}).id,
      quantity: x.quantity == null ? null : x.quantity, unit: x.unit || null, note: x.note || '', sortOrder: k + 1,
    })).filter(x => x.ingredientId),
  }));
  return { version: 1, household: null, settings, shopping: E.touch({ from: '', to: '', checkedKeys: [], extraItems: [] }),
    recipes, ingredients, rotation: [], plan: [] };
}
if (typeof module !== 'undefined') module.exports = seedToDb;
