// Kurztest der Sammlung nach dem Aufräumen (17.11.2026): Hauptmenü, Kosten, Spiele, Workout.
// Aufruf: node sammlung-e2e.js   (ROOT=<Ordner mit den HTML-Dateien>)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');
const ROOT = process.env.ROOT || '/home/claude/offlineapps';
let fails = 0, passes = 0;
const ok = (m, c, x) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || x === undefined ? '' : ' → ' + x)); c ? passes++ : fails++; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const server = http.createServer((req, res) => { let u = req.url.split('?')[0].split('#')[0]; if (u.endsWith('/')) u += 'index.html'; const f = ROOT + u;
  if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : f.endsWith('.webmanifest') ? 'application/manifest+json' : 'text/html; charset=utf-8' }); res.end(fs.readFileSync(f)); });
(async () => {
  await new Promise(r => server.listen(0, r)); const base = `http://localhost:${server.address().port}/`;
  const b = await chromium.launch(); const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log('Durchlauf ' + scheme);
    const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost)/, r => r.abort());
    const p = await ctx.newPage(); p.on('pageerror', e => errors.push(p.url().split('/').pop() + ': ' + e.message));
    const over = () => p.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    const tap = async s => { await p.locator(s).first().click(); await sleep(300); };
    const homeOk = async sel => { const l = p.locator(sel).first(); const bb = await l.boundingBox(); return !!bb && bb.width >= 44 && bb.height >= 44 && await l.locator('svg').count() === 1 && /Übersicht|Anwendungssammlung/.test(await l.getAttribute('aria-label') || ''); };

    // ---- Hauptmenü
    await p.goto(base + 'index.html'); await sleep(500);
    const order = await p.evaluate(() => [...document.querySelectorAll('#scr-menu .ghead')].map(h => h.textContent.trim()));
    ok('Hauptmenü: Apps zuerst, Konto darunter', JSON.stringify(order) === JSON.stringify(['Alltag', 'Freizeit', 'Konto']), order.join(','));
    ok('Hauptmenü: 7 App-Kacheln', await p.locator('#scr-menu .apptile').count() === 7);
    ok('Statusleisten-Farbe gesetzt (hell + dunkel)', await p.locator('meta[name=theme-color]').count() === 2);
    await tap('#konto-row');
    ok('Konto-Zeile öffnet die Anmeldung', await p.locator('#scr-konto-login.active, #scr-konto.active').count() === 1);
    await tap('.screen.active .back');
    await tap('#scr-menu .apptile:has-text("Briefe")');
    ok('Briefe: Haus-Symbol statt Pfeil', await p.locator('#scr-lt-profiles.active').count() === 1 && await homeOk('#scr-lt-profiles .back'));
    ok('Briefe: kein doppeltes Symbol', await p.evaluate(() => getComputedStyle(document.querySelector('#scr-lt-profiles .back'), '::before').content) === 'none');
    await tap('#scr-lt-profiles .back');
    ok('… führt zurück ins Hauptmenü', await p.locator('#scr-menu.active').count() === 1 && !(await over()));
    ok('Brief-Knöpfe ohne Emoji', await p.evaluate(() => ![...document.querySelectorAll('button')].some(x => /[\u{1F300}-\u{1FAFF}]/u.test(x.textContent))));

    // ---- Kosten
    await p.goto(base + 'kosten.html'); await sleep(600);
    ok('Kosten: Haus-Symbol zur Sammlung', await homeOk('.top a[href*="index.html"]') && !/Sammlung/.test(await p.locator('.top').innerText()));
    await tap('button:has-text("Beispielreise")'); await sleep(400);
    ok('Kosten: Beispielreise lädt', /Hütte Tirol/.test(await p.locator('.top').innerText()) && !(await over()));
    await tap('.top .back, .top [data-act=back], .top .iconbtn');
    ok('Kosten: zurück zur Reiseliste', /Kosten\u00AD?aufteilung/.test(await p.locator('body').innerText()) && await p.locator('button:has-text("Neue Reise")').count() === 1);
    await tap('[data-act=showSettings]');
    ok('Kosten: Einstellungen öffnen', /Einstellungen/.test(await p.locator('.top').innerText()));

    // ---- Spiele
    await p.goto(base + 'spiele.html'); await sleep(600);
    ok('Spiele: Haus-Symbol, kein doppeltes Symbol', await homeOk('#scr-spiele .back') && await p.evaluate(() => getComputedStyle(document.querySelector('#scr-spiele .back'), '::before').content) === 'none');
    const tabs = p.locator('nav button, .tabbar button');
    await tabs.nth(2).click(); await sleep(300);
    const inp = p.locator('.screen.active input[type=text], .screen.active input:not([type])').first();
    await inp.fill('Tim'); await p.locator('.screen.active button:has-text("+")').first().click(); await sleep(300);
    ok('Spiele: Spieler anlegen', await p.locator('#pl-list .pl-row:has-text("Tim")').count() === 1);
    await tabs.nth(3).click(); await sleep(300);
    const mehr = await p.locator('#mehr-body').innerText();
    ok('Spiele „Mehr“: gekürzte Hinweise', /Laufende Partien werden nie geteilt\./.test(mehr) && !/Im Hauptmenü anmelden|Enthält Spielstände/.test(mehr));
    await tabs.nth(0).click(); await sleep(200);
    await tap('text=Flip7');
    ok('Spiele: Flip7 öffnet, Spieler zum Antippen', /Tim/.test(await p.locator('.screen.active').innerText()) && !(await over()));
    await p.locator('.screen.active button:has-text("Tim"), .screen.active .pchip:has-text("Tim")').first().click().catch(() => {}); await sleep(300);
    const del = p.locator('.screen.active .del').first();
    ok('Spiele: ✕ zum Entfernen eines Mitspielers ist da', await del.count() === 1 && (await del.innerText()).trim() === '✕');

    // ---- Workout
    await p.goto(base + 'workout.html'); await sleep(500);
    ok('Workout: Haus-Symbol', await homeOk('#scr-wk-setup .back'));
    ok('Workout: Statusleisten-Farbe gesetzt', await p.locator('meta[name=theme-color]').count() === 2);
    ok('Workout: keine langen Hinweise mehr', !/Tippe auf einen Wert|automatisch gemeinsam/.test(await p.locator('#scr-wk-setup').innerText()));
    await tap('button:has-text("Weiter zur Vorschau")');
    ok('Workout: Vorschau öffnet', /Dein Plan/.test(await p.locator('.screen.active').innerText()) && !(await over()));
    await ctx.close();
  }
  ok('Keine JS-Fehler', !errors.length, errors.join(' | '));
  await b.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`); process.exit(fails ? 1 : 0);
})();
