// E2E: Rezept-Editor – Anleitung als einzelne Schritte (hinzufügen, verschieben, löschen, Textmodus).
// Aufruf: node e2e-schritte.js   (SHOTS=<ordner> für Bildschirmfotos)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');
let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const LROW = 'label.item:has(.nm:text-matches("^Lauch\\s*(für|$)"))';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };
const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' }); res.end(fs.readFileSync(f));
});
(async () => {
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log(`Durchlauf ${scheme}`);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
    const page = await ctx.newPage();
    await page.clock.install({ time: new Date('2026-11-02T10:00:00+01:00') }); await page.clock.resume();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
    const tap = async sel => { await page.locator(sel).first().click(); await sleep(250); };
    const over = () => page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    await page.goto(URL_);
    await tap('text=Neuen Haushalt einrichten');
    await page.fill('#a-n', 'Posten-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
    await tap('[data-x=ok]');
    await until(() => page.locator('#tabs button').count().then(n => n === 4));
    ok('Start im Reiter „Einkauf“', await page.locator('#tabs [data-tab=shop][aria-current=page]').count() === 1);
    const id = await page.evaluate(() => { const r = newRecipe('Testsuppe', 'MAIN'); r.instructions = 'Für 4 Personen.\n1. Zwiebeln würfeln\n2. Anbraten\nund salzen'; db.recipes.push(r); persist(); return r.id; });
    await page.evaluate(id => openEdit(id), id); await sleep(300);
    const steps = () => page.$$eval('#e-steps [data-step]', e => e.map(x => x.value));
    ok('Zwei Schrittfelder, Folgezeile gehört zu Schritt 2', JSON.stringify(await steps()) === JSON.stringify(['Zwiebeln würfeln', 'Anbraten und salzen']), JSON.stringify(await steps()));
    ok('Text vor den Schritten als „Vorab“', await page.inputValue('#e-intro') === 'Für 4 Personen.');
    await tap('[data-act=estepadd]');
    ok('„Schritt hinzufügen“ → neues leeres Feld mit Fokus', (await steps()).length === 3 && await page.evaluate(() => document.activeElement && document.activeElement.dataset.step === '2'));
    await page.fill('#e-steps [data-step="2"]', 'Mit Petersilie servieren');
    await tap('[data-act=estepmv][data-arg="2|-1"]');
    ok('↑ verschiebt den Schritt', JSON.stringify(await steps()) === JSON.stringify(['Zwiebeln würfeln', 'Mit Petersilie servieren', 'Anbraten und salzen']), JSON.stringify(await steps()));
    await tap('[data-act=estepdel][data-arg="1"]');
    ok('✕ löscht den Schritt', JSON.stringify(await steps()) === JSON.stringify(['Zwiebeln würfeln', 'Anbraten und salzen']));
    const bb = await page.locator('[data-act=estepdel]').first().boundingBox();
    ok('Knöpfe ≥44 px, kein seitliches Scrollen', bb.width >= 44 && bb.height >= 44 && !(await over()));
    await page.fill('#e-steps [data-step="1"]', 'Anbraten\nund salzen');
    await tap('[data-act=estepadd]');   // leerer Schritt wird nicht gespeichert
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/schritte-${scheme}.png` });
    await tap('#hdrsave'); await sleep(300);
    const ins = await page.evaluate(id => recipeById(id).instructions, id);
    ok('Gespeichert als nummerierte Zeilen, leerer Schritt entfällt', ins === 'Für 4 Personen.\n1. Zwiebeln würfeln\n2. Anbraten und salzen', JSON.stringify(ins));
    await page.evaluate(id => openEdit(id), id); await sleep(300);
    await tap('[data-act=estepmode]');
    ok('„Als Text bearbeiten“ zeigt den ganzen Text', await page.inputValue('#e-ins') === ins);
    await page.fill('#e-ins', '1. Eins\n2. Zwei\n3. Drei');
    await tap('[data-act=estepmode]');
    ok('Zurück zu „Einzelne Schritte“ übernimmt den Text', JSON.stringify(await steps()) === JSON.stringify(['Eins', 'Zwei', 'Drei']) && await page.locator('#e-intro').count() === 0);
    await tap('#hdrsave'); await sleep(300);
    ok('Kochansicht zeigt 3 Schritte', await page.evaluate(id => { openCook(id); return $$('#cookview [data-cs]').length; }, id) === 3);
    await page.evaluate(() => closeCook());
    await page.evaluate(() => { $('#qa') || go('recipes'); }); await tap('[data-tab=recipes]');
    await page.fill('#qa', 'Neues Gericht'); await tap('[data-act=qa]');
    const nid = await page.evaluate(() => liveRecipes().find(r => r.name === 'Neues Gericht').id);
    await page.evaluate(id => openEdit(id), nid); await sleep(300);
    ok('Neues Rezept: ein leeres Schrittfeld', JSON.stringify(await steps()) === '[""]');
    await page.fill('#e-steps [data-step="0"]', 'Alles mischen'); await tap('#hdrsave'); await sleep(300);
    ok('… gespeichert als „1. Alles mischen“', await page.evaluate(id => recipeById(id).instructions, nid) === '1. Alles mischen');
    await ctx.close();
  }
  ok('Keine JS-Fehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})();
