// E2E: Portionen je Kochtag (z. B. 2 statt 4) – Zutaten und Resttage passen sich an.
// Aufruf: node e2e-portionen.js   (SHOTS=<ordner> für Bildschirmfotos)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');
let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const LROW = 'label.item:has(.nm:text-matches("^Lauch\\s*(für|$)"))';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };
const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' }); res.end(fs.readFileSync(f));
});
(async () => {
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log(`Durchlauf ${scheme}`);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
    const page = await ctx.newPage();
    await page.clock.install({ time: new Date('2026-11-02T10:00:00+01:00') }); await page.clock.resume();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
    const tap = async sel => { await page.locator(sel).first().click(); await sleep(250); };
    const over = () => page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    await page.goto(URL_);
    await tap('text=Neuen Haushalt einrichten');
    await page.fill('#a-n', 'Posten-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
    await tap('[data-x=ok]');
    await until(() => page.locator('#tabs button').count().then(n => n === 4));
    ok('Start im Reiter „Einkauf“', await page.locator('#tabs [data-tab=shop][aria-current=page]').count() === 1);
    const D = '2026-11-03', D2 = '2026-11-04', D3 = '2026-11-05';
    const id = await page.evaluate(D => {
      db.settings.portionsPerDay = 2;
      const i = EP.touch({ id: EP.uuid(), name: 'Kartoffel', category: 'GEMUESE', deleted: false }); db.ingredients.push(i);
      const r = newRecipe('Kartoffelgratin', 'MAIN'); r.servings = 4; r.ingredients.push({ ingredientId: i.id, quantity: 800, unit: 'G', note: '', sortOrder: 0 }); db.recipes.push(r);
      placeBlock(D, { recipeId: r.id }); persist(); return r.id;
    }, D);
    const main = () => page.evaluate(() => EP.live(db.plan).filter(p => EP.laneOf(p) === 'MAIN' && p.type !== 'BLOCKED').map(p => p.date + ':' + p.type + ':' + p.dayIndex + '/' + p.dayCount).sort());
    const kart = () => page.evaluate(() => (EP.shopUnits(db, '2026-11-01', '2026-11-30').units.find(u => u.recipe === 'Kartoffelgratin') || {}).quantity);
    ok('Start: 4 Portionen = 2 Tage, 800 g', JSON.stringify(await main()) === JSON.stringify([`${D}:COOK:1/2`, `${D2}:LEFTOVER:2/2`]) && await kart() === 800);
    await tap('[data-tab=week]');
    await tap(`[data-act=day][data-arg="${D}"]`);
    ok('Tagesmenü hat „Portionen“', await page.locator('#scrim button:has-text("Portionen")').count() === 1);
    await tap('#scrim button:has-text("Portionen")');
    ok('Blatt zeigt 4, „Wie im Rezept · 2 Tage“', (await page.locator('#pn').innerText()) === '4' && /Wie im Rezept · 2 Tage/.test(await page.locator('#pi').innerText()));
    const sb = await page.locator('#scrim [data-x=m]').boundingBox();
    ok('Knöpfe ≥44 px', sb.width >= 44 && sb.height >= 44);
    await tap('#scrim [data-x=m]'); await tap('#scrim [data-x=m]');
    ok('2 → „Zutaten für 2 statt 4 · 1 Tag“', /Zutaten für 2 statt 4 · 1 Tag/.test(await page.locator('#pi').innerText()));
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/portionen-${scheme}.png` });
    await tap('#scrim [data-x=yes]');
    ok('Resttag fällt weg', JSON.stringify(await main()) === JSON.stringify([`${D}:COOK:1/1`]), JSON.stringify(await main()));
    ok('Einkauf: 400 g', await kart() === 400);
    ok('Hinweis „2 Portionen, ein Resttag weniger.“', /2 Portionen, ein Resttag weniger/.test(await page.locator('#toast').innerText()));
    ok('Woche zeigt „2 Port.“', await page.locator('.badge.guests:has-text("2 Port.")').count() >= 1);
    await tap('#toast button');
    ok('Rückgängig stellt 2 Tage und 800 g wieder her', (await main()).length === 2 && await kart() === 800);
    await page.evaluate(D => { const p = EP.live(db.plan).find(x => x.date === D && x.type === 'COOK'); setPortions(p.id, 6); persist(); }, D);
    ok('6 Portionen = 3 Tage, 1200 g', JSON.stringify(await main()) === JSON.stringify([`${D}:COOK:1/3`, `${D2}:LEFTOVER:2/3`, `${D3}:LEFTOVER:3/3`]) && await kart() === 1200, JSON.stringify(await main()));
    await page.evaluate(id => { const b = EP.live(db.plan).find(x => x.recipeId === id && x.type === 'COOK').blockId; moveBlock(b, '2026-11-10'); persist(); }, id);
    ok('Verschieben behält die Portionen (3 Tage ab 10.11.)', JSON.stringify(await main()) === JSON.stringify(['2026-11-10:COOK:1/3', '2026-11-11:LEFTOVER:2/3', '2026-11-12:LEFTOVER:3/3']) && await kart() === 1200, JSON.stringify(await main()));
    await page.evaluate(() => { const p = EP.live(db.plan).find(x => x.type === 'COOK' && EP.laneOf(x) === 'MAIN'); setPortions(p.id, 2); persist(); });
    await page.evaluate(id => openCook(id), id); await sleep(300);
    ok('Kochansicht startet mit 2 Portionen', /2 Portionen/.test(await page.locator('#cook-n').innerText()));
    await page.evaluate(() => closeCook());
    await tap('[data-act=day][data-arg="2026-11-10"]');
    ok('Menüpunkt zeigt „2 statt 4“', /2 statt 4/.test(await page.locator('#scrim button:has-text("Portionen")').innerText()));
    ok('kein seitliches Scrollen', !(await over()));
    await ctx.close();
  }
  ok('Keine JS-Fehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})();
