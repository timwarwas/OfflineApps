// E2E: Gericht wählen mit offener Tastatur (simuliert über visualViewport) – Suchfeld oben, Treffer über der Tastatur.
// Aufruf: node e2e-tastatur.js   (SHOTS=<ordner> für Bildschirmfotos)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');
let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const LROW = 'label.item:has(.nm:text-matches("^Lauch\\s*(für|$)"))';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };
const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' }); res.end(fs.readFileSync(f));
});
(async () => {
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log(`Durchlauf ${scheme}`);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
    const page = await ctx.newPage();
    await page.clock.install({ time: new Date('2026-11-02T10:00:00+01:00') }); await page.clock.resume();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
    const tap = async sel => { await page.locator(sel).first().click(); await sleep(250); };
    const over = () => page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    await page.addInitScript(() => {
      const fake = { height: window.innerHeight, offsetTop: 0, width: window.innerWidth, _l: {}, addEventListener(t, f) { (this._l[t] = this._l[t] || []).push(f); } };
      Object.defineProperty(window, 'visualViewport', { value: fake, configurable: true });
      window.__kbd = h => { fake.height = h || window.innerHeight; (fake._l.resize || []).forEach(f => f()); };
    });
    await page.goto(URL_);
    await tap('text=Neuen Haushalt einrichten');
    await page.fill('#a-n', 'Posten-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
    await tap('[data-x=ok]');
    await until(() => page.locator('#tabs button').count().then(n => n === 4));
    ok('Start im Reiter „Einkauf“', await page.locator('#tabs [data-tab=shop][aria-current=page]').count() === 1);
    await page.evaluate(() => {
      const names = ['Apfelstrudel-Auflauf', 'Bohnensuppe', 'Chili sin Carne', 'Dal mit Reis', 'Eintopf', 'Flammkuchen', 'Gemüsecurry', 'Hirse-Pfanne', 'Infused Pasta', 'Jägerschnitzel', 'Käsespätzle', 'Linsensuppe', 'Minestrone', 'Nudelauflauf', 'Ofengemüse', 'Pizza', 'Quiche', 'Risotto', 'Spaghetti', 'Tomatensuppe', 'Zucchini-Puffer'];
      names.forEach(n => { const r = newRecipe(n, 'MAIN'); r.inRotation = true; db.recipes.push(r); });
      persist();
    });
    await tap('[data-tab=week]');
    await page.evaluate(() => pickRecipeSheet ? 0 : 0).catch(() => 0);
    await tap('[data-act=day]');
    await tap('#scrim button:has-text("Selbst wählen"), #scrim button:has-text("Anderes Gericht"), #scrim button:has-text("hinzufügen")');
    ok('Gerichte-Blatt offen', await page.locator('#ps').count() === 1);
    await page.locator('#ps').focus();
    await page.evaluate(() => window.__kbd(450)); await sleep(500);
    ok('Blatt passt in den Bereich über der Tastatur', await page.evaluate(() => { const r = $('#scrim .sheet').getBoundingClientRect(); return $('#scrim').classList.contains('kb') && r.bottom <= 451; }));
    await page.locator('#ps').pressSequentially('supp', { delay: 20 }); await sleep(500);
    const geo = await page.evaluate(() => { const sh = $('#scrim .sheet').getBoundingClientRect(), ps = $('#ps').getBoundingClientRect();
      const vis = $$('#pl .opt').filter(b => !b.classList.contains('hidden')).map(b => { const r = b.getBoundingClientRect(); return { n: b.textContent.trim().split('\n')[0], top: r.top, bottom: r.bottom }; });
      return { sheetTop: sh.top, psTop: ps.top, psBottom: ps.bottom, vis }; });
    ok('3 Treffer (Bohnen-, Linsen-, Tomatensuppe)', geo.vis.length === 3, JSON.stringify(geo.vis.map(v => v.n)));
    ok('Suchfeld oben im Blatt', geo.psTop - geo.sheetTop < 80, JSON.stringify(geo));
    ok('Alle Treffer über der Tastatur sichtbar', geo.vis.every(v => v.bottom <= 450 && v.top >= geo.psBottom - 1), JSON.stringify(geo.vis));
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/tastatur-${scheme}.png` });
    await page.evaluate(() => { document.activeElement.blur(); window.__kbd(0); }); await sleep(300);
    ok('Tastatur zu: Blatt wieder normal', await page.evaluate(() => !$('#scrim').classList.contains('kb') && !$('#scrim').style.height));
    await tap('#pl .opt:not(.hidden)');
    ok('Auswahl funktioniert', await page.locator('#scrim').count() === 0 || !(await page.locator('#ps').isVisible()));
    await ctx.close();
  }
  ok('Keine JS-Fehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})();
