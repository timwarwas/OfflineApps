/* ==========================================================================
   Essensplanung – Kernlogik (rein, ohne DOM/Speicher)
   Umsetzung der Spezifikation „Rezept-Rotation“ Abschnitt 5
   ========================================================================== */
const EP = (function () {
  'use strict';

  /* ---------- Hilfen ---------- */
  let clock = () => Date.now();
  function setClock(fn) { clock = fn; }
  function uuid() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
    return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
  }
  function touch(o) {
    const t = clock();
    if (!o.createdAt) o.createdAt = t;
    o.updatedAt = Math.max(t, (o.updatedAt || 0) + 1);
    return o;
  }
  const live = arr => (arr || []).filter(x => !x.deleted);
  function tomb(o) { o.deleted = true; touch(o); }

  /* seedbarer Zufallsgenerator (mulberry32) */
  function seededRng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ---------- Datum (lokale Zeit, Woche ab Montag) ---------- */
  const pad = n => String(n).padStart(2, '0');
  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseISO(s) { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d, 12); }
  function addDays(s, n) { const d = parseISO(s); d.setDate(d.getDate() + n); return iso(d); }
  function todayISO() { return iso(new Date()); }
  function weekStart(s) { const d = parseISO(s); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return iso(d); }
  function weekDays(start) { return [0, 1, 2, 3, 4, 5, 6].map(i => addDays(start, i)); }
  function isoWeek(s) {
    const d = parseISO(s);
    const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    const day = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - day);
    const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
    return Math.ceil(((t - y0) / 86400000 + 1) / 7);
  }
  function fmtDate(s) { const [y, m, d] = s.split('-'); return d + '.' + m + '.' + y; }
  function fmtShort(s) { const [, m, d] = s.split('-'); return d + '.' + m + '.'; }
  const WD = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
  const WD_LONG = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
  function weekday(s) { return WD[parseISO(s).getDay()]; }
  function weekdayLong(s) { return WD_LONG[parseISO(s).getDay()]; }
  function fmtRange(from, to) {
    if (from.slice(0, 4) === to.slice(0, 4)) return fmtShort(from) + '–' + fmtDate(to);
    return fmtDate(from) + '–' + fmtDate(to);
  }

  /* ---------- 5.1 Tage pro Gericht ---------- */
  function daysFor(recipe, settings) {
    if (recipe.daysOverride) return recipe.daysOverride;
    const raw = recipe.servings / settings.portionsPerDay;
    const days = settings.roundingMode === 'FLOOR' ? Math.floor(raw) : Math.ceil(raw);
    return Math.max(1, days);
  }
  /* Hinweistext für ungerade Portionen */
  function daysHint(recipe, settings) {
    if (recipe.daysOverride) return '';
    const rest = recipe.servings % settings.portionsPerDay;
    if (!rest || recipe.servings < settings.portionsPerDay) return '';
    return settings.roundingMode === 'FLOOR'
      ? `${rest} ${rest === 1 ? 'Portion bleibt' : 'Portionen bleiben'} übrig`
      : `letzter Tag nur ${rest} ${rest === 1 ? 'Portion' : 'Portionen'}`;
  }

  /* ---------- 5.2 Rotation ---------- */
  /* Spuren: jede hat ihre eigene Rotation */
  const LANES = [
    { key: 'MAIN', label: 'Hauptgerichte', short: 'Hauptgericht' },
    { key: 'LUNCH', label: 'Mittagessen', short: 'Mittag' },
    { key: 'CAKE', label: 'Kuchen', short: 'Kuchen' },
  ];
  /* Arten von Rezepten: Rotationsspuren + Beilagen (ohne Rotation) */
  /* Besonderes: aufwendige Gerichte für Sonntage/Festtage – gesammelt, aber nie in der Rotation */
  const KINDS = LANES.concat({ key: 'SIDE', label: 'Beilagen', short: 'Beilage' }, { key: 'SPECIAL', label: 'Besonderes', short: 'Besonderes' });
  /* eigene Bezeichnungen der Rezept-Arten (settings.kindNames = {KEY: Name}) */
  function kindName(settings, key, plural) {
    const n = settings && settings.kindNames && String(settings.kindNames[key] || '').trim();
    if (n) return n;
    const k = KINDS.find(x => x.key === key);
    return k ? (plural ? k.label : k.short) : key;
  }
  /* verknüpfte Beilagen eines Rezepts (nur vorhandene, nicht gelöschte, ohne sich selbst) */
  function linkedSides(db, r) {
    if (!r || !r.sides || !r.sides.length) return [];
    return r.sides.map(id => (db.recipes || []).find(x => x.id === id)).filter(x => x && !x.deleted && !x.archivedAt && x.id !== r.id);
  }
  /* umgekehrt: zu welchen Gerichten passt diese Beilage */
  function linkedFrom(db, r) {
    return r ? live(db.recipes || []).filter(x => !x.archivedAt && x.id !== r.id && (x.sides || []).includes(r.id)) : [];
  }
  /* besondere Tage (Wochentage 0=So … 6=Sa), Standard Sonntag */
  function specialDays(settings) { const d = settings && settings.specialDays; return Array.isArray(d) ? d : [0]; }
  /* Gäste: Personen am Kochtag statt der üblichen Portionen pro Tag. Die zusätzlichen (oder fehlenden) Portionen
     werden nur für diesen Tag mitgekocht – die Reste bleiben gleich. */
  function guestFactor(p, r, settings) {
    if (!p || !p.guests || !r || laneOf(r) === 'CAKE') return 1;
    const sv = r.servings || (settings && settings.portionsPerDay) || 2, pp = (settings && settings.portionsPerDay) || 2;
    return Math.max(0.25, (sv + p.guests - pp) / sv);
  }
  const ROTATES = k => LANES.some(l => l.key === k);
  const laneOf = x => (x && (x.lane || x.kind)) || 'MAIN';
  const MONTHS = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
  function inSeason(recipe, month) {
    const m = recipe && recipe.seasonMonths;
    return !month || !m || !m.length || m.length >= 12 || m.includes(month);
  }
  function seasonLabel(recipe) {
    const m = (recipe.seasonMonths || []).slice().sort((a, b) => a - b);
    if (!m.length || m.length >= 12) return '';
    // zusammenhängende Bereiche, auch über den Jahreswechsel (z. B. Nov–Feb)
    const set = new Set(m), parts = [];
    let start = m.find(x => !set.has(x === 1 ? 12 : x - 1));
    if (start === undefined) return 'ganzjährig';
    const seen = new Set();
    for (const s0 of m.filter(x => !set.has(x === 1 ? 12 : x - 1))) {
      let e = s0; while (set.has(e === 12 ? 1 : e + 1) && !seen.has(e)) { seen.add(e); e = e === 12 ? 1 : e + 1; }
      parts.push(s0 === e ? MONTHS[s0 - 1] : MONTHS[s0 - 1] + '–' + MONTHS[e - 1]);
    }
    return parts.join(', ');
  }
  function monthOf(isoDate) { return +isoDate.slice(5, 7); }
  function activeRecipes(db, lane) {
    return live(db.recipes).filter(r => r.inRotation && !r.archivedAt && ROTATES(laneOf(r)) && (!lane || laneOf(r) === lane));
  }
  function repairAdjacency(items, prevLastRecipeId) {
    let moves = 0;
    const maxMoves = items.length * items.length + 10;
    for (let i = 0; i < items.length && moves < maxMoves; i++) {
      const prev = i === 0 ? prevLastRecipeId : items[i - 1].recipeId;
      if (items[i].recipeId !== prev) continue;
      const j = items.findIndex((x, idx) => idx > i && x.recipeId !== prev);
      if (j !== -1) {
        const [moved] = items.splice(j, 1);
        items.splice(i, 0, moved);
        moves++;
        continue;
      }
      // Abweichung von der Referenz: Kein Tauschpartner mehr weiter hinten (z. B. beide
      // Vorkommen ganz am Ende). Dann den Eintrag an die nächstgelegene frühere Stelle setzen,
      // an der keiner seiner Nachbarn dasselbe Rezept ist. Sonst ist es unvermeidbar.
      const x = items[i].recipeId;
      let target = -1;
      for (let k = i - 1; k >= 0; k--) {
        const left = k === 0 ? prevLastRecipeId : items[k - 1].recipeId;
        if (left !== x && items[k].recipeId !== x) { target = k; break; }
      }
      if (target === -1) break;
      const [moved] = items.splice(i, 1);
      items.splice(target, 0, moved);
      moves++;
      i = target; // ab hier erneut prüfen
    }
  }
  function countAdjacent(items, prevLastRecipeId) {
    let a = 0;
    for (let i = 0; i < items.length; i++) {
      const prev = i === 0 ? prevLastRecipeId : items[i - 1].recipeId;
      if (items[i].recipeId === prev) a++;
    }
    return a;
  }
  /* Rückfallebene: ordnet so um, dass nie dasselbe Rezept folgt (sofern überhaupt möglich).
     Wählt jeweils das Rezept mit den meisten verbleibenden Vorkommen, das nicht dem vorigen
     entspricht; bei Gleichstand entscheidet die ursprüngliche (gemischte) Reihenfolge. */
  function greedyArrange(items, prevLastRecipeId) {
    const queues = new Map();
    items.forEach(it => { if (!queues.has(it.recipeId)) queues.set(it.recipeId, []); queues.get(it.recipeId).push(it); });
    const out = [];
    let prev = prevLastRecipeId;
    while (out.length < items.length) {
      let best = null;
      queues.forEach((q, id) => {
        if (!q.length || id === prev) return;
        if (!best || q.length > best.q.length || (q.length === best.q.length && q[0].key < best.q[0].key)) best = { id, q };
      });
      if (!best) queues.forEach((q, id) => { if (q.length && !best) best = { id, q }; }); // unvermeidbar
      out.push(best.q.shift());
      prev = best.id;
    }
    return out;
  }
  function buildCycle(recipes, settings, cycleNumber, prevLastRecipeId, rng, lane, month) {
    lane = lane || 'MAIN';
    const active = recipes.filter(r => r.inRotation && !r.archivedAt && !r.deleted && laneOf(r) === lane && inSeason(r, month))
      .sort((a, b) => a.sortOrder - b.sortOrder);
    const n = active.length;
    let items = active.flatMap((r, idx) =>
      Array.from({ length: r.weight }, (_, k) => {
        const u = settings.rotationMode === 'SHUFFLE' ? rng() : (idx + 0.5) / n;
        return { recipeId: r.id, occurrence: k + 1, key: (k + u) / r.weight };
      }));
    items.sort((a, b) => a.key - b.key);
    repairAdjacency(items, prevLastRecipeId);
    if (countAdjacent(items, prevLastRecipeId)) {
      const alt = greedyArrange([...items].sort((a, b) => a.key - b.key), prevLastRecipeId);
      if (countAdjacent(alt, prevLastRecipeId) < countAdjacent(items, prevLastRecipeId)) items = alt;
    }
    // Vorkommen in Reihenfolge des Auftretens nummerieren (1/2 vor 2/2)
    const seen = {};
    items.forEach(it => { seen[it.recipeId] = (seen[it.recipeId] || 0) + 1; it.occurrence = seen[it.recipeId]; });
    return items.map((it, i) => touch({
      id: uuid(), lane, cycleNumber, recipeId: it.recipeId, occurrence: it.occurrence,
      position: (i + 1) * 1000, status: 'PENDING', deleted: false,
    }));
  }
  const byCyclePos = (a, b) => a.cycleNumber - b.cycleNumber || a.position - b.position;
  const inLane = (lane) => e => laneOf(e) === (lane || 'MAIN');
  function cycleEntries(db, c, lane) { return live(db.rotation).filter(inLane(lane)).filter(e => e.cycleNumber === c).sort(byCyclePos); }
  function maxCycle(db, lane) { return live(db.rotation).filter(inLane(lane)).reduce((m, e) => Math.max(m, e.cycleNumber), 0); }
  function openCycles(db, lane) {
    return [...new Set(live(db.rotation).filter(inLane(lane)).filter(e => e.status === 'PENDING').map(e => e.cycleNumber))].sort((a, b) => a - b);
  }
  function pendingSorted(db, lane) { return live(db.rotation).filter(inLane(lane)).filter(e => e.status === 'PENDING').sort(byCyclePos); }
  function lastRecipeOfCycle(db, c, lane) {
    const es = cycleEntries(db, c, lane);
    return es.length ? es[es.length - 1].recipeId : null;
  }
  function appendCycle(db, rng, lane, month) {
    lane = lane || 'MAIN';
    const mc = maxCycle(db, lane);
    const cyc = buildCycle(live(db.recipes), db.settings, mc + 1, lastRecipeOfCycle(db, mc, lane), rng, lane, month);
    db.rotation.push(...cyc);
    return cyc;
  }
  /* next(n, exclude): die nächsten offenen Einträge einer Spur; erzeugt bei Bedarf Folgedurchläufe (R3, R7).
     Mit Monatsangabe werden Gerichte außerhalb ihrer Saison für diesen Durchlauf ausgelassen. */
  function nextEntries(db, n, exclude, rng, lane, month) {
    exclude = exclude || new Set();
    lane = lane || 'MAIN';
    cleanRotation(db);
    const rec = month ? new Map(live(db.recipes).map(r => [r.id, r])) : null;
    for (let guard = 0; guard < 60; guard++) {
      let pend = pendingSorted(db, lane).filter(e => !exclude.has(e.id));
      if (month) {
        pend = pend.filter(e => {
          if (inSeason(rec.get(e.recipeId), month)) return true;
          e.status = 'SKIPPED'; e.skipReason = 'SEASON'; touch(e);
          return false;
        });
      }
      if (pend.length >= n) return pend.slice(0, n);
      if (!appendCycle(db, rng, lane, month).length) return pend;
    }
    return pendingSorted(db, lane).filter(e => !exclude.has(e.id)).slice(0, n);
  }
  /* offene Einträge entfernen, deren Rezept gelöscht, archiviert, pausiert oder in eine andere Spur gewechselt ist
     (z. B. nach dem Abgleich mit einem anderen Gerät oder dem Zusammenführen zweier Haushalte) */
  function cleanRotation(db) {
    const rec = new Map((db.recipes || []).map(r => [r.id, r]));
    let n = 0;
    live(db.rotation).forEach(e => {
      if (e.status !== 'PENDING') return;
      const r = rec.get(e.recipeId);
      const ok = r && !r.deleted && r.inRotation && !r.archivedAt && ROTATES(laneOf(r)) && laneOf(r) === laneOf(e);
      if (!ok) { tomb(e); n++; }
    });
    return n;
  }
  /* „Geplant“ ohne zugehörigen Planeintrag (Tag gelöscht, auf anderem Gerät geändert) → wieder offen */
  function releaseOrphans(db) {
    const used = new Set(live(db.plan).map(p => p.rotationEntryId).filter(Boolean));
    let n = 0;
    live(db.rotation).forEach(e => { if (e.status === 'PLANNED' && !used.has(e.id)) { e.status = 'PENDING'; touch(e); n++; } });
    return n;
  }
  function setStatus(entry, status) { entry.status = status; touch(entry); }
  function planEntry(entry) { setStatus(entry, 'PLANNED'); }
  function completeEntry(entry) { setStatus(entry, 'DONE'); }
  function skipEntry(entry) { setStatus(entry, 'SKIPPED'); }
  function postpone(db, entry) {
    const es = cycleEntries(db, entry.cycleNumber, laneOf(entry));
    entry.position = es.reduce((m, e) => Math.max(m, e.position), 0) + 1000;
    touch(entry);
  }
  function release(db, entry) {
    const es = cycleEntries(db, entry.cycleNumber, laneOf(entry));
    entry.position = es.reduce((m, e) => Math.min(m, e.position), Infinity) - 1000;
    entry.status = 'PENDING';
    touch(entry);
  }
  /* manualPick: erster offener Eintrag des Rezepts – oder null (dann MANUAL) */
  function manualPickEntry(db, recipeId, exclude) {
    exclude = exclude || new Set();
    return live(db.rotation).filter(e => e.status === 'PENDING' && e.recipeId === recipeId && !exclude.has(e.id)).sort(byCyclePos)[0] || null;
  }
  function resetRotation(db, rng, lane, month) {
    pendingSorted(db, lane).forEach(tomb);
    return appendCycle(db, rng, lane, month);
  }
  /* Rezept in laufende Durchläufe einarbeiten (neu, reaktiviert, pausiert, Gewicht oder Spur geändert) */
  function syncRecipeIntoCycles(db, recipe, rng) {
    const lane = laneOf(recipe);
    // offene Einträge in einer anderen Spur (Art des Gerichts geändert) entfernen
    live(db.rotation).filter(e => e.recipeId === recipe.id && e.status === 'PENDING' && laneOf(e) !== lane).forEach(tomb);
    const active = recipe.inRotation && !recipe.archivedAt && !recipe.deleted && ROTATES(lane);
    openCycles(db, lane).forEach(c => {
      const mine = cycleEntries(db, c, lane).filter(e => e.recipeId === recipe.id);
      if (!active) { mine.filter(e => e.status === 'PENDING').forEach(tomb); return; }
      const diff = recipe.weight - mine.length;
      if (diff > 0) insertIntoCycle(db, c, recipe, diff, rng, lane);
      if (diff < 0) {
        mine.filter(e => e.status === 'PENDING').sort((a, b) => b.position - a.position)
          .slice(0, -diff).forEach(tomb);
      }
    });
  }
  function insertIntoCycle(db, c, recipe, count, rng, lane) {
    const es = cycleEntries(db, c, lane);
    let occ = es.filter(e => e.recipeId === recipe.id).reduce((m, e) => Math.max(m, e.occurrence), 0);
    const prevCycleLast = lastRecipeOfCycle(db, c - 1, lane);
    const nextCycleFirst = (cycleEntries(db, c + 1, lane)[0] || {}).recipeId || null;
    for (let k = 0; k < count; k++) {
      const firstOpen = es.findIndex(e => e.status === 'PENDING');
      const from = firstOpen === -1 ? es.length : firstOpen;
      const slots = [];
      for (let i = from; i <= es.length; i++) slots.push(i);
      const ok = slots.filter(i => {
        const prev = i === 0 ? prevCycleLast : es[i - 1].recipeId;
        const next = i === es.length ? nextCycleFirst : es[i].recipeId;
        return prev !== recipe.id && next !== recipe.id;
      });
      const pool = ok.length ? ok : slots;
      const at = pool[Math.floor(rng() * pool.length)];
      const entry = touch({ id: uuid(), lane, cycleNumber: c, recipeId: recipe.id, occurrence: ++occ,
        position: 0, status: 'PENDING', deleted: false });
      es.splice(at, 0, entry);
      db.rotation.push(entry);
    }
    es.forEach((e, i) => { const p = (i + 1) * 1000; if (e.position !== p) { e.position = p; touch(e); } });
  }
  /* Fortschritt des laufenden Durchlaufs für den Vorschlag */
  function cycleProgress(db, lane) {
    const oc = openCycles(db, lane);
    if (!oc.length) return null;
    const c = oc[0];
    const es = cycleEntries(db, c, lane);
    const used = es.filter(e => e.status !== 'PENDING').length;
    return { cycle: c, current: Math.min(es.length, used + 1), total: es.length };
  }

  /* ---------- 5.4 Wochenplan ---------- */
  function nextFreeDates(start, n, occupied) {
    const res = [];
    let d = start;
    for (let guard = 0; res.length < n && guard < 400; guard++) {
      if (!occupied.has(d)) res.push(d);
      d = addDays(d, 1);
    }
    return res;
  }
  /* Legt eine Folge von Gerichten auf freie Tage. Leere Folge = „Woche automatisch füllen“.
     seq-Einträge: { kind:'ROT', entryId, recipeId } oder { kind:'MAN', recipeId } */
  function layoutDraft({ days, occupied, sequence, nextFn, recipeOf, settings, today }) {
    const occ = new Set(occupied);
    const used = new Set(sequence.filter(s => s.kind === 'ROT').map(s => s.entryId));
    const drafts = [], placed = [];
    let si = 0;
    const firstFree = () => days.find(d => !occ.has(d) && d >= today);
    for (let start = firstFree(), guard = 0; start && guard < 60; start = firstFree(), guard++) {
      let item;
      if (si < sequence.length) item = sequence[si++];
      else {
        const e = nextFn(used, start);
        if (!e) break;
        used.add(e.id);
        item = { kind: 'ROT', entryId: e.id, recipeId: e.recipeId };
      }
      const recipe = recipeOf(item.recipeId);
      if (!recipe) continue;
      const n = daysFor(recipe, settings);
      const dates = nextFreeDates(start, n, occ);
      item.blockId = item.blockId || uuid();
      dates.forEach((date, i) => {
        occ.add(date);
        drafts.push({
          date, lane: 'MAIN', type: i === 0 ? 'COOK' : 'LEFTOVER', recipeId: recipe.id, blockId: item.blockId,
          dayIndex: i + 1, dayCount: n, rotationEntryId: item.kind === 'ROT' ? item.entryId : null,
          source: item.kind === 'ROT' ? 'ROTATION' : 'MANUAL', locked: !!item.locked, status: 'PLANNED', note: '',
        });
      });
      placed.push(item);
    }
    return { drafts, sequence: placed };
  }
  function fillWeek(opts) { return layoutDraft(Object.assign({ sequence: [] }, opts)).drafts; }

  /* ---------- Einheiten ---------- */
  const UNITS = {
    G: { s: 'g', dim: 'MASS', f: 1 }, KG: { s: 'kg', dim: 'MASS', f: 1000 },
    ML: { s: 'ml', dim: 'VOLUME', f: 1 }, L: { s: 'l', dim: 'VOLUME', f: 1000 },
    STUECK: { s: 'Stück', p: 'Stück' }, EL: { s: 'EL', p: 'EL' }, TL: { s: 'TL', p: 'TL' },
    PRISE: { s: 'Prise', p: 'Prisen' }, BUND: { s: 'Bund', p: 'Bund' },
    ZEHE: { s: 'Zehe', p: 'Zehen' }, DOSE: { s: 'Dose', p: 'Dosen' },
    GLAS: { s: 'Glas', p: 'Gläser' }, PACKUNG: { s: 'Packung', p: 'Packungen' },
    SCHEIBE: { s: 'Scheibe', p: 'Scheiben' },
  };
  const UNIT_ORDER = ['G', 'KG', 'ML', 'L', 'STUECK', 'EL', 'TL', 'PRISE', 'BUND', 'ZEHE', 'DOSE', 'GLAS', 'PACKUNG', 'SCHEIBE'];
  function dimOf(unit) { if (!unit) return 'NONE'; return UNITS[unit].dim || unit; }
  function fmtNum(x) {
    const r = Math.round(x * 100) / 100;
    return String(r).replace('.', ',');
  }
  function fmtDim(dim, total) {
    if (total == null) return '';
    if (dim === 'MASS') return total >= 1000 ? fmtNum(total / 1000) + ' kg' : fmtNum(total) + ' g';
    if (dim === 'VOLUME') return total >= 1000 ? fmtNum(total / 1000) + ' l' : fmtNum(total) + ' ml';
    const u = UNITS[dim];
    return fmtNum(total) + ' ' + (Math.abs(total - 1) < 1e-9 ? u.s : u.p);
  }
  /* Summiert Mengen (quantity/unit) zu einem Anzeigetext, Dimensionen in Reihenfolge des ersten Auftretens */
  function sumAmounts(items) {
    const order = [], tot = {};
    items.forEach(({ quantity, unit }) => {
      const dim = quantity == null ? 'NONE' : dimOf(unit);
      if (!(dim in tot)) { order.push(dim); tot[dim] = dim === 'NONE' ? null : 0; }
      if (dim !== 'NONE') tot[dim] += quantity * ((UNITS[unit] && UNITS[unit].f) || 1);
    });
    const dims = order.filter(d => d !== 'NONE');
    return { dims: order, text: dims.map(d => fmtDim(d, tot[d])).join(' + ') };
  }

  /* ---------- 5.5 Einkaufsliste ---------- */
  const CATEGORIES = [
    ['GEMUESE', 'Gemüse', 'MARKT'], ['OBST', 'Obst', 'MARKT'], ['KRAEUTER', 'Frische Kräuter', 'MARKT'],
    ['EIER', 'Eier', 'MARKT'], ['BACKWAREN', 'Brot & Backwaren', 'SUPERMARKT'],
    ['FLEISCH', 'Fleisch & Wurst', 'SUPERMARKT'], ['FISCH', 'Fisch', 'SUPERMARKT'],
    ['MILCHPRODUKTE', 'Milchprodukte', 'SUPERMARKT'], ['KAESE', 'Käse', 'SUPERMARKT'],
    ['TROCKENWAREN', 'Nudeln, Reis & Hülsenfrüchte', 'SUPERMARKT'],
    ['KONSERVEN', 'Konserven & Gläser', 'SUPERMARKT'], ['TIEFKUEHL', 'Tiefkühl', 'SUPERMARKT'],
    ['SUESSES', 'Süßes & Snacks', 'SUPERMARKT'], ['GETRAENKE', 'Getränke', 'SUPERMARKT'],
    ['HAUSHALT', 'Haushalt & Reinigung', 'SUPERMARKT'], ['TIER', 'Tierbedarf', 'SUPERMARKT'],
    ['DROGERIE', 'Drogerie & Pflege', 'DROGERIE'],
    ['SONSTIGES', 'Sonstiges', 'SUPERMARKT'], ['GEWUERZE', 'Gewürze', 'VORRAT'], ['OELE_ESSIG', 'Öl & Essig', 'VORRAT'],
  ].map(([key, label, source]) => ({ key, label, source }));
  const CAT = Object.fromEntries(CATEGORIES.map(c => [c.key, c]));
  function categorySource(cat, settings) {
    const o = settings && settings.categorySources;
    return (o && o[cat]) || (CAT[cat] || CAT.SONSTIGES).source;
  }
  /* Zutaten, die nie auf die Einkaufsliste kommen: von Hand markiert (noShop) oder Wasser aus der Leitung */
  const WATER = /^(heißes|heisses|kaltes|lauwarmes|warmes|kochendes|eiskaltes|lauwarm(es)?)?\s*(leitungs|eis|koch|nudel)?wasser$/i;
  /* Vorbereitungs-Anweisungen in einem Text erkennen („fein würfeln“, „in Ringe schneiden“, „schälen“ …).
     Liefert Bezeichnungen in sinnvoller Reihenfolge (erst waschen/schälen, dann schneiden). */
  const PREP_RULES = [
    [0, /\b(waschen|gewaschen|abspülen|abgespült)\b/, 'waschen'],
    [1, /\b(putzen|geputzt)\b/, 'putzen'],
    [2, /\b(schälen|geschält|pellen|gepellt)\b/, 'schälen'],
    [3, /\b(entkernen|entkernt|entsteinen|entsteint)\b/, 'entkernen'],
    [4, /\b(abtropfen)\b/, 'abtropfen lassen'],
    [5, /\b(zupfen|gezupft|abzupfen)\b/, 'Blätter zupfen'],
    [6, /\b(halbieren|halbiert)\b/, 'halbieren'],
    [6, /\b(vierteln|geviertelt)\b/, 'vierteln'],
    [6, /\b(achteln|geachtelt)\b/, 'achteln'],
    [7, /\bin\s+(?:(dünne|feine|dicke|halbe|grobe|schmale)\s+)?(ringe|halbringe)\b/, m => `in ${m[1] ? m[1] + ' ' : ''}${m[2] === 'halbringe' ? 'Halbringe' : 'Ringe'} schneiden`],
    [7, /\bin\s+(?:(dünne|feine|dicke|grobe)\s+)?scheiben\b/, m => `in ${m[1] ? m[1] + ' ' : ''}Scheiben schneiden`],
    [7, /\bin\s+(?:(dünne|feine|breite|schmale)\s+)?streifen\b/, m => `in ${m[1] ? m[1] + ' ' : ''}Streifen schneiden`],
    [7, /\bin\s+(?:(kleine|grobe|große|mundgerechte|feine|\d+\s*cm\s*große)\s+)?(stücke|würfel|stifte|spalten)\b/, m => `in ${m[1] ? m[1] + ' ' : ''}${m[2][0].toUpperCase() + m[2].slice(1)} schneiden`],
    [7, /\b(?:(fein|grob|klein)\s+)?(würfeln|gewürfelt|würfelt)\b/, m => `${m[1] ? m[1] + ' ' : ''}würfeln`],
    [7, /\b(?:(fein|grob)\s+)?(hacken|gehackt|hackt)\b/, m => `${m[1] ? m[1] + ' ' : ''}hacken`],
    [7, /\b(?:(fein|grob)\s+)?(reiben|gerieben|raspeln|geraspelt)\b/, m => `${m[1] ? m[1] + ' ' : ''}reiben`],
    [7, /\b(zerkleinern|zerkleinert)\b/, 'zerkleinern'],
    [8, /\b(auspressen|ausgepresst)\b/, 'auspressen'],
    [8, /\b(pressen|gepresst)\b/, 'pressen'],
    [8, /\b(abreiben|abrieb)\b/, 'Schale abreiben'],
    [9, /\b(?:(fein|klein|grob|dünn)\s+)?(schneiden|geschnitten|schneidet|aufschneiden|kleinschneiden|kleingeschnitten)\b/, m => `${m[1] ? m[1] + ' ' : ''}schneiden`],
  ];
  function prepPhrases(text) {
    const t = String(text || '').toLowerCase();
    const hits = [];
    PREP_RULES.forEach(([rank, re, lbl]) => { const m = t.match(re); if (m) hits.push([rank, typeof lbl === 'function' ? lbl(m) : lbl]); });
    // „in Ringe schneiden“ enthält schon „schneiden“ → allgemeines Schneiden weglassen
    const cut = hits.some(h => h[0] === 7);
    return [...new Set(hits.filter(h => !(cut && h[0] === 9)).sort((a, b) => a[0] - b[0]).map(h => h[1]))];
  }
  /* Text in Sätze und diese in Satzteile zerlegen: [[Satzteil, …], …] */
  function prepClauses(text) {
    return String(text || '').replace(/<[^>]+>/g, ' ').split(/[.!?;:\n]+/)
      .map(sn => sn.split(/,|\b(?:dann|anschließend|danach)\b/i).map(x => x.trim()).filter(Boolean)).filter(a => a.length);
  }
  /* Anweisungen den Zutaten zuordnen. hit(text) → Liste der erwähnten Zutat-Schlüssel.
     Satzteil ohne Zutat gehört zum vorigen („Paprika waschen, entkernen und in Streifen schneiden“),
     Zutat ohne Anweisung wartet auf den nächsten Satzteil („Zwiebeln, Knoblauch und Ingwer fein hacken“). */
  function prepAssign(text, hit) {
    const out = new Map(), add = (keys, ph) => keys.forEach(k => { const l = out.get(k) || []; ph.forEach(p => { if (!l.includes(p)) l.push(p); }); out.set(k, l); });
    prepClauses(text).forEach(sn => {
      let pending = [], last = null;
      sn.forEach((c, i) => {
        const keys = hit(c), ph = prepPhrases(c);
        if (!keys.length) { if (last) add(last, ph); else if (pending.length) { add(pending, ph); last = pending; pending = []; } return; }
        const all = pending.concat(keys);
        if (!ph.length && i < sn.length - 1) { pending = all; last = null; return; }
        add(all, ph); last = all; pending = [];
      });
    });
    return out;
  }
  function neverShop(ing) { return !!ing && (ing.noShop === true || (ing.noShop !== false && WATER.test(String(ing.name || '').trim()))); }
  function sourceOf(ing, settings) { return ing.shoppingSource || categorySource(ing.category, settings); }
  /* Kategorie aus dem Zutatennamen erraten (längster Treffer gewinnt) */
  const GUESS = {
    GEMUESE: 'tomate tomaten gurke zwiebel knoblauch karotte möhre paprika zucchini aubergine kartoffel spinat blattspinat salat kopfsalat rucola feldsalat kohl weißkohl rotkohl wirsing grünkohl brokkoli blumenkohl lauch porree sellerie staudensellerie kürbis pilz pilze champignon spargel radieschen rettich rote bete fenchel mangold frühlingszwiebel schalotte ingwer chili peperoni mais kolben erbsenschoten zuckerschoten grüne bohnen avocado okra pastinake kohlrabi rosenkohl süßkartoffel',
    OBST: 'wassermelone apfel äpfel birne banane zitrone limette orange mandarine clementine beere beeren erdbeere erdbeeren himbeere himbeeren heidelbeere heidelbeeren blaubeere johannisbeere kirsche kirschen pflaume pflaumen zwetschge zwetschgen rhabarber traube trauben mango ananas aprikose pfirsich nektarine melone kiwi granatapfel feige',
    KRAEUTER: 'basilikum petersilie koriander schnittlauch dill minze rosmarin thymian salbei estragon kerbel liebstöckel frische kräuter',
    EIER: 'ei eier eigelb eiweiß',
    BACKWAREN: 'brot brötchen toast toastbrot vollkornbrot tortilla tortillas weizentortillas wrap baguette fladenbrot pita ciabatta knäckebrot semmel croissant croissants laugenbrezel brezel brezeln bagel bagels kuchenboden zwieback',
    FLEISCH: 'hackfleisch hack rinderhack rind rindfleisch schwein schweinefleisch hähnchen hähnchenbrust huhn pute putenbrust speck schinken wurst würstchen salami lamm bacon chorizo fleisch geschnetzeltes gulasch leberkäse',
    FISCH: 'lachs thunfisch fisch garnele garnelen kabeljau forelle seelachs scampi krabben',
    MILCHPRODUKTE: 'milch sahne schlagsahne joghurt quark magerquark butter schmand crème fraîche creme fraiche saure sahne buttermilch kefir',
    KAESE: 'käse parmesan mozzarella feta gouda emmentaler ricotta halloumi frischkäse bergkäse reibekäse mascarpone pecorino',
    TROCKENWAREN: 'nudel nudeln suppennudeln spaghetti pasta penne fusilli lasagneplatten reis basmatireis risottoreis linsen rote linsen mehl weizenmehl zucker puderzucker vanillezucker haferflocken couscous bulgur quinoa grieß backpulver speisestärke stärke polenta nüsse mandeln haselnüsse walnüsse kakao schokolade trockenhefe hefe paniermehl semmelbrösel',
    KONSERVEN: 'gehackte tomaten passierte tomaten tomatenmark kokosmilch kidneybohnen bohnen kichererbsen dosenmais oliven pesto senf ketchup marmelade honig kapern essiggurken thunfisch dose',
    TIEFKUEHL: 'tk tiefkühl erbsen tiefkühlerbsen blätterteig eis eiscreme tiefkühlpizza tk-pizza pommes fischstäbchen rahmspinat',
    SUESSES: 'schokolade schoki chips kekse keks gummibärchen süßigkeiten riegel müsliriegel nüsse erdnüsse cashews mandeln popcorn salzstangen cracker pralinen bonbons kaugummi nutella',
    GETRAENKE: 'wasser mineralwasser sprudel saft apfelsaft orangensaft cola limo limonade schorle bier radler wein rotwein weißwein rosé sekt prosecco tee kaffee kaffeebohnen espresso kaffeepads kapseln kakao eistee energydrink sirup',
    HAUSHALT: 'spülmittel geschirrspültabs spültabs spülmaschinentabs tabs klarspüler spülmaschinensalz regeneriersalz waschmittel weichspüler küchenrolle küchenpapier müllbeutel müllsäcke alufolie frischhaltefolie backpapier gefrierbeutel schwamm schwämme spülschwamm putzmittel allzweckreiniger glasreiniger wc-reiniger badreiniger entkalker batterien glühbirne kerzen servietten teelichter streichhölzer',
    TIER: 'katzenfutter hundefutter katzenstreu leckerli futter vogelfutter',
    DROGERIE: 'zahnpasta zahnbürste zahnseide mundspülung shampoo spülung duschgel seife flüssigseife deo deodorant rasierer rasierklingen rasierschaum sonnencreme bodylotion handcreme gesichtscreme taschentücher toilettenpapier klopapier watte wattepads wattestäbchen pflaster tampons binden slipeinlagen windeln feuchttücher haargel haarspray lippenpflege labello nagellack kosmetiktücher abschminktücher kontaktlinsen kopfschmerztabletten ibuprofen paracetamol vitamine',
    GEWUERZE: 'salz pfeffer paprikapulver currypulver curry kurkuma zimt muskat muskatnuss kreuzkümmel kümmel oregano getrocknet lorbeer lorbeerblatt nelke nelken vanille chiliflocken chilipulver knoblauchpulver gemüsebrühe brühe gewürz gewürze sojasauce sojasoße',
    OELE_ESSIG: 'rotweinessig weißweinessig öl olivenöl rapsöl sonnenblumenöl sesamöl essig balsamico weißweinessig apfelessig',
  };
  const GUESS_LIST = Object.entries(GUESS).flatMap(([cat, words]) => {
    // Mehrwort-Begriffe stehen hintereinander: bekannte Paare zusammenfassen
    const w = words.split(' '), out = [];
    for (let i = 0; i < w.length; i++) {
      const pair = w[i] + ' ' + w[i + 1];
      if (['rote bete', 'grüne bohnen', 'gehackte tomaten', 'passierte tomaten', 'crème fraîche', 'creme fraiche', 'saure sahne', 'rote linsen', 'frische kräuter', 'oregano getrocknet'].includes(pair)) { out.push([cat, pair]); i++; }
      else out.push([cat, w[i]]);
    }
    return out;
  });
  const normExtra = t => parseExtra(t).name.toLowerCase().replace(/\s+/g, ' ');
  /* Mengen in frei eingetragenen Artikeln: „4 Oatly“, „4 Packungen Feta“, „Feta 4 Pck.“, „Oatly x4“, „500g Hack“, „1,5 l Milch“ */
  const XUNITS = {
    G: ['g', 'g'], KG: ['kg', 'kg'], ML: ['ml', 'ml'], L: ['l', 'l'], STUECK: ['Stück', 'Stück'], PACKUNG: ['Packung', 'Packungen'],
    DOSE: ['Dose', 'Dosen'], GLAS: ['Glas', 'Gläser'], BUND: ['Bund', 'Bund'], SCHEIBE: ['Scheibe', 'Scheiben'],
    FLASCHE: ['Flasche', 'Flaschen'], BECHER: ['Becher', 'Becher'], BEUTEL: ['Beutel', 'Beutel'], TUETE: ['Tüte', 'Tüten'],
    NETZ: ['Netz', 'Netze'], KISTE: ['Kiste', 'Kisten'], TAFEL: ['Tafel', 'Tafeln'], ROLLE: ['Rolle', 'Rollen'], TUBE: ['Tube', 'Tuben'],
    SCHALE: ['Schale', 'Schalen'], KOPF: ['Kopf', 'Köpfe'], LAIB: ['Laib', 'Laibe'], KARTON: ['Karton', 'Kartons'], STANGE: ['Stange', 'Stangen'], DOSENPACK: ['Pack', 'Packs'],
  };
  const XALIAS = { g: 'G', gr: 'G', gramm: 'G', kg: 'KG', kilo: 'KG', ml: 'ML', l: 'L', liter: 'L', ltr: 'L',
    stück: 'STUECK', stueck: 'STUECK', stk: 'STUECK', st: 'STUECK', packung: 'PACKUNG', packungen: 'PACKUNG', pck: 'PACKUNG', pkg: 'PACKUNG',
    pkt: 'PACKUNG', päckchen: 'PACKUNG', paeckchen: 'PACKUNG', pack: 'DOSENPACK', packs: 'DOSENPACK', dose: 'DOSE', dosen: 'DOSE', glas: 'GLAS', gläser: 'GLAS', glaeser: 'GLAS',
    bund: 'BUND', scheibe: 'SCHEIBE', scheiben: 'SCHEIBE', flasche: 'FLASCHE', flaschen: 'FLASCHE', fl: 'FLASCHE', becher: 'BECHER',
    beutel: 'BEUTEL', tüte: 'TUETE', tüten: 'TUETE', tuete: 'TUETE', tueten: 'TUETE', netz: 'NETZ', netze: 'NETZ', kiste: 'KISTE', kisten: 'KISTE',
    tafel: 'TAFEL', tafeln: 'TAFEL', rolle: 'ROLLE', rollen: 'ROLLE', tube: 'TUBE', tuben: 'TUBE', schale: 'SCHALE', schalen: 'SCHALE',
    kopf: 'KOPF', köpfe: 'KOPF', koepfe: 'KOPF', laib: 'LAIB', laibe: 'LAIB', karton: 'KARTON', kartons: 'KARTON', stange: 'STANGE', stangen: 'STANGE' };
  const XWORDS = { ein: 1, eine: 1, einen: 1, zwei: 2, drei: 3, vier: 4, fünf: 5, fuenf: 5, sechs: 6, sieben: 7, acht: 8, neun: 9, zehn: 10, elf: 11, zwölf: 12, zwoelf: 12, halbe: 0.5, halber: 0.5, halbes: 0.5 };
  const XNUM = '(\\d+(?:[.,]\\d+)?|½|' + Object.keys(XWORDS).join('|') + ')';
  const XUNIT = '(' + Object.keys(XALIAS).sort((a, b) => b.length - a.length).join('|') + ')';
  const RX_FRONT = new RegExp('^' + XNUM + '\\s*(?:x|×|mal)?\\s*(?:' + XUNIT + '\\.?)?\\s+(.+)$', 'i');
  const RX_FRONT_GLUED = new RegExp('^(\\d+(?:[.,]\\d+)?)' + XUNIT + '\\.?\\s+(.+)$', 'i');
  const RX_BACK = new RegExp('^(.+?)\\s+(?:x|×)?\\s*(\\d+(?:[.,]\\d+)?|½)\\s*(?:x|×)?\\s*(?:' + XUNIT + '\\.?)?$', 'i');
  const xnum = s => { s = String(s).toLowerCase(); if (s === '½') return 0.5; if (XWORDS[s] != null) return XWORDS[s]; const n = parseFloat(s.replace(',', '.')); return isFinite(n) && n > 0 ? n : null; };
  function parseExtra(text) {
    const t = String(text || '').trim().replace(/\s+/g, ' ');
    const out = (name, q, u) => {
      const qty = xnum(q), nm = String(name || '').trim().replace(/^[-–:,]+\s*|\s*[-–:,]+$/g, '');
      if (!qty || !nm || /^\d/.test(nm) && !/[a-zäöüß]/i.test(nm)) return null;
      return { name: nm, qty, unit: u ? XALIAS[u.toLowerCase()] || null : null };
    };
    let m = t.match(RX_FRONT_GLUED), r = m && out(m[3], m[1], m[2]);
    if (!r && (m = t.match(RX_FRONT))) r = out(m[3], m[1], m[2]);
    if (!r && (m = t.match(RX_BACK)) && !/\s(in|zu|für|mit|und|von|pro|à|a|x|nr\.?|größe|gr\.?)$/i.test(m[1])) r = out(m[1], m[2], m[3]);
    return r || { name: t, qty: null, unit: null };
  }
  /* Name/Menge eines Zusatzartikels (neue Einträge speichern sie getrennt, ältere werden aus dem Text gelesen) */
  function extraParts(x) {
    if (!x) return { name: '', qty: null, unit: null };
    if (x.qty != null) return { name: String(x.text || '').trim(), qty: x.qty, unit: x.unit || null };
    return parseExtra(x.text);
  }
  function extraAmount(p) {
    if (!p || p.qty == null) return '';
    const u = XUNITS[p.unit || 'STUECK'] || XUNITS.STUECK;
    return fmtNum(p.qty) + ' ' + (p.qty === 1 ? u[0] : u[1]);
  }
  /* Text zum Bearbeiten: „4 Packungen Feta“ */
  const extraEditText = p => (p.qty != null ? extraAmount(p) + ' ' : '') + p.name;
  /* Kategorie für einen frei eingetragenen Artikel: gelernte Zuordnung, sonst erraten */
  function extraCategory(text, learned) {
    const n = normExtra(text);
    if (learned && learned[n]) return learned[n];
    return guessCategory(n);
  }
  function guessCategory(name) {
    const n = ' ' + String(name || '').toLowerCase().trim().replace(/\s+/g, ' ') + ' ';
    let best = null;
    GUESS_LIST.forEach(([cat, word]) => {
      const short = word.length <= 3; // kurze Wörter (ei, tk, öl) nur als ganzes Wort oder Wortende
      const hit = short ? new RegExp('[\\s-]' + word + '(\\s|$)').test(n) || (word === 'öl' && /öl\s$/.test(n)) : n.includes(word);
      if (hit && (!best || word.length > best[1].length)) best = [cat, word];
    });
    return best ? best[0] : 'SONSTIGES';
  }
  const cmpDe = (a, b) => a.localeCompare(b, 'de');

  /* ---------- Geschäfte mit Regal-Reihenfolge ----------
     settings.stores = [{ id, name, kind: 'SUPERMARKT'|'MARKT'|'DROGERIE', order: [Kategorie | 'S:<Bereich-ID>'],
                          sections: [{ id, name }], assign: { <normierter Artikelname>: <Bereich-ID> } }]
     settings.storeDefault = { SUPERMARKT: id, … }; je Einkaufsliste shopping.stores = { SUPERMARKT: id | 'none' } */
  const STORE_KINDS = [['SUPERMARKT', 'Supermarkt'], ['MARKT', 'Markt'], ['DROGERIE', 'Drogerie']];
  const liveStores = settings => ((settings && settings.stores) || []).filter(x => x && !x.deleted);
  function storeById(settings, id) { return liveStores(settings).find(x => x.id === id) || null; }
  /* gewähltes Geschäft für einen Einkaufsort: Auswahl der Liste, sonst Standard */
  function storeFor(settings, src, shopping) {
    const pick = shopping && shopping.stores && shopping.stores[src];
    if (pick === 'none') return null;
    const s = pick && storeById(settings, pick);
    if (s && s.kind === src) return s;
    const d = settings && settings.storeDefault && storeById(settings, settings.storeDefault[src]);
    return d && d.kind === src ? d : null;
  }
  /* vollständige Reihenfolge eines Geschäfts: gespeicherte Reihenfolge, dann fehlende Kategorien und Bereiche */
  function storeOrder(store, settings) {
    const secs = new Map((store.sections || []).map(x => [x.id, x]));
    const cats = CATEGORIES.filter(c => { const src = categorySource(c.key, settings); return src === store.kind || (c.key === 'SONSTIGES' && store.kind !== 'MARKT'); }).map(c => c.key);
    const ok = k => k.startsWith('S:') ? secs.has(k.slice(2)) : cats.includes(k);
    const out = [];
    (store.order || []).forEach(k => { if (ok(k) && !out.includes(k)) out.push(k); });
    cats.forEach(k => { if (!out.includes(k)) out.push(k); });
    secs.forEach((x, id) => { if (!out.includes('S:' + id)) out.push('S:' + id); });
    return out.map(k => k.startsWith('S:') ? { key: k, label: secs.get(k.slice(2)).name, section: true, id: k.slice(2) } : { key: k, label: CAT[k].label, section: false });
  }

  /* ---------- Vorschläge für zusätzliche Artikel: häufig gekauft und „wieder fällig“ ----------
     stats = { <normierter Name>: { t: Anzeigename, d: [ISO-Daten, je Tag einmal, max. 12], hidden?: true } } */
  function recordExtra(stats, text, date) {
    const n = normExtra(text); if (!n) return stats;
    const o = Object.assign({}, stats), e = Object.assign({ d: [] }, o[n]);
    e.t = String(text).trim(); delete e.hidden;
    if (!e.d.includes(date)) e.d = e.d.concat(date).sort().slice(-12);
    o[n] = e; return o;
  }
  /* Tippfehler korrigiert: Kauftag vom alten Begriff auf den neuen übertragen */
  function renameExtra(stats, oldText, newText, date) {
    const o = Object.assign({}, stats), n = normExtra(oldText);
    if (n && n !== normExtra(newText) && o[n]) {
      const e = Object.assign({}, o[n]); e.d = (e.d || []).filter(x => x !== date);
      if (e.d.length) o[n] = e; else delete o[n];
    }
    return recordExtra(o, newText, date);
  }
  const dayDiff = (a, b) => Math.round((parseISO(b) - parseISO(a)) / 864e5);
  /* liefert [{ text, n, due, every }] – fällige zuerst (nach Überfälligkeit), dann die häufigsten */
  function extraSuggestions(stats, today, exclude, max) {
    const out = [];
    Object.entries(stats || {}).forEach(([k, e]) => {
      if (!e || e.hidden || !e.d || !e.d.length || (exclude && exclude.has(k))) return;
      const d = e.d.slice().sort(), n = d.length, last = d[n - 1], since = dayDiff(last, today);
      const every = n >= 2 ? dayDiff(d[0], last) / (n - 1) : null;
      const due = !!(every && every >= 1 && since >= every * 0.8);
      const ratio = every ? since / every : 0;
      const score = (due ? 1000 + Math.min(ratio, 3) * 100 : 0) + n * 10 - Math.min(since, 120) / 12;
      out.push({ text: e.t || k, n, due, every: every ? Math.round(every) : null, score });
    });
    return out.sort((a, b) => b.score - a.score).slice(0, max || 8);
  }

  /* ---------- Backformen (Kuchen) ----------
     pan = { shape: 'ROUND'|'RING'|'RECT'|'TRAY'|'LOAF', d?, w?, l? } in cm. Mengen skalieren mit der Grundfläche. */
  const PAN_SHAPES = [['ROUND', 'Springform rund'], ['RING', 'Gugelhupf / Kranz'], ['RECT', 'Eckige Form'], ['TRAY', 'Backblech'], ['LOAF', 'Kastenform']];
  const PAN_PRESETS = [
    { shape: 'ROUND', d: 18 }, { shape: 'ROUND', d: 20 }, { shape: 'ROUND', d: 22 }, { shape: 'ROUND', d: 24 }, { shape: 'ROUND', d: 26 }, { shape: 'ROUND', d: 28 },
    { shape: 'RING', d: 22 }, { shape: 'RING', d: 26 }, { shape: 'LOAF', l: 25 }, { shape: 'LOAF', l: 30 },
    { shape: 'RECT', w: 20, l: 20 }, { shape: 'RECT', w: 20, l: 30 }, { shape: 'TRAY', w: 30, l: 40 },
  ];
  const panNum = v => { const n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) && n > 0 && n < 200 ? Math.round(n * 10) / 10 : null; };
  function cleanPan(p) {
    if (!p || !PAN_SHAPES.some(([k]) => k === p.shape)) return null;
    if (p.shape === 'ROUND' || p.shape === 'RING') { const d = panNum(p.d); return d ? { shape: p.shape, d } : null; }
    if (p.shape === 'LOAF') { const l = panNum(p.l); return l ? { shape: 'LOAF', l } : null; }
    const w = panNum(p.w), l = panNum(p.l); return w && l ? { shape: p.shape, w, l } : null;
  }
  function panArea(p) {
    p = cleanPan(p); if (!p) return 0;
    if (p.shape === 'ROUND') return Math.PI * (p.d / 2) ** 2;
    if (p.shape === 'RING') return Math.PI * (p.d / 2) ** 2 * 0.86;   // ohne Mittelrohr
    if (p.shape === 'LOAF') return p.l * 11;                          // übliche Breite 11 cm
    return p.w * p.l;
  }
  /* Faktor für die Zutaten, wenn statt der Originalform eine andere benutzt wird */
  function panFactor(orig, target) {
    const a = panArea(orig), b = panArea(target);
    return a && b ? b / a : 1;
  }
  const fmtCm = n => String(n).replace('.', ',');
  function panLabel(p) {
    p = cleanPan(p); if (!p) return '';
    if (p.shape === 'ROUND') return `Springform Ø ${fmtCm(p.d)} cm`;
    if (p.shape === 'RING') return `Gugelhupf Ø ${fmtCm(p.d)} cm`;
    if (p.shape === 'LOAF') return `Kastenform ${fmtCm(p.l)} cm`;
    return `${p.shape === 'TRAY' ? 'Blech' : 'Form'} ${fmtCm(p.w)} × ${fmtCm(p.l)} cm`;
  }
  const samePan = (a, b) => JSON.stringify(cleanPan(a)) === JSON.stringify(cleanPan(b));
  /* umgerechnete Menge zum Einkaufen sinnvoll runden: Gewicht/Volumen auf 5 bzw. 1, Stückartiges aufrunden */
  function roundScaled(q, unit) {
    if (q == null) return q;
    const dim = dimOf(unit), f = (UNITS[unit] && UNITS[unit].f) || 1;
    if (dim === 'MASS' || dim === 'VOLUME') { const base = q * f, r = base >= 100 ? 5 : base >= 10 ? 1 : 0.1; return Math.round(base / r) * r / f; }
    if (['EL', 'TL', 'PRISE'].includes(unit)) return Math.max(0.5, Math.round(q * 2) / 2);
    return Math.max(1, Math.ceil(q - 0.05));
  }
  /* Faktor eines Planeintrags (Kuchen mit eigener Backform) */
  function planFactor(p, r) { return p && p.pan && r && r.pan ? panFactor(r.pan, p.pan) : 1; }

  /* ---------- Einkaufsstand (v2) ----------
     Gekauft/entfernt wird je Kochtag und Zutat gemerkt („Einheit“ = Planeintrag|Position der Zutat im Rezept),
     damit derselbe Stand in jeder Ansicht gilt (alles Kommende, einzelne Woche, eigener Zeitraum) und
     nicht Gekauftes in die nächste Woche wandert. shopping = { v:2, bought:{key:{on,t}}, removed:{key:{on,t}},
     extras:[{id,text,date,checked,category,del,addedAt,updatedAt}], stores:{…} } */
  function shopUnits(db, from, to) {
    const recipes = new Map(live(db.recipes).map(r => [r.id, r]));
    const ings = new Map(live(db.ingredients).map(i => [i.id, i]));
    const laneRank = { MAIN: 0, LUNCH: 1, CAKE: 2, EXTRA: 3, SIDE: 3 };
    const cooks = live(db.plan).filter(p => p.type === 'COOK' && p.date >= from && p.date <= to)
      .sort((a, b) => a.date.localeCompare(b.date) || laneRank[laneOf(a)] - laneRank[laneOf(b)]);
    const names = [], warnings = [], units = [];
    cooks.forEach(p => {
      const r = recipes.get(p.recipeId);
      if (!r) return;
      if (!names.includes(r.name)) names.push(r.name);
      const list = (r.ingredients || []).filter(x => ings.has(x.ingredientId));   // (Wasser zählt hier mit: Rezept hat Zutaten)
      if (!list.length) {
        const w = `Für „${r.name}“ sind keine Zutaten hinterlegt.`;
        if (!warnings.includes(w)) warnings.push(w);
      }
      const f = planFactor(p, r) * guestFactor(p, r, db.settings);   // Kuchen in anderer Backform, Gäste
      (r.ingredients || []).forEach((x, k) => {
        if (ings.has(x.ingredientId) && !neverShop(ings.get(x.ingredientId))) units.push({ key: p.id + '|' + k, pid: p.id, k, recipeId: p.recipeId, recipe: r.name, cooked: !!p.cookedAt, ingId: x.ingredientId, quantity: x.quantity == null || f === 1 ? x.quantity : roundScaled(x.quantity * f, x.unit), unit: x.unit, date: p.date });
      });
    });
    return { names, warnings, units, ings };
  }
  /* älteren Stand (ein Zeitraum mit checkedKeys/extraItems) übernehmen – gleiches Ergebnis auf jedem Gerät */
  function migrateShopping(old, db) {
    if (old && old.v === 2) return old;
    const t = (old && old.updatedAt) || 0;
    const s = { v: 2, bought: {}, removed: {}, extras: [], stores: (old && old.stores) || {}, updatedAt: t };
    if (!old) return s;
    if (old.from && old.to && db) {
      const ck = new Set((old.checkedKeys || []).map(k => String(k).split('|')[0]));
      const rm = new Set((old.removedKeys || []).map(k => String(k).split('|')[0]));
      shopUnits(db, old.from, old.to).units.forEach(u => {
        if (ck.has(u.ingId)) s.bought[u.key] = { on: true, t };
        if (rm.has(u.ingId)) s.removed[u.key] = { on: true, t };
      });
    }
    (old.extraItems || []).forEach((x, i) => {
      if (x && x.text) s.extras.push({ id: 'm' + i + '-' + t, text: x.text, date: old.from || todayISO(), checked: !!x.checked, category: x.category || null, addedAt: t + i, updatedAt: t });
    });
    return s;
  }
  function ensureShopping(db) {
    if (!db.shopping || db.shopping.v !== 2) db.shopping = migrateShopping(db.shopping, db);
    ['bought', 'removed', 'stores'].forEach(k => { if (!db.shopping[k] || typeof db.shopping[k] !== 'object') db.shopping[k] = {}; });
    if (!Array.isArray(db.shopping.extras)) db.shopping.extras = [];
    return db.shopping;
  }
  const isOn = (m, k) => !!(m && m[k] && m[k].on);
  /* Vorgänger eines Planeintrags: gelöschte Kochtage desselben Rezepts (verschoben, neu gefüllt, auf einem anderen
     Gerät doppelt angelegt …), älter als der Eintrag und höchstens 14 Tage entfernt – neueste zuerst.
     Ihr Einkaufsstand (gekauft/entfernt) gilt weiter, solange der neue Eintrag keinen eigenen hat. */
  function predecessorsFn(db) {
    const dead = new Map();
    (db.plan || []).forEach(q => { if (q.deleted && q.type === 'COOK' && q.recipeId) { if (!dead.has(q.recipeId)) dead.set(q.recipeId, []); dead.get(q.recipeId).push(q); } });
    dead.forEach(l => l.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)));
    const cache = new Map();
    return p => {
      if (!p || !dead.has(p.recipeId)) return [];
      if (cache.has(p.id)) return cache.get(p.id);
      const pd = parseISO(p.date), r = dead.get(p.recipeId).filter(q => q.id !== p.id && ((q.createdAt || 0) <= (p.createdAt || 0) || q.date === p.date)
        && Math.abs(pd - parseISO(q.date)) <= 14 * 864e5);
      cache.set(p.id, r); return r;
    };
  }
  /* Markierung einer Einheit – eigene, sonst vom Vorgänger geerbte */
  function markOf(m, u, preds) {
    if (m && m[u.key]) return m[u.key];
    if (!preds || !u.pid) return null;
    for (const q of preds(u)) { const v = m && m[q.id + '|' + u.k]; if (v) return v; }
    return null;
  }
  /* Einheiten als gekauft/entfernt markieren (oder zurücknehmen) */
  function shopMark(db, map, keys, on) {
    const s = ensureShopping(db), t = clock();
    keys.forEach(k => { s[map][k] = { on: !!on, t }; });
    touch(s);
  }
  /* zwei Einkaufsstände zusammenführen: je Einheit/Artikel gewinnt die neuere Änderung */
  function mergeShopping(a, b, da, dbb) {
    if (!a) return b; if (!b) return a;
    a = migrateShopping(a, da); b = migrateShopping(b, dbb);
    const mm = (x, y) => { const o = Object.assign({}, x); Object.entries(y || {}).forEach(([k, v]) => { if (!o[k] || (v.t || 0) > (o[k].t || 0)) o[k] = v; }); return o; };
    const ex = new Map();
    (a.extras || []).concat(b.extras || []).forEach(e => { const c = ex.get(e.id); if (!c || (e.updatedAt || 0) > (c.updatedAt || 0)) ex.set(e.id, e); });
    const nb = (b.updatedAt || 0) > (a.updatedAt || 0) ? b : a;
    return { v: 2, bought: mm(a.bought, b.bought), removed: mm(a.removed, b.removed),
      extras: [...ex.values()].sort((x, y) => (x.addedAt || 0) - (y.addedAt || 0)), stores: nb.stores || {}, updatedAt: Math.max(a.updatedAt || 0, b.updatedAt || 0),
      carryFrom: [a.carryFrom || '', b.carryFrom || ''].sort().pop() || undefined };
  }
  /* alte Markierungen und erledigte Zusatzartikel aufräumen */
  function pruneShopping(db, today) {
    const s = ensureShopping(db), lim = addDays(today || todayISO(), -45);
    const plan = new Map((db.plan || []).filter(p => !p.deleted).map(p => [p.id, p]));
    let n = 0;
    // Stand gelöschter Kochtage an ihre Nachfolger (verschoben/neu gefüllt) weitergeben, bevor er wegfällt
    const pf = predecessorsFn(db);
    plan.forEach(p => {
      if (p.type !== 'COOK') return;
      const ps = pf(p); if (!ps.length) return;
      ['bought', 'removed'].forEach(m => Object.keys(s[m]).forEach(k => {
        const [qid, idx] = k.split('|'); if (!ps.some(q => q.id === qid)) return;
        const nk = p.id + '|' + idx;
        if (!s[m][nk]) { s[m][nk] = s[m][k]; n++; }
      }));
    });
    ['bought', 'removed'].forEach(m => Object.keys(s[m]).forEach(k => {
      const p = plan.get(k.split('|')[0]);
      if (!p || p.date < lim) { delete s[m][k]; n++; }
    }));
    const before = s.extras.length;
    s.extras = s.extras.filter(x => !((x.del || x.checked) && (x.date || '') < addDays(today || todayISO(), -30)));
    return n + before - s.extras.length;
  }

  /* opts.today (Tests); läuft der Zeitraum über heute, wandern nicht Gekauftes der Vorwoche und offene Zusatzartikel mit */
  function buildShoppingList(db, from, to, opts) {
    opts = opts || {};
    const today = opts.today || todayISO();
    const st = migrateShopping(db.shopping, db);
    const pf = predecessorsFn(db), byId = new Map((db.plan || []).map(p => [p.id, p]));
    const preds = u => pf(byId.get(u.pid));
    const on = (m, u) => { const v = markOf(st[m], u, preds); return !!(v && v.on); };
    const carry = from <= today && today <= to;
    // Übertrag nur aus den letzten 7 Tagen – und nie von vor dem Tag, an dem die Liste komplett geleert wurde
    const carryFrom = [addDays(today, -7), st.carryFrom || ''].sort().pop();
    const main = shopUnits(db, from, to), ings = main.ings, names = main.names, warnings = main.warnings;
    let units = main.units.filter(u => !on('removed', u));
    if (carry && carryFrom < from) {
      units = units.concat(shopUnits(db, carryFrom, addDays(from, -1)).units
        .filter(u => !on('removed', u) && !on('bought', u) && !u.cooked && sourceOf(ings.get(u.ingId), db.settings) !== 'VORRAT')   // Vorrat prüft man je Woche neu; gekocht = erledigt
        .map(u => Object.assign(u, { carry: true })));
    }
    const learned = (db.settings && db.settings.extraCats) || {};
    const per = new Map();
    units.forEach(u => { if (!per.has(u.ingId)) per.set(u.ingId, []); per.get(u.ingId).push(u); });
    const rows = [...per.entries()].map(([id, us]) => {
      const ing = ings.get(id);
      const open = us.filter(u => !on('bought', u)), checked = !open.length;
      const sum = sumAmounts(checked ? us : open);
      const dishes = [...new Set((checked ? us : open).map(u => u.recipe).filter(Boolean))];   // für welche Gerichte
      // Einzelposten je Planeintrag (Gericht + Tag) zum Aufklappen
      const byPid = new Map(); us.forEach(u => { if (!byPid.has(u.pid)) byPid.set(u.pid, []); byPid.get(u.pid).push(u); });
      const parts = [...byPid.values()].map(g => ({ label: g[0].recipe || '', date: g[0].date, amount: sumAmounts(g).text,
        units: g.map(u => u.key), checked: g.every(u => on('bought', u)), carry: g.some(u => u.carry) }))
        .sort((a, b) => a.date.localeCompare(b.date));
      return { key: 'i:' + id, ingId: id, units: us.map(u => u.key), name: ing.name, amount: sum.text, category: ing.category,
        source: sourceOf(ing, db.settings), checked, carry: open.some(u => u.carry), dishes, parts, extras: [], _open: open };
    });
    const rowByName = new Map(rows.filter(r => r.source !== 'VORRAT').map(r => [normExtra(r.name), r]));
    const removedIngs = new Set(main.units.filter(u => on('removed', u)).map(u => u.ingId));
    rows.forEach(r => removedIngs.delete(r.ingId));
    /* zusätzliche Artikel („Spülmittel“) wie Zutaten einsortieren; Vorrat zählt hier nicht – die will man ja kaufen */
    const extras = (st.extras || []).filter(x => x && !x.del && x.text && x.text.trim()
      && ((x.date >= from && x.date <= to) || (carry && x.date < from && x.date >= carryFrom && !x.checked)));
    extras.forEach(x => {
      const p = extraParts(x);
      const same = rowByName.get(normExtra(p.name));   // „Lauch“ selbst hinzugefügt + Lauch aus Rezepten → eine Zeile
      if (same) {
        same.extras.push(x.id);
        same.parts.push({ extra: x.id, label: 'Selbst hinzugefügt', amount: extraAmount(p), checked: !!x.checked, carry: x.date < from, xp: p });
        return;
      }
      const category = x.category || extraCategory(p.name, learned);
      let source = ((db.settings && db.settings.extraSrc) || {})[normExtra(p.name)] || categorySource(category, db.settings);   // eigener Einkaufsort je Begriff
      if (source === 'VORRAT') source = 'SUPERMARKT';
      rows.push({ key: 'x:' + x.id, extra: x.id, name: p.name, amount: extraAmount(p), category, source, checked: !!x.checked, carry: x.date < from });
    });
    rows.forEach(r => {   // Zeilen mit eingeordneten eigenen Artikeln: Menge und Haken über alle Posten
      if (r.extras && r.extras.length) {
        const xs = r.parts.filter(q => q.extra), allDone = r.checked && xs.every(q => q.checked);
        const xsUse = allDone ? xs : xs.filter(q => !q.checked);
        const conv = [], other = [];
        xsUse.forEach(q => { if (q.xp.qty == null) return; const u = q.xp.unit || 'STUECK'; UNITS[u] ? conv.push({ quantity: q.xp.qty, unit: u }) : other.push(q.amount); });
        const unitObjs = allDone ? units.filter(u => u.ingId === r.ingId) : r._open;
        r.amount = [sumAmounts(unitObjs.concat(conv)).text].concat(other).filter(Boolean).join(' + ');
        r.checked = allDone;
        r.carry = r.carry || xsUse.some(q => q.carry);
      }
      delete r._open; if (r.parts) r.parts.forEach(q => delete q.xp);
    });
    const stores = {}; STORE_KINDS.forEach(([k]) => { stores[k] = storeFor(db.settings, k, st); });
    /* Gruppen nach der Reihenfolge des Geschäfts; eigene Bereiche ziehen ihre Artikel aus den Kategorien */
    const storeGroups = (src, store) => {
      const own = rows.filter(r => r.source === src);
      const secOf = r => { const id = store.assign && store.assign[normExtra(r.name)]; return id && (store.sections || []).some(x => x.id === id) ? 'S:' + id : null; };
      const order = storeOrder(store, db.settings), used = new Set();
      const g = order.map(o => ({ category: o.key, label: o.label, section: o.section,
        items: own.filter(r => { const k = secOf(r) || r.category; if (k !== o.key) return false; used.add(r); return true; }).sort((a, b) => cmpDe(a.name, b.name)) }));
      const rest = own.filter(r => !used.has(r));   // Kategorien, die (noch) nicht zu diesem Geschäft gehören
      CATEGORIES.forEach(c => { const it = rest.filter(r => r.category === c.key); if (it.length) g.push({ category: c.key, label: c.label, items: it.sort((a, b) => cmpDe(a.name, b.name)) }); });
      const misc = rest.filter(r => !CAT[r.category]);
      if (misc.length) g.push({ category: 'SONSTIGES', label: 'Sonstiges', items: misc.sort((a, b) => cmpDe(a.name, b.name)) });
      return g.filter(x => x.items.length);
    };
    let market = rows.filter(r => r.source === 'MARKT').sort((a, b) => cmpDe(a.name, b.name)), marketGroups = null;
    if (stores.MARKT) { marketGroups = storeGroups('MARKT', stores.MARKT); market = [].concat(...marketGroups.map(x => x.items)); }
    const groupsOf = src => {
      if (stores[src]) return storeGroups(src, stores[src]);
      const g = CATEGORIES.map(c => ({
        category: c.key, label: c.label,
        items: rows.filter(r => r.source === src && r.category === c.key).sort((a, b) => cmpDe(a.name, b.name)),
      })).filter(x => x.items.length);
      const misc = rows.filter(r => r.source === src && !CATEGORIES.some(c => c.key === r.category));
      if (misc.length) g.push({ category: 'SONSTIGES', label: 'Sonstiges', items: misc.sort((a, b) => cmpDe(a.name, b.name)) });
      return g;
    };
    const supermarket = groupsOf('SUPERMARKT'), drogerie = groupsOf('DROGERIE');
    const pantry = rows.filter(r => r.source === 'VORRAT').sort((a, b) => cmpDe(a.name, b.name))
      .map(r => ({ key: r.key, ingId: r.ingId, units: r.units, name: r.name, checked: r.checked, carry: r.carry, dishes: r.dishes, parts: r.parts, extras: r.extras }));
    return { from, to, recipes: names, market, marketGroups, supermarket, drogerie, pantry, extraItems: extras, warnings,
      removedCount: removedIngs.size, stores, carried: rows.filter(r => r.carry && !r.checked).length };
  }
  /* Text zum Teilen/Kopieren: nur die offenen Zutaten, eine pro Zeile – ohne Überschrift, Gerichte oder Kategorien
     (so lässt es sich z. B. direkt in die Erinnerungen einfügen). Vorrat und Hinweise bleiben weg. */
  function shoppingText(list, settings) {
    const open = r => !r.checked;
    const L = [];
    list.market.filter(open).forEach(r => L.push(r.name + (settings && settings.marketListShowQuantities && r.amount ? ` (${r.amount})` : '')));
    list.supermarket.concat(list.drogerie || []).forEach(g => g.items.filter(open).forEach(r => L.push(r.name + (r.amount ? ` (${r.amount})` : ''))));
    // ältere Listenform ohne einsortierte Zusatzartikel
    if (!list.supermarket.concat(list.market, list.drogerie || []).some(g => (g.items || [g]).some(r => r.extra != null)))
      (list.extraItems || []).filter(x => open(x) && x.text && x.text.trim()).forEach(x => { const p = extraParts(x); L.push(p.name + (p.qty != null ? ` (${extraAmount(p)})` : '')); });
    return L.join('\n');
  }

  /* ---------- Zusammenführen zweier Datenstände (Geräteabgleich) ---------- */
  function mergeById(a, b) {
    const m = new Map();
    (a || []).forEach(x => m.set(x.id, x));
    (b || []).forEach(y => {
      const x = m.get(y.id);
      if (!x || (y.updatedAt || 0) > (x.updatedAt || 0)) m.set(y.id, y);
    });
    return [...m.values()];
  }
  const newer = (a, b) => (!a ? b : !b ? a : ((b.updatedAt || 0) > (a.updatedAt || 0) ? b : a));
  function mergeDb(local, remote) {
    if (!remote) return local;
    if (!local) return remote;
    return {
      version: Math.max(local.version || 1, remote.version || 1),
      household: newer(local.household, remote.household),
      settings: newer(local.settings, remote.settings),
      shopping: mergeShopping(local.shopping, remote.shopping, local, remote),
      recipes: mergeById(local.recipes, remote.recipes),
      ingredients: mergeById(local.ingredients, remote.ingredients),
      rotation: mergeById(local.rotation, remote.rotation),
      plan: mergeById(local.plan, remote.plan),
    };
  }
  /* Nach dem Zusammenführen: pro Datum höchstens ein Planeintrag (neuerer gewinnt) */
  function normalizePlan(db) {
    const byDate = new Map();
    live(db.plan).forEach(p => {
      if (laneOf(p) === 'EXTRA') return; // zusätzliche Gerichte: beliebig viele pro Tag
      const k = p.date + '|' + laneOf(p);
      const o = byDate.get(k);
      if (!o) { byDate.set(k, p); return; }
      const [keep, drop] = (p.updatedAt || 0) > (o.updatedAt || 0) ? [p, o] : [o, p];
      byDate.set(k, keep);
      tomb(drop);
    });
  }
  function pruneTombstones(db, maxAgeMs) {
    const lim = clock() - maxAgeMs;
    ['recipes', 'ingredients', 'rotation', 'plan'].forEach(k => {
      db[k] = (db[k] || []).filter(x => !x.deleted || (x.updatedAt || 0) > lim);
    });
  }
  /* ---------- Rezept-Import (Format „essensplanung-import“ v1) ----------
     Nimmt den Text aus dem Scanner-Chat entgegen (auch mit ```json-Zaun oder Begleittext)
     und liefert normalisierte Rezepte mit Hinweisen. Keine Speicherzugriffe. */
  const KIND_ALIAS = { HAUPT: 'MAIN', HAUPTGERICHT: 'MAIN', MAIN: 'MAIN', ABEND: 'MAIN', ABENDESSEN: 'MAIN',
    MITTAG: 'LUNCH', MITTAGESSEN: 'LUNCH', LUNCH: 'LUNCH', KUCHEN: 'CAKE', CAKE: 'CAKE', GEBAECK: 'CAKE', BACKEN: 'CAKE',
    BEILAGE: 'SIDE', BEILAGEN: 'SIDE', SIDE: 'SIDE', SALAT: 'SIDE', SOSSE: 'SIDE', SAUCE: 'SIDE', DIP: 'SIDE',
    BESONDERES: 'SPECIAL', BESONDERS: 'SPECIAL', SONNTAG: 'SPECIAL', SONNTAGSESSEN: 'SPECIAL', FESTESSEN: 'SPECIAL', FEST: 'SPECIAL', SPECIAL: 'SPECIAL' };
  const UNIT_ALIAS = {
    g: 'G', gr: 'G', gramm: 'G', kg: 'KG', kilo: 'KG', kilogramm: 'KG', ml: 'ML', milliliter: 'ML', l: 'L', liter: 'L',
    stueck: 'STUECK', stück: 'STUECK', stk: 'STUECK', st: 'STUECK', el: 'EL', essloeffel: 'EL', esslöffel: 'EL',
    tl: 'TL', teeloeffel: 'TL', teelöffel: 'TL', prise: 'PRISE', prisen: 'PRISE', bund: 'BUND', zehe: 'ZEHE', zehen: 'ZEHE',
    dose: 'DOSE', dosen: 'DOSE', glas: 'GLAS', glaeser: 'GLAS', gläser: 'GLAS', packung: 'PACKUNG', packungen: 'PACKUNG',
    pck: 'PACKUNG', pkg: 'PACKUNG', paeckchen: 'PACKUNG', päckchen: 'PACKUNG', scheibe: 'SCHEIBE', scheiben: 'SCHEIBE',
  };
  const UNIT_CONVERT = { cl: ['ML', 10], dl: ['ML', 100], tasse: ['ML', 250, 1], tassen: ['ML', 250, 1] };
  const FRACTIONS = { '½': 0.5, '¼': 0.25, '¾': 0.75, '⅓': 1 / 3, '⅔': 2 / 3, '⅛': 0.125 };
  function parseAmount(v) {
    if (v == null || v === '') return null;
    if (typeof v === 'number') return isFinite(v) && v > 0 ? v : null;
    let t = String(v).trim().replace(',', '.');
    let add = 0;
    for (const [f, x] of Object.entries(FRACTIONS)) if (t.includes(f)) { add += x; t = t.replace(f, ' '); }
    t = t.trim();
    const range = t.match(/^(\d+(?:\.\d+)?)\s*[-–]\s*(\d+(?:\.\d+)?)$/); // 2–3 → 3
    if (range) return +range[2] + add;
    const mixed = t.match(/^(\d+)\s+(\d+)\/(\d+)$/);
    if (mixed) return +mixed[1] + mixed[2] / mixed[3] + add;
    const frac = t.match(/^(\d+)\/(\d+)$/);
    if (frac) return +frac[1] / +frac[2] + add;
    const n = t === '' ? 0 : parseFloat(t);
    const r = (isFinite(n) ? n : 0) + add;
    return r > 0 ? Math.round(r * 1000) / 1000 : null;
  }
  function extractJson(text) {
    const s = String(text || '').trim();
    const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
    const body = fence ? fence[1] : s;
    const a = body.search(/[{[]/);
    if (a < 0) throw new Error('Im Text wurde kein Rezept-Block gefunden.');
    const close = body[a] === '{' ? '}' : ']';
    const b = body.lastIndexOf(close);
    const raw = body.slice(a, b + 1);
    try { return JSON.parse(raw); } catch (e) { /* Reparaturversuche unten */ }
    const noComma = raw.replace(/,\s*([}\]])/g, '$1'); // überzählige Kommas
    try { return JSON.parse(noComma); } catch (e) { /* weiter */ }
    // von iOS-Autokorrektur ersetzte Anführungszeichen – nur die, die JSON-Syntax sein müssen
    const fixed = noComma.replace(/[“”„](?=\s*[:,}\]])|(?<=[{\[,:]\s*)[“”„]/g, '"');
    try { return JSON.parse(fixed); }
    catch (e) { throw new Error('Der Rezept-Block ist unvollständig oder beschädigt. Bitte die Antwort komplett kopieren.'); }
  }
  const str = v => (v == null ? '' : String(v)).trim();
  function normalizeImportRecipe(x, idx) {
    const warn = [];
    const name = str(x.name || x.titel || x.title).replace(/\s+/g, ' ').slice(0, 120);
    const kindKey = str(x.art || x.kind).toUpperCase().replace(/Ä/g, 'AE').replace(/Ü/g, 'UE').replace(/Ö/g, 'OE');
    const kind = KIND_ALIAS[kindKey] || 'MAIN';
    if (kindKey && !KIND_ALIAS[kindKey]) warn.push(`Unbekannte Art „${str(x.art || x.kind)}“, als Hauptgericht übernommen.`);
    let servings = Math.round(parseAmount(x.portionen != null ? x.portionen : x.servings) || 0);
    if (kind === 'CAKE' && servings < 2) servings = 12;
    if (servings < 1) { servings = 4; warn.push('Keine Portionen angegeben, 4 angenommen.'); }
    servings = Math.min(99, servings);
    const time = Math.round(parseAmount(x.zubereitungszeitMin != null ? x.zubereitungszeitMin : x.prepTimeMinutes) || 0) || null;
    const tags = [...new Set((Array.isArray(x.tags) ? x.tags : str(x.tags).split(',')).map(str).filter(Boolean))].slice(0, 12);
    let months = (Array.isArray(x.saison) ? x.saison : []).map(Number).filter(m => m >= 1 && m <= 12);
    months = [...new Set(months)].sort((a, b) => a - b);
    const seasonMonths = months.length && months.length < 12 ? months : null;
    const ingredients = [];
    (Array.isArray(x.zutaten) ? x.zutaten : Array.isArray(x.ingredients) ? x.ingredients : []).forEach(z => {
      if (typeof z === 'string') z = { name: z };
      const iname = str(z.name || z.zutat || z.ingredient).replace(/\s+/g, ' ').slice(0, 80);
      if (!iname) return;
      let quantity = parseAmount(z.menge != null ? z.menge : z.quantity);
      let note = str(z.notiz || z.note);
      const rawUnit = str(z.einheit != null ? z.einheit : z.unit);
      const uKey = rawUnit.toLowerCase().replace(/\.$/, '');
      let unit = null;
      if (quantity != null) {
        if (UNITS[rawUnit.toUpperCase()]) unit = rawUnit.toUpperCase();
        else if (UNIT_ALIAS[uKey]) unit = UNIT_ALIAS[uKey];
        else if (UNIT_CONVERT[uKey]) {
          const [u, f, keep] = UNIT_CONVERT[uKey];
          if (keep) note = [note, 'Original: ' + fmtNum(quantity) + ' ' + rawUnit].filter(Boolean).join(', ');
          unit = u; quantity = Math.round(quantity * f * 100) / 100;
        }
        else if (!rawUnit) unit = 'STUECK';
        else {
          unit = 'STUECK';
          note = [note, 'Original: ' + fmtNum(quantity) + ' ' + rawUnit].filter(Boolean).join(', ');
          warn.push(`${iname}: Einheit „${rawUnit}“ unbekannt, als Stück übernommen.`);
        }
      }
      const catRaw = str(z.kategorie || z.category).toUpperCase();
      const category = CAT[catRaw] ? catRaw : guessCategory(iname);
      ingredients.push({ name: iname, quantity, unit, note: note.slice(0, 120), category });
    });
    let steps = x.anleitung != null ? x.anleitung : x.instructions;
    let instructions = '';
    if (Array.isArray(steps)) {
      instructions = steps.map(str).filter(Boolean).map((t, i) => `${i + 1}. ${t.replace(/^\d+[.)]\s*/, '')}`).join('\n');
    } else instructions = str(steps);
    const notes = [str(x.notizen || x.notes), str(x.quelle || x.source) ? 'Quelle: ' + str(x.quelle || x.source) : ''].filter(Boolean).join('\n');
    (Array.isArray(x.hinweise) ? x.hinweise : x.hinweise ? [x.hinweise] : []).map(str).filter(Boolean).forEach(h => warn.push(h));
    if (!ingredients.length) warn.push('Keine Zutaten erkannt.');
    if (!instructions) warn.push('Keine Anleitung erkannt.');
    return { name: name || `Rezept ${idx + 1}`, noName: !name, kind, servings, prepTimeMinutes: time, tags, seasonMonths,
      ingredients, instructions, notes, favorite: x.favorit === true || x.favorite === true, warnings: warn,
      sideNames: (Array.isArray(x.beilagen) ? x.beilagen : Array.isArray(x.sides) ? x.sides : []).map(str).filter(Boolean).slice(0, 12) };
  }
  /* Rezepte im Import-Format ausgeben (wieder einlesbar mit parseRecipeImport) */
  const KIND_OUT = { MAIN: 'Hauptgericht', LUNCH: 'Mittag', CAKE: 'Kuchen', SIDE: 'Beilage', SPECIAL: 'Besonderes' };
  function buildRecipeExport(db, ids) {
    const ing = new Map((db.ingredients || []).map(i => [i.id, i]));
    const byId = new Map(live(db.recipes).filter(r => !r.archivedAt).map(r => [r.id, r]));
    const pick = new Set(ids);
    const rezepte = live(db.recipes).filter(r => !r.archivedAt && pick.has(r.id))
      .sort((a, b) => a.name.localeCompare(b.name, 'de')).map(r => {
        const o = { name: r.name, art: KIND_OUT[r.kind || 'MAIN'] || 'Hauptgericht', portionen: r.servings };
        if (r.prepTimeMinutes) o.zubereitungszeitMin = r.prepTimeMinutes;
        if (r.tags && r.tags.length) o.tags = r.tags.slice();
        if (r.seasonMonths && r.seasonMonths.length) o.saison = r.seasonMonths.slice();
        o.zutaten = (r.ingredients || []).slice().sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0)).map(x => {
          const i = ing.get(x.ingredientId); if (!i) return null;
          const z = { name: i.name };
          if (x.quantity != null) { z.menge = x.quantity; z.einheit = x.unit || 'STUECK'; }
          if (x.note) z.notiz = x.note;
          if (i.category) z.kategorie = i.category;
          return z;
        }).filter(Boolean);
        if (r.instructions) o.anleitung = r.instructions;
        if (r.notes) o.notizen = r.notes;
        if (r.favorite) o.favorit = true;
        const sides = (r.sides || []).map(id => byId.get(id)).filter(Boolean).map(s => s.name);
        if (sides.length) o.beilagen = sides;
        return o;
      });
    return { format: 'essensplanung-import', version: 1, exportiertAm: new Date().toISOString(), rezepte };
  }
  /* Zeitangaben in einem Anleitungsschritt erkennen („10 Minuten“, „5–7 Min.“, „eine halbe Stunde“, „1 ½ Std.“)
     → [{ sec, label }]; bei Spannen zählt der kleinere Wert (lieber früher nachsehen) */
  const NUMW = { ein: 1, eine: 1, einer: 1, einen: 1, zwei: 2, drei: 3, vier: 4, 'fünf': 5, sechs: 6, sieben: 7, acht: 8, neun: 9, zehn: 10,
    'elf': 11, 'zwölf': 12, 'fünfzehn': 15, zwanzig: 20, 'dreißig': 30, vierzig: 40, 'fünfundvierzig': 45, anderthalb: 1.5, eineinhalb: 1.5, halbe: 0.5, halben: 0.5 };
  const NUM = '(\\d+(?:[.,]\\d+)?|' + Object.keys(NUMW).sort((a, b) => b.length - a.length).join('|') + ')';
  const TIME_RE = new RegExp('(?<![\\wäöüß])(?:' + NUM + '\\s*(?:-|–|—|bis)\\s*)?' + NUM + '(\\s*½)?\\s*(Sekunden|Sekunde|Sek\\.?|Minuten|Minute|Min\\.?|Stunden|Stunde|Std\\.?)(?![\\wäöüß])', 'gi');
  function parseTimers(text) {
    const t = String(text || '').replace(/<[^>]*>/g, ' ');
    const num = v => { if (v == null) return null; const k = v.toLowerCase(); return k in NUMW ? NUMW[k] : parseFloat(k.replace(',', '.')); };
    const out = [];
    let m; TIME_RE.lastIndex = 0;
    while ((m = TIME_RE.exec(t))) {
      const lo = num(m[1]), hi = num(m[2]) + (m[3] ? 0.5 : 0), u = m[4].toLowerCase();
      const mult = u.startsWith('s') && !u.startsWith('st') ? 1 : u.startsWith('m') ? 60 : 3600;
      const v = lo != null && lo < hi ? lo : hi;
      const sec = Math.round(v * mult);
      if (!(sec >= 5 && sec <= 24 * 3600)) continue;
      const label = m[0].replace(/\s+/g, ' ').trim();
      if (!out.some(o => o.sec === sec)) out.push({ sec, label });
    }
    return out;
  }
  function fmtClock(sec) {
    sec = Math.max(0, Math.ceil(sec));
    const h = Math.floor(sec / 3600), mi = Math.floor(sec % 3600 / 60), s = sec % 60, p = n => String(n).padStart(2, '0');
    return h ? `${h}:${p(mi)}:${p(s)}` : `${p(mi)}:${p(s)}`;
  }
  /* Ähnliche Rezeptnamen erkennen (Tippfehler, Schreibweisen, Zusätze wie „mit Parmesan“) */
  const STOP = new Set(['mit', 'und', 'in', 'im', 'an', 'auf', 'der', 'die', 'das', 'den', 'dem', 'vom', 'von', 'nach', 'art', 'a', 'la', 'al', 'alla', 'aus', 'ohne', 'oder', 'zu', 'zum', 'zur', 'klassisch', 'klassische', 'einfach', 'einfache', 'schnell', 'schnelle']);
  const normName = n => String(n || '').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss')
    .normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
  function lev(a, b) {
    if (a === b) return 0;
    let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      const cur = [i];
      for (let j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[b.length];
  }
  const sameTok = (a, b) => a === b || (a.length >= 5 && b.length >= 5 && Math.abs(a.length - b.length) <= 2 && (a.startsWith(b) || b.startsWith(a)));
  function nameSimilar(a, b) {
    const na = normName(a), nb = normName(b);
    if (!na || !nb) return false;
    const ja = na.replace(/ /g, ''), jb = nb.replace(/ /g, '');
    if (ja === jb) return true;
    const L = Math.max(ja.length, jb.length);
    if (L >= 6 && 1 - lev(ja, jb) / L >= 0.85) return true;
    const ta = na.split(' ').filter(w => !STOP.has(w)), tb = nb.split(' ').filter(w => !STOP.has(w));
    if (!ta.length || !tb.length) return false;
    const shared = ta.filter(w => tb.some(v => sameTok(w, v)));
    return shared.some(w => w.length >= 4) && shared.length / Math.min(ta.length, tb.length) >= 0.75 && Math.min(ta.length, tb.length) >= 1
      && (Math.min(ta.length, tb.length) >= 2 || Math.max(ta.length, tb.length) <= 3);
  }
  function similarRecipes(db, name, kind) {   // kind: nur Rezepte derselben Art (sonst alle)
    const n = normName(name);
    return live(db.recipes).filter(r => !r.archivedAt && (!kind || laneOf(r) === kind) && normName(r.name) !== n && nameSimilar(r.name, name));
  }
  function parseRecipeImport(text) {
    const j = typeof text === 'string' ? extractJson(text) : text;
    const list = Array.isArray(j) ? j : Array.isArray(j.rezepte) ? j.rezepte : Array.isArray(j.recipes) ? j.recipes : (j && (j.name || j.titel)) ? [j] : null;
    if (!list) throw new Error(j && j.format === 'essensplanung' ? 'Das ist eine Sicherung. Bitte unter Einstellungen → „Sicherung einlesen“ öffnen.' : 'Im Block wurden keine Rezepte gefunden.');
    const recipes = list.filter(x => x && typeof x === 'object').map(normalizeImportRecipe);
    if (!recipes.length) throw new Error('Im Block wurden keine Rezepte gefunden.');
    recipes.forEach(r => { if (r.noName) r.warnings.unshift('Kein Name erkannt – bitte nach dem Import umbenennen.'); });
    return recipes;
  }


  return {
    setClock, uuid, touch, live, tomb, seededRng,
    iso, parseISO, addDays, todayISO, weekStart, weekDays, isoWeek, fmtDate, fmtShort, fmtRange, weekday, weekdayLong,
    daysFor, daysHint, LANES, KINDS, ROTATES, laneOf, kindName, specialDays, guestFactor, linkedSides, linkedFrom, MONTHS, inSeason, seasonLabel, monthOf,
    activeRecipes, repairAdjacency, buildCycle, cycleEntries, maxCycle, openCycles, pendingSorted,
    lastRecipeOfCycle, appendCycle, nextEntries, planEntry, completeEntry, skipEntry, postpone, release,
    manualPickEntry, resetRotation, syncRecipeIntoCycles, cycleProgress,
    nextFreeDates, layoutDraft, fillWeek,
    UNITS, UNIT_ORDER, dimOf, fmtNum, sumAmounts,
    CATEGORIES, CAT, neverShop, prepPhrases, prepClauses, prepAssign, categorySource, extraCategory, STORE_KINDS, liveStores, storeById, storeFor, storeOrder, normExtra, sourceOf, guessCategory, buildShoppingList, shoppingText, recordExtra, renameExtra, parseExtra, extraParts, extraAmount, extraEditText, extraSuggestions, PAN_SHAPES, PAN_PRESETS, cleanPan, panArea, panFactor, panLabel, samePan, planFactor, roundScaled, shopUnits, migrateShopping, ensureShopping, shopMark, mergeShopping, pruneShopping,
    mergeDb, cleanRotation, releaseOrphans, normalizePlan, pruneTombstones, buildRecipeExport,
    parseAmount, parseRecipeImport, parseTimers, fmtClock, nameSimilar, similarRecipes,
  };
})();
if (typeof module !== 'undefined') module.exports = EP;
