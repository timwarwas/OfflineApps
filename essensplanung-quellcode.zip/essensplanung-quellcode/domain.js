/* ==========================================================================
   Essensplanung – Kernlogik (rein, ohne DOM/Speicher)
   Umsetzung der Spezifikation „Rezept-Rotation“ Abschnitt 5
   ========================================================================== */
const EP = (function () {
  'use strict';

  /* ---------- Hilfen ---------- */
  let clock = () => Date.now();
  function setClock(fn) { clock = fn; }
  function uuid() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
    return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
  }
  function touch(o) {
    const t = clock();
    if (!o.createdAt) o.createdAt = t;
    o.updatedAt = Math.max(t, (o.updatedAt || 0) + 1);
    return o;
  }
  const live = arr => (arr || []).filter(x => !x.deleted);
  function tomb(o) { o.deleted = true; touch(o); }

  /* seedbarer Zufallsgenerator (mulberry32) */
  function seededRng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ---------- Datum (lokale Zeit, Woche ab Montag) ---------- */
  const pad = n => String(n).padStart(2, '0');
  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseISO(s) { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d, 12); }
  function addDays(s, n) { const d = parseISO(s); d.setDate(d.getDate() + n); return iso(d); }
  function todayISO() { return iso(new Date()); }
  function weekStart(s) { const d = parseISO(s); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return iso(d); }
  function weekDays(start) { return [0, 1, 2, 3, 4, 5, 6].map(i => addDays(start, i)); }
  function isoWeek(s) {
    const d = parseISO(s);
    const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    const day = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - day);
    const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
    return Math.ceil(((t - y0) / 86400000 + 1) / 7);
  }
  function fmtDate(s) { const [y, m, d] = s.split('-'); return d + '.' + m + '.' + y; }
  function fmtShort(s) { const [, m, d] = s.split('-'); return d + '.' + m + '.'; }
  const WD = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
  const WD_LONG = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
  function weekday(s) { return WD[parseISO(s).getDay()]; }
  function weekdayLong(s) { return WD_LONG[parseISO(s).getDay()]; }
  function fmtRange(from, to) {
    if (from.slice(0, 4) === to.slice(0, 4)) return fmtShort(from) + '–' + fmtDate(to);
    return fmtDate(from) + '–' + fmtDate(to);
  }

  /* ---------- 5.1 Tage pro Gericht ---------- */
  function daysFor(recipe, settings) {
    if (recipe.daysOverride) return recipe.daysOverride;
    const raw = recipe.servings / settings.portionsPerDay;
    const days = settings.roundingMode === 'FLOOR' ? Math.floor(raw) : Math.ceil(raw);
    return Math.max(1, days);
  }
  /* Hinweistext für ungerade Portionen */
  function daysHint(recipe, settings) {
    if (recipe.daysOverride) return '';
    const rest = recipe.servings % settings.portionsPerDay;
    if (!rest || recipe.servings < settings.portionsPerDay) return '';
    return settings.roundingMode === 'FLOOR'
      ? `${rest} ${rest === 1 ? 'Portion bleibt' : 'Portionen bleiben'} übrig`
      : `letzter Tag nur ${rest} ${rest === 1 ? 'Portion' : 'Portionen'}`;
  }

  /* ---------- 5.2 Rotation ---------- */
  /* Spuren: jede hat ihre eigene Rotation */
  const LANES = [
    { key: 'MAIN', label: 'Hauptgerichte', short: 'Hauptgericht' },
    { key: 'LUNCH', label: 'Mittagessen', short: 'Mittag' },
    { key: 'CAKE', label: 'Kuchen', short: 'Kuchen' },
  ];
  const laneOf = x => (x && (x.lane || x.kind)) || 'MAIN';
  const MONTHS = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
  function inSeason(recipe, month) {
    const m = recipe && recipe.seasonMonths;
    return !month || !m || !m.length || m.length >= 12 || m.includes(month);
  }
  function seasonLabel(recipe) {
    const m = (recipe.seasonMonths || []).slice().sort((a, b) => a - b);
    if (!m.length || m.length >= 12) return '';
    // zusammenhängende Bereiche, auch über den Jahreswechsel (z. B. Nov–Feb)
    const set = new Set(m), parts = [];
    let start = m.find(x => !set.has(x === 1 ? 12 : x - 1));
    if (start === undefined) return 'ganzjährig';
    const seen = new Set();
    for (const s0 of m.filter(x => !set.has(x === 1 ? 12 : x - 1))) {
      let e = s0; while (set.has(e === 12 ? 1 : e + 1) && !seen.has(e)) { seen.add(e); e = e === 12 ? 1 : e + 1; }
      parts.push(s0 === e ? MONTHS[s0 - 1] : MONTHS[s0 - 1] + '–' + MONTHS[e - 1]);
    }
    return parts.join(', ');
  }
  function monthOf(isoDate) { return +isoDate.slice(5, 7); }
  function activeRecipes(db, lane) {
    return live(db.recipes).filter(r => r.inRotation && !r.archivedAt && (!lane || laneOf(r) === lane));
  }
  function repairAdjacency(items, prevLastRecipeId) {
    let moves = 0;
    const maxMoves = items.length * items.length + 10;
    for (let i = 0; i < items.length && moves < maxMoves; i++) {
      const prev = i === 0 ? prevLastRecipeId : items[i - 1].recipeId;
      if (items[i].recipeId !== prev) continue;
      const j = items.findIndex((x, idx) => idx > i && x.recipeId !== prev);
      if (j !== -1) {
        const [moved] = items.splice(j, 1);
        items.splice(i, 0, moved);
        moves++;
        continue;
      }
      // Abweichung von der Referenz: Kein Tauschpartner mehr weiter hinten (z. B. beide
      // Vorkommen ganz am Ende). Dann den Eintrag an die nächstgelegene frühere Stelle setzen,
      // an der keiner seiner Nachbarn dasselbe Rezept ist. Sonst ist es unvermeidbar.
      const x = items[i].recipeId;
      let target = -1;
      for (let k = i - 1; k >= 0; k--) {
        const left = k === 0 ? prevLastRecipeId : items[k - 1].recipeId;
        if (left !== x && items[k].recipeId !== x) { target = k; break; }
      }
      if (target === -1) break;
      const [moved] = items.splice(i, 1);
      items.splice(target, 0, moved);
      moves++;
      i = target; // ab hier erneut prüfen
    }
  }
  function countAdjacent(items, prevLastRecipeId) {
    let a = 0;
    for (let i = 0; i < items.length; i++) {
      const prev = i === 0 ? prevLastRecipeId : items[i - 1].recipeId;
      if (items[i].recipeId === prev) a++;
    }
    return a;
  }
  /* Rückfallebene: ordnet so um, dass nie dasselbe Rezept folgt (sofern überhaupt möglich).
     Wählt jeweils das Rezept mit den meisten verbleibenden Vorkommen, das nicht dem vorigen
     entspricht; bei Gleichstand entscheidet die ursprüngliche (gemischte) Reihenfolge. */
  function greedyArrange(items, prevLastRecipeId) {
    const queues = new Map();
    items.forEach(it => { if (!queues.has(it.recipeId)) queues.set(it.recipeId, []); queues.get(it.recipeId).push(it); });
    const out = [];
    let prev = prevLastRecipeId;
    while (out.length < items.length) {
      let best = null;
      queues.forEach((q, id) => {
        if (!q.length || id === prev) return;
        if (!best || q.length > best.q.length || (q.length === best.q.length && q[0].key < best.q[0].key)) best = { id, q };
      });
      if (!best) queues.forEach((q, id) => { if (q.length && !best) best = { id, q }; }); // unvermeidbar
      out.push(best.q.shift());
      prev = best.id;
    }
    return out;
  }
  function buildCycle(recipes, settings, cycleNumber, prevLastRecipeId, rng, lane, month) {
    lane = lane || 'MAIN';
    const active = recipes.filter(r => r.inRotation && !r.archivedAt && !r.deleted && laneOf(r) === lane && inSeason(r, month))
      .sort((a, b) => a.sortOrder - b.sortOrder);
    const n = active.length;
    let items = active.flatMap((r, idx) =>
      Array.from({ length: r.weight }, (_, k) => {
        const u = settings.rotationMode === 'SHUFFLE' ? rng() : (idx + 0.5) / n;
        return { recipeId: r.id, occurrence: k + 1, key: (k + u) / r.weight };
      }));
    items.sort((a, b) => a.key - b.key);
    repairAdjacency(items, prevLastRecipeId);
    if (countAdjacent(items, prevLastRecipeId)) {
      const alt = greedyArrange([...items].sort((a, b) => a.key - b.key), prevLastRecipeId);
      if (countAdjacent(alt, prevLastRecipeId) < countAdjacent(items, prevLastRecipeId)) items = alt;
    }
    // Vorkommen in Reihenfolge des Auftretens nummerieren (1/2 vor 2/2)
    const seen = {};
    items.forEach(it => { seen[it.recipeId] = (seen[it.recipeId] || 0) + 1; it.occurrence = seen[it.recipeId]; });
    return items.map((it, i) => touch({
      id: uuid(), lane, cycleNumber, recipeId: it.recipeId, occurrence: it.occurrence,
      position: (i + 1) * 1000, status: 'PENDING', deleted: false,
    }));
  }
  const byCyclePos = (a, b) => a.cycleNumber - b.cycleNumber || a.position - b.position;
  const inLane = (lane) => e => laneOf(e) === (lane || 'MAIN');
  function cycleEntries(db, c, lane) { return live(db.rotation).filter(inLane(lane)).filter(e => e.cycleNumber === c).sort(byCyclePos); }
  function maxCycle(db, lane) { return live(db.rotation).filter(inLane(lane)).reduce((m, e) => Math.max(m, e.cycleNumber), 0); }
  function openCycles(db, lane) {
    return [...new Set(live(db.rotation).filter(inLane(lane)).filter(e => e.status === 'PENDING').map(e => e.cycleNumber))].sort((a, b) => a - b);
  }
  function pendingSorted(db, lane) { return live(db.rotation).filter(inLane(lane)).filter(e => e.status === 'PENDING').sort(byCyclePos); }
  function lastRecipeOfCycle(db, c, lane) {
    const es = cycleEntries(db, c, lane);
    return es.length ? es[es.length - 1].recipeId : null;
  }
  function appendCycle(db, rng, lane, month) {
    lane = lane || 'MAIN';
    const mc = maxCycle(db, lane);
    const cyc = buildCycle(live(db.recipes), db.settings, mc + 1, lastRecipeOfCycle(db, mc, lane), rng, lane, month);
    db.rotation.push(...cyc);
    return cyc;
  }
  /* next(n, exclude): die nächsten offenen Einträge einer Spur; erzeugt bei Bedarf Folgedurchläufe (R3, R7).
     Mit Monatsangabe werden Gerichte außerhalb ihrer Saison für diesen Durchlauf ausgelassen. */
  function nextEntries(db, n, exclude, rng, lane, month) {
    exclude = exclude || new Set();
    lane = lane || 'MAIN';
    const rec = month ? new Map(live(db.recipes).map(r => [r.id, r])) : null;
    for (let guard = 0; guard < 60; guard++) {
      let pend = pendingSorted(db, lane).filter(e => !exclude.has(e.id));
      if (month) {
        pend = pend.filter(e => {
          if (inSeason(rec.get(e.recipeId), month)) return true;
          e.status = 'SKIPPED'; e.skipReason = 'SEASON'; touch(e);
          return false;
        });
      }
      if (pend.length >= n) return pend.slice(0, n);
      if (!appendCycle(db, rng, lane, month).length) return pend;
    }
    return pendingSorted(db, lane).filter(e => !exclude.has(e.id)).slice(0, n);
  }
  function setStatus(entry, status) { entry.status = status; touch(entry); }
  function planEntry(entry) { setStatus(entry, 'PLANNED'); }
  function completeEntry(entry) { setStatus(entry, 'DONE'); }
  function skipEntry(entry) { setStatus(entry, 'SKIPPED'); }
  function postpone(db, entry) {
    const es = cycleEntries(db, entry.cycleNumber, laneOf(entry));
    entry.position = es.reduce((m, e) => Math.max(m, e.position), 0) + 1000;
    touch(entry);
  }
  function release(db, entry) {
    const es = cycleEntries(db, entry.cycleNumber, laneOf(entry));
    entry.position = es.reduce((m, e) => Math.min(m, e.position), Infinity) - 1000;
    entry.status = 'PENDING';
    touch(entry);
  }
  /* manualPick: erster offener Eintrag des Rezepts – oder null (dann MANUAL) */
  function manualPickEntry(db, recipeId, exclude) {
    exclude = exclude || new Set();
    return live(db.rotation).filter(e => e.status === 'PENDING' && e.recipeId === recipeId && !exclude.has(e.id)).sort(byCyclePos)[0] || null;
  }
  function resetRotation(db, rng, lane, month) {
    pendingSorted(db, lane).forEach(tomb);
    return appendCycle(db, rng, lane, month);
  }
  /* Rezept in laufende Durchläufe einarbeiten (neu, reaktiviert, pausiert, Gewicht oder Spur geändert) */
  function syncRecipeIntoCycles(db, recipe, rng) {
    const lane = laneOf(recipe);
    // offene Einträge in einer anderen Spur (Art des Gerichts geändert) entfernen
    live(db.rotation).filter(e => e.recipeId === recipe.id && e.status === 'PENDING' && laneOf(e) !== lane).forEach(tomb);
    const active = recipe.inRotation && !recipe.archivedAt && !recipe.deleted;
    openCycles(db, lane).forEach(c => {
      const mine = cycleEntries(db, c, lane).filter(e => e.recipeId === recipe.id);
      if (!active) { mine.filter(e => e.status === 'PENDING').forEach(tomb); return; }
      const diff = recipe.weight - mine.length;
      if (diff > 0) insertIntoCycle(db, c, recipe, diff, rng, lane);
      if (diff < 0) {
        mine.filter(e => e.status === 'PENDING').sort((a, b) => b.position - a.position)
          .slice(0, -diff).forEach(tomb);
      }
    });
  }
  function insertIntoCycle(db, c, recipe, count, rng, lane) {
    const es = cycleEntries(db, c, lane);
    let occ = es.filter(e => e.recipeId === recipe.id).reduce((m, e) => Math.max(m, e.occurrence), 0);
    const prevCycleLast = lastRecipeOfCycle(db, c - 1, lane);
    const nextCycleFirst = (cycleEntries(db, c + 1, lane)[0] || {}).recipeId || null;
    for (let k = 0; k < count; k++) {
      const firstOpen = es.findIndex(e => e.status === 'PENDING');
      const from = firstOpen === -1 ? es.length : firstOpen;
      const slots = [];
      for (let i = from; i <= es.length; i++) slots.push(i);
      const ok = slots.filter(i => {
        const prev = i === 0 ? prevCycleLast : es[i - 1].recipeId;
        const next = i === es.length ? nextCycleFirst : es[i].recipeId;
        return prev !== recipe.id && next !== recipe.id;
      });
      const pool = ok.length ? ok : slots;
      const at = pool[Math.floor(rng() * pool.length)];
      const entry = touch({ id: uuid(), lane, cycleNumber: c, recipeId: recipe.id, occurrence: ++occ,
        position: 0, status: 'PENDING', deleted: false });
      es.splice(at, 0, entry);
      db.rotation.push(entry);
    }
    es.forEach((e, i) => { const p = (i + 1) * 1000; if (e.position !== p) { e.position = p; touch(e); } });
  }
  /* Fortschritt des laufenden Durchlaufs für den Vorschlag */
  function cycleProgress(db, lane) {
    const oc = openCycles(db, lane);
    if (!oc.length) return null;
    const c = oc[0];
    const es = cycleEntries(db, c, lane);
    const used = es.filter(e => e.status !== 'PENDING').length;
    return { cycle: c, current: Math.min(es.length, used + 1), total: es.length };
  }

  /* ---------- 5.4 Wochenplan ---------- */
  function nextFreeDates(start, n, occupied) {
    const res = [];
    let d = start;
    for (let guard = 0; res.length < n && guard < 400; guard++) {
      if (!occupied.has(d)) res.push(d);
      d = addDays(d, 1);
    }
    return res;
  }
  /* Legt eine Folge von Gerichten auf freie Tage. Leere Folge = „Woche automatisch füllen“.
     seq-Einträge: { kind:'ROT', entryId, recipeId } oder { kind:'MAN', recipeId } */
  function layoutDraft({ days, occupied, sequence, nextFn, recipeOf, settings, today }) {
    const occ = new Set(occupied);
    const used = new Set(sequence.filter(s => s.kind === 'ROT').map(s => s.entryId));
    const drafts = [], placed = [];
    let si = 0;
    const firstFree = () => days.find(d => !occ.has(d) && d >= today);
    for (let start = firstFree(), guard = 0; start && guard < 60; start = firstFree(), guard++) {
      let item;
      if (si < sequence.length) item = sequence[si++];
      else {
        const e = nextFn(used, start);
        if (!e) break;
        used.add(e.id);
        item = { kind: 'ROT', entryId: e.id, recipeId: e.recipeId };
      }
      const recipe = recipeOf(item.recipeId);
      if (!recipe) continue;
      const n = daysFor(recipe, settings);
      const dates = nextFreeDates(start, n, occ);
      item.blockId = item.blockId || uuid();
      dates.forEach((date, i) => {
        occ.add(date);
        drafts.push({
          date, lane: 'MAIN', type: i === 0 ? 'COOK' : 'LEFTOVER', recipeId: recipe.id, blockId: item.blockId,
          dayIndex: i + 1, dayCount: n, rotationEntryId: item.kind === 'ROT' ? item.entryId : null,
          source: item.kind === 'ROT' ? 'ROTATION' : 'MANUAL', locked: !!item.locked, status: 'PLANNED', note: '',
        });
      });
      placed.push(item);
    }
    return { drafts, sequence: placed };
  }
  function fillWeek(opts) { return layoutDraft(Object.assign({ sequence: [] }, opts)).drafts; }

  /* ---------- Einheiten ---------- */
  const UNITS = {
    G: { s: 'g', dim: 'MASS', f: 1 }, KG: { s: 'kg', dim: 'MASS', f: 1000 },
    ML: { s: 'ml', dim: 'VOLUME', f: 1 }, L: { s: 'l', dim: 'VOLUME', f: 1000 },
    STUECK: { s: 'Stück', p: 'Stück' }, EL: { s: 'EL', p: 'EL' }, TL: { s: 'TL', p: 'TL' },
    PRISE: { s: 'Prise', p: 'Prisen' }, BUND: { s: 'Bund', p: 'Bund' },
    ZEHE: { s: 'Zehe', p: 'Zehen' }, DOSE: { s: 'Dose', p: 'Dosen' },
    GLAS: { s: 'Glas', p: 'Gläser' }, PACKUNG: { s: 'Packung', p: 'Packungen' },
    SCHEIBE: { s: 'Scheibe', p: 'Scheiben' },
  };
  const UNIT_ORDER = ['G', 'KG', 'ML', 'L', 'STUECK', 'EL', 'TL', 'PRISE', 'BUND', 'ZEHE', 'DOSE', 'GLAS', 'PACKUNG', 'SCHEIBE'];
  function dimOf(unit) { if (!unit) return 'NONE'; return UNITS[unit].dim || unit; }
  function fmtNum(x) {
    const r = Math.round(x * 100) / 100;
    return String(r).replace('.', ',');
  }
  function fmtDim(dim, total) {
    if (total == null) return '';
    if (dim === 'MASS') return total >= 1000 ? fmtNum(total / 1000) + ' kg' : fmtNum(total) + ' g';
    if (dim === 'VOLUME') return total >= 1000 ? fmtNum(total / 1000) + ' l' : fmtNum(total) + ' ml';
    const u = UNITS[dim];
    return fmtNum(total) + ' ' + (Math.abs(total - 1) < 1e-9 ? u.s : u.p);
  }
  /* Summiert Mengen (quantity/unit) zu einem Anzeigetext, Dimensionen in Reihenfolge des ersten Auftretens */
  function sumAmounts(items) {
    const order = [], tot = {};
    items.forEach(({ quantity, unit }) => {
      const dim = quantity == null ? 'NONE' : dimOf(unit);
      if (!(dim in tot)) { order.push(dim); tot[dim] = dim === 'NONE' ? null : 0; }
      if (dim !== 'NONE') tot[dim] += quantity * ((UNITS[unit] && UNITS[unit].f) || 1);
    });
    const dims = order.filter(d => d !== 'NONE');
    return { dims: order, text: dims.map(d => fmtDim(d, tot[d])).join(' + ') };
  }

  /* ---------- 5.5 Einkaufsliste ---------- */
  const CATEGORIES = [
    ['GEMUESE', 'Gemüse', 'MARKT'], ['OBST', 'Obst', 'MARKT'], ['KRAEUTER', 'Frische Kräuter', 'MARKT'],
    ['EIER', 'Eier', 'MARKT'], ['BACKWAREN', 'Brot & Backwaren', 'SUPERMARKT'],
    ['FLEISCH', 'Fleisch & Wurst', 'SUPERMARKT'], ['FISCH', 'Fisch', 'SUPERMARKT'],
    ['MILCHPRODUKTE', 'Milchprodukte', 'SUPERMARKT'], ['KAESE', 'Käse', 'SUPERMARKT'],
    ['TROCKENWAREN', 'Nudeln, Reis & Hülsenfrüchte', 'SUPERMARKT'],
    ['KONSERVEN', 'Konserven & Gläser', 'SUPERMARKT'], ['TIEFKUEHL', 'Tiefkühl', 'SUPERMARKT'],
    ['SONSTIGES', 'Sonstiges', 'SUPERMARKT'], ['GEWUERZE', 'Gewürze', 'VORRAT'], ['OELE_ESSIG', 'Öl & Essig', 'VORRAT'],
  ].map(([key, label, source]) => ({ key, label, source }));
  const CAT = Object.fromEntries(CATEGORIES.map(c => [c.key, c]));
  function categorySource(cat, settings) {
    const o = settings && settings.categorySources;
    return (o && o[cat]) || (CAT[cat] || CAT.SONSTIGES).source;
  }
  function sourceOf(ing, settings) { return ing.shoppingSource || categorySource(ing.category, settings); }
  /* Kategorie aus dem Zutatennamen erraten (längster Treffer gewinnt) */
  const GUESS = {
    GEMUESE: 'tomate tomaten gurke zwiebel knoblauch karotte möhre paprika zucchini aubergine kartoffel spinat blattspinat salat kopfsalat rucola feldsalat kohl weißkohl rotkohl wirsing grünkohl brokkoli blumenkohl lauch porree sellerie staudensellerie kürbis pilz pilze champignon spargel radieschen rettich rote bete fenchel mangold frühlingszwiebel schalotte ingwer chili peperoni mais kolben erbsenschoten zuckerschoten grüne bohnen avocado okra pastinake kohlrabi rosenkohl süßkartoffel',
    OBST: 'apfel äpfel birne banane zitrone limette orange mandarine clementine beere beeren erdbeere erdbeeren himbeere himbeeren heidelbeere heidelbeeren blaubeere johannisbeere kirsche kirschen pflaume pflaumen zwetschge zwetschgen rhabarber traube trauben mango ananas aprikose pfirsich nektarine melone kiwi granatapfel feige',
    KRAEUTER: 'basilikum petersilie koriander schnittlauch dill minze rosmarin thymian salbei estragon kerbel liebstöckel frische kräuter',
    EIER: 'ei eier eigelb eiweiß',
    BACKWAREN: 'brot brötchen toast toastbrot vollkornbrot tortilla tortillas weizentortillas wrap baguette fladenbrot pita ciabatta knäckebrot semmel',
    FLEISCH: 'hackfleisch hack rinderhack rind rindfleisch schwein schweinefleisch hähnchen hähnchenbrust huhn pute putenbrust speck schinken wurst würstchen salami lamm bacon chorizo fleisch geschnetzeltes gulasch leberkäse',
    FISCH: 'lachs thunfisch fisch garnele garnelen kabeljau forelle seelachs scampi krabben',
    MILCHPRODUKTE: 'milch sahne schlagsahne joghurt quark magerquark butter schmand crème fraîche creme fraiche saure sahne buttermilch kefir',
    KAESE: 'käse parmesan mozzarella feta gouda emmentaler ricotta halloumi frischkäse bergkäse reibekäse mascarpone pecorino',
    TROCKENWAREN: 'nudel nudeln suppennudeln spaghetti pasta penne fusilli lasagneplatten reis basmatireis risottoreis linsen rote linsen mehl weizenmehl zucker puderzucker vanillezucker haferflocken couscous bulgur quinoa grieß backpulver speisestärke stärke polenta nüsse mandeln haselnüsse walnüsse kakao schokolade trockenhefe hefe paniermehl semmelbrösel',
    KONSERVEN: 'gehackte tomaten passierte tomaten tomatenmark kokosmilch kidneybohnen bohnen kichererbsen dosenmais oliven pesto senf ketchup marmelade honig kapern essiggurken thunfisch dose',
    TIEFKUEHL: 'tk tiefkühl erbsen tiefkühlerbsen blätterteig',
    GEWUERZE: 'salz pfeffer paprikapulver currypulver curry kurkuma zimt muskat muskatnuss kreuzkümmel kümmel oregano getrocknet lorbeer lorbeerblatt nelke nelken vanille chiliflocken chilipulver knoblauchpulver gemüsebrühe brühe gewürz gewürze sojasauce sojasoße',
    OELE_ESSIG: 'öl olivenöl rapsöl sonnenblumenöl sesamöl essig balsamico weißweinessig apfelessig',
  };
  const GUESS_LIST = Object.entries(GUESS).flatMap(([cat, words]) => {
    // Mehrwort-Begriffe stehen hintereinander: bekannte Paare zusammenfassen
    const w = words.split(' '), out = [];
    for (let i = 0; i < w.length; i++) {
      const pair = w[i] + ' ' + w[i + 1];
      if (['rote bete', 'grüne bohnen', 'gehackte tomaten', 'passierte tomaten', 'crème fraîche', 'creme fraiche', 'saure sahne', 'rote linsen', 'frische kräuter', 'oregano getrocknet'].includes(pair)) { out.push([cat, pair]); i++; }
      else out.push([cat, w[i]]);
    }
    return out;
  });
  function guessCategory(name) {
    const n = ' ' + String(name || '').toLowerCase().trim().replace(/\s+/g, ' ') + ' ';
    let best = null;
    GUESS_LIST.forEach(([cat, word]) => {
      const short = word.length <= 3; // kurze Wörter (ei, tk, öl) nur als ganzes Wort oder Wortende
      const hit = short ? new RegExp('[\\s-]' + word + '(\\s|$)').test(n) || (word === 'öl' && /öl\s$/.test(n)) : n.includes(word);
      if (hit && (!best || word.length > best[1].length)) best = [cat, word];
    });
    return best ? best[0] : 'SONSTIGES';
  }
  const cmpDe = (a, b) => a.localeCompare(b, 'de');

  function buildShoppingList(db, from, to) {
    const recipes = new Map(live(db.recipes).map(r => [r.id, r]));
    const ings = new Map(live(db.ingredients).map(i => [i.id, i]));
    const laneRank = { MAIN: 0, LUNCH: 1, CAKE: 2 };
    const cooks = live(db.plan).filter(p => p.type === 'COOK' && p.date >= from && p.date <= to)
      .sort((a, b) => a.date.localeCompare(b.date) || laneRank[laneOf(a)] - laneRank[laneOf(b)]);
    const names = [], warnings = [], per = new Map();
    cooks.forEach(p => {
      const r = recipes.get(p.recipeId);
      if (!r) return;
      if (!names.includes(r.name)) names.push(r.name);
      const list = (r.ingredients || []).filter(x => ings.has(x.ingredientId));
      if (!list.length) {
        const w = `Für „${r.name}“ sind keine Zutaten hinterlegt.`;
        if (!warnings.includes(w)) warnings.push(w);
      }
      list.forEach(x => {
        if (!per.has(x.ingredientId)) per.set(x.ingredientId, []);
        per.get(x.ingredientId).push({ quantity: x.quantity, unit: x.unit });
      });
    });
    const st = db.shopping && db.shopping.from === from && db.shopping.to === to ? db.shopping : { checkedKeys: [], extraItems: [] };
    const checked = new Set(st.checkedKeys || []);
    const rows = [...per.entries()].map(([id, items]) => {
      const ing = ings.get(id);
      const sum = sumAmounts(items);
      const key = id + '|' + sum.dims.join('+');
      return { key, name: ing.name, amount: sum.text, category: ing.category, source: sourceOf(ing, db.settings), checked: checked.has(key) };
    });
    const market = rows.filter(r => r.source === 'MARKT').sort((a, b) => cmpDe(a.name, b.name));
    const supermarket = CATEGORIES.map(c => ({
      category: c.key, label: c.label,
      items: rows.filter(r => r.source === 'SUPERMARKT' && r.category === c.key).sort((a, b) => cmpDe(a.name, b.name)),
    })).filter(g => g.items.length);
    // Supermarkt-Zutaten mit Kategorie, die standardmäßig woanders liegt (z. B. Gemüse auf Supermarkt umgestellt)
    const misc = rows.filter(r => r.source === 'SUPERMARKT' && !CATEGORIES.some(c => c.key === r.category));
    if (misc.length) supermarket.push({ category: 'SONSTIGES', label: 'Sonstiges', items: misc.sort((a, b) => cmpDe(a.name, b.name)) });
    const pantry = rows.filter(r => r.source === 'VORRAT').sort((a, b) => cmpDe(a.name, b.name))
      .map(r => ({ key: r.key, name: r.name, checked: r.checked }));
    return { from, to, recipes: names, market, supermarket, pantry, extraItems: st.extraItems || [], warnings };
  }
  function shoppingText(list, settings) {
    const kwA = isoWeek(list.from), kwB = isoWeek(list.to);
    const kw = kwA === kwB ? 'KW ' + kwA : 'KW ' + kwA + '–' + kwB;
    const L = [];
    L.push(`Einkaufsliste ${fmtRange(list.from, list.to)} (${kw})`);
    L.push('Gerichte: ' + (list.recipes.length ? list.recipes.join(', ') : '–'));
    if (list.market.length) {
      L.push('', 'MARKT');
      list.market.forEach(r => L.push('- ' + r.name + (settings.marketListShowQuantities && r.amount ? ` (${r.amount})` : '')));
    }
    const groups = list.supermarket.map(g => ({ label: g.label, lines: g.items.map(r => '- ' + r.name + (r.amount ? ': ' + r.amount : '')) }));
    const extras = (list.extraItems || []).filter(x => x.text && x.text.trim());
    if (extras.length) {
      let g = groups.find(x => x.label === 'Sonstiges');
      if (!g) { g = { label: 'Sonstiges', lines: [] }; groups.push(g); }
      extras.forEach(x => g.lines.push('- ' + x.text.trim()));
    }
    if (groups.length) {
      L.push('', 'SUPERMARKT');
      groups.forEach(g => { L.push(g.label); g.lines.forEach(l => L.push(l)); });
    }
    if (list.pantry.length) {
      L.push('', 'VORRAT PRÜFEN');
      L.push(list.pantry.map(p => p.name).join(', '));
    }
    if (list.warnings.length) {
      L.push('', 'HINWEISE');
      list.warnings.forEach(w => L.push('- ' + w));
    }
    return L.join('\n');
  }

  /* ---------- Zusammenführen zweier Datenstände (Geräteabgleich) ---------- */
  function mergeById(a, b) {
    const m = new Map();
    (a || []).forEach(x => m.set(x.id, x));
    (b || []).forEach(y => {
      const x = m.get(y.id);
      if (!x || (y.updatedAt || 0) > (x.updatedAt || 0)) m.set(y.id, y);
    });
    return [...m.values()];
  }
  const newer = (a, b) => (!a ? b : !b ? a : ((b.updatedAt || 0) > (a.updatedAt || 0) ? b : a));
  function mergeDb(local, remote) {
    if (!remote) return local;
    if (!local) return remote;
    return {
      version: Math.max(local.version || 1, remote.version || 1),
      household: newer(local.household, remote.household),
      settings: newer(local.settings, remote.settings),
      shopping: newer(local.shopping, remote.shopping),
      recipes: mergeById(local.recipes, remote.recipes),
      ingredients: mergeById(local.ingredients, remote.ingredients),
      rotation: mergeById(local.rotation, remote.rotation),
      plan: mergeById(local.plan, remote.plan),
    };
  }
  /* Nach dem Zusammenführen: pro Datum höchstens ein Planeintrag (neuerer gewinnt) */
  function normalizePlan(db) {
    const byDate = new Map();
    live(db.plan).forEach(p => {
      const k = p.date + '|' + laneOf(p);
      const o = byDate.get(k);
      if (!o) { byDate.set(k, p); return; }
      const [keep, drop] = (p.updatedAt || 0) > (o.updatedAt || 0) ? [p, o] : [o, p];
      byDate.set(k, keep);
      tomb(drop);
    });
  }
  function pruneTombstones(db, maxAgeMs) {
    const lim = clock() - maxAgeMs;
    ['recipes', 'ingredients', 'rotation', 'plan'].forEach(k => {
      db[k] = (db[k] || []).filter(x => !x.deleted || (x.updatedAt || 0) > lim);
    });
  }
  /* ---------- Rezept-Import (Format „essensplanung-import“ v1) ----------
     Nimmt den Text aus dem Scanner-Chat entgegen (auch mit ```json-Zaun oder Begleittext)
     und liefert normalisierte Rezepte mit Hinweisen. Keine Speicherzugriffe. */
  const KIND_ALIAS = { HAUPT: 'MAIN', HAUPTGERICHT: 'MAIN', MAIN: 'MAIN', ABEND: 'MAIN', ABENDESSEN: 'MAIN',
    MITTAG: 'LUNCH', MITTAGESSEN: 'LUNCH', LUNCH: 'LUNCH', KUCHEN: 'CAKE', CAKE: 'CAKE', GEBAECK: 'CAKE', BACKEN: 'CAKE' };
  const UNIT_ALIAS = {
    g: 'G', gr: 'G', gramm: 'G', kg: 'KG', kilo: 'KG', kilogramm: 'KG', ml: 'ML', milliliter: 'ML', l: 'L', liter: 'L',
    stueck: 'STUECK', stück: 'STUECK', stk: 'STUECK', st: 'STUECK', el: 'EL', essloeffel: 'EL', esslöffel: 'EL',
    tl: 'TL', teeloeffel: 'TL', teelöffel: 'TL', prise: 'PRISE', prisen: 'PRISE', bund: 'BUND', zehe: 'ZEHE', zehen: 'ZEHE',
    dose: 'DOSE', dosen: 'DOSE', glas: 'GLAS', glaeser: 'GLAS', gläser: 'GLAS', packung: 'PACKUNG', packungen: 'PACKUNG',
    pck: 'PACKUNG', pkg: 'PACKUNG', paeckchen: 'PACKUNG', päckchen: 'PACKUNG', scheibe: 'SCHEIBE', scheiben: 'SCHEIBE',
  };
  const UNIT_CONVERT = { cl: ['ML', 10], dl: ['ML', 100], tasse: ['ML', 250, 1], tassen: ['ML', 250, 1] };
  const FRACTIONS = { '½': 0.5, '¼': 0.25, '¾': 0.75, '⅓': 1 / 3, '⅔': 2 / 3, '⅛': 0.125 };
  function parseAmount(v) {
    if (v == null || v === '') return null;
    if (typeof v === 'number') return isFinite(v) && v > 0 ? v : null;
    let t = String(v).trim().replace(',', '.');
    let add = 0;
    for (const [f, x] of Object.entries(FRACTIONS)) if (t.includes(f)) { add += x; t = t.replace(f, ' '); }
    t = t.trim();
    const range = t.match(/^(\d+(?:\.\d+)?)\s*[-–]\s*(\d+(?:\.\d+)?)$/); // 2–3 → 3
    if (range) return +range[2] + add;
    const mixed = t.match(/^(\d+)\s+(\d+)\/(\d+)$/);
    if (mixed) return +mixed[1] + mixed[2] / mixed[3] + add;
    const frac = t.match(/^(\d+)\/(\d+)$/);
    if (frac) return +frac[1] / +frac[2] + add;
    const n = t === '' ? 0 : parseFloat(t);
    const r = (isFinite(n) ? n : 0) + add;
    return r > 0 ? Math.round(r * 1000) / 1000 : null;
  }
  function extractJson(text) {
    const s = String(text || '').trim();
    const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
    const body = fence ? fence[1] : s;
    const a = body.search(/[{[]/);
    if (a < 0) throw new Error('Im Text wurde kein Rezept-Block gefunden.');
    const close = body[a] === '{' ? '}' : ']';
    const b = body.lastIndexOf(close);
    const raw = body.slice(a, b + 1);
    try { return JSON.parse(raw); } catch (e) { /* Reparaturversuche unten */ }
    const noComma = raw.replace(/,\s*([}\]])/g, '$1'); // überzählige Kommas
    try { return JSON.parse(noComma); } catch (e) { /* weiter */ }
    // von iOS-Autokorrektur ersetzte Anführungszeichen – nur die, die JSON-Syntax sein müssen
    const fixed = noComma.replace(/[“”„](?=\s*[:,}\]])|(?<=[{\[,:]\s*)[“”„]/g, '"');
    try { return JSON.parse(fixed); }
    catch (e) { throw new Error('Der Rezept-Block ist unvollständig oder beschädigt. Bitte die Antwort komplett kopieren.'); }
  }
  const str = v => (v == null ? '' : String(v)).trim();
  function normalizeImportRecipe(x, idx) {
    const warn = [];
    const name = str(x.name || x.titel || x.title).replace(/\s+/g, ' ').slice(0, 120);
    const kindKey = str(x.art || x.kind).toUpperCase().replace(/Ä/g, 'AE').replace(/Ü/g, 'UE').replace(/Ö/g, 'OE');
    const kind = KIND_ALIAS[kindKey] || 'MAIN';
    if (kindKey && !KIND_ALIAS[kindKey]) warn.push(`Unbekannte Art „${str(x.art || x.kind)}“, als Hauptgericht übernommen.`);
    let servings = Math.round(parseAmount(x.portionen != null ? x.portionen : x.servings) || 0);
    if (kind === 'CAKE' && servings < 2) servings = 12;
    if (servings < 1) { servings = 4; warn.push('Keine Portionen angegeben, 4 angenommen.'); }
    servings = Math.min(99, servings);
    const time = Math.round(parseAmount(x.zubereitungszeitMin != null ? x.zubereitungszeitMin : x.prepTimeMinutes) || 0) || null;
    const tags = [...new Set((Array.isArray(x.tags) ? x.tags : str(x.tags).split(',')).map(str).filter(Boolean))].slice(0, 12);
    let months = (Array.isArray(x.saison) ? x.saison : []).map(Number).filter(m => m >= 1 && m <= 12);
    months = [...new Set(months)].sort((a, b) => a - b);
    const seasonMonths = months.length && months.length < 12 ? months : null;
    const ingredients = [];
    (Array.isArray(x.zutaten) ? x.zutaten : Array.isArray(x.ingredients) ? x.ingredients : []).forEach(z => {
      if (typeof z === 'string') z = { name: z };
      const iname = str(z.name || z.zutat || z.ingredient).replace(/\s+/g, ' ').slice(0, 80);
      if (!iname) return;
      let quantity = parseAmount(z.menge != null ? z.menge : z.quantity);
      let note = str(z.notiz || z.note);
      const rawUnit = str(z.einheit != null ? z.einheit : z.unit);
      const uKey = rawUnit.toLowerCase().replace(/\.$/, '');
      let unit = null;
      if (quantity != null) {
        if (UNITS[rawUnit.toUpperCase()]) unit = rawUnit.toUpperCase();
        else if (UNIT_ALIAS[uKey]) unit = UNIT_ALIAS[uKey];
        else if (UNIT_CONVERT[uKey]) {
          const [u, f, keep] = UNIT_CONVERT[uKey];
          if (keep) note = [note, 'Original: ' + fmtNum(quantity) + ' ' + rawUnit].filter(Boolean).join(', ');
          unit = u; quantity = Math.round(quantity * f * 100) / 100;
        }
        else if (!rawUnit) unit = 'STUECK';
        else {
          unit = 'STUECK';
          note = [note, 'Original: ' + fmtNum(quantity) + ' ' + rawUnit].filter(Boolean).join(', ');
          warn.push(`${iname}: Einheit „${rawUnit}“ unbekannt, als Stück übernommen.`);
        }
      }
      const catRaw = str(z.kategorie || z.category).toUpperCase();
      const category = CAT[catRaw] ? catRaw : guessCategory(iname);
      ingredients.push({ name: iname, quantity, unit, note: note.slice(0, 120), category });
    });
    let steps = x.anleitung != null ? x.anleitung : x.instructions;
    let instructions = '';
    if (Array.isArray(steps)) {
      instructions = steps.map(str).filter(Boolean).map((t, i) => `${i + 1}. ${t.replace(/^\d+[.)]\s*/, '')}`).join('\n');
    } else instructions = str(steps);
    const notes = [str(x.notizen || x.notes), str(x.quelle || x.source) ? 'Quelle: ' + str(x.quelle || x.source) : ''].filter(Boolean).join('\n');
    (Array.isArray(x.hinweise) ? x.hinweise : x.hinweise ? [x.hinweise] : []).map(str).filter(Boolean).forEach(h => warn.push(h));
    if (!ingredients.length) warn.push('Keine Zutaten erkannt.');
    if (!instructions) warn.push('Keine Anleitung erkannt.');
    return { name: name || `Rezept ${idx + 1}`, noName: !name, kind, servings, prepTimeMinutes: time, tags, seasonMonths,
      ingredients, instructions, notes, warnings: warn };
  }
  function parseRecipeImport(text) {
    const j = typeof text === 'string' ? extractJson(text) : text;
    const list = Array.isArray(j) ? j : Array.isArray(j.rezepte) ? j.rezepte : Array.isArray(j.recipes) ? j.recipes : (j && (j.name || j.titel)) ? [j] : null;
    if (!list) throw new Error(j && j.format === 'essensplanung' ? 'Das ist eine Sicherung. Bitte unter Einstellungen → „Sicherung einlesen“ öffnen.' : 'Im Block wurden keine Rezepte gefunden.');
    const recipes = list.filter(x => x && typeof x === 'object').map(normalizeImportRecipe);
    if (!recipes.length) throw new Error('Im Block wurden keine Rezepte gefunden.');
    recipes.forEach(r => { if (r.noName) r.warnings.unshift('Kein Name erkannt – bitte nach dem Import umbenennen.'); });
    return recipes;
  }


  return {
    setClock, uuid, touch, live, tomb, seededRng,
    iso, parseISO, addDays, todayISO, weekStart, weekDays, isoWeek, fmtDate, fmtShort, fmtRange, weekday, weekdayLong,
    daysFor, daysHint, LANES, laneOf, MONTHS, inSeason, seasonLabel, monthOf,
    activeRecipes, repairAdjacency, buildCycle, cycleEntries, maxCycle, openCycles, pendingSorted,
    lastRecipeOfCycle, appendCycle, nextEntries, planEntry, completeEntry, skipEntry, postpone, release,
    manualPickEntry, resetRotation, syncRecipeIntoCycles, cycleProgress,
    nextFreeDates, layoutDraft, fillWeek,
    UNITS, UNIT_ORDER, dimOf, fmtNum, sumAmounts,
    CATEGORIES, CAT, categorySource, sourceOf, guessCategory, buildShoppingList, shoppingText,
    mergeDb, normalizePlan, pruneTombstones,
    parseAmount, parseRecipeImport,
  };
})();
if (typeof module !== 'undefined') module.exports = EP;
