/* Minimale Leaflet-Attrappe für Tests: bildet die benutzte API nach und zeichnet Marker als DOM-Elemente */
(function () {
  const log = window.__L = { tiles: [], views: [], fits: 0 };
  function Layer() {}
  Layer.prototype.addTo = function (map) { map._layers.push(this); this._map = map; if (this._add) this._add(map); return this; };
  function map(id) {
    const el = typeof id === 'string' ? document.getElementById(id) : id;
    const m = { _layers: [], _zoom: 5, _el: el,
      setView(ll, z) { log.views.push([ll, z]); this._zoom = z; return this; },
      fitBounds(b) { log.fits++; return this; },
      getZoom() { return this._zoom; }, setMaxZoom() { return this; }, invalidateSize() { return this; },
      removeLayer(l) { this._layers = this._layers.filter(x => x !== l); if (l._el) l._el.remove(); return this; },
      remove() { el.innerHTML = ''; } };
    return m;
  }
  function tileLayer(url, o) { const l = new Layer(); l.url = url; l.opts = o; l._add = () => log.tiles.push(url); return l; }
  function marker(ll, o) {
    const l = new Layer(); l.ll = ll; l.icon = o.icon; l.handlers = {};
    l._add = m => { l._el = document.createElement('div'); l._el.className = 'stub-marker ' + (l.icon.options.className || ''); l._el.innerHTML = l.icon.options.html || ''; l._el.onclick = () => l.handlers.click && l.handlers.click(); m._el.appendChild(l._el); l._draw(); };
    l._draw = () => { if (l._el) { l._el.dataset.ll = l.ll.join(','); l._el.dataset.tip = l.tip || ''; l._el.className = 'stub-marker ' + (l.icon.options.className || ''); l._el.innerHTML = l.icon.options.html || ''; } };
    l.bindTooltip = t => { l.tip = t; l._draw(); return l; };
    l.setTooltipContent = t => { l.tip = t; l._draw(); return l; };
    l.setLatLng = x => { l.ll = x; l._draw(); return l; };
    l.setIcon = i => { l.icon = i; l._draw(); return l; };
    l.on = (e, f) => { l.handlers[e] = f; return l; };
    return l;
  }
  function vec() { const l = new Layer(); l.setLatLng = x => l; l.setRadius = r => l; l.setLatLngs = p => { l.pts = p; return l; }; return l; }
  window.L = { map, tileLayer, marker, circle: vec, polyline: vec, divIcon: o => ({ options: o }) };
})();
