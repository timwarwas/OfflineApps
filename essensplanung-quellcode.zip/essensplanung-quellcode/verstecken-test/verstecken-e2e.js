/* Browsertest Verstecken: zwei Geräte (iPhone hell, Android dunkel), nachgebaute PocketBase + Push-Dienst */
'use strict';
const { chromium, devices } = require('playwright');
const PORT = 8765, O = 'http://127.0.0.1:' + PORT;
require('./server.js');
let pass = 0, fail = 0;
const ok = (c, msg) => { if (c) { pass++; console.log('  ✓', msg); } else { fail++; console.log('  ✗', msg); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const getLog = () => fetch(O + '/__log').then(r => r.json());
async function until(fn, ms = 12000, step = 250) { const end = Date.now() + ms; while (Date.now() < end) { try { const v = await fn(); if (v) return v; } catch (e) {} await sleep(step); } return null; }

const INIT = origin => {
  localStorage.setItem('verstecken-server', origin);
  localStorage.setItem('push-server', origin + '/push');
  localStorage.setItem('verstecken-leaflet', origin + '/leaflet/');
  const fake = { endpoint: 'https://push.example/' + (localStorage.getItem('__ep') || (localStorage.setItem('__ep', Math.random().toString(36).slice(2)), localStorage.getItem('__ep'))),
    toJSON() { return { endpoint: this.endpoint, keys: { p256dh: 'BPk', auth: 'au' } }; }, unsubscribe: async () => { localStorage.removeItem('__sub'); return true; } };
  if (window.Notification) {
    Object.defineProperty(Notification, 'permission', { configurable: true, get: () => localStorage.getItem('__perm') || 'default' });
    Notification.requestPermission = async () => { localStorage.setItem('__perm', 'granted'); return 'granted'; };
  }
  if (window.PushManager) {
    PushManager.prototype.getSubscription = async function () { return localStorage.getItem('__sub') ? fake : null; };
    PushManager.prototype.subscribe = async function () { localStorage.setItem('__sub', '1'); return fake; };
  }
};
async function mkDevice(browser, opts, geo, errs, tag) {
  const ctx = await browser.newContext(Object.assign({ permissions: ['geolocation', 'notifications'], geolocation: geo, locale: 'de-DE', timezoneId: 'Europe/Berlin' }, opts));
  await ctx.addInitScript(INIT, O);
  const page = await ctx.newPage();
  page.on('pageerror', e => errs.push(tag + ': ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/favicon|404/.test(m.text())) errs.push(tag + ' console: ' + m.text()); });
  await page.clock.install();
  return { ctx, page };
}
async function layoutCheck(page, tag) {
  const r = await page.evaluate(() => {
    const W = document.documentElement.clientWidth, sw = document.documentElement.scrollWidth;
    const small = [...document.querySelectorAll('button, a.btn, a.iconbtn, .chip')].filter(b => b.offsetParent && !b.closest('[hidden]')).map(b => [b.textContent.trim().slice(0, 20), Math.round(b.getBoundingClientRect().height), Math.round(b.getBoundingClientRect().width)]).filter(x => x[1] < 44 || x[2] < 44);
    return { W, sw, small };
  });
  ok(r.sw <= r.W, `${tag}: kein seitliches Scrollen (${r.sw} ≤ ${r.W})`);
  ok(!r.small.length, `${tag}: Bedienelemente ≥ 44 px` + (r.small.length ? ' ' + JSON.stringify(r.small) : ''));
}
const visible = (page, sel) => page.locator(sel).first().isVisible();
async function sheetBtn(page, label) { await page.locator('#sheet:not([hidden]) #shBtns >> text=' + label).first().click(); }

(async () => {
  const errs = [];
  const browser = await chromium.launch();
  const iphone = Object.assign({}, devices['iPhone 13'], { isMobile: false, defaultBrowserType: undefined });
  delete iphone.defaultBrowserType;
  const pixel = Object.assign({}, devices['Pixel 7']); delete pixel.defaultBrowserType;
  const A = await mkDevice(browser, Object.assign(iphone, { colorScheme: 'light' }), { latitude: 48.6856, longitude: 9.0109, accuracy: 8 }, errs, 'A');
  const B = await mkDevice(browser, Object.assign(pixel, { colorScheme: 'dark' }), { latitude: 48.6890, longitude: 9.0150, accuracy: 12 }, errs, 'B');
  const a = A.page, b = B.page;

  console.log('Start und Lobby');
  await a.goto(O + '/verstecken.html');
  await layoutCheck(a, 'A Start');
  await a.click('[data-act=create]');
  ok(await until(() => a.locator('#startMsg').isVisible()), 'ohne Namen: Hinweis');
  await a.fill('#nameIn', 'Tim');
  await a.click('[data-act=create]');
  ok(await until(() => visible(a, '#v-lobby .codebig')), 'Spiel angelegt, Lobby sichtbar');
  const code = (await a.textContent('#v-lobby .codebig')).trim();
  ok(/^[A-HJ-NP-Z2-9]{6}$/.test(code), 'Session-Code ' + code);
  await a.click('#v-lobby [data-act=pushOn]');
  ok(await until(() => a.locator('#v-lobby .row:has-text("Mitteilungen") .ok').isVisible()), 'A: Mitteilungen eingeschaltet');
  await a.click('#v-lobby [data-act=geoTest]');
  ok(await until(() => a.locator('#v-lobby .row:has-text("Standort") .ok').isVisible()), 'A: Standort getestet');
  let log = await getLog();
  ok(log.push.some(x => x.p === '/subscribe' && Object.values(x.body.channels).every(k => k.join() === 'spiele')), 'A: beim Push-Dienst angemeldet (Art spiele)');
  ok(await a.evaluate(() => new Promise(r => { const q = indexedDB.open('verstecken-keys', 1); q.onsuccess = () => { const c = q.result.transaction('k').objectStore('k').count(); c.onsuccess = () => r(c.result); }; q.onerror = () => r(0); })) === 1, 'A: Kanalschlüssel in IndexedDB verstecken-keys');

  await b.goto(O + '/verstecken.html#code=' + code.toLowerCase());
  ok(await b.evaluate(() => document.documentElement.classList.contains('android')), 'B: Android-Optik aktiv');
  ok((await b.inputValue('#codeIn')) === code, 'B: Code aus dem Link übernommen');
  await layoutCheck(b, 'B Start (Android, dunkel)');
  await b.screenshot({ path: 'shot-b-start.png' });
  await b.fill('#codeIn', 'ZZZZZZ'); await b.fill('#nameIn', 'Lena');
  await b.click('[data-act=join]');
  ok(await until(async () => /Kein Spiel/.test(await b.textContent('#startMsg'))), 'falscher Code: „Kein Spiel gefunden“');
  await b.fill('#codeIn', code);
  await b.click('[data-act=join]');
  ok(await until(() => visible(b, '#v-lobby .codebig')), 'B: beigetreten');
  await b.click('#v-lobby [data-act=pushOn]');
  await b.click('#v-lobby [data-act=geoTest]');
  ok(await until(() => b.locator('#v-lobby .row:has-text("Standort") .ok').isVisible()), 'B: Standort getestet');
  ok(await until(async () => (await a.locator('#v-lobby .card:has-text("Spieler") .row').count()) === 2, 15000), 'A sieht 2 Spieler');
  ok(await until(async () => (await a.locator('#v-lobby .row:has-text("Lena") .flags .no').count()) === 0, 15000), 'A: Lena bereit (🔔 + 📍)');
  await layoutCheck(a, 'A Lobby');
  await a.screenshot({ path: 'shot-a-lobby.png', fullPage: true });
  await b.screenshot({ path: 'shot-b-lobby.png', fullPage: true });
  ok((await b.locator('#v-lobby [data-act=start]').count()) === 0, 'B (kein Gastgeber) hat keinen Start-Knopf');
  for (let i = 0; i < 4; i++) await a.click('[data-act=ivMinus]');
  ok(/1 min/.test(await a.textContent('#v-lobby .stepper')), 'Intervall auf 1 min');

  console.log('Spiel starten');
  await a.click('#v-lobby [data-act=start]');
  ok(await until(() => visible(a, '#sheet:not([hidden])')), 'Start-Rückfrage');
  await sheetBtn(a, 'Starten');
  ok(await until(() => visible(a, '#v-seek')), 'A: Sucher-Ansicht');
  ok(await until(async () => (await getLog()).push.filter(x => x.p === '/send' && x.body.at).length >= 24), '24 Abfragen beim Push-Dienst geplant');
  log = await getLog();
  const sched = log.push.filter(x => x.p === '/send' && x.body.at);
  const ats = sched.map(x => Date.parse(x.body.at)).sort();
  ok(ats[1] - ats[0] === 60000 && new Set(sched.map(x => x.body.tag)).size === sched.length, 'Abfragen im Minutentakt mit eigenem Tag');
  const hideCh = sched[0].body.channels[0];
  ok(!sched.some(x => x.body.exclude), 'Abfragen ohne Ausschluss (gehen an alle Versteckten)');
  ok(await until(() => visible(b, '#v-hide'), 15000), 'B: Versteckt-Ansicht');
  ok(await until(() => b.locator('[data-cd]').isVisible()), 'B: Countdown sichtbar');
  ok(await until(() => a.locator('.stub-marker.pin:not(.mepin)').count().then(n => n === 0)), 'A: noch keine Marker');
  ok((await getLog()).push.some(x => x.p === '/subscribe' && x.body.channels[hideCh]), 'B ist auf dem Abfrage-Kanal angemeldet');
  await layoutCheck(b, 'B Versteckt');
  await layoutCheck(a, 'A Sucher');

  console.log('Erste Abfrage nach 1 min');
  await a.clock.fastForward(61000); await b.clock.fastForward(61000);
  ok(await until(() => b.locator('#sheet:not([hidden]) #shT:has-text("Standort senden?")').isVisible(), 8000), 'B: Rückfrage „Standort senden?“ erscheint von selbst');
  await b.screenshot({ path: 'shot-b-frage.png' });
  await sheetBtn(b, 'Jetzt senden');
  ok(await until(async () => /Gesendet/.test(await b.textContent('#toast'))), 'B: „Gesendet ✓“');
  log = await getLog();
  ok(log.records.length === 2, 'Server: Spiel- und Standort-Datensatz');
  ok(log.records.every(r => /^v1\./.test(r.data) && !/Lena|Tim|48\.68/.test(r.data)), 'Server sieht nur verschlüsselte Daten');
  const seekSend = log.push.filter(x => x.p === '/send' && !x.body.at && x.body.channels[0] !== hideCh && x.body.exclude).pop();
  ok(!!seekSend, 'Sucher werden per Mitteilung informiert (ohne eigenes Gerät)');
  ok(await until(async () => /±12 m/.test(await a.textContent('#seeklist')), 12000), 'A: Lena mit Zeit und Genauigkeit in der Liste');
  ok(/\d+ m (N|NO|O|SO|S|SW|W|NW)/.test(await a.textContent('#seeklist')), 'A: Entfernung und Richtung');
  ok(await until(() => a.locator('.stub-marker.pin:not(.mepin)').count().then(n => n === 1)), 'A: Marker auf der Karte');
  ok(/Lena/.test(await a.getAttribute('.stub-marker.pin:not(.mepin)', 'data-tip')), 'A: Marker beschriftet');
  ok(await until(async () => /Gesendet|zuletzt|Zuletzt/.test(await b.textContent('#v-hide'))), 'B: „Zuletzt gesendet“');
  await a.screenshot({ path: 'shot-a-sucher.png', fullPage: true });
  await b.screenshot({ path: 'shot-b-versteckt.png', fullPage: true });

  console.log('Mitteilung im Service Worker entschlüsseln');
  {
    /* Headless-Chromium zeigt keine Mitteilungen an – daher die Funktionen des Service Workers im Fenster ausführen */
    const swSrc = await (await fetch(O + '/sw.js')).text();
    const part = swSrc.slice(swSrc.indexOf('function idbKey'), swSrc.indexOf('const KIND_TITLE'));
    const seekCh = seekSend.body.channels[0];
    const m = await a.evaluate(async ([code, ch, box]) => { const f = new Function('ch', 'box', code + '; return pushKey(ch).then(k => k ? openBox(k, box) : null);'); return f(ch, box); }, [part, seekCh, seekSend.body.boxes['*']]);
    ok(m && m.title === '📍 Lena' && m.url === 'verstecken.html', 'Service Worker findet Schlüssel und entschlüsselt: ' + JSON.stringify(m));
    const r1 = sched[0].body;
    const m2 = await b.evaluate(async ([code, ch, box]) => { const f = new Function('ch', 'box', code + '; return pushKey(ch).then(k => k ? openBox(k, box) : null);'); return f(ch, box); }, [part, r1.channels[0], r1.boxes['*']]);
    ok(m2 && /Standort senden/.test(m2.title) && m2.url === 'verstecken.html#send', 'Abfrage-Mitteilung auf B: ' + JSON.stringify(m2));
    ok(/KIND_TITLE/.test(swSrc) && /'\/verstecken\.html'/.test(swSrc), 'sw.js hält verstecken.html offline bereit');
  }

  console.log('Ebenen, Spieler-Menü, gefunden');
  await a.click('[data-act=layer][data-key=sat]');
  ok(await a.evaluate(() => /World_Imagery/.test(window.__L.tiles.slice(-1)[0])), 'Ebene Satellit geladen');
  ok(await a.locator('[data-act=layer][data-key=sat].on').count() === 1, 'Ebenen-Chip markiert');
  await a.click('#seeklist [data-act=player]');
  ok(await until(() => visible(a, '#sheet:not([hidden])')), 'Spieler-Menü offen');
  const hrefs = await a.$$eval('#shBtns a', as => as.map(x => x.getAttribute('href')));
  ok(hrefs.some(h => /^https:\/\/maps\.apple\.com\/\?ll=48\.689,9\.015/.test(h)) && hrefs.some(h => h.startsWith('om://map')) && hrefs.some(h => h.includes('osmand.net/map?pin=')), 'iPhone: Apple Karten, OsmAnd, Organic Maps verlinkt');
  const bl = await b.evaluate(() => mapLinks({ lat: 1, lon: 2 }, 'X').map(x => x[1]));
  ok(bl[0].startsWith('geo:1,2') && !bl.some(h => h.includes('apple')), 'Android: geo:-Link statt Apple Karten');
  await sheetBtn(a, 'Gefunden');
  ok(await until(async () => /gefunden/.test(await a.textContent('#seeklist'))), 'A: Lena als gefunden markiert');
  ok(await until(async () => /Gefunden!/.test(await b.textContent('#v-hide')), 15000), 'B: „Gefunden!“');
  ok(await until(async () => { const l = await getLog(); const last = l.push.filter(x => x.p === '/unsubscribe' || x.p === '/subscribe').pop(); return last && (last.p === '/unsubscribe' || !last.body.channels[hideCh]); }), 'B: nach „gefunden“ keine Abfragen mehr');

  console.log('Android-Zurück');
  await b.click('#menuBtn');
  ok(await until(() => visible(b, '#sheet:not([hidden])')), 'B: Menü offen');
  ok(await b.locator('#sheet .grip').isVisible(), 'B: Bottom-Sheet mit Griff');
  await b.screenshot({ path: 'shot-b-menu.png' });
  await b.goBack();
  ok(await until(async () => !(await visible(b, '#sheet:not([hidden])'))), 'Zurück schließt den Dialog');
  ok(/verstecken\.html/.test(b.url()), 'und bleibt in der App');
  await b.click('#menuBtn'); await until(() => visible(b, '#sheet:not([hidden])'));
  await sheetBtn(b, 'Schließen');
  await sleep(400);
  const len = await b.evaluate(() => history.length);
  await b.click('#menuBtn'); await until(() => visible(b, '#sheet:not([hidden])'));
  await sheetBtn(b, 'Schließen'); await sleep(400);
  ok(await b.evaluate(() => history.length) === len, 'Schließen per Knopf hinterlässt keinen Verlaufseintrag');

  console.log('Mitteilung antippen (#send)');
  await a.click('#seeklist [data-act=player]'); await until(() => visible(a, '#sheet:not([hidden])'));
  await sheetBtn(a, 'Doch nicht gefunden');
  ok(await until(async () => !/Gefunden!/.test(await b.textContent('#v-hide')), 15000), 'B: wieder im Spiel');
  await b.goto(O + '/verstecken.html#send');
  ok(await until(() => b.locator('#sheet:not([hidden]) #shT:has-text("Standort senden?")').isVisible(), 8000), 'Öffnen über Mitteilung → Rückfrage');
  await sheetBtn(b, 'Jetzt senden');
  ok(await until(async () => /Gesendet/.test(await b.textContent('#toast'))), 'nach Bestätigung gesendet');

  console.log('Runde beenden, Spiel löschen');
  await a.click('#menuBtn'); await until(() => visible(a, '#sheet:not([hidden])'));
  await sheetBtn(a, 'Runde beenden'); await until(() => a.locator('#shT:has-text("Runde beenden?")').isVisible());
  await sheetBtn(a, 'Runde beenden');
  ok(await until(() => visible(a, '#v-lobby')), 'A: zurück in der Lobby');
  ok(await until(async () => (await getLog()).push.filter(x => x.p === '/cancel').length >= 20), 'offene Abfragen beim Push-Dienst zurückgenommen');
  ok(await until(() => visible(b, '#v-lobby'), 15000), 'B: zurück in der Lobby');
  await a.click('#menuBtn'); await until(() => visible(a, '#sheet:not([hidden])'));
  await sheetBtn(a, 'Spiel löschen'); await until(() => a.locator('#shT:has-text("Spiel löschen?")').isVisible());
  await sheetBtn(a, 'Löschen');
  ok(await until(() => visible(a, '#v-start')), 'A: Startseite');
  ok(await until(async () => (await getLog()).records.length === 0), 'Server: alle Datensätze gelöscht');
  ok(await until(() => b.locator('#shT:has-text("Spiel beendet")').isVisible(), 15000), 'B: „Spiel beendet“');

  console.log('Seitenfehler:', errs.length ? errs : 'keine');
  ok(!errs.length, 'keine JS-Fehler');
  await browser.close();
  console.log(`\n${pass} bestanden, ${fail} fehlgeschlagen`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
