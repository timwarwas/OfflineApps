/* Testserver: statische Dateien des Repos + nachgebaute PocketBase (trips) + nachgebauter Push-Dienst + Leaflet-Attrappe */
'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const ROOT = process.argv[2] || '/home/claude/offlineapps';
const records = new Map(), pushLog = [];
let lastUpd = 0;
const stamp = () => { let t = Date.now(); if (t <= lastUpd) t = lastUpd + 1; lastUpd = t; return new Date(t).toISOString().replace('T', ' '); };
const LEAFLET = fs.readFileSync(path.join(__dirname, 'leaflet-stub.js'), 'utf8');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.webmanifest': 'application/manifest+json', '.css': 'text/css', '.png': 'image/png' };
const vapidPub = Buffer.concat([Buffer.from([4]), crypto.randomBytes(64)]).toString('base64url');

function json(res, st, obj) { res.writeHead(st, { 'Content-Type': 'application/json' }); res.end(obj === undefined ? '' : JSON.stringify(obj)); }
function pb(req, res, url, body) {
  const m = /^\/api\/collections\/trips\/records(?:\/([^/?]+))?$/.exec(url.pathname);
  if (!m) return json(res, 404, { message: 'not found' });
  const id = m[1], auth = req.headers['x-trip-auth'];
  const out = r => { const f = url.searchParams.get('fields'); if (!f) return r; const o = {}; f.split(',').forEach(k => { o[k] = r[k]; }); return o; };
  if (req.method === 'POST' && !id) {
    if (typeof body.auth !== 'string' || body.auth.length < 40 || body.auth.length > 100) return json(res, 400, { message: 'auth' });
    const rid = body.id || crypto.randomBytes(8).toString('hex').slice(0, 15);
    if (!/^[a-z0-9]{15}$/.test(rid) || records.has(rid)) return json(res, 400, { message: 'id' });
    if (String(body.data || '').length > 2e6) return json(res, 400, { message: 'data' });
    const t = stamp(), r = { id: rid, auth: body.auth, data: String(body.data || ''), rev: +body.rev || 0, created: t, updated: t };
    records.set(rid, r); return json(res, 200, r);
  }
  const r = id && records.get(id);
  if (!r || r.auth !== auth) return json(res, 404, { message: 'not found' });
  if (req.method === 'GET') return json(res, 200, out(r));
  if (req.method === 'PATCH') {
    if ('auth' in body && body.auth !== r.auth) return json(res, 404, { message: 'rule' });
    if ('data' in body) r.data = String(body.data); if ('rev' in body) r.rev = +body.rev; r.updated = stamp();
    return json(res, 200, r);
  }
  if (req.method === 'DELETE') { records.delete(id); res.writeHead(204); return res.end(); }
  json(res, 405, {});
}
function push(req, res, url, body) {
  const p = url.pathname.replace(/^\/push/, '');
  pushLog.push({ p, body, t: Date.now() });
  if (p === '/vapid') return json(res, 200, { publicKey: vapidPub });
  if (p === '/send') return json(res, 200, body.at ? { ok: true, scheduled: body.at } : { ok: true, targets: 1, ok2: 1 });
  json(res, 200, { ok: true });
}
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/__log') return json(res, 200, { push: pushLog, records: [...records.values()] });
  if (url.pathname === '/__reset') { records.clear(); pushLog.length = 0; return json(res, 200, { ok: true }); }
  if (url.pathname.startsWith('/leaflet/')) { res.writeHead(200, { 'Content-Type': url.pathname.endsWith('.css') ? 'text/css' : 'text/javascript' }); return res.end(url.pathname.endsWith('.css') ? '.leaflet-stub{}' : LEAFLET); }
  let raw = '';
  req.on('data', c => { raw += c; });
  req.on('end', () => {
    let body = {}; try { body = raw ? JSON.parse(raw) : {}; } catch (e) {}
    if (url.pathname.startsWith('/api/')) return pb(req, res, url, body);
    if (url.pathname.startsWith('/push/')) return push(req, res, url, body);
    const f = path.join(ROOT, path.normalize(url.pathname === '/' ? '/index.html' : url.pathname));
    if (!f.startsWith(ROOT) || !fs.existsSync(f)) { res.writeHead(404); return res.end('nicht da'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    fs.createReadStream(f).pipe(res);
  });
});
server.listen(+process.argv[3] || 8765, '127.0.0.1', () => console.log('Testserver läuft'));
module.exports = server;
