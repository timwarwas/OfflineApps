# Test für verstecken.html

`node verstecken-e2e.js` (Playwright, Repo unter /home/claude/offlineapps; sonst Pfad als 1. Argument an server.js).
Zwei Geräte (iPhone hell, Android dunkel), nachgebaute PocketBase (`trips`) und Push-Dienst, Leaflet-Attrappe.
Headless-Chromium zeigt keine Mitteilungen an – die Entschlüsselung des Service Workers wird im Fenster geprüft.
