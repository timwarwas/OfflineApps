// E2E: Einkaufsliste über Wochen – „alles Kommende“ als Standard, Übernahme nicht Gekauftem in die nächste Woche,
// Abhaken gilt in jeder Ansicht. Außerdem: Rotation zeigt keine gelöschten/archivierten Rezepte.
// Aufruf: node e2e-einkauf.js   (SHOTS=<ordner> für Bildschirmfotos)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');

let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };

const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' });
  res.end(fs.readFileSync(f));
});

(async () => {
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log(`Durchlauf ${scheme}`);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
    const page = await ctx.newPage();
    await page.clock.install({ time: new Date('2026-10-06T10:00:00+02:00') });   // Dienstag, KW 41
    await page.clock.resume();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
    const tap = async sel => { await page.locator(sel).first().click(); await sleep(220); };
    const rowsJs = () => page.evaluate(() => shopRows(curShopList()).map(r => ({ name: r.name, checked: r.checked, carry: r.carry, extra: r.extra != null })));

    await page.goto(URL_);
    await tap('text=Neuen Haushalt einrichten');
    await page.fill('#a-n', 'Einkauf-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
    await tap('[data-x=ok]');
    await until(() => page.locator('#tabs button').count().then(n => n === 4));
    await tap('[data-tab=suggest]'); await tap('[data-act=seed]');
    // Plan: Vorwoche (Do 01.10.), diese Woche (Mi 07.10.), nächste Woche (Mi 14.10.)
    const names = await page.evaluate(() => {
      const rs = liveRecipes().filter(r => r.ingredients.length >= 3 && EP.laneOf(r) === 'MAIN').slice(0, 3);
      [['2026-10-01', rs[0]], ['2026-10-07', rs[1]], ['2026-10-14', rs[2]]].forEach(([date, r]) => db.plan.push(EP.touch({ id: EP.uuid(), date, lane: 'MAIN', type: 'COOK', recipeId: r.id,
        blockId: EP.uuid(), dayIndex: 1, dayCount: 1, rotationEntryId: null, source: 'MANUAL', locked: false, status: date < EP.todayISO() ? 'DONE' : 'PLANNED', note: '', deleted: false })));
      return persist().then(() => rs.map(r => r.name));
    });

    console.log('Standard: alles Kommende');
    await tap('[data-tab=shop]');
    ok('Ansicht „Alles Kommende“ ist vorgewählt', await page.locator('[data-act=shopmode][data-arg=all][aria-pressed=true]').count() === 1);
    ok('Zeitraum ab heute bis zum letzten geplanten Kochtag', /Ab heute/.test(await page.locator('.weekhead .kw').innerText()) && /06\.10\.–14\.10\.2026/.test(await page.locator('.weekhead .kw span').innerText()), await page.locator('.weekhead .kw').innerText());
    const sub = await page.locator('p.sub').first().innerText();
    ok('Gerichte dieser und nächster Woche', sub.includes(names[1]) && sub.includes(names[2]) && !sub.includes(names[0]), sub);
    ok('nicht Gekauftes der Vorwoche ist übernommen und markiert', await page.locator('.carryhint').count() === 1 && await page.locator('small.carry').count() > 0);
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/einkauf-alles-${scheme}.png` });
    const lay = await page.evaluate(() => ({ over: document.documentElement.scrollWidth > document.documentElement.clientWidth,
      small: [...document.querySelectorAll('.shopmode button')].filter(b => b.getBoundingClientRect().height < 44).length }));
    ok('kein seitliches Scrollen, Umschalter ≥ 44 px', !lay.over && !lay.small);

    console.log('Nach Woche');
    await tap('[data-act=shopmode][data-arg=week]');
    ok('Wochenansicht startet mit der aktuellen Woche', /KW 41/.test(await page.locator('.weekhead .kw b').innerText()));
    ok('auch hier Übernahme aus der Vorwoche', (await rowsJs()).some(r => r.carry));
    await tap('[data-act=shopwk][data-arg="7"]');
    ok('nächste Woche: keine Übernahme', /KW 42/.test(await page.locator('.weekhead .kw b').innerText()) && !(await rowsJs()).some(r => r.carry) && await page.locator('.carryhint').count() === 0);
    await tap('[data-act=shopwk][data-arg="-7"]'); await tap('[data-act=shopwk][data-arg="-7"]');
    ok('Vorwoche zeigt ihre Zutaten (offen)', /KW 40/.test(await page.locator('.weekhead .kw b').innerText()) && (await rowsJs()).length > 0 && (await rowsJs()).every(r => !r.checked && !r.carry));
    // in der Vorwoche alles abhaken
    await page.evaluate(() => document.querySelectorAll('details.shopsec').forEach(d => { d.open = true; }));
    const boxes = page.locator('[data-check]');
    for (let i = 0, n = await boxes.count(); i < n; i++) { await boxes.nth(i).check(); await sleep(60); }
    await tap('[data-act=shopwk][data-arg="7"]');
    ok('in der Vorwoche Gekauftes wird nicht mehr übernommen', !(await rowsJs()).some(r => r.carry) && await page.locator('.carryhint').count() === 0);
    // in KW 41 eine Zutat abhaken → in „alles Kommende“ ebenfalls abgehakt
    const first = await page.locator('[data-check] ~ .nm').first().innerText();
    await page.locator('[data-check]').first().check(); await sleep(150);
    await tap('[data-act=shopmode][data-arg=all]');
    const inAll = (await rowsJs()).find(r => r.name === first.split('\n')[0]);
    ok('Abhaken in der Woche gilt auch in „alles Kommende“', inAll && (inAll.checked || await page.evaluate(n => { const l = curShopList(); return shopRows(l).find(r => r.name === n).units.some(k => db.shopping.bought[k] && db.shopping.bought[k].on); }, inAll.name)), JSON.stringify(inAll));
    // Zusatzartikel in der Wochenansicht für nächste Woche
    await tap('[data-act=shopmode][data-arg=week]'); await tap('[data-act=shopwk][data-arg="7"]');
    await page.fill('#extra', 'Sekt'); await tap('[data-act=addextra]');
    await tap('[data-act=shopwk][data-arg="-7"]');
    ok('Zusatzartikel für nächste Woche steht nicht in dieser Woche', !(await rowsJs()).some(r => r.name === 'Sekt'));
    await tap('[data-act=shopmode][data-arg=all]');
    ok('… aber in „alles Kommende“', (await rowsJs()).some(r => r.name === 'Sekt'));
    ok('Kopieren enthält nur Offenes in Ladenreihenfolge', await page.evaluate(() => { const t = shopText(); return t.includes('Sekt') && t.split('\n').length > 3; }));

    console.log('Rotation');
    const rot = await page.evaluate(() => {
      const shownNames = () => [...document.querySelectorAll('#main .item .nm')].map(e => e.textContent.trim());
      go('rotation');
      const before = shownNames();
      const victim = EP.live(db.rotation).map(e => recipeById(e.recipeId)).find(r => r && before.some(n => n.startsWith(r.name)));
      // ein Eintrag dieses Rezepts gilt als gekocht (DONE) – danach wird das Rezept gelöscht (archiviert)
      const e = EP.live(db.rotation).find(x => x.recipeId === victim.id); e.status = 'DONE'; EP.touch(e);
      archiveRecipe(victim); rerender();
      const after = shownNames();
      // verwaister „Geplant“-Eintrag (Tag aus dem Plan gelöscht)
      const e2 = EP.live(db.rotation).find(x => x.status === 'PENDING'); e2.status = 'PLANNED'; EP.touch(e2);
      housekeeping(); rerender();
      return { victim: victim.name, gone: !after.some(n => n.startsWith(victim.name)), orphan: e2.status };
    });
    ok('gelöschtes (archiviertes) Rezept verschwindet aus der Rotation, auch bereits gekochte Einträge', rot.gone, rot.victim);
    ok('„Geplant“ ohne Planeintrag wird wieder offen', rot.orphan === 'PENDING', rot.orphan);
    await ctx.close();
  }
  ok('keine Seitenfehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
