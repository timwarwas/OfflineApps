/* ==== Zentrales Konto der Anwendungssammlung (gleicher Code in allen Apps) ====
   Ein Konto = ein verschlüsselter „Schlüsselbund“ auf dem Pi (Collection trips).
   Aus Benutzername + Passwort wird per PBKDF2 ein Hauptschlüssel abgeleitet, daraus per HKDF
   die Datensatz-ID, der Zugangsnachweis (X-Trip-Auth) und der AES-GCM-Schlüssel.
   Der Server sieht nur verschlüsselte Daten und kennt weder Namen noch Passwort.
   Im Schlüsselbund liegen die Verbindungslinks (Reisen, Haushalt, Spielgruppe, Projekte)
   und – falls gewünscht – Passwörter der Brief-Profile.
   Angemeldet bleibt man bis zum Abmelden (localStorage „konto“, gilt für alle Apps derselben Adresse).
   Face ID: optional über einen Passkey mit PRF-Erweiterung (iOS 18+).
   Passwort vergessen: optional Sicherheitsfrage. Aus Benutzername + Antwort wird (PBKDF2) ein zweiter
   Schlüssel abgeleitet, der einen Datensatz mit dem Hauptschlüssel öffnet. Die Frage selbst liegt
   in einem Datensatz, der nur mit dem Benutzernamen lesbar ist.
   Einladungen: Jedes Konto veröffentlicht ein Profil (öffentliche Schlüssel ECDH + ECDSA) und hat ein Postfach,
   beide auffindbar über den Benutzernamen. Eine Einladung (Verbindungslink einer Reise/eines Haushalts …) wird für
   den Empfänger verschlüsselt, vom Absender signiert, ins Postfach gelegt und läuft nach einigen Tagen ab. */
const Konto = (() => {
  const DEFAULT = 'https://kostenpi.tail281e3e.ts.net';
  const ITER = 310000;
  const te = t => new TextEncoder().encode(t);
  const b64e = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
  const b64d = str => { str = String(str).replace(/-/g, '+').replace(/_/g, '/'); while (str.length % 4) str += '='; const b = atob(str), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
  const ls = {
    get(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} },
    del(k) { try { localStorage.removeItem(k); } catch (e) {} },
  };
  const server = () => { try { return localStorage.getItem('konto-server') || DEFAULT; } catch (e) { return DEFAULT; } };
  const normUser = u => String(u || '').trim().toLowerCase();
  const nowIso = () => new Date().toISOString();

  /* ---------- Schlüssel ---------- */
  async function masterFrom(user, pw) {
    const base = await crypto.subtle.importKey('raw', te(pw), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: te('anwendungssammlung-konto-v1|' + normUser(user)), iterations: ITER }, base, 256);
    return b64e(new Uint8Array(bits));
  }
  const keyCache = new Map();
  function keys(master, salt) {
    const ck = salt + '|' + master;
    if (!keyCache.has(ck)) keyCache.set(ck, (async () => {
      const s = te(salt);
      const base = await crypto.subtle.importKey('raw', b64d(master), 'HKDF', false, ['deriveKey', 'deriveBits']);
      const enc = await crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: s, info: te('enc') }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
      const auth = b64e(new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt: s, info: te('auth') }, base, 256)));
      const idb = new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt: s, info: te('id') }, base, 256));
      const a = 'abcdefghijklmnopqrstuvwxyz0123456789'; let id = '';
      for (let i = 0; i < 15; i++) id += a[idb[i] % 36];
      return { id, auth, enc };
    })());
    return keyCache.get(ck);
  }
  const vaultKeys = master => keys(master, 'konto-v1');
  const pkKeys = secret => keys(secret, 'konto-passkey-v1');
  const normAnswer = a => String(a || '').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
  async function recoverySecret(user, answer) {
    const base = await crypto.subtle.importKey('raw', te(normAnswer(answer)), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: te('anwendungssammlung-recovery-v1|' + normUser(user)), iterations: ITER }, base, 256);
    return b64e(new Uint8Array(bits));
  }
  const recKeys = secret => keys(secret, 'konto-recovery-v1');
  async function questionKeys(user) {
    const h = new Uint8Array(await crypto.subtle.digest('SHA-256', te('konto-frage-v1|' + normUser(user))));
    return keys(b64e(h), 'konto-frage-v1');
  }
  /* Datensatz mit fester ID anlegen oder überschreiben */
  async function upsert(k, obj) {
    const data = await encrypt(k.enc, obj);
    const r = await api('POST', '', null, { id: k.id, auth: k.auth, data, rev: 1 });
    if (r.status === 200) return;
    if (r.status !== 400) throw fail(r);
    const u = await api('PATCH', '/' + k.id, k.auth, { data });
    if (u.status !== 200) throw fail(u);
  }
  async function encrypt(key, obj) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, te(JSON.stringify(obj)));
    return 'v1.' + b64e(iv) + '.' + b64e(new Uint8Array(ct));
  }
  async function decrypt(key, str) {
    const p = String(str || '').split('.');
    if (p.length !== 3 || p[0] !== 'v1') throw new Error('Unbekanntes Datenformat');
    return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64d(p[1]) }, key, b64d(p[2]))));
  }

  /* ---------- Server ---------- */
  async function api(method, path, auth, body) {
    const h = {}; if (auth) h['X-Trip-Auth'] = auth; if (body) h['Content-Type'] = 'application/json';
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 15000);
    try {
      const r = await fetch(server() + '/api/collections/trips/records' + path, { method, headers: h, body: body ? JSON.stringify(body) : undefined, cache: 'no-store', signal: ctl.signal });
      let j = null; try { j = await r.json(); } catch (e) {}
      return { status: r.status, json: j };
    } catch (e) {
      const err = new Error('Server nicht erreichbar'); err.offline = true; throw err;
    } finally { clearTimeout(to); }
  }
  const fail = r => { const e = new Error('Server antwortet mit ' + r.status); e.status = r.status; return e; };

  /* ---------- Schlüsselbund zusammenführen ---------- */
  function emptyVault(user) { return { v: 1, user, items: {}, deleted: {}, passkeys: {}, recovery: null, keys: null, sent: {} }; }
  function clean(v, user) {
    v = v && typeof v === 'object' ? v : {};
    return { v: 1, user: v.user || user || '', items: v.items && typeof v.items === 'object' ? v.items : {},
      deleted: v.deleted && typeof v.deleted === 'object' ? v.deleted : {}, passkeys: v.passkeys && typeof v.passkeys === 'object' ? v.passkeys : {},
      recovery: v.recovery && typeof v.recovery === 'object' ? v.recovery : null,
      keys: v.keys && typeof v.keys === 'object' ? v.keys : null, sent: v.sent && typeof v.sent === 'object' ? v.sent : {} };
  }
  function merge(a, b) {
    a = clean(a); b = clean(b);
    const out = emptyVault(a.user || b.user);
    const cut = new Date(Date.now() - 365 * 864e5).toISOString();
    for (const d of [a.deleted, b.deleted]) for (const k in d) if (d[k] >= cut && (!out.deleted[k] || d[k] > out.deleted[k])) out.deleted[k] = d[k];
    for (const src of [a.items, b.items]) for (const k in src) {
      const x = src[k], o = out.items[k];
      if (!o || (x.updatedAt || '') > (o.updatedAt || '') || ((x.updatedAt || '') === (o.updatedAt || '') && JSON.stringify(x) > JSON.stringify(o))) out.items[k] = x;
    }
    for (const k in out.items) if (out.deleted[k] && out.deleted[k] >= (out.items[k].updatedAt || '')) delete out.items[k];
    for (const src of [a.passkeys, b.passkeys]) for (const k in src) if (!out.passkeys[k] || (src[k].createdAt || '') > (out.passkeys[k].createdAt || '')) out.passkeys[k] = src[k];
    for (const k in out.passkeys) if (out.deleted['pk:' + k]) delete out.passkeys[k];
    out.recovery = [a.recovery, b.recovery].filter(Boolean).sort((x, y) => (y.createdAt || '').localeCompare(x.createdAt || ''))[0] || null;
    if (out.recovery && out.deleted.recovery && out.deleted.recovery >= out.recovery.createdAt) out.recovery = null;
    out.keys = [a.keys, b.keys].filter(Boolean).sort((x, y) => (x.createdAt || '').localeCompare(y.createdAt || '') || (x.encPub > y.encPub ? 1 : -1))[0] || null;   // älteste gewinnt
    for (const src of [a.sent, b.sent]) for (const k in src) if (!out.deleted['sent:' + k]) out.sent[k] = src[k];
    return out;
  }
  const canon = v => { const s = x => Array.isArray(x) ? '[' + x.map(s).join(',') + ']' : x && typeof x === 'object' ? '{' + Object.keys(x).sort().map(k => JSON.stringify(k) + ':' + s(x[k])).join(',') + '}' : JSON.stringify(x); return s(v); };

  /* ---------- Sitzung ---------- */
  const session = () => { const s = ls.get('konto'); return s && s.master && s.user ? s : null; };
  const cache = () => clean(ls.get('konto-cache'), (session() || {}).user);
  const listeners = new Set();
  const emit = () => listeners.forEach(fn => { try { fn(); } catch (e) {} });

  async function fetchVault(master) {
    const k = await vaultKeys(master);
    const r = await api('GET', '/' + k.id, k.auth);
    if (r.status === 404) return null;
    if (r.status !== 200 || !r.json) throw fail(r);
    return { vault: clean(await decrypt(k.enc, r.json.data)), rev: +r.json.rev || 0 };
  }
  async function createVault(master, vault) {
    const k = await vaultKeys(master);
    const r = await api('POST', '', null, { id: k.id, auth: k.auth, data: await encrypt(k.enc, vault), rev: 1 });
    if (r.status !== 200) throw fail(r);
  }

  let busy = null, again = false;
  /* Abgleich: holen, zusammenführen, bei Bedarf zurückschreiben */
  async function sync() {
    const s = session(); if (!s) return null;
    if (busy) { again = true; return busy; }
    busy = (async () => {
      try {
        const k = await vaultKeys(s.master);
        for (let round = 0; round < 4; round++) {
          const r = await api('GET', '/' + k.id, k.auth);
          if (r.status === 404) { const e = new Error('Konto nicht mehr vorhanden'); e.gone = true; throw e; }
          if (r.status !== 200 || !r.json) throw fail(r);
          const remote = clean(await decrypt(k.enc, r.json.data), s.user);
          const local = ls.get('konto-cache') ? cache() : remote;
          const merged = merge(local, remote);
          ls.set('konto-cache', merged);
          if (canon(merged) === canon(remote)) { ls.set('konto-state', { at: nowIso(), err: '' }); break; }
          const u = await api('PATCH', '/' + k.id, k.auth, { data: await encrypt(k.enc, merged), rev: (+r.json.rev || 0) + 1 });
          if (u.status === 200) { ls.set('konto-state', { at: nowIso(), err: '' }); break; }
          if (u.status !== 400 && u.status !== 409) throw fail(u);
        }
        emit();
        return cache();
      } catch (e) {
        ls.set('konto-state', { at: (ls.get('konto-state') || {}).at || null, err: e.message || 'Fehler' });
        if (e.gone) { logout(); emit(); }
        throw e;
      } finally {
        busy = null;
        if (again) { again = false; setTimeout(() => sync().catch(() => {}), 50); }
      }
    })();
    return busy;
  }

  async function login(user, pw) {
    user = String(user || '').trim();
    if (!user || !pw) throw new Error('Bitte Benutzername und Passwort eingeben.');
    const master = await masterFrom(user, pw);
    const f = await fetchVault(master);
    if (!f) return { notFound: true };
    ls.set('konto', { user: f.vault.user || user, master, at: nowIso() });
    ls.set('konto-cache', f.vault);
    emit();
    ensureProfile().catch(() => {});
    return { ok: true };
  }
  async function register(user, pw) {
    user = String(user || '').trim();
    if (user.length < 2) throw new Error('Der Benutzername braucht mindestens 2 Zeichen.');
    if (String(pw || '').length < 8) throw new Error('Das Passwort braucht mindestens 8 Zeichen.');
    const master = await masterFrom(user, pw);
    const f = await fetchVault(master);
    if (f) { ls.set('konto', { user: f.vault.user || user, master, at: nowIso() }); ls.set('konto-cache', f.vault); emit(); return { existed: true }; }
    await createVault(master, emptyVault(user));
    ls.set('konto', { user, master, at: nowIso() });
    ls.set('konto-cache', emptyVault(user));
    emit();
    await ensureProfile().catch(() => {});
    return { ok: true };
  }
  function logout() { ['konto', 'konto-cache', 'konto-state', 'konto-inbox'].forEach(ls.del); keyCache.clear(); emit(); }
  let recovered = false;   // gerade über die Sicherheitsfrage angemeldet → neues Passwort ohne altes erlaubt
  async function changePassword(oldPw, newPw) {
    const s = session(); if (!s) throw new Error('Nicht angemeldet.');
    if (String(newPw || '').length < 8) throw new Error('Das neue Passwort braucht mindestens 8 Zeichen.');
    if (!(recovered && oldPw == null) && (await masterFrom(s.user, oldPw)) !== s.master) throw new Error('Das bisherige Passwort stimmt nicht.');
    const v = await sync();
    const nm = await masterFrom(s.user, newPw);
    await createVault(nm, v);
    for (const cid in v.passkeys) {   // Face-ID-Zugänge auf den neuen Schlüssel umstellen
      const p = v.passkeys[cid], pk = await pkKeys(p.secret);
      await api('PATCH', '/' + pk.id, pk.auth, { data: await encrypt(pk.enc, { user: s.user, master: nm }), rev: 2 });
    }
    if (v.recovery && v.recovery.secret) await upsert(await recKeys(v.recovery.secret), { user: s.user, master: nm });
    const ok = await vaultKeys(s.master);
    await api('DELETE', '/' + ok.id, ok.auth);
    ls.set('konto', { user: s.user, master: nm, at: nowIso() });
    recovered = false;
    emit();
  }

  /* ---------- Sicherheitsfrage ---------- */
  async function setRecovery(question, answer) {
    const s = session(); if (!s) throw new Error('Nicht angemeldet.');
    question = String(question || '').trim();
    if (question.length < 5) throw new Error('Bitte eine Frage eingeben.');
    if (normAnswer(answer).length < 3) throw new Error('Die Antwort braucht mindestens 3 Zeichen.');
    const v = await sync();
    const secret = await recoverySecret(s.user, answer);
    await upsert(await recKeys(secret), { user: s.user, master: s.master });
    await upsert(await questionKeys(s.user), { question });
    if (v.recovery && v.recovery.secret && v.recovery.secret !== secret) {   // alte Antwort ungültig machen
      const old = await recKeys(v.recovery.secret); await api('DELETE', '/' + old.id, old.auth);
    }
    const c = cache(); c.recovery = { secret, question, createdAt: nowIso() }; delete c.deleted.recovery;
    ls.set('konto-cache', c); await sync();
    return true;
  }
  async function removeRecovery() {
    const s = session(); if (!s) return;
    const v = await sync();
    if (v.recovery && v.recovery.secret) { const k = await recKeys(v.recovery.secret); await api('DELETE', '/' + k.id, k.auth); }
    const q = await questionKeys(s.user); await api('DELETE', '/' + q.id, q.auth);
    const c = cache(); c.recovery = null; c.deleted.recovery = nowIso(); ls.set('konto-cache', c); await sync();
  }
  async function getQuestion(user) {
    const q = await questionKeys(String(user || '').trim());
    const r = await api('GET', '/' + q.id, q.auth);
    if (r.status === 404) return null;
    if (r.status !== 200 || !r.json) throw fail(r);
    return (await decrypt(q.enc, r.json.data)).question || null;
  }
  /* mit richtiger Antwort anmelden; danach muss ein neues Passwort gesetzt werden */
  async function recover(user, answer) {
    user = String(user || '').trim();
    const k = await recKeys(await recoverySecret(user, answer));
    const r = await api('GET', '/' + k.id, k.auth);
    if (r.status === 404) return { wrong: true };
    if (r.status !== 200 || !r.json) throw fail(r);
    const d = await decrypt(k.enc, r.json.data);
    const f = await fetchVault(d.master);
    if (!f) return { wrong: true };
    ls.set('konto', { user: d.user || user, master: d.master, at: nowIso() });
    ls.set('konto-cache', f.vault);
    recovered = true;
    emit();
    return { ok: true };
  }

  /* ---------- Einträge ---------- */
  function items(app) {
    const v = cache();
    return Object.keys(v.items).filter(k => !app || v.items[k].app === app).map(k => Object.assign({ key: k }, v.items[k]));
  }
  function put(key, item) {
    if (!session()) return false;
    const v = cache();
    const old = v.items[key];
    const nx = Object.assign({}, item, { updatedAt: nowIso() });
    if (old) { const a = Object.assign({}, old), b = Object.assign({}, nx); delete a.updatedAt; delete b.updatedAt; if (canon(a) === canon(b)) return false; }
    v.items[key] = nx; delete v.deleted[key];
    ls.set('konto-cache', v);
    sync().catch(() => {});
    return true;
  }
  function remove(key) {
    if (!session()) return false;
    const v = cache();
    if (!v.items[key]) return false;
    delete v.items[key]; v.deleted[key] = nowIso();
    ls.set('konto-cache', v);
    sync().catch(() => {});
    return true;
  }

  /* ---------- Face ID (Passkey mit PRF) ---------- */
  const PRF_SALT = te('anwendungssammlung-konto-prf-v1');
  const rpId = () => location.hostname;
  async function passkeySupported() {
    try {
      if (!window.PublicKeyCredential || !navigator.credentials || location.protocol !== 'https:') return false;
      if (PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable && !(await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable())) return false;
      if (PublicKeyCredential.getClientCapabilities) { const c = await PublicKeyCredential.getClientCapabilities(); if (c && c['extension:prf'] === false) return false; }
      return true;
    } catch (e) { return false; }
  }
  const prfOut = cred => { const x = cred.getClientExtensionResults && cred.getClientExtensionResults(); return x && x.prf && x.prf.results && x.prf.results.first ? new Uint8Array(x.prf.results.first) : null; };
  async function enablePasskey() {
    const s = session(); if (!s) throw new Error('Nicht angemeldet.');
    const cred = await navigator.credentials.create({ publicKey: {
      rp: { name: 'Anwendungssammlung', id: rpId() },
      user: { id: crypto.getRandomValues(new Uint8Array(16)), name: s.user, displayName: s.user },
      challenge: crypto.getRandomValues(new Uint8Array(32)),
      pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
      authenticatorSelection: { residentKey: 'required', userVerification: 'required', authenticatorAttachment: 'platform' },
      extensions: { prf: { eval: { first: PRF_SALT } } },
    } });
    let out = prfOut(cred);
    if (!out) {   // manche Geräte liefern das Ergebnis erst bei der ersten Anmeldung
      const a = await navigator.credentials.get({ publicKey: { challenge: crypto.getRandomValues(new Uint8Array(32)), rpId: rpId(), userVerification: 'required',
        allowCredentials: [{ type: 'public-key', id: cred.rawId }], extensions: { prf: { eval: { first: PRF_SALT } } } } });
      out = prfOut(a);
    }
    if (!out) throw new Error('Dieses Gerät unterstützt die Anmeldung per Face ID für Web-Apps noch nicht (nötig: iOS 18 oder neuer).');
    const secret = b64e(out), pk = await pkKeys(secret);
    const r = await api('POST', '', null, { id: pk.id, auth: pk.auth, data: await encrypt(pk.enc, { user: s.user, master: s.master }), rev: 1 });
    if (r.status !== 200 && r.status !== 400) throw fail(r);
    const v = cache(); const cid = b64e(new Uint8Array(cred.rawId));
    v.passkeys[cid] = { secret, createdAt: nowIso(), device: (navigator.platform || 'Gerät') };
    ls.set('konto-cache', v); await sync();
    ls.set('konto-passkey', true);
    return true;
  }
  async function loginWithPasskey() {
    const a = await navigator.credentials.get({ publicKey: { challenge: crypto.getRandomValues(new Uint8Array(32)), rpId: rpId(), userVerification: 'required',
      extensions: { prf: { eval: { first: PRF_SALT } } } }, mediation: 'optional' });
    const out = prfOut(a);
    if (!out) throw new Error('Face ID hat keinen Schlüssel geliefert. Bitte mit Passwort anmelden.');
    const pk = await pkKeys(b64e(out));
    const r = await api('GET', '/' + pk.id, pk.auth);
    if (r.status === 404) throw new Error('Für diesen Passkey ist kein Konto hinterlegt. Bitte mit Passwort anmelden und Face ID neu einrichten.');
    if (r.status !== 200 || !r.json) throw fail(r);
    const d = await decrypt(pk.enc, r.json.data);
    const f = await fetchVault(d.master);
    if (!f) throw new Error('Konto nicht gefunden.');
    ls.set('konto', { user: d.user, master: d.master, at: nowIso() });
    ls.set('konto-cache', f.vault);
    emit();
    return { ok: true };
  }

  /* ---------- Profil, Postfach, Einladungen ---------- */
  const INVITE_DAYS = 7;
  async function nameKeys(user, salt) {
    const h = new Uint8Array(await crypto.subtle.digest('SHA-256', te(salt + '|' + normUser(user))));
    return keys(b64e(h), salt);
  }
  const profileKeys = user => nameKeys(user, 'konto-profil-v1');
  const inboxKeys = user => nameKeys(user, 'konto-postfach-v1');
  const ECDH = { name: 'ECDH', namedCurve: 'P-256' }, ECDSA = { name: 'ECDSA', namedCurve: 'P-256' };
  async function readRec(k) {
    const r = await api('GET', '/' + k.id, k.auth);
    if (r.status === 404) return null;
    if (r.status !== 200 || !r.json) throw fail(r);
    return { data: await decrypt(k.enc, r.json.data), rev: +r.json.rev || 0 };
  }
  /* Schlüsselpaare anlegen (einmal pro Konto) und Profil + Postfach veröffentlichen */
  async function ensureProfile() {
    const s = session(); if (!s) return null;
    let v = cache();
    if (!v.keys) {
      const e = await crypto.subtle.generateKey(ECDH, true, ['deriveBits']);
      const g = await crypto.subtle.generateKey(ECDSA, true, ['sign', 'verify']);
      v.keys = { createdAt: nowIso(), encPub: await crypto.subtle.exportKey('jwk', e.publicKey), encPriv: await crypto.subtle.exportKey('jwk', e.privateKey),
        sigPub: await crypto.subtle.exportKey('jwk', g.publicKey), sigPriv: await crypto.subtle.exportKey('jwk', g.privateKey) };
      ls.set('konto-cache', v);
      v = await sync();
    }
    const pk = await profileKeys(s.user), cur = await readRec(pk);
    const prof = { user: s.user, encPub: v.keys.encPub, sigPub: v.keys.sigPub };
    if (!cur || canon(cur.data) !== canon(prof)) await upsert(pk, prof);
    const ik = await inboxKeys(s.user);
    if (!(await readRec(ik))) await upsert(ik, { entries: {} });
    return prof;
  }
  /* Gibt es ein Konto mit genau diesem Namen? → Profil (mit richtiger Schreibweise) oder null */
  async function findUser(name) { const p = await readRec(await profileKeys(String(name || '').trim())); return p ? p.data : null; }
  async function sealFor(prof, payload) {
    const eph = await crypto.subtle.generateKey(ECDH, true, ['deriveBits']);
    const pub = await crypto.subtle.importKey('jwk', prof.encPub, ECDH, false, []);
    const bits = await crypto.subtle.deriveBits({ name: 'ECDH', public: pub }, eph.privateKey, 256);
    const key = (await keys(b64e(new Uint8Array(bits)), 'konto-einladung-v1')).enc;
    return { epk: await crypto.subtle.exportKey('jwk', eph.publicKey), box: await encrypt(key, payload) };
  }
  async function openSealed(sealed, encPriv) {
    const priv = await crypto.subtle.importKey('jwk', encPriv, ECDH, false, ['deriveBits']);
    const pub = await crypto.subtle.importKey('jwk', sealed.epk, ECDH, false, []);
    const bits = await crypto.subtle.deriveBits({ name: 'ECDH', public: pub }, priv, 256);
    return decrypt((await keys(b64e(new Uint8Array(bits)), 'konto-einladung-v1')).enc, sealed.box);
  }
  async function signBody(body, sigPriv) {
    const k = await crypto.subtle.importKey('jwk', sigPriv, ECDSA, false, ['sign']);
    return b64e(new Uint8Array(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, k, te(canon(body)))));
  }
  async function verifyBody(body, sig, sigPub) {
    try { const k = await crypto.subtle.importKey('jwk', sigPub, ECDSA, false, ['verify']); return await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, k, b64d(sig), te(canon(body))); }
    catch (e) { return false; }
  }
  async function editInbox(user, fn) {
    const ik = await inboxKeys(user);
    for (let i = 0; i < 3; i++) {
      const cur = await readRec(ik);
      if (!cur) throw new Error('Postfach nicht gefunden');
      const entries = Object.assign({}, cur.data.entries || {});
      const now = nowIso();
      for (const k in entries) if ((entries[k].expiresAt || '') < now) delete entries[k];   // Abgelaufenes aufräumen
      if (fn(entries) === false) return;
      const u = await api('PATCH', '/' + ik.id, ik.auth, { data: await encrypt(ik.enc, { entries }), rev: cur.rev + 1 });
      if (u.status === 200) return;
    }
    throw new Error('Postfach gerade nicht beschreibbar');
  }
  /* Einladung senden: item = {app, id, secret, label} (wie im Schlüsselbund) */
  async function invite(toName, key, item, days) {
    const s = session(); if (!s) throw new Error('Bitte zuerst anmelden.');
    await ensureProfile();
    const prof = await findUser(toName);
    if (!prof) { const e = new Error(`Kein Konto „${String(toName).trim()}“ gefunden. Stimmt die Schreibweise?`); e.notFound = true; throw e; }
    if (normUser(prof.user) === normUser(s.user)) throw new Error('Du kannst dich nicht selbst einladen.');
    const iid = b64e(crypto.getRandomValues(new Uint8Array(12)));
    const createdAt = nowIso(), expiresAt = new Date(Date.now() + (days || INVITE_DAYS) * 864e5).toISOString();
    const body = { iid, from: s.user, to: prof.user, key, item, createdAt, expiresAt };
    const sig = await signBody(body, cache().keys.sigPriv);
    const sealed = await sealFor(prof, { body, sig });
    await editInbox(prof.user, e => { e[iid] = { sealed, expiresAt }; });
    const v = cache(); v.sent[iid] = { to: prof.user, app: item.app, label: item.label || '', key, createdAt, expiresAt };
    ls.set('konto-cache', v); sync().catch(() => {});
    return { iid, to: prof.user, expiresAt };
  }
  async function withdraw(iid) {
    const v = cache(), x = v.sent[iid]; if (!x) return false;
    try { await editInbox(x.to, e => { if (!e[iid]) return false; delete e[iid]; }); } catch (e) { if (!/Postfach nicht gefunden/.test(e.message)) throw e; }
    delete v.sent[iid]; v.deleted['sent:' + iid] = nowIso(); ls.set('konto-cache', v); sync().catch(() => {});
    return true;
  }
  /* gesendete Einladungen mit Stand: offen | abgelaufen | erledigt (angenommen/abgelehnt) */
  async function sentList(app) {
    const v = cache(), now = nowIso(), out = [];
    const byUser = {};
    for (const iid in v.sent) { const x = v.sent[iid]; if (app && x.app !== app) continue; (byUser[x.to] = byUser[x.to] || []).push(Object.assign({ iid }, x)); }
    for (const u in byUser) {
      let entries = null;
      try { const r = await readRec(await inboxKeys(u)); entries = r ? r.data.entries || {} : {}; } catch (e) { entries = null; }
      byUser[u].forEach(x => out.push(Object.assign(x, { status: x.expiresAt < now ? 'abgelaufen' : entries === null ? 'unbekannt' : entries[x.iid] ? 'offen' : 'erledigt' })));
    }
    return out.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
  function forget(iid) { const v = cache(); if (!v.sent[iid]) return; delete v.sent[iid]; v.deleted['sent:' + iid] = nowIso(); ls.set('konto-cache', v); sync().catch(() => {}); }
  /* eigene Einladungen lesen (geprüft: Signatur des Absenders, nicht abgelaufen) */
  async function inbox() {
    const s = session(); if (!s) return [];
    await ensureProfile();
    const r = await readRec(await inboxKeys(s.user)); if (!r) return [];
    const now = nowIso(), keysV = cache().keys, out = [];
    for (const iid in r.data.entries || {}) {
      const e = r.data.entries[iid]; if ((e.expiresAt || '') < now) continue;
      try {
        const { body, sig } = await openSealed(e.sealed, keysV.encPriv);
        if (body.iid !== iid || normUser(body.to) !== normUser(s.user) || body.expiresAt < now) continue;
        const sender = await findUser(body.from);
        if (!sender || !(await verifyBody(body, sig, sender.sigPub))) continue;
        out.push(Object.assign({}, body, { from: sender.user }));
      } catch (err) { /* nicht für uns / beschädigt */ }
    }
    ls.set('konto-inbox', out.map(x => ({ iid: x.iid, from: x.from, app: x.item.app, label: x.item.label, expiresAt: x.expiresAt })));
    emit();
    return out.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
  async function accept(inv) {
    put(inv.key, Object.assign({}, inv.item, { invitedBy: inv.from }));
    await editInbox(user(), e => { if (!e[inv.iid]) return false; delete e[inv.iid]; });
    await sync().catch(() => {});
    inbox().catch(() => {});
  }
  async function decline(inv) { await editInbox(user(), e => { if (!e[inv.iid]) return false; delete e[inv.iid]; }); inbox().catch(() => {}); }
  const user = () => (session() || {}).user || '';

  return {
    session, user, loggedIn: () => !!session(), state: () => ls.get('konto-state') || {},
    login, register, logout, changePassword, sync, items, put, remove, onChange: fn => listeners.add(fn),
    passkeySupported, enablePasskey, loginWithPasskey, hasPasskey: () => Object.keys(cache().passkeys).length > 0,
    setRecovery, removeRecovery, getQuestion, recover,
    ensureProfile, findUser, invite, withdraw, sentList, forget, inbox, accept, decline, inviteDays: INVITE_DAYS,
    inboxCount: () => (ls.get('konto-inbox') || []).filter(x => x.expiresAt >= nowIso()).length, hasRecovery: () => !!cache().recovery, recoveryQuestion: () => (cache().recovery || {}).question || '',
    _merge: merge,
    _forge: async (prof, body, sig) => { const sealed = await sealFor(prof, { body, sig }); await editInbox(prof.user, e => { e[body.iid] = { sealed, expiresAt: body.expiresAt }; }); },
  };
})();
