# Rezept-Rotation – Spezifikation (Arbeitstitel)

> Version 1.0 · Stand 21.09.2026 · Sprache der Anwendung: Deutsch

---

## 0. Hinweise für den umsetzenden Agenten

- Dieses Dokument ist die verbindliche Grundlage. Lies es vollständig, bevor du Code schreibst.
- Setze die Ausbaustufen (Abschnitt 3) **in Reihenfolge** um. Jede Stufe muss für sich lauffähig und nutzbar sein. Phase 4 nur nach Rückfrage.
- Das Datenmodell (Abschnitt 4) wird **von Anfang an vollständig** angelegt. Felder späterer Stufen sind optional und werden in der UI erst in der jeweiligen Stufe sichtbar.
- Die Kernlogik (Abschnitt 5: Tageberechnung, Rotation, Wochenplan, Einkaufsliste) wird als **reine, DB-unabhängige Funktionen** implementiert (`/src/domain`) und mit den Tests aus Abschnitt 10 abgesichert. Zufall kommt aus einem injizierbaren, seedbaren Zufallsgenerator.
- Bei Unklarheiten gelten die Annahmen aus Abschnitt 11. Abweichungen im `README.md` dokumentieren.
- Alle UI-Texte auf Deutsch. Datumsformat `TT.MM.JJJJ`, Dezimalkomma, Woche beginnt Montag, Zeitzone `Europe/Berlin`.

---

## 1. Ziel & Kontext

Eine private Web-Anwendung zur Verwaltung einer Rezeptsammlung („Fundus“) mit Rotationsprinzip: Alle aktiven Rezepte werden einmal durchgekocht, bevor sich eines wiederholt. Daraus entstehen Einzelvorschläge und Wochenpläne inklusive Einkaufsliste, bei der Marktware separat ausgegeben wird.

Kernanforderungen:

1. Rezepte anlegen – anfangs nur mit Namen, später mit Zutaten, Anleitung und Bildern.
2. Nutzung auf mehreren Geräten (Handy, Tablet, PC) mit gemeinsamem Datenstand.
3. Rotation: Jedes aktive Rezept kommt pro Durchlauf dran, bevor ein neuer Durchlauf beginnt.
4. Rezepte können aus der Rotation genommen werden, bleiben aber im Fundus.
5. Gewichtung: Ein Rezept kann mehrfach pro Durchlauf vorkommen (z. B. Spaghetti Bolognese ×2).
6. Portionen: Ein Gericht mit 6 Portionen belegt bei 2 Portionen/Tag 3 aufeinanderfolgende Tage.
7. Wochenplanung mit Einkaufsliste; Marktzutaten als separate, einfache Liste.

---

## 2. Begriffe

| Begriff | Bedeutung |
|---|---|
| Fundus | Alle gespeicherten Rezepte (aktive und pausierte). |
| In Rotation | Rezept nimmt an der Rotation teil (`inRotation = true`). Pausierte Rezepte bleiben im Fundus. |
| Durchlauf (Zyklus) | Eine vollständige Runde über alle aktiven Rezepte inkl. Gewichtung. |
| Gewichtung | Wie oft ein Rezept pro Durchlauf vorkommt (1–5). |
| Rotationseintrag | Ein einzelnes Vorkommen eines Rezepts in einem Durchlauf. |
| Portionen (Rezept) | Wie viele Portionen eine Zubereitung ergibt. |
| Portionen pro Tag | Globale Einstellung: wie viele Portionen der Haushalt pro Tag isst. |
| Block | Zusammenhängende Plantage eines Gerichts (Kochtag + Resttage). |
| Kochtag / Resttag | Erster Tag eines Blocks (es wird gekocht) / Folgetage (Reste). |
| Marktzutat | Zutat mit Einkaufsort `MARKT` (Wochenmarkt: Obst, Gemüse, Kräuter, Eier). |
| Vorrat | Zutaten, die üblicherweise im Haus sind (Salz, Öl, Gewürze). |

---

## 3. Ausbaustufen

### Phase 1 – MVP: Namen & Rotation

- Login mit einem gemeinsamen Haushaltskonto, Nutzung auf mehreren Geräten
- Rezepte: Name, In Rotation (an/aus), Gewichtung, Portionen, optionaler Tage-Override
- Schnellerfassung: Name eintippen + Enter = Rezept angelegt; mehrzeiliges Einfügen (eine Zeile = ein Rezept)
- Rotation inkl. Anzeige des aktuellen Durchlaufs
- Vorschlagsmodus „Was koche ich als Nächstes?“
- Wochenplan (automatisch füllen, manuell ändern, Tage sperren, übernehmen)
- Einstellungen, JSON-Export/-Import
- Installierbar als PWA

**Fertig, wenn:** Tests T1–T9 grün, App per `docker compose up` startbar, ein auf Gerät A angelegtes Rezept erscheint auf Gerät B.

### Phase 2 – Zutaten & Einkaufsliste

- Zutaten-Stammdaten (Name, Kategorie, Einkaufsort, Standardeinheit)
- Zutaten je Rezept (Menge, Einheit, Notiz) mit Autovervollständigung
- Einkaufsliste für einen Zeitraum (Standard: angezeigte Woche), aufgeteilt in **Markt / Supermarkt / Vorrat prüfen**
- Abhaken, als Text kopieren, teilen (Web Share API), drucken
- Manuelle Zusatzartikel auf der Einkaufsliste

**Fertig, wenn:** Tests T10–T12 grün.

### Phase 3 – Anleitung, Bilder, Komfort

- Anleitung (Markdown, nummerierte Schritte), Zubereitungszeit, Notizen, Tags
- Bilder hochladen (mehrere, eines als Titelbild), serverseitig verkleinert
- Suche und Filter im Fundus (Name, Tag, Zutat, Status)
- Kochansicht: Anleitung groß, Bildschirm bleibt an (Screen Wake Lock API)

### Phase 4 – Optional (nur auf ausdrückliche Anfrage)

- Saisonalität (Rezept nur in bestimmten Monaten in Rotation)
- Mengen skalieren (z. B. 4 statt 6 Portionen kochen)
- Mehrere Mahlzeiten pro Tag (Mittag/Abend)
- Rezept-Import per URL (schema.org/Recipe)
- Mehrere Benutzer mit eigenen Logins
- Statistik („zuletzt gekocht“, „am häufigsten gekocht“)

---

## 4. Datenmodell

Alle Tabellen haben `id` (UUID), `createdAt`, `updatedAt` und `householdId` (vorbereitet für mehrere Haushalte; in Phase 1–3 existiert genau einer).

### 4.1 Recipe (Rezept)

| Feld | Typ | Pflicht | Standard | Phase | Beschreibung |
|---|---|---|---|---|---|
| name | string (1–120) | ja | – | 1 | Eindeutig je Haushalt (Groß-/Kleinschreibung egal) |
| inRotation | boolean | ja | true | 1 | false = pausiert |
| weight | int 1–5 | ja | 1 | 1 | Vorkommen pro Durchlauf |
| servings | int ≥ 1 | ja | = portionsPerDay | 1 | Portionen pro Zubereitung |
| daysOverride | int ≥ 1 / null | nein | null | 1 | Überschreibt die berechneten Tage |
| sortOrder | int | ja | fortlaufend | 1 | Für Rotationsmodus `FIXED` |
| notes | text | nein | – | 1 | Freitext |
| instructions | text (Markdown) | nein | – | 3 | Anleitung |
| prepTimeMinutes | int | nein | – | 3 | Zubereitungszeit |
| tags | string[] | nein | [] | 3 | z. B. „vegetarisch“, „schnell“ |
| archivedAt | datetime / null | nein | null | 1 | Gelöscht (Soft Delete); bestehende Planeinträge bleiben sichtbar |

### 4.2 Ingredient (Zutat, Stammdaten) – Phase 2

| Feld | Typ | Pflicht | Beschreibung |
|---|---|---|---|
| name | string | ja | Eindeutig je Haushalt, Singular („Zwiebel“) |
| category | enum `Category` | ja | Gruppierung im Supermarkt |
| shoppingSource | `MARKT` \| `SUPERMARKT` \| `VORRAT` | ja | Standard aus Kategorie (Tabelle unten), pro Zutat änderbar |
| defaultUnit | enum `Unit` | ja | Vorbelegung im Zutateneditor |

`Category` – Reihenfolge der Tabelle = Sortierung im Supermarkt-Abschnitt:

| Category | Anzeige | Standard-Einkaufsort |
|---|---|---|
| GEMUESE | Gemüse | MARKT |
| OBST | Obst | MARKT |
| KRAEUTER | Frische Kräuter | MARKT |
| EIER | Eier | MARKT |
| BACKWAREN | Brot & Backwaren | SUPERMARKT |
| FLEISCH | Fleisch & Wurst | SUPERMARKT |
| FISCH | Fisch | SUPERMARKT |
| MILCHPRODUKTE | Milchprodukte | SUPERMARKT |
| KAESE | Käse | SUPERMARKT |
| TROCKENWAREN | Nudeln, Reis & Hülsenfrüchte | SUPERMARKT |
| KONSERVEN | Konserven & Gläser | SUPERMARKT |
| TIEFKUEHL | Tiefkühl | SUPERMARKT |
| SONSTIGES | Sonstiges | SUPERMARKT |
| GEWUERZE | Gewürze | VORRAT |
| OELE_ESSIG | Öl & Essig | VORRAT |

`Unit` mit Anzeige (Singular/Plural):

| Unit | Anzeige | Dimension |
|---|---|---|
| G, KG | g, kg | MASS (Basis g) |
| ML, L | ml, l | VOLUME (Basis ml) |
| STUECK | Stück | eigene |
| EL, TL | EL, TL | eigene (keine Umrechnung in ml) |
| PRISE | Prise / Prisen | eigene |
| BUND | Bund | eigene |
| ZEHE | Zehe / Zehen | eigene |
| DOSE | Dose / Dosen | eigene |
| GLAS | Glas / Gläser | eigene |
| PACKUNG | Packung / Packungen | eigene |
| SCHEIBE | Scheibe / Scheiben | eigene |

### 4.3 RecipeIngredient (Zutat im Rezept) – Phase 2

| Feld | Typ | Pflicht | Beschreibung |
|---|---|---|---|
| recipeId | UUID | ja | |
| ingredientId | UUID | ja | |
| quantity | decimal / null | nein | null = „nach Geschmack“ |
| unit | Unit / null | nein | null nur wenn quantity null |
| note | string | nein | z. B. „fein gewürfelt“ |
| sortOrder | int | ja | |

Mengen beziehen sich immer auf die **gesamte Zubereitung** (= `servings` Portionen).

### 4.4 RecipeImage – Phase 3

| Feld | Typ | Beschreibung |
|---|---|---|
| recipeId | UUID | |
| fileKey | string | Dateiname im Bildverzeichnis |
| width, height | int | nach Verkleinerung |
| sortOrder | int | |
| isCover | boolean | genau ein Titelbild pro Rezept |

### 4.5 Settings (eine Zeile je Haushalt)

| Feld | Typ | Standard | Beschreibung |
|---|---|---|---|
| portionsPerDay | int ≥ 1 | 2 | Portionen, die pro Tag gegessen werden |
| roundingMode | `FLOOR` \| `CEIL` | FLOOR | Rundung der Tageberechnung (5.1) |
| rotationMode | `SHUFFLE` \| `FIXED` | SHUFFLE | Jeder Durchlauf neu gemischt / feste Reihenfolge nach `sortOrder` |
| marketListShowQuantities | boolean | true | Mengen auf der Marktliste anzeigen |

### 4.6 RotationEntry (Rotationseintrag)

| Feld | Typ | Beschreibung |
|---|---|---|
| cycleNumber | int ≥ 1 | Durchlauf |
| recipeId | UUID | |
| occurrence | int | 1 … weight |
| position | int | Sortierschlüssel im Durchlauf (Schrittweite 1000, bei Bedarf neu nummerieren) |
| status | `PENDING` \| `PLANNED` \| `DONE` \| `SKIPPED` | |

Statusübergänge:

```
PENDING ──(in Plan übernommen)──▶ PLANNED ──(Kochtag vorbei / „gekocht“)──▶ DONE
   ▲                                  │
   └──────(Planeintrag gelöscht)──────┘

PENDING ──(„Diesmal auslassen“)──▶ SKIPPED
```

`PLANNED`, `DONE` und `SKIPPED` gelten als verbraucht.

### 4.7 PlanEntry (Planeintrag – höchstens einer pro Datum)

| Feld | Typ | Beschreibung |
|---|---|---|
| date | date (`YYYY-MM-DD`) | eindeutig je Haushalt |
| type | `COOK` \| `LEFTOVER` \| `BLOCKED` | Kochtag, Resttag, gesperrter Tag |
| recipeId | UUID / null | null bei BLOCKED |
| blockId | UUID / null | verbindet Koch- und Resttage eines Gerichts |
| dayIndex, dayCount | int | z. B. 2 und 3 → „Reste 2/3“ |
| rotationEntryId | UUID / null | null bei manueller Auswahl außerhalb der Rotation |
| source | `ROTATION` \| `MANUAL` | |
| locked | boolean | Gilt für den ganzen Block; wird beim automatischen Füllen nicht überschrieben |
| status | `PLANNED` \| `DONE` | |
| note | string | z. B. „Auswärts essen“ bei BLOCKED |

### 4.8 ShoppingListState – Phase 2

| Feld | Typ | Beschreibung |
|---|---|---|
| from, to | date | Zeitraum der Liste |
| checkedKeys | string[] | abgehakte Positionen |
| extraItems | `{ text, checked }[]` | manuelle Zusatzartikel |

Positionsschlüssel: `ingredientId|dimension` (dimension = `MASS`, `VOLUME`, Unit-Name oder `NONE`).

### 4.9 Household (Login)

| Feld | Typ | Beschreibung |
|---|---|---|
| name | string | z. B. „Familie Muster“ |
| passwordHash | string | argon2id |

---

## 5. Kernlogik

### 5.1 Tage pro Gericht

```ts
function daysFor(recipe: Recipe, settings: Settings): number {
  if (recipe.daysOverride) return recipe.daysOverride;
  const raw = recipe.servings / settings.portionsPerDay;
  const days = settings.roundingMode === 'FLOOR' ? Math.floor(raw) : Math.ceil(raw);
  return Math.max(1, days);
}
```

Beispiele bei `portionsPerDay = 2`:

| Rezept | Portionen | FLOOR | CEIL |
|---|---|---|---|
| Tortillas mit Chili sin Carne | 6 | 3 | 3 |
| Spaghetti Bolognese | 4 | 2 | 2 |
| Eintopf | 5 | 2 (UI-Hinweis: 1 Portion Rest) | 3 (UI-Hinweis: letzter Tag nur 1 Portion) |
| Pfannkuchen | 2 | 1 | 1 |
| Omelett | 1 | 1 | 1 |

### 5.2 Rotation

**Regeln**

- **R1** Jedes Rezept mit `inRotation = true` (nicht archiviert) erscheint pro Durchlauf genau `weight`-mal.
- **R2** Pausierte und archivierte Rezepte erscheinen in keinem neuen Durchlauf.
- **R3** Ein neuer Durchlauf entsteht erst, wenn der laufende keinen `PENDING`-Eintrag mehr hat. Er wird bei Bedarf automatisch erzeugt (z. B. wenn der Wochenplan mehr Gerichte braucht) und sofort gespeichert.
- **R4** Mehrfachvorkommen eines Rezepts werden gleichmäßig über den Durchlauf verteilt.
- **R5** Dasselbe Rezept steht nie direkt hintereinander – auch nicht über die Durchlaufgrenze –, sofern das möglich ist.
- **R6** Die Rotation zählt Gerichte, nicht Tage: Chili sin Carne über 3 Tage ist **ein** Eintrag.
- **R7** Offene Einträge werden nach `(cycleNumber, position)` abgearbeitet.

**Durchlauf erzeugen**

```ts
type Rng = () => number; // [0, 1); in Tests mit festem Seed

function buildCycle(recipes: Recipe[], settings: Settings, cycleNumber: number,
                    prevLastRecipeId: string | null, rng: Rng): RotationEntry[] {
  const active = recipes
    .filter(r => r.inRotation && !r.archivedAt)
    .sort((a, b) => a.sortOrder - b.sortOrder);
  const n = active.length;

  const items = active.flatMap((r, idx) =>
    Array.from({ length: r.weight }, (_, k) => {
      // SHUFFLE: zufälliger Versatz, FIXED: deterministischer Versatz aus sortOrder
      const u = settings.rotationMode === 'SHUFFLE' ? rng() : (idx + 0.5) / n;
      // Das k-te Vorkommen landet im k-ten Abschnitt des Durchlaufs → R4
      return { recipeId: r.id, occurrence: k + 1, key: (k + u) / r.weight };
    }));

  items.sort((a, b) => a.key - b.key);
  repairAdjacency(items, prevLastRecipeId); // R5

  return items.map((it, i) => ({
    cycleNumber, recipeId: it.recipeId, occurrence: it.occurrence,
    position: (i + 1) * 1000, status: 'PENDING',
  }));
}

function repairAdjacency(items: { recipeId: string }[], prevLastRecipeId: string | null) {
  for (let i = 0; i < items.length; i++) {
    const prev = i === 0 ? prevLastRecipeId : items[i - 1].recipeId;
    if (items[i].recipeId !== prev) continue;
    const j = items.findIndex((x, idx) => idx > i && x.recipeId !== prev);
    if (j === -1) break;               // nicht vermeidbar (z. B. nur ein Rezept aktiv)
    const [moved] = items.splice(j, 1);
    items.splice(i, 0, moved);
  }
}
```

**Operationen**

| Operation | Auslöser in der UI | Wirkung |
|---|---|---|
| `next(n, exclude)` | Vorschlag, Wochenplan | Die nächsten n `PENDING`-Einträge; erzeugt bei Bedarf Folgedurchläufe |
| `plan(entry)` | „Übernehmen“, „Plan übernehmen“ | `PENDING → PLANNED` |
| `complete(entry)` | automatisch, sobald der Kochtag vor heute liegt; oder „Gekocht“ | `PLANNED → DONE` |
| `postpone(entry)` | „Später“ | ans Ende des eigenen Durchlaufs (`position = max + 1000`), bleibt `PENDING` |
| `skip(entry)` | „Diesmal auslassen“ | `PENDING → SKIPPED` |
| `release(entry)` | Planeintrag gelöscht / ersetzt | `PLANNED → PENDING`, `position = kleinste Position im Durchlauf − 1000` → ist wieder nächster Vorschlag |
| `manualPick(recipe)` | „Selbst wählen“ | Hat das Rezept einen `PENDING`-Eintrag in einem offenen Durchlauf, wird der erste davon `PLANNED`. Sonst Planeintrag mit `source = MANUAL` ohne Rotationsbezug; Rotation bleibt unverändert. |
| `reset()` | „Rotation neu starten“ (mit Bestätigung) | alle `PENDING`-Einträge löschen, neuen Durchlauf erzeugen |

**Änderungen während eines laufenden Durchlaufs** (gilt für jeden Durchlauf, der noch `PENDING`-Einträge hat):

| Änderung | Wirkung |
|---|---|
| Rezept pausiert oder archiviert | alle `PENDING`-Einträge des Rezepts löschen; `PLANNED` bleibt (Nutzer entscheidet im Plan) |
| Neues Rezept / Rezept reaktiviert | `weight − (Einträge des Rezepts in diesem Durchlauf, egal welcher Status)` neue `PENDING`-Einträge an zufälligen Positionen zwischen den offenen Einträgen einfügen, R5 beachten |
| Gewichtung um d erhöht | d neue `PENDING`-Einträge wie oben einfügen |
| Gewichtung um d verringert | bis zu d `PENDING`-Einträge des Rezepts entfernen (die hintersten); verbrauchte bleiben |

**Beispiel** – Fundus aus Anhang A:

- Spaghetti Bolognese (×2), Tortillas mit Chili sin Carne, Gemüsecurry, Pfannkuchen, Linsensuppe, Kürbissuppe (pausiert)
- → Durchlauf mit 6 Einträgen, z. B.:
  1. Spaghetti Bolognese (1/2)
  2. Gemüsecurry
  3. Tortillas mit Chili sin Carne
  4. Linsensuppe
  5. Spaghetti Bolognese (2/2)
  6. Pfannkuchen
- Durchlauf 2 wird neu gemischt, beginnt aber nicht mit Pfannkuchen. Kürbissuppe taucht nie auf, bis sie wieder aktiviert wird.

### 5.3 Vorschlagsmodus „Was koche ich als Nächstes?“

- Zeigt `next(1)` groß an: Name, Titelbild (ab Phase 3), Portionen, „reicht für X Tage“.
- Darunter: Vorschau der nächsten 3–5 Einträge und Fortschritt, z. B. „Durchlauf 3 · 4 von 7 Gerichten“.
- Aktionen:
  - **Übernehmen** → Block ab Startdatum anlegen (Standard: heute; falls belegt: nächster freier Tag; Datum änderbar) → `plan()`
  - **Später** → `postpone()`
  - **Diesmal auslassen** → `skip()`
  - **Selbst wählen** → Liste aller Rezepte (aktive zuerst) → `manualPick()`

### 5.4 Wochenplan

Ansicht einer Kalenderwoche (Mo–So) mit Navigation vor/zurück. Jeder Tag zeigt das Gericht und ein Badge („Kochtag“, „Reste 2/3“, „Gesperrt: Auswärts essen“) sowie ein Schloss-Symbol bei fixierten Blöcken.

**„Woche automatisch füllen“**

1. Bestehen bleiben: gesperrte Tage (`BLOCKED`), fixierte Blöcke (`locked`), Resttage von Blöcken, die vor der Woche begonnen haben (Übertrag), sowie Tage vor heute. Alle übrigen Einträge der Woche werden entfernt und ihre Rotationseinträge per `release()` freigegeben.
2. Freie Tage = Tage der Woche ohne Eintrag, ab heute.
3. Solange ein freier Tag existiert: nächsten `PENDING`-Eintrag holen und einen Block mit `daysFor()` Tagen auf die nächsten freien Tage legen. Belegte oder gesperrte Tage werden übersprungen (die Reste rutschen weiter). Reicht ein Block über Sonntag hinaus, werden die Resttage in der Folgewoche angelegt (Übertrag).
4. Das Ergebnis ist ein **Entwurf** (noch nicht gespeichert, Rotationsstatus unverändert; benötigte Folgedurchläufe dürfen bereits erzeugt werden). Im Entwurf kann der Nutzer:
   - einen Tag „tauschen“ → nächster Rotationseintrag; der ersetzte bleibt vorne in der Warteschlange
   - Blöcke per Drag & Drop verschieben
   - Tage sperren (mit Notiz)
   - Gerichte selbst wählen
5. **Plan übernehmen** speichert alle Einträge und setzt die Rotationseinträge auf `PLANNED`. Änderungen an einem bereits übernommenen Plan wirken sofort (ersetzen = `release()` + `plan()`).

```ts
function fillWeek(week: Date[], existing: Map<string, PlanEntry>, queue: RotationQueue,
                  recipes: Map<string, Recipe>, settings: Settings): DraftEntry[] {
  const occupied = new Set(existing.keys());      // alle belegten Daten, auch der Folgewoche
  const drafts: DraftEntry[] = [];
  const used = new Set<string>();
  const firstFree = () => week.find(d => !occupied.has(iso(d)) && d >= today());

  for (let start = firstFree(); start; start = firstFree()) {
    const entry = queue.next({ exclude: used });   // erzeugt ggf. neuen Durchlauf
    if (!entry) break;                             // keine aktiven Rezepte
    used.add(entry.id);
    const recipe = recipes.get(entry.recipeId)!;
    const n = daysFor(recipe, settings);
    const dates = nextFreeDates(start, n, occupied); // darf über die Woche hinausgehen
    const blockId = uuid();
    dates.forEach((date, i) => {
      occupied.add(iso(date));
      drafts.push({
        date, type: i === 0 ? 'COOK' : 'LEFTOVER', recipeId: recipe.id, blockId,
        dayIndex: i + 1, dayCount: n, rotationEntryId: entry.id,
        source: 'ROTATION', locked: false,
      });
    });
  }
  return drafts;
}
```

**Beispiel** – KW 40, `portionsPerDay = 2`, `FLOOR`, Freitag gesperrt, Rotation wie in 5.2:

| Datum | Eintrag |
|---|---|
| Mo 28.09. | Spaghetti Bolognese – Kochtag (1/2) |
| Di 29.09. | Spaghetti Bolognese – Reste (2/2) |
| Mi 30.09. | Gemüsecurry – Kochtag (1/2) |
| Do 01.10. | Gemüsecurry – Reste (2/2) |
| Fr 02.10. | Gesperrt – Auswärts essen |
| Sa 03.10. | Tortillas mit Chili sin Carne – Kochtag (1/3) |
| So 04.10. | Tortillas mit Chili sin Carne – Reste (2/3) |
| Mo 05.10. (KW 41) | Tortillas mit Chili sin Carne – Reste (3/3), Übertrag |

Nach „Plan übernehmen“ sind Bolognese (1/2), Gemüsecurry und Tortillas `PLANNED`; der nächste Vorschlag ist Linsensuppe.

### 5.5 Einkaufsliste (Phase 2)

Eingabe: Zeitraum (Standard: angezeigte Woche). Es zählen nur **Kochtage** (`type = COOK`) im Zeitraum. Resttage lösen keinen Einkauf aus – ein Gericht mit Kochtag am Samstag gehört vollständig in diese Woche, auch wenn die Reste in die Folgewoche reichen.

**Algorithmus**

1. Alle `RecipeIngredient`s der Kochtage sammeln (ein zweimal geplantes Rezept zählt doppelt).
2. Einheiten normalisieren: Masse → g, Volumen → ml. Alle anderen Einheiten bilden eine eigene Dimension (EL wird nicht in ml umgerechnet).
3. Summieren je (Zutat, Dimension). Einträge ohne Menge („nach Geschmack“) → Zutat ohne Menge listen.
4. Anzeige: ab 1000 g → kg, ab 1000 ml → l, höchstens 2 Nachkommastellen, Dezimalkomma. Mehrere Dimensionen einer Zutat in einer Zeile mit „ + “ verbinden (z. B. „Paprika: 3 Stück + 200 g“). Plural der Einheit beachten („5 Zehen“, „3 Dosen“).
5. Aufteilen nach `shoppingSource`:
   - **Markt:** einfache, alphabetische Liste (Mengen per Einstellung ein-/ausblendbar)
   - **Supermarkt:** nach Kategorie gruppiert (Reihenfolge wie in 4.2), innerhalb alphabetisch, mit Mengen
   - **Vorrat prüfen:** eingeklappt, nur Namen, alphabetisch
6. Rezepte ohne hinterlegte Zutaten erzeugen einen Hinweis („Für ‚Linsensuppe‘ sind keine Zutaten hinterlegt.“).
7. Manuelle Zusatzartikel erscheinen unter „Sonstiges“.

Alphabetische Sortierung mit `localeCompare(…, 'de')`.

**API-Antwort (Ausschnitt)**

```json
{
  "from": "2026-09-28",
  "to": "2026-10-04",
  "recipes": ["Spaghetti Bolognese", "Gemüsecurry", "Tortillas mit Chili sin Carne"],
  "market": [
    { "key": "<ingredientId>|STUECK", "name": "Zwiebel", "amount": "4 Stück", "checked": false },
    { "key": "<ingredientId>|ZEHE", "name": "Knoblauch", "amount": "5 Zehen", "checked": false }
  ],
  "supermarket": [
    {
      "category": "BACKWAREN",
      "label": "Brot & Backwaren",
      "items": [
        { "key": "<ingredientId>|STUECK", "name": "Weizentortillas", "amount": "12 Stück", "checked": false }
      ]
    }
  ],
  "pantry": [
    { "key": "<ingredientId>|NONE", "name": "Salz", "checked": false }
  ],
  "extraItems": [],
  "warnings": []
}
```

Der vollständige Textexport für dieses Beispiel steht in Anhang B.

---

## 6. Oberfläche

Mobile-first. Untere Navigationsleiste mit vier Reitern: **Vorschlag · Woche · Einkauf · Rezepte**. Einstellungen über das Zahnrad oben rechts.

| Screen | Inhalt |
|---|---|
| Login / Ersteinrichtung | Beim ersten Start: Haushaltsname + Passwort festlegen. Danach Passwort-Login, Session 90 Tage. |
| Vorschlag | siehe 5.3 |
| Woche | siehe 5.4; Buttons „Woche füllen“, „Plan übernehmen“, „Einkaufsliste“ |
| Einkauf | Abschnitte Markt / Supermarkt / Vorrat prüfen mit Checkboxen; „Text kopieren“, „Teilen“, „Drucken“; Zeitraum wählbar; Zusatzartikel hinzufügen |
| Rezepte (Fundus) | Schnellerfassung oben; Liste mit Name, Schalter „In Rotation“, Gewichtung (Stepper ×1 … ×5), Portionen → Tage; Filter Alle / In Rotation / Pausiert; Suche |
| Rezept bearbeiten | Name, Portionen mit Live-Anzeige („= 3 Tage bei 2 Portionen/Tag“), Tage-Override, Gewichtung, In Rotation. Ab Phase 2: Zutateneditor (Zeile = Menge · Einheit · Zutat mit Autovervollständigung · Notiz; unbekannte Zutat inline mit Kategorie anlegen). Ab Phase 3: Anleitung, Bilder, Tags, Zeit. |
| Zutaten | Stammdatenliste; Kategorie und Einkaufsort änderbar; doppelte Zutaten zusammenführen |
| Rotation (unter Einstellungen) | aktueller Durchlauf als Liste mit Status; Aktionen „Später“, „Auslassen“, „Rotation neu starten“ |
| Einstellungen | Portionen pro Tag, Rundung, Rotationsmodus, Marktliste mit Mengen, Export/Import, Passwort ändern |

Schnellerfassung legt Rezepte mit Standardwerten an: `inRotation = true`, `weight = 1`, `servings = portionsPerDay`.

---

## 7. API

REST mit JSON. Alle Routen außer Einrichtung und Login erfordern eine gültige Session. Eingaben werden serverseitig validiert (zod).

| Methode | Pfad | Zweck |
|---|---|---|
| POST | `/api/auth/setup` | Ersteinrichtung (nur solange kein Haushalt existiert) |
| POST | `/api/auth/login` | Anmelden |
| POST | `/api/auth/logout` | Abmelden |
| GET | `/api/recipes?search=&status=all\|active\|paused` | Rezeptliste |
| POST | `/api/recipes` | Anlegen (Objekt oder Array für Mehrfach-Einfügen) |
| GET | `/api/recipes/:id` | Detail inkl. Zutaten und Bilder |
| PATCH | `/api/recipes/:id` | Ändern; löst ggf. Rotationsanpassung aus (5.2) |
| DELETE | `/api/recipes/:id` | Archivieren |
| POST | `/api/recipes/:id/images` | Bild hochladen (multipart) |
| PATCH / DELETE | `/api/recipes/:id/images/:imageId` | Titelbild/Reihenfolge ändern / löschen |
| GET | `/api/ingredients?search=` | Autovervollständigung |
| POST / PATCH / DELETE | `/api/ingredients[/:id]` | Pflege (Löschen nur, wenn unbenutzt) |
| POST | `/api/ingredients/:id/merge` | `{ targetId }` – in andere Zutat zusammenführen |
| GET | `/api/rotation?peek=5` | Durchlauf-Info + nächste Einträge |
| POST | `/api/rotation/entries/:id/accept` | `{ startDate }` – Block anlegen (Vorschlagsmodus) |
| POST | `/api/rotation/entries/:id/postpone` | Später |
| POST | `/api/rotation/entries/:id/skip` | Diesmal auslassen |
| POST | `/api/rotation/reset` | Rotation neu starten |
| GET | `/api/plan?from=&to=` | Planeinträge |
| POST | `/api/plan/draft` | `{ weekStart }` – Entwurf berechnen (nicht gespeichert) |
| POST | `/api/plan/commit` | `{ entries[] }` – Entwurf speichern, Rotation aktualisieren |
| POST | `/api/plan/manual` | `{ date, recipeId }` – `manualPick()` |
| PATCH | `/api/plan/blocks/:blockId` | verschieben, fixieren, als gekocht markieren |
| DELETE | `/api/plan/blocks/:blockId` | Block löschen → `release()` |
| PUT / DELETE | `/api/plan/blocked/:date` | Tag sperren (mit Notiz) / entsperren |
| GET | `/api/shopping-list?from=&to=&format=json\|text` | Einkaufsliste |
| PATCH | `/api/shopping-list/state` | Häkchen, Zusatzartikel |
| GET / PATCH | `/api/settings` | Einstellungen |
| GET | `/api/export` | Vollständiger JSON-Export |
| POST | `/api/import?mode=replace\|merge` | Import (merge = Abgleich per Name) |

Alle Operationen, die Rotation und Plan gemeinsam ändern, laufen in **einer DB-Transaktion**.

---

## 8. Technik & Architektur

### 8.1 Stack (Empfehlung – beibehalten, sofern keine triftigen Gründe dagegen sprechen)

- Next.js (App Router, aktuelle stabile Version) + TypeScript (`strict`)
- Prisma + SQLite; Wechsel zu PostgreSQL nur über Provider/`DATABASE_URL`
- Tailwind CSS, Komponenten z. B. shadcn/ui
- TanStack Query für Datenabruf (`refetchOnWindowFocus`)
- zod für Validierung
- sharp für Bildverarbeitung
- Serwist (oder vergleichbar) für den Service Worker
- Vitest (Unit) + Playwright (E2E)

### 8.2 Projektstruktur

```
/src
  /domain          # reine Logik, keine DB- oder Framework-Importe
    days.ts
    rotation.ts
    planner.ts
    shopping.ts
    units.ts
    rng.ts         # seedbarer Zufallsgenerator
  /server          # Prisma-Zugriff, Services, Auth, Transaktionen
  /app             # Next.js-Seiten und API-Routen
  /components
/prisma
  schema.prisma
  seed.ts          # liest /seed/seed.json
/seed
  seed.json        # Inhalt: Anhang A
/tests
  /unit
  /e2e
Dockerfile
docker-compose.yml
README.md
```

### 8.3 Mehrere Geräte

- Die Server-Datenbank ist die einzige Wahrheit. Clients laden beim Öffnen und bei Fokuswechsel neu.
- Konflikte: last write wins; Rotations- und Planänderungen sind durch Transaktionen konsistent.

### 8.4 PWA

- Manifest mit Icons, installierbar auf iOS und Android.
- Offline lesbar: Wochenplan und Einkaufsliste (zuletzt geladener Stand).
- Nice-to-have: Häkchen offline lokal puffern und beim Reconnect senden.

### 8.5 Bilder (Phase 3)

- Upload bis 10 MB (JPEG, PNG, WebP; HEIC, falls sharp es unterstützt).
- Serverseitig in WebP umwandeln: längste Kante 1600 px + Vorschaubild 400 px.
- Speicherung im Volume unter `/data/images`, Auslieferung nur mit gültiger Session.

### 8.6 Authentifizierung

- Ein Haushaltskonto, Passwort-Hash mit argon2id.
- Session-Cookie: `httpOnly`, `secure`, `sameSite=lax`, 90 Tage.
- Rate-Limit auf Login (z. B. 5 Versuche / 15 min).

### 8.7 Deployment

- `Dockerfile` + `docker-compose.yml`, Volume `/data` (SQLite-Datei + Bilder).
- HTTPS über Reverse Proxy (z. B. Caddy) – nötig für PWA und Kamera-Upload.
- Umgebungsvariablen: `DATABASE_URL`, `SESSION_SECRET`, `DATA_DIR`.
- Läuft auf NAS, Raspberry Pi oder VPS.

### 8.8 Backup

- JSON-Export aller Daten; ab Phase 3 zusätzlich ZIP mit Bildern.
- Import mit Vorschau (ersetzen oder per Name zusammenführen).

---

## 9. Nicht-funktionale Anforderungen

- Bedienbar ab 360 px Breite, Touch-Ziele mindestens 44 px
- Startseite lädt in unter 2 s im mobilen Netz
- Hell/Dunkel nach Systemeinstellung
- Barrierearm: beschriftete Bedienelemente, Kontrast nach WCAG AA
- Keine externen Tracker oder Analytics
- Ausgelegt für bis zu 1.000 Rezepte ohne spürbare Verzögerung

---

## 10. Tests & Akzeptanzkriterien

Unit-Tests (Vitest) mit festem Seed, Daten aus Anhang A.

| Nr. | Test | Erwartung |
|---|---|---|
| T1 | Durchlauf-Zusammensetzung | Genau 6 Einträge; Bolognese 2×, alle anderen aktiven 1×, Kürbissuppe 0× |
| T2 | Verteilung (1.000 Seeds) | Die beiden Bolognese-Einträge stehen nie direkt hintereinander |
| T3 | Durchlaufgrenze (1.000 Seeds) | Letzter Eintrag von Durchlauf n ≠ erster Eintrag von Durchlauf n+1 |
| T4 | Unvermeidbarer Fall | Nur ein aktives Rezept mit Gewicht 2 → 2 Einträge, keine Endlosschleife |
| T5 | `daysFor` | Alle Werte der Tabelle in 5.1 inkl. Override |
| T6 | Pausieren im laufenden Durchlauf | `PENDING`-Einträge des Rezepts entfernt, `PLANNED` bleibt |
| T7 | Neues Rezept im laufenden Durchlauf | Erscheint noch im selben Durchlauf, genau `weight`-mal |
| T8 | `postpone` / `release` | postpone: bleibt `PENDING`, steht am Ende des Durchlaufs. release: ist der nächste Vorschlag |
| T9 | Wochenplan | Beispiel aus 5.4 wird mit fester Rotationsreihenfolge exakt reproduziert, inkl. Übertrag auf 05.10. |
| T10 | Einkaufsliste | Textexport aus Anhang B wird exakt reproduziert |
| T11 | Einheiten | 800 g + 400 g → „1,2 kg“; 1 Stück + 200 g → „1 Stück + 200 g“; 3 EL bleiben „3 EL“; 1500 ml → „1,5 l“ |
| T12 | Nur Kochtage | Resttage im Zeitraum erzeugen keine Zutaten; Rezept ohne Zutaten erzeugt Hinweis |

E2E-Smoke-Test (Playwright): Einrichten → Rezepte per Schnellerfassung anlegen → Woche füllen → Plan übernehmen → Vorschlag zeigt das nächste offene Gericht → (Phase 2) Einkaufsliste enthält die erwarteten Zutaten.

---

## 11. Annahmen & offene Punkte

Diese Punkte sind als Standard umgesetzt. Der Auftraggeber kann sie ändern; die Alternative ist jeweils mitgedacht.

| # | Annahme (Standard) | Alternative |
|---|---|---|
| A1 | „Auf dem Markt erhältlich“ = Wochenmarkt: Gemüse, Obst, frische Kräuter, Eier landen auf der Marktliste; pro Zutat änderbar | Andere Aufteilung, z. B. Frischware vs. Trockenware |
| A2 | Eine geplante Hauptmahlzeit pro Tag | Mittag und Abend getrennt (Phase 4) |
| A3 | Portionen pro Tag global (Standard 2), Abrunden | Aufrunden; abweichend je Wochentag |
| A4 | Jeder Durchlauf wird neu gemischt | Feste Reihenfolge (Einstellung vorhanden) |
| A5 | Ein Gericht gilt als „dran gewesen“, sobald es in den Plan übernommen wird | Erst wenn es als gekocht markiert ist |
| A6 | Resttage folgen direkt; gesperrte Tage werden übersprungen, die Reste rutschen weiter | Block wird durch einen gesperrten Tag gekürzt |
| A7 | Ein gemeinsames Haushaltskonto für alle Geräte | Eigene Logins pro Person (Phase 4) |
| A8 | Self-Hosting per Docker (NAS, Raspberry Pi, VPS) | Cloud-Hosting mit PostgreSQL |
| A9 | Zutatenmengen gelten für das ganze Rezept, keine Skalierung | Skalierung (Phase 4) |
| A10 | Marktliste mit Mengen (abschaltbar) | Nur Namen |
| A11 | Die Einkaufsliste enthält nur Gerichte, deren Kochtag im Zeitraum liegt | Anteilige Zuordnung nach Tagen |

---

## Anhang A – Seed-Daten (`/seed/seed.json`)

Zutaten werden in Rezepten per Name referenziert; das Seed-Skript löst sie auf. `shoppingSource` fehlt → Standard aus Kategorie. Pfannkuchen, Linsensuppe und Kürbissuppe zeigen den Phase-1-Stand (nur Name).

```json
{
  "settings": {
    "portionsPerDay": 2,
    "roundingMode": "FLOOR",
    "rotationMode": "SHUFFLE",
    "marketListShowQuantities": true
  },
  "ingredients": [
    { "name": "Zwiebel",           "category": "GEMUESE",       "defaultUnit": "STUECK" },
    { "name": "Knoblauch",         "category": "GEMUESE",       "defaultUnit": "ZEHE" },
    { "name": "Karotte",           "category": "GEMUESE",       "defaultUnit": "STUECK" },
    { "name": "Paprika",           "category": "GEMUESE",       "defaultUnit": "STUECK" },
    { "name": "Süßkartoffel",      "category": "GEMUESE",       "defaultUnit": "G" },
    { "name": "Blattspinat",       "category": "GEMUESE",       "defaultUnit": "G" },
    { "name": "Avocado",           "category": "OBST",          "defaultUnit": "STUECK" },
    { "name": "Limette",           "category": "OBST",          "defaultUnit": "STUECK" },
    { "name": "Koriander",         "category": "KRAEUTER",      "defaultUnit": "BUND" },
    { "name": "Weizentortillas",   "category": "BACKWAREN",     "defaultUnit": "STUECK" },
    { "name": "Rinderhackfleisch", "category": "FLEISCH",       "defaultUnit": "G" },
    { "name": "Schmand",           "category": "MILCHPRODUKTE", "defaultUnit": "G" },
    { "name": "Spaghetti",         "category": "TROCKENWAREN",  "defaultUnit": "G" },
    { "name": "Basmatireis",       "category": "TROCKENWAREN",  "defaultUnit": "G" },
    { "name": "Rote Linsen",       "category": "TROCKENWAREN",  "defaultUnit": "G" },
    { "name": "Gehackte Tomaten",  "category": "KONSERVEN",     "defaultUnit": "DOSE" },
    { "name": "Kidneybohnen",      "category": "KONSERVEN",     "defaultUnit": "DOSE" },
    { "name": "Mais",              "category": "KONSERVEN",     "defaultUnit": "DOSE" },
    { "name": "Kokosmilch",        "category": "KONSERVEN",     "defaultUnit": "ML" },
    { "name": "Currypaste",        "category": "KONSERVEN",     "defaultUnit": "EL" },
    { "name": "Tomatenmark",       "category": "KONSERVEN",     "defaultUnit": "EL", "shoppingSource": "VORRAT" },
    { "name": "Olivenöl",          "category": "OELE_ESSIG",    "defaultUnit": "EL" },
    { "name": "Salz",              "category": "GEWUERZE",      "defaultUnit": "PRISE" },
    { "name": "Pfeffer",           "category": "GEWUERZE",      "defaultUnit": "PRISE" },
    { "name": "Kreuzkümmel",       "category": "GEWUERZE",      "defaultUnit": "TL" },
    { "name": "Paprikapulver",     "category": "GEWUERZE",      "defaultUnit": "TL" }
  ],
  "recipes": [
    {
      "name": "Spaghetti Bolognese",
      "inRotation": true,
      "weight": 2,
      "servings": 4,
      "ingredients": [
        { "ingredient": "Spaghetti",         "quantity": 500,  "unit": "G" },
        { "ingredient": "Rinderhackfleisch", "quantity": 400,  "unit": "G" },
        { "ingredient": "Zwiebel",           "quantity": 1,    "unit": "STUECK", "note": "fein gewürfelt" },
        { "ingredient": "Knoblauch",         "quantity": 2,    "unit": "ZEHE" },
        { "ingredient": "Karotte",           "quantity": 2,    "unit": "STUECK", "note": "fein gewürfelt" },
        { "ingredient": "Gehackte Tomaten",  "quantity": 1,    "unit": "DOSE" },
        { "ingredient": "Tomatenmark",       "quantity": 2,    "unit": "EL" },
        { "ingredient": "Olivenöl",          "quantity": 2,    "unit": "EL" },
        { "ingredient": "Salz",              "quantity": null, "unit": null },
        { "ingredient": "Pfeffer",           "quantity": null, "unit": null }
      ],
      "instructions": "1. Zwiebel, Knoblauch und Karotten fein würfeln und in Olivenöl anschwitzen.\n2. Hackfleisch zugeben und krümelig braten.\n3. Tomatenmark kurz mitrösten, gehackte Tomaten zugeben und 30 Minuten köcheln lassen.\n4. Spaghetti nach Packungsangabe kochen und mit der Soße servieren."
    },
    {
      "name": "Tortillas mit Chili sin Carne",
      "inRotation": true,
      "weight": 1,
      "servings": 6,
      "ingredients": [
        { "ingredient": "Weizentortillas",  "quantity": 12,   "unit": "STUECK" },
        { "ingredient": "Rote Linsen",      "quantity": 150,  "unit": "G" },
        { "ingredient": "Kidneybohnen",     "quantity": 2,    "unit": "DOSE" },
        { "ingredient": "Mais",             "quantity": 1,    "unit": "DOSE" },
        { "ingredient": "Gehackte Tomaten", "quantity": 2,    "unit": "DOSE" },
        { "ingredient": "Zwiebel",          "quantity": 2,    "unit": "STUECK" },
        { "ingredient": "Knoblauch",        "quantity": 2,    "unit": "ZEHE" },
        { "ingredient": "Paprika",          "quantity": 2,    "unit": "STUECK" },
        { "ingredient": "Schmand",          "quantity": 200,  "unit": "G" },
        { "ingredient": "Avocado",          "quantity": 1,    "unit": "STUECK" },
        { "ingredient": "Koriander",        "quantity": 1,    "unit": "BUND" },
        { "ingredient": "Kreuzkümmel",      "quantity": 1,    "unit": "TL" },
        { "ingredient": "Paprikapulver",    "quantity": 2,    "unit": "TL" },
        { "ingredient": "Salz",             "quantity": null, "unit": null }
      ]
    },
    {
      "name": "Gemüsecurry",
      "inRotation": true,
      "weight": 1,
      "servings": 4,
      "ingredients": [
        { "ingredient": "Basmatireis",  "quantity": 250,  "unit": "G" },
        { "ingredient": "Kokosmilch",   "quantity": 400,  "unit": "ML" },
        { "ingredient": "Süßkartoffel", "quantity": 500,  "unit": "G" },
        { "ingredient": "Paprika",      "quantity": 1,    "unit": "STUECK" },
        { "ingredient": "Blattspinat",  "quantity": 200,  "unit": "G" },
        { "ingredient": "Zwiebel",      "quantity": 1,    "unit": "STUECK" },
        { "ingredient": "Knoblauch",    "quantity": 1,    "unit": "ZEHE" },
        { "ingredient": "Currypaste",   "quantity": 2,    "unit": "EL" },
        { "ingredient": "Limette",      "quantity": 1,    "unit": "STUECK" },
        { "ingredient": "Salz",         "quantity": null, "unit": null }
      ]
    },
    { "name": "Pfannkuchen", "inRotation": true,  "weight": 1, "servings": 2 },
    { "name": "Linsensuppe", "inRotation": true,  "weight": 1, "servings": 4 },
    { "name": "Kürbissuppe", "inRotation": false, "weight": 1, "servings": 4, "notes": "Nur im Herbst – bei Bedarf wieder aktivieren." }
  ]
}
```

---

## Anhang B – Erwartete Einkaufsliste (Textexport) für das Beispiel aus 5.4

```
Einkaufsliste 28.09.–04.10.2026 (KW 40)
Gerichte: Spaghetti Bolognese, Gemüsecurry, Tortillas mit Chili sin Carne

MARKT
- Avocado (1 Stück)
- Blattspinat (200 g)
- Karotte (2 Stück)
- Knoblauch (5 Zehen)
- Koriander (1 Bund)
- Limette (1 Stück)
- Paprika (3 Stück)
- Süßkartoffel (500 g)
- Zwiebel (4 Stück)

SUPERMARKT
Brot & Backwaren
- Weizentortillas: 12 Stück
Fleisch & Wurst
- Rinderhackfleisch: 400 g
Milchprodukte
- Schmand: 200 g
Nudeln, Reis & Hülsenfrüchte
- Basmatireis: 250 g
- Rote Linsen: 150 g
- Spaghetti: 500 g
Konserven & Gläser
- Currypaste: 2 EL
- Gehackte Tomaten: 3 Dosen
- Kidneybohnen: 2 Dosen
- Kokosmilch: 400 ml
- Mais: 1 Dose

VORRAT PRÜFEN
Kreuzkümmel, Olivenöl, Paprikapulver, Pfeffer, Salz, Tomatenmark
```

Mit `marketListShowQuantities = false` entfallen im Abschnitt MARKT die Klammern mit Mengen.
