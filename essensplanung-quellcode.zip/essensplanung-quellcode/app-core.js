/* ==========================================================================
   Essensplanung – App Teil 1: Infrastruktur
   ========================================================================== */
'use strict';
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const deep = o => JSON.parse(JSON.stringify(o));
const rng = Math.random;
const DAY = 86400000;

/* ---------- Lokaler Speicher (IndexedDB, Rückfall localStorage) ---------- */
const Store = (() => {
  let dbp = null;
  function open() {
    if (dbp) return dbp;
    dbp = new Promise((res, rej) => {
      if (!('indexedDB' in window)) return rej(new Error('kein IndexedDB'));
      const r = indexedDB.open('essensplanung', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('kv');
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
    return dbp;
  }
  const tx = (mode, fn) => open().then(d => new Promise((res, rej) => {
    const t = d.transaction('kv', mode); const req = fn(t.objectStore('kv'));
    t.oncomplete = () => res(req && req.result); t.onerror = () => rej(t.error);
  }));
  const ls = {
    get: k => { try { const v = localStorage.getItem('ep_kv_' + k); return Promise.resolve(v ? JSON.parse(v) : undefined); } catch (e) { return Promise.resolve(undefined); } },
    set: (k, v) => { try { localStorage.setItem('ep_kv_' + k, JSON.stringify(v)); } catch (e) {} return Promise.resolve(); },
    del: k => { try { localStorage.removeItem('ep_kv_' + k); } catch (e) {} return Promise.resolve(); },
  };
  return {
    get: k => tx('readonly', s => s.get(k)).catch(() => ls.get(k)),
    set: (k, v) => tx('readwrite', s => s.put(v, k)).catch(() => ls.set(k, v)),
    del: k => tx('readwrite', s => s.delete(k)).catch(() => ls.del(k)),
  };
})();
const LS = {
  get(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} },
  del(k) { try { localStorage.removeItem(k); } catch (e) {} },
};

/* ---------- Kodierung ---------- */
function bytesToB64(bytes) {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}
function b64ToBytes(b64) {
  const bin = atob(String(b64).replace(/\s/g, ''));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
const utf8ToB64 = s => bytesToB64(new TextEncoder().encode(s));
const b64ToUtf8 = b => new TextDecoder().decode(b64ToBytes(b));

/* ---------- Kryptografie (PBKDF2 + AES-GCM) ---------- */
const Crypt = {
  ITER: 150000,
  async pbkdfKey(password, salt) {
    const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), { name: 'PBKDF2' }, false, ['deriveKey', 'deriveBits']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: this.ITER, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  },
  async verifier(password, saltB64) {
    const salt = saltB64 ? b64ToBytes(saltB64) : crypto.getRandomValues(new Uint8Array(16));
    const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), { name: 'PBKDF2' }, false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: this.ITER, hash: 'SHA-256' }, km, 256);
    return { salt: bytesToB64(salt), hash: bytesToB64(new Uint8Array(bits)), iter: this.ITER };
  },
  async check(password, v) { return v && (await this.verifier(password, v.salt)).hash === v.hash; },
  async encWithPassword(password, text) {
    const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await this.pbkdfKey(password, salt);
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
    return { salt: bytesToB64(salt), iv: bytesToB64(iv), data: bytesToB64(new Uint8Array(ct)) };
  },
  async decWithPassword(password, blob) {
    const key = await this.pbkdfKey(password, b64ToBytes(blob.salt));
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64ToBytes(blob.iv) }, key, b64ToBytes(blob.data));
    return new TextDecoder().decode(pt);
  },
  async rawKey(raw) { return crypto.subtle.importKey('raw', raw, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']); },
  async encRaw(raw, text) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await this.rawKey(raw), new TextEncoder().encode(text));
    return { iv: bytesToB64(iv), data: bytesToB64(new Uint8Array(ct)) };
  },
  async decRaw(raw, blob) {
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64ToBytes(blob.iv) }, await this.rawKey(raw), b64ToBytes(blob.data));
    return new TextDecoder().decode(pt);
  },
};

/* ---------- Datenstand ---------- */
let db = null;
function emptyDb() {
  return {
    version: 1, household: null,
    settings: EP.touch({ portionsPerDay: 2, roundingMode: 'FLOOR', rotationMode: 'SHUFFLE', marketListShowQuantities: true,
      categorySources: { GEWUERZE: 'SUPERMARKT', OELE_ESSIG: 'SUPERMARKT' },
      lanes: { LUNCH: { days: [6, 0] }, CAKE: { days: [6] } } }),
    shopping: EP.touch({ from: '', to: '', checkedKeys: [], extraItems: [] }),
    recipes: [], ingredients: [], rotation: [], plan: [],
  };
}
function repairDb(d) {
  const e = emptyDb();
  d = d || e;
  ['recipes', 'ingredients', 'rotation', 'plan'].forEach(k => { if (!Array.isArray(d[k])) d[k] = []; });
  d.settings = Object.assign({}, e.settings, d.settings || {});
  d.settings.categorySources = Object.assign({}, e.settings.categorySources, d.settings.categorySources || {});
  d.settings.lanes = Object.assign({}, e.settings.lanes, d.settings.lanes || {});
  ['LUNCH', 'CAKE'].forEach(l => { if (!d.settings.lanes[l] || !Array.isArray(d.settings.lanes[l].days)) d.settings.lanes[l] = deep(e.settings.lanes[l]); });
  d.ingredients.forEach(i => { if (i.reviewed === undefined) i.reviewed = true; });
  d.shopping = Object.assign({}, e.shopping, d.shopping || {});
  if (!Array.isArray(d.shopping.checkedKeys)) d.shopping.checkedKeys = [];
  if (!Array.isArray(d.shopping.extraItems)) d.shopping.extraItems = [];
  d.recipes.forEach(r => {
    if (!Array.isArray(r.ingredients)) r.ingredients = [];
    if (!Array.isArray(r.images)) r.images = [];
    if (!Array.isArray(r.tags)) r.tags = [];
    if (!r.weight) r.weight = 1;
    if (!r.servings) r.servings = d.settings.portionsPerDay;
    if (!r.kind) r.kind = 'MAIN';
    if (r.seasonMonths === undefined) r.seasonMonths = null;
  });
  return d;
}
/* Täglicher Abschluss: vergangene Kochtage gelten als gekocht (5.2 complete) */
function housekeeping() {
  const today = EP.todayISO();
  let changed = false;
  const rot = new Map(db.rotation.map(e => [e.id, e]));
  EP.live(db.plan).forEach(p => {
    if (p.type === 'BLOCKED' || p.date >= today) return;
    if (p.status !== 'DONE') { p.status = 'DONE'; EP.touch(p); changed = true; }
    if (p.type === 'COOK' && p.rotationEntryId) {
      const e = rot.get(p.rotationEntryId);
      if (e && !e.deleted && e.status === 'PLANNED') { EP.completeEntry(e); changed = true; }
    }
  });
  const before = JSON.stringify([db.recipes.length, db.ingredients.length, db.rotation.length, db.plan.length]);
  EP.pruneTombstones(db, 60 * DAY);
  if (before !== JSON.stringify([db.recipes.length, db.ingredients.length, db.rotation.length, db.plan.length])) changed = true;
  return changed;
}
let saveTimer = null;
async function persist(opts) {
  opts = opts || {};
  await Store.set('db', db);
  if (!opts.noSync) Sync.markDirty();
}

/* ---------- Anmeldung & Sitzung ---------- */
const Auth = {
  get cfg() { return LS.get('ep_auth') || {}; },
  set cfg(v) { LS.set('ep_auth', v); },
  session: null, token: null,
  locked() {
    const l = LS.get('ep_lock');
    return l && l.until && l.until > Date.now() ? Math.ceil((l.until - Date.now()) / 60000) : 0;
  },
  failed() {
    const l = LS.get('ep_lock') || { fails: 0 };
    l.fails = (l.fails || 0) + 1;
    if (l.fails >= 5) { l.until = Date.now() + 15 * 60000; l.fails = 0; }
    LS.set('ep_lock', l);
  },
  async startSession(token) {
    const raw = crypto.getRandomValues(new Uint8Array(32));
    const s = { exp: Date.now() + 90 * DAY, key: bytesToB64(raw), tokenEnc: token ? await Crypt.encRaw(raw, token) : null };
    LS.set('ep_session', s);
    LS.del('ep_lock');
    this.token = token || null;
  },
  async resume() {
    const s = LS.get('ep_session');
    if (!s || !s.exp || s.exp < Date.now()) return false;
    try { this.token = s.tokenEnc ? await Crypt.decRaw(b64ToBytes(s.key), s.tokenEnc) : null; }
    catch (e) { this.token = null; }
    return true;
  },
  logout() { LS.del('ep_session'); this.token = null; },
  /* Token dauerhaft mit dem Haushaltspasswort verschlüsselt ablegen */
  async storeToken(password, token, repo) {
    const c = this.cfg;
    c.tokenEnc = token ? await Crypt.encWithPassword(password, token) : null;
    c.repo = repo || null;
    this.cfg = c;
    const s = LS.get('ep_session');
    if (s) { s.tokenEnc = token ? await Crypt.encRaw(b64ToBytes(s.key), token) : null; LS.set('ep_session', s); }
    this.token = token || null;
  },
  async tokenFromPassword(password) {
    const c = this.cfg;
    if (!c.tokenEnc) return null;
    try { return await Crypt.decWithPassword(password, c.tokenEnc); } catch (e) { return undefined; }
  },
};

/* ---------- Eigener Server (PocketBase auf dem Pi) ----------
   Ein Haushalt = ein Datensatz in der Collection "trips". Inhalt ist verschlüsselt (AES-GCM),
   Schlüssel und Zugangsnachweis werden per HKDF aus dem Geheimnis im Verbindungslink abgeleitet.
   Bilder liegen als eigene Datensätze mit fester, aus dem Bildschlüssel berechneter ID. */
const PB = {
  DEFAULT: 'https://kostenpi.tail281e3e.ts.net',
  get url() { try { return localStorage.getItem('ep_server') || this.DEFAULT; } catch (e) { return this.DEFAULT; } },
  b64e(u8) { return bytesToB64(u8).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); },
  b64d(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return b64ToBytes(s); },
  newSecret() { return this.b64e(crypto.getRandomValues(new Uint8Array(32))); },
  cache: new Map(),
  keysFor(secret) {
    if (!this.cache.has(secret)) this.cache.set(secret, (async () => {
      const te = t => new TextEncoder().encode(t), salt = te('essensplanung-v1');
      const base = await crypto.subtle.importKey('raw', this.b64d(secret), 'HKDF', false, ['deriveKey', 'deriveBits']);
      const enc = await crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt, info: te('enc') }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
      const bits = await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info: te('auth') }, base, 256);
      return { enc, auth: this.b64e(new Uint8Array(bits)) };
    })());
    return this.cache.get(secret);
  },
  async enc(key, text) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
    return 'v1.' + this.b64e(iv) + '.' + this.b64e(new Uint8Array(ct));
  },
  async dec(key, str) {
    const p = String(str || '').split('.');
    if (p.length !== 3 || p[0] !== 'v1') throw new Error('Unbekanntes Datenformat auf dem Server.');
    return new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: this.b64d(p[1]) }, key, this.b64d(p[2])));
  },
  async api(method, path, auth, body) {
    const h = {}; if (auth) h['X-Trip-Auth'] = auth; if (body) h['Content-Type'] = 'application/json';
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 20000);
    try {
      const r = await fetch(this.url + '/api/collections/trips/records' + path, { method, headers: h, body: body ? JSON.stringify(body) : undefined, cache: 'no-store', signal: ctl.signal });
      let j = null; try { j = await r.json(); } catch (e) {}
      return { status: r.status, json: j };
    } catch (e) {
      const err = new Error('Server nicht erreichbar.'); err.status = 0; throw err;
    } finally { clearTimeout(to); }
  },
  fail(r) { const e = new Error('Server antwortet mit Fehler ' + r.status + '.'); e.status = r.status; return e; },
  /* feste Datensatz-ID für ein Bild: 15 Zeichen a–z0–9 */
  async imgId(household, key, suffix) {
    const h = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(household + '|' + key + '|' + suffix)));
    const a = 'abcdefghijklmnopqrstuvwxyz0123456789'; let s = '';
    for (let i = 0; i < 15; i++) s += a[h[i] % 36];
    return s;
  },
  parseLink(str) {
    const m = /(?:#join=)?([a-z0-9]{15})\.([A-Za-z0-9_-]{43})\s*$/.exec(String(str || '').trim());
    return m ? { id: m[1], secret: m[2] } : null;
  },
  link(id, secret) { return location.origin + location.pathname + '#join=' + id + '.' + secret; },
  /* Haushalt vom Server holen (für "Verbinden") */
  async fetchHousehold(id, secret) {
    const k = await this.keysFor(secret);
    const r = await this.api('GET', '/' + id, k.auth);
    if (r.status === 404) { const e = new Error('Haushalt nicht gefunden. Ist der Link vollständig?'); e.status = 404; throw e; }
    if (r.status !== 200 || !r.json) throw this.fail(r);
    return { remote: repairDb(JSON.parse(await this.dec(k.enc, r.json.data))), updated: r.json.updated, rev: +r.json.rev || 0 };
  },
  /* neuen Haushalt-Datensatz anlegen */
  async create(secret, data) {
    const k = await this.keysFor(secret);
    const r = await this.api('POST', '', null, { auth: k.auth, data: await this.enc(k.enc, JSON.stringify(data)), rev: 1 });
    if (r.status !== 200 || !r.json || !r.json.id) throw this.fail(r);
    return r.json;
  },
};

/* ---------- Abgleich über ein privates GitHub-Repository (alt) oder den eigenen Server ---------- */
const Sync = {
  sha: null, dirty: false, busy: false, again: false, timer: null, poll: null,
  state: 'off', msg: '', lastSync: null,
  gen: 0, remoteRev: 0,
  get repo() { return Auth.cfg.repo || null; },
  get isPB() { const r = this.repo; return !!(r && r.pb); },
  enabled() { return !!(Auth.token && this.repo); },
  async api(path, opts) {
    opts = opts || {};
    const res = await fetch('https://api.github.com' + path, Object.assign({}, opts, {
      cache: 'no-store',
      headers: Object.assign({ Authorization: 'Bearer ' + Auth.token, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' }, opts.headers || {}),
    }));
    return res;
  },
  path(p) { const r = this.repo; return `/repos/${encodeURIComponent(r.owner)}/${encodeURIComponent(r.name)}/contents/${p}`; },
  async getFile(p) {
    const res = await this.api(this.path(p));
    if (res.status === 404) return null;
    if (!res.ok) throw await this.err(res);
    const j = await res.json();
    let b64 = j.content;
    if ((!b64 || j.encoding === 'none') && j.sha) {   // Dateien über 1 MB: über die Blob-Schnittstelle laden
      const r = this.repo;
      const br = await this.api(`/repos/${encodeURIComponent(r.owner)}/${encodeURIComponent(r.name)}/git/blobs/${j.sha}`);
      if (!br.ok) throw await this.err(br);
      b64 = (await br.json()).content;
    }
    return { sha: j.sha, b64 };
  },
  async putFile(p, b64, sha, message) {
    const body = { message, content: b64 };
    if (sha) body.sha = sha;
    const res = await this.api(this.path(p), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!res.ok) throw await this.err(res);
    return (await res.json()).content.sha;
  },
  async deleteFile(p) {
    const f = await this.getFile(p).catch(() => null);
    if (!f) return;
    await this.api(this.path(p), { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: 'Bild entfernt', sha: f.sha }) });
  },
  async err(res) {
    let m = '';
    try { m = (await res.json()).message || ''; } catch (e) {}
    const e = new Error(m || ('HTTP ' + res.status));
    e.status = res.status;
    return e;
  },
  /* Vergleichsform unabhängig von der Reihenfolge */
  canon(d) {
    const c = deep(d);
    ['recipes', 'ingredients', 'rotation', 'plan'].forEach(k => c[k] = (c[k] || []).sort((a, b) => (a.id < b.id ? -1 : 1)));
    return JSON.stringify(c);
  },
  async loadMeta() {
    const m = (await Store.get('sync')) || {};
    this.sha = m.sha || null; this.dirty = !!m.dirty; this.lastSync = m.lastSync || null;
  },
  saveMeta() { return Store.set('sync', { sha: this.sha, dirty: this.dirty, lastSync: this.lastSync }); },
  markDirty() {
    this.dirty = true; this.gen++; this.saveMeta();
    if (!this.enabled()) { this.setState('off'); return; }
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.run(), 1500);
  },
  setState(s, msg) { this.state = s; this.msg = msg || ''; if (typeof renderSyncPill === 'function') renderSyncPill(); },
  async pull() {
    if (this.isPB) return this.pullPB();
    const f = await this.getFile('data.json');
    if (!f) { this.sha = null; if (db && db.household) this.dirty = true; return false; }
    if (f.sha === this.sha) return false;
    const remote = repairDb(JSON.parse(b64ToUtf8(f.b64)));
    db = repairDb(EP.mergeDb(db, remote));
    EP.normalizePlan(db);
    this.sha = f.sha;
    if (this.canon(db) !== this.canon(remote)) this.dirty = true;
    await Store.set('db', db);
    await this.saveMeta();
    return true;
  },
  async pullPB() {
    const k = await PB.keysFor(Auth.token);
    const r = await PB.api('GET', '/' + this.repo.pb, k.auth);
    if (r.status === 404) { const e = new Error('Haushalt auf dem Server nicht gefunden.'); e.status = 404; throw e; }
    if (r.status !== 200 || !r.json) throw PB.fail(r);
    this.remoteRev = +r.json.rev || 0;
    if (r.json.updated === this.sha) return false;
    const remote = repairDb(JSON.parse(await PB.dec(k.enc, r.json.data)));
    db = repairDb(EP.mergeDb(db, remote));
    EP.normalizePlan(db);
    this.sha = r.json.updated;
    if (this.canon(db) !== this.canon(remote)) this.dirty = true;
    await Store.set('db', db);
    await this.saveMeta();
    return true;
  },
  async pushPB() {
    const k = await PB.keysFor(Auth.token);
    for (let attempt = 0; attempt < 5 && this.dirty; attempt++) {
      const g0 = this.gen;
      const u = await PB.api('PATCH', '/' + this.repo.pb, k.auth, { data: await PB.enc(k.enc, JSON.stringify(db)), rev: (this.remoteRev || 0) + 1 });
      if (u.status === 404) { const e = new Error('Haushalt auf dem Server nicht gefunden.'); e.status = 404; throw e; }
      if (u.status !== 200 || !u.json) throw PB.fail(u);
      this.sha = u.json.updated; this.remoteRev = +u.json.rev || 0;
      if (this.gen === g0) this.dirty = false;
      await this.saveMeta();
      // Kontrolle: Hat zwischenzeitlich ein anderes Gerät geschrieben? Dann zusammenführen und erneut schreiben.
      const v = await PB.api('GET', '/' + this.repo.pb, k.auth);
      if (v.status === 200 && v.json && v.json.updated !== this.sha) await this.pullPB();
    }
  },
  async push() {
    if (this.isPB) return this.pushPB();
    for (let attempt = 0; attempt < 4 && this.dirty; attempt++) {
      try {
        this.sha = await this.putFile('data.json', utf8ToB64(JSON.stringify(db)), this.sha, 'Essensplanung aktualisiert');
        this.dirty = false;
        await this.saveMeta();
      } catch (e) {
        if (e.status === 409 || e.status === 422) { await this.pull(); continue; } // zwischenzeitlich geändert → zusammenführen
        throw e;
      }
    }
  },
  async run(opts) {
    opts = opts || {};
    if (!this.enabled()) { this.setState('off'); return; }
    if (typeof draft !== 'undefined' && draft && !opts.force) return; // während eines Wochenentwurfs nicht dazwischenfunken
    if (this.busy) { this.again = true; return; }
    if (!navigator.onLine) { this.setState('offline'); return; }
    this.busy = true; this.setState('busy');
    try {
      const changed = await this.pull();
      await this.push();
      await Images.sync();
      this.lastSync = Date.now(); await this.saveMeta();
      this.setState('ok');
      if (changed && typeof rerender === 'function') rerender();
    } catch (e) {
      const m = this.isPB ? (e.status === 404 ? 'Haushalt auf dem Server nicht gefunden.' : e.status === 0 ? 'Server nicht erreichbar – wird automatisch wiederholt.' : (e.message || 'Abgleich fehlgeschlagen.'))
        : e.status === 401 ? 'Zugang abgelaufen oder ungültig – Token neu eingeben.'
        : e.status === 403 ? 'Kein Schreibzugriff auf das Repository.'
        : e.status === 404 ? 'Repository nicht gefunden.' : (e.message || 'Abgleich fehlgeschlagen.');
      this.setState(navigator.onLine ? 'err' : 'offline', m);
    } finally {
      this.busy = false;
      if (this.again) { this.again = false; setTimeout(() => this.run(), 300); }
    }
  },
  startPolling() {
    clearInterval(this.poll);
    this.poll = setInterval(() => { if (document.visibilityState === 'visible') this.run(); }, this.isPB ? 30000 : 60000);
  },
  /* Verbindung prüfen: Repository muss existieren und privat sein */
  async checkRepo(owner, name, token) {
    const res = await fetch(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}`, {
      cache: 'no-store', headers: { Authorization: 'Bearer ' + token, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' } });
    if (res.status === 401) throw new Error('Der Token ist ungültig oder abgelaufen.');
    if (res.status === 404) throw new Error('Repository nicht gefunden – oder der Token hat keinen Zugriff darauf.');
    if (!res.ok) throw new Error('GitHub antwortet mit Fehler ' + res.status + '.');
    const j = await res.json();
    if (!j.private) throw new Error('Dieses Repository ist öffentlich. Deine Rezepte und dein Wochenplan wären für alle sichtbar – bitte ein privates Repository verwenden.');
    return j;
  },
};

/* ---------- Bilder (lokal in IndexedDB, im Repository unter images/) ---------- */
const Images = {
  mem: new Map(),
  async put(key, full, thumb) {
    await Store.set('img:' + key, full); await Store.set('thumb:' + key, thumb);
    this.mem.set('img:' + key, full); this.mem.set('thumb:' + key, thumb);
    const q = (await Store.get('imgq')) || []; q.push(key); await Store.set('imgq', q);
  },
  async remove(key) {
    const d = (await Store.get('imgdel')) || []; d.push(key); await Store.set('imgdel', d);
  },
  async get(key, thumb) {
    const k = (thumb ? 'thumb:' : 'img:') + key;
    if (this.mem.has(k)) return this.mem.get(k);
    let v = await Store.get(k);
    if (!v && Sync.enabled() && navigator.onLine) {
      try {
        if (Sync.isPB) {
          const kk = await PB.keysFor(Auth.token);
          const r = await PB.api('GET', '/' + await PB.imgId(Sync.repo.pb, key, thumb ? 't' : 'f'), kk.auth);
          if (r.status === 200 && r.json) { v = await PB.dec(kk.enc, r.json.data); await Store.set(k, v); }
        } else {
          const f = await Sync.getFile(`images/${key}${thumb ? '_t' : ''}.jpg`);
          if (f) { v = 'data:image/jpeg;base64,' + f.b64.replace(/\s/g, ''); await Store.set(k, v); }
        }
      } catch (e) {}
    }
    if (v) this.mem.set(k, v);
    return v || null;
  },
  async sync() {
    if (Sync.isPB) return this.syncPB();
    const q = (await Store.get('imgq')) || [];
    const rest = [];
    for (const key of q) {
      try {
        for (const [suffix, sk] of [['', 'img:'], ['_t', 'thumb:']]) {
          const v = await Store.get(sk + key);
          if (!v) continue;
          try { await Sync.putFile(`images/${key}${suffix}.jpg`, v.split(',')[1], null, 'Bild hinzugefügt'); }
          catch (e) { if (e.status !== 422) throw e; } // existiert schon
        }
      } catch (e) { rest.push(key); }
    }
    await Store.set('imgq', rest);
    const d = (await Store.get('imgdel')) || [];
    for (const key of d) {
      try { await Sync.deleteFile(`images/${key}.jpg`); await Sync.deleteFile(`images/${key}_t.jpg`); } catch (e) {}
      await Store.del('img:' + key); await Store.del('thumb:' + key);
    }
    await Store.set('imgdel', []);
  },
  /* Bilder mit dem eigenen Server abgleichen: je Bild ein Datensatz für groß (f) und Vorschau (t) */
  async syncPB() {
    const kk = await PB.keysFor(Auth.token), hh = Sync.repo.pb;
    const q = (await Store.get('imgq')) || [], rest = [];
    for (const key of q) {
      try {
        for (const [suffix, sk] of [['f', 'img:'], ['t', 'thumb:']]) {
          let v = await Store.get(sk + key);
          if (!v) continue;
          if (v.length > 1400000) v = await this.shrink(v);   // Obergrenze eines Datensatzes: 2 MB
          const id = await PB.imgId(hh, key, suffix);
          const r = await PB.api('POST', '', null, { id, auth: kk.auth, data: await PB.enc(kk.enc, v), rev: 1 });
          if (r.status === 200) continue;
          const g = await PB.api('GET', '/' + id, kk.auth);        // existiert schon?
          if (g.status !== 200) throw PB.fail(r);
        }
      } catch (e) { rest.push(key); }
    }
    await Store.set('imgq', rest);
    const d = (await Store.get('imgdel')) || [];
    for (const key of d) {
      try { for (const suffix of ['f', 't']) await PB.api('DELETE', '/' + await PB.imgId(hh, key, suffix), kk.auth); } catch (e) {}
      await Store.del('img:' + key); await Store.del('thumb:' + key);
    }
    await Store.set('imgdel', []);
  },
  async shrink(url) {
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
    const s = Math.min(1, 1200 / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * s); c.height = Math.round(img.naturalHeight * s);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.72);
  },
  /* alle Bildschlüssel der Rezepte (zum ersten Hochladen) */
  allKeys() { const out = new Set(); (db.recipes || []).forEach(r => { if (!r.deleted) (r.images || []).forEach(i => out.add(i.fileKey)); }); return [...out]; },
  /* Bild verkleinern: längste Kante 1600 px + Vorschau 400 px */
  async process(file) {
    if (file.size > 10 * 1024 * 1024) throw new Error('Das Bild ist größer als 10 MB.');
    const url = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(file); });
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Dieses Bildformat kann der Browser nicht lesen.')); i.src = url; });
    const scale = (max, q) => {
      const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas');
      c.width = Math.round(img.naturalWidth * s); c.height = Math.round(img.naturalHeight * s);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      return { url: c.toDataURL('image/jpeg', q), w: c.width, h: c.height };
    };
    const full = scale(1600, 0.82), thumb = scale(400, 0.75);
    return { full: full.url, thumb: thumb.url, width: full.w, height: full.h };
  },
  /* Platzhalter im DOM nachträglich befüllen */
  async hydrate(root) {
    for (const el of $$('img[data-img]', root)) {
      const v = await this.get(el.dataset.img, el.dataset.thumb === '1');
      if (v) el.src = v; else if (el.dataset.hideEmpty) el.remove();
    }
  },
};
