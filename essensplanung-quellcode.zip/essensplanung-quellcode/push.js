/* ==== Mitteilungen der Anwendungssammlung (gleicher Code in allen Apps) ====
   Web-Push über den Push-Dienst auf dem Pi (…/push). Funktioniert auf dem iPhone nur in einer App
   vom Home-Bildschirm (ab iOS 16.4). Kanäle werden aus den Geheimnissen der Apps abgeleitet, Texte
   sind mit einem Kanalschlüssel verschlüsselt – der Pi sieht weder Namen noch Inhalte. Der Service
   Worker (sw.js) entschlüsselt sie mit den Schlüsseln aus IndexedDB „push-keys“ und zeigt sie an.
   Welche Arten ein Gerät bekommt, steht in localStorage „push-prefs“ und wird beim Pi hinterlegt. */
const Push = (() => {
  const DEFAULT = 'https://kostenpi.tail281e3e.ts.net/push';
  const KINDS = [
    { key: 'timer', label: 'Kochtimer', sub: 'Wenn ein Timer der Kochansicht abläuft', def: true },
    { key: 'remind', label: 'Kocherinnerung', sub: 'Am Kochtag: „Heute: Spaghetti Bolognese“', def: false },
    { key: 'einkauf', label: 'Einkaufsliste', sub: 'Jemand im Haushalt ergänzt die Einkaufsliste', def: true },
    { key: 'plan', label: 'Wochenplan', sub: 'Jemand im Haushalt übernimmt einen neuen Wochenplan', def: false },
    { key: 'invite', label: 'Einladungen', sub: 'Jemand lädt dich per Benutzername ein', def: true },
    { key: 'kosten', label: 'Neue Ausgaben', sub: 'Jemand trägt in einer geteilten Reise etwas ein', def: true },
    { key: 'spiele', label: 'Spiele', sub: 'Neue Partie im Verlauf der Spielgruppe', def: false },
    { key: 'cocktails', label: 'Cocktails', sub: 'Änderungen an geteilten Cocktail-Projekten', def: false },
  ];
  const APP_KINDS = { essen: ['einkauf', 'plan'], kosten: ['kosten'], spiele: ['spiele'], cocktails: ['cocktails'] };
  const te = t => new TextEncoder().encode(t);
  const b64e = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
  const b64d = str => { str = String(str).replace(/-/g, '+').replace(/_/g, '/'); while (str.length % 4) str += '='; const b = atob(str), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
  const ls = {
    get(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} },
    del(k) { try { localStorage.removeItem(k); } catch (e) {} },
  };
  const server = () => { try { return localStorage.getItem('push-server') || DEFAULT; } catch (e) { return DEFAULT; } };
  const rnd = n => b64e(crypto.getRandomValues(new Uint8Array(n)));
  function device() {
    let d = ls.get('push-device');
    if (!d || !d.id) { d = { id: rnd(18), secret: rnd(24), ch: rnd(32) }; ls.set('push-device', d); }
    return d;
  }
  function prefs() {
    const p = Object.assign({ remindTime: '16:30' }, ls.get('push-prefs') || {});
    KINDS.forEach(k => { if (typeof p[k.key] !== 'boolean') p[k.key] = k.def; });
    return p;
  }
  const listeners = new Set(); const emit = () => listeners.forEach(f => { try { f(); } catch (e) {} });

  /* ---------- Kanäle ---------- */
  const chanCache = new Map();
  function chan(secret, label) {
    const ck = label + '|' + secret;
    if (!chanCache.has(ck)) chanCache.set(ck, (async () => {
      const base = await crypto.subtle.importKey('raw', te(secret), 'HKDF', false, ['deriveBits']);
      const bits = n => crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt: te('push-v1'), info: te(label + '|' + n) }, base, 256);
      return { id: b64e(new Uint8Array(await bits('id')).subarray(0, 24)), key: b64e(new Uint8Array(await bits('key'))) };
    })());
    return chanCache.get(ck);
  }
  const normUser = u => String(u || '').trim().toLowerCase();
  const itemChan = it => chan(it.secret, it.app + ':' + it.id);
  const userChan = name => chan('konto-postfach|' + normUser(name), 'inbox');
  const devChan = () => chan(device().ch, 'device');
  async function encrypt(keyB64, obj) {
    const key = await crypto.subtle.importKey('raw', b64d(keyB64), 'AES-GCM', false, ['encrypt']);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    return 'v1.' + b64e(iv) + '.' + b64e(new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, te(JSON.stringify(obj)))));
  }
  /* Kanalschlüssel für den Service Worker ablegen */
  function idb() {
    return new Promise((res, rej) => { const r = indexedDB.open('push-keys', 1); r.onupgradeneeded = () => r.result.createObjectStore('k'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  }
  async function storeKeys(map) {
    const db = await idb();
    await new Promise((res, rej) => { const tx = db.transaction('k', 'readwrite'), st = tx.objectStore('k'); st.clear(); Object.entries(map).forEach(([k, v]) => st.put(v, k)); tx.oncomplete = res; tx.onerror = () => rej(tx.error); });
    db.close();
  }
  async function channels() {
    const p = prefs(), out = {}, keys = {};
    const add = (c, kinds) => { if (!kinds.length) return; out[c.id] = (out[c.id] || []).concat(kinds); keys[c.id] = c.key; };
    add(await devChan(), ['test'].concat(['timer', 'remind'].filter(k => p[k])));   // „test“ immer, damit die Testmitteilung ankommt
    const K = typeof Konto !== 'undefined' && Konto.loggedIn() ? Konto : null;
    if (K) {
      if (p.invite) add(await userChan(K.user()), ['invite']);
      for (const it of K.items()) { const kinds = (APP_KINDS[it.app] || []).filter(k => p[k]); if (kinds.length && it.secret) add(await itemChan(it), kinds); }
    }
    return { out, keys };
  }

  /* ---------- Server ---------- */
  async function api(path, body) {
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 15000);
    try {
      const r = await fetch(server() + path, { method: body ? 'POST' : 'GET', headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, cache: 'no-store', signal: ctl.signal });
      let j = null; try { j = await r.json(); } catch (e) {}
      if (!r.ok) { const e = new Error((j && j.error) || ('Push-Dienst antwortet mit ' + r.status)); e.status = r.status; throw e; }
      return j;
    } catch (e) { if (e.status) throw e; const err = new Error('Push-Dienst nicht erreichbar'); err.offline = true; throw err; }
    finally { clearTimeout(to); }
  }

  /* ---------- Abo ---------- */
  const standalone = () => { try { return window.navigator.standalone === true || matchMedia('(display-mode: standalone)').matches; } catch (e) { return false; } };
  const supported = () => typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  function status() {
    if (!supported()) return { state: standalone() ? 'unsupported' : 'notInstalled', text: standalone() ? 'Dieses Gerät unterstützt keine Mitteilungen für Web-Apps (iOS 16.4 oder neuer nötig).' : 'Mitteilungen gehen nur in der App vom Home-Bildschirm (Teilen → „Zum Home-Bildschirm“).' };
    if (Notification.permission === 'denied') return { state: 'denied', text: 'Mitteilungen sind abgelehnt. Erlauben unter iPhone-Einstellungen → Mitteilungen → diese App.' };
    const s = ls.get('push-state') || {};
    if (Notification.permission === 'granted' && s.on) return { state: 'on', text: s.err ? 'Aktiv – letzter Abgleich fehlgeschlagen: ' + s.err : 'Aktiv auf diesem Gerät' };
    return { state: 'off', text: 'Aus' };
  }
  async function swReg() {
    const reg = (await navigator.serviceWorker.getRegistration()) || (await navigator.serviceWorker.register('sw.js'));
    return navigator.serviceWorker.ready.then(() => reg);
  }
  /* Einschalten – muss aus einem Tipp heraus aufgerufen werden (iOS fragt dann nach der Erlaubnis) */
  async function enable() {
    if (!supported()) throw new Error(status().text);
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') throw new Error('Ohne Erlaubnis keine Mitteilungen.');
    const { publicKey } = await api('/vapid');
    const reg = await swReg();
    let sub = await reg.pushManager.getSubscription();
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64d(publicKey) });
    ls.set('push-state', { on: true, err: '' });
    await sync(true);
    emit();
    return true;
  }
  async function disable() {
    try { const reg = await navigator.serviceWorker.getRegistration(); const sub = reg && await reg.pushManager.getSubscription(); if (sub) await sub.unsubscribe(); } catch (e) {}
    const d = device();
    try { await api('/unsubscribe', { device: d.id, secret: d.secret }); } catch (e) {}
    ls.set('push-state', { on: false }); ls.del('push-sig'); emit();
  }
  let syncing = null;
  /* Kanäle und Arten beim Pi aktualisieren (nur wenn sich etwas geändert hat) */
  async function sync(force) {
    const st = ls.get('push-state') || {};
    if (!st.on || !supported() || Notification.permission !== 'granted') return false;
    if (syncing) return syncing;
    syncing = (async () => {
      try {
        const reg = await swReg();
        const sub = await reg.pushManager.getSubscription();
        if (!sub) { ls.set('push-state', { on: false }); emit(); return false; }
        const { out, keys } = await channels();
        await storeKeys(keys);
        const sj = sub.toJSON(), sig = JSON.stringify([sj.endpoint, out]);
        if (!force && ls.get('push-sig') === sig) return true;
        const d = device();
        await api('/subscribe', { device: d.id, secret: d.secret, sub: { endpoint: sj.endpoint, keys: sj.keys }, channels: out });
        ls.set('push-sig', sig); ls.set('push-state', { on: true, err: '' });
        return true;
      } catch (e) { ls.set('push-state', { on: true, err: e.message }); throw e; }
      finally { syncing = null; emit(); }
    })();
    return syncing;
  }
  function setPrefs(p) { ls.set('push-prefs', Object.assign(prefs(), p)); emit(); return sync().catch(() => {}); }

  /* ---------- Senden ---------- */
  /* an alle Geräte eines geteilten Dings (außer diesem): item = {app, id, secret} */
  async function notify(item, kind, title, body, url) {
    if (!item || !item.secret || !item.id) return false;
    try {
      const c = await itemChan(item);
      await api('/send', { channels: [c.id], kind, boxes: { '*': await encrypt(c.key, { title, body, url: url || null, tag: kind + ':' + item.id }) }, exclude: device().id });
      return true;
    } catch (e) { return false; }
  }
  async function notifyUser(name, kind, title, body, url) {
    try { const c = await userChan(name); await api('/send', { channels: [c.id], kind, boxes: { '*': await encrypt(c.key, { title, body, url: url || null }) } }); return true; }
    catch (e) { return false; }
  }
  /* an dieses Gerät zu einem Zeitpunkt (Kochtimer, Kocherinnerung); gleicher tag ersetzt */
  async function schedule(tag, at, kind, title, body, url) {
    if (!(ls.get('push-state') || {}).on) return false;
    try {
      const c = await devChan();
      await api('/send', { channels: [c.id], kind, tag, at: new Date(at).toISOString(), ttl: 3600, boxes: { '*': await encrypt(c.key, { title, body, url: url || null, tag }) } });
      return true;
    } catch (e) { return false; }
  }
  async function cancel(tag) {
    if (!(ls.get('push-state') || {}).on) return false;
    try { const c = await devChan(); await api('/cancel', { channels: [c.id], tag }); return true; } catch (e) { return false; }
  }
  async function test() {
    const c = await devChan();
    await api('/send', { channels: [c.id], kind: 'test', boxes: { '*': await encrypt(c.key, { title: 'Testmitteilung', body: 'Mitteilungen funktionieren 👍', url: 'index.html#mitteilungen' }) } });
  }

  /* Einladungen automatisch ankündigen */
  if (typeof Konto !== 'undefined' && Konto.invite && !Konto.invite._push) {
    const orig = Konto.invite;
    Konto.invite = async function (name, key, item, days) {
      const r = await orig.apply(this, arguments);
      notifyUser(r.to, 'invite', 'Neue Einladung', `${Konto.user()} lädt dich zu „${(item && item.label) || 'etwas'}“ ein`, 'index.html#konto');
      return r;
    };
    Konto.invite._push = true;
  }
  if (typeof Konto !== 'undefined' && Konto.onChange) Konto.onChange(() => { sync().catch(() => {}); });
  if (typeof document !== 'undefined') document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { emit(); sync().catch(() => {}); } });
  /* Zurück aus dem Hauptmenü: iOS zeigt die Seite aus dem Zwischenspeicher – Anzeigen („An/Aus“) auffrischen */
  if (typeof window !== 'undefined') {
    window.addEventListener('pageshow', e => { if (e.persisted) emit(); });
    window.addEventListener('storage', e => { if (!e.key || /^push-(state|prefs)$/.test(e.key)) emit(); });
  }

  return { KINDS, supported, standalone, status, enable, disable, sync, prefs, setPrefs, notify, notifyUser, schedule, cancel, test, onChange: f => listeners.add(f),
    enabled: () => !!(ls.get('push-state') || {}).on && supported() && Notification.permission === 'granted', _chan: chan, _channels: channels };
})();
