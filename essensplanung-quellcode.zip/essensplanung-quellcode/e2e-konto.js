const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs'), crypto = require('crypto');

/* ---------- lokaler Webserver (localhost = sicherer Kontext wie GitHub Pages) ---------- */
const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' });
  res.end(fs.readFileSync(f));
});

/* ---------- nachgebaute GitHub-Contents-API (privates Repo) ---------- */
const repo = new Map(); // Pfad → { sha, b64 }
let puts = 0, conflicts = 0;
const TOKEN = 'github_pat_TEST';
async function github(route) {
  const req = route.request();
  const url = new URL(req.url());
  if (req.headers()['authorization'] !== 'Bearer ' + TOKEN) return route.fulfill({ status: 401, json: { message: 'Bad credentials' } });
  if (url.pathname === '/repos/tim/essensplanung-daten') return route.fulfill({ json: { private: true, default_branch: 'main' } });
  const m = url.pathname.match(/^\/repos\/tim\/essensplanung-daten\/contents\/(.+)$/);
  if (!m) return route.fulfill({ status: 404, json: { message: 'Not Found' } });
  const p = decodeURIComponent(m[1]), cur = repo.get(p);
  if (req.method() === 'GET') {
    if (!cur) return route.fulfill({ status: 404, json: { message: 'Not Found' } });
    return route.fulfill({ json: { sha: cur.sha, encoding: 'base64', content: cur.b64.replace(/(.{60})/g, '$1\n') } });
  }
  const body = JSON.parse(req.postData() || '{}');
  if (req.method() === 'PUT') {
    if (cur && body.sha !== cur.sha) { conflicts++; return route.fulfill({ status: cur && !body.sha ? 422 : 409, json: { message: 'sha does not match' } }); }
    const sha = crypto.createHash('sha1').update(body.content + Date.now() + Math.random()).digest('hex');
    repo.set(p, { sha, b64: body.content }); puts++;
    return route.fulfill({ status: cur ? 200 : 201, json: { content: { sha } } });
  }
  if (req.method() === 'DELETE') { repo.delete(p); return route.fulfill({ json: {} }); }
  route.fulfill({ status: 405, json: {} });
}
/* ---------- nachgebaute PocketBase auf dem Pi (Collection "trips" mit Tims Regeln) ---------- */
const PBURL = 'https://kostenpi.tail281e3e.ts.net';
const pbRecs = new Map(); let pbPatches = 0, pbTick = 0;
const pbTs = () => new Date().toISOString().replace('Z', '') + String(++pbTick).padStart(6, '0') + 'Z';
async function pocketbase(route) {
  const req = route.request(), u = new URL(req.url());
  const H = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' };
  const send = (status, json) => route.fulfill({ status, headers: H, json: json === undefined ? {} : json });
  if (req.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: H });
  const m = u.pathname.match(/^\/api\/collections\/trips\/records(?:\/([a-z0-9]{15}))?$/);
  if (!m) return send(404);
  const id = m[1], auth = req.headers()['x-trip-auth'];
  if (!id && req.method() === 'GET') return send(403, { message: 'Only superusers can perform this action.' });
  if (!id && req.method() === 'POST') {
    const b = JSON.parse(req.postData() || '{}');
    if (typeof b.auth !== 'string' || b.auth.length < 40 || b.auth.length > 100) return send(400, { message: 'auth' });
    if (typeof b.data === 'string' && b.data.length > 2000000) return send(400, { message: 'data too long' });
    if (b.id && (!/^[a-z0-9]{15}$/.test(b.id) || pbRecs.has(b.id))) return send(400, { message: 'id invalid or exists' });
    const nid = b.id || crypto.randomBytes(15).toString('hex').replace(/[^a-z0-9]/g, '').slice(0, 15).padEnd(15, 'a');
    const rec = { id: nid, auth: b.auth, data: b.data || '', rev: +b.rev || 0, created: pbTs(), updated: pbTs() };
    pbRecs.set(nid, rec); return send(200, rec);
  }
  const r = pbRecs.get(id);
  if (!r || r.auth !== auth) return send(404, { message: "The requested resource wasn't found." });
  if (req.method() === 'GET') return send(200, r);
  if (req.method() === 'PATCH') {
    const b = JSON.parse(req.postData() || '{}');
    if ('auth' in b && b.auth !== r.auth) return send(404);
    if ('data' in b) r.data = b.data; if ('rev' in b) r.rev = +b.rev; r.updated = pbTs(); pbPatches++;
    return send(200, r);
  }
  if (req.method() === 'DELETE') { pbRecs.delete(id); return route.fulfill({ status: 204, headers: H }); }
  send(405);
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
let pass = 0, fail = 0;
const ok = (n, c, i) => { c ? pass++ : fail++; console.log((c ? '  ✓ ' : '  ✗ ') + n + (c ? '' : '  → ' + (i || ''))); };
async function waitFor(fn, ms = 10000) { const t = Date.now(); while (Date.now() - t < ms) { try { if (await fn()) return true; } catch (e) {} await sleep(150); } return false; }
async function dev(browser, errs, label) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE' });
  await ctx.route(PBURL + '/**', pocketbase);
  const p = await ctx.newPage(); p.on('pageerror', e => errs.push(label + ': ' + e.message));
  await p.goto('http://localhost:' + PORT + '/essensplanung.html'); await sleep(500);
  return p;
}
const PORT = 8791;
(async () => {
  server.listen(PORT);
  const browser = await chromium.launch(); const errs = [];
  console.log('Gerät A: bestehender Haushalt, dann Konto');
  const a = await dev(browser, errs, 'A');
  await a.click('[data-x=new]'); await a.fill('#a-n', 'Familie Test'); await a.fill('#a-p1', 'haushalt1'); await a.fill('#a-p2', 'haushalt1'); await a.click('[data-x=ok]'); await sleep(400);
  await a.evaluate(() => { const r = newRecipe('Konto-Linsensuppe'); db.recipes.push(r); return persist(); });
  ok('Haushalt ohne Konto wie bisher', await a.evaluate(() => !Konto.loggedIn() && !!db.household && !Sync.enabled()));
  ok('ohne Konto keine Server-Anfragen', pbRecs.size === 0);
  await a.evaluate(() => Konto.register('tim', 'kontopasswort1')); await a.reload(); await sleep(800);
  ok('nach Anmeldung geht die App ohne Passwort auf', await waitFor(() => a.evaluate(() => !document.getElementById('shell').classList.contains('hidden'))));
  ok('Haushalt automatisch auf dem Pi und im Konto', await waitFor(() => a.evaluate(() => Sync.isPB && Konto.items('essen').length === 1 && Konto.items('essen')[0].label === 'Familie Test')));
  ok('Server sieht nur verschlüsselte Daten', [...pbRecs.values()].every(r => r.data.startsWith('v1.') && !r.data.includes('Linsensuppe')));
  await waitFor(() => a.evaluate(() => Sync.state === 'ok'));

  console.log('Gerät B: leer, nur Konto');
  const b = await dev(browser, errs, 'B');
  ok('ohne Konto: Begrüßung', await b.locator('[data-x=new]').isVisible());
  await b.evaluate(() => Konto.login('Tim', 'kontopasswort1')); await b.reload(); await sleep(800);
  ok('Haushalt kommt ohne Link und Passwort', await waitFor(() => b.evaluate(() => !!findRecipeByName('Konto-Linsensuppe') && !document.getElementById('shell').classList.contains('hidden'))));
  await b.evaluate(() => { const r = newRecipe('Von Gerät B'); db.recipes.push(r); return persist(); });
  await waitFor(() => b.evaluate(() => Sync.state === 'ok' && !Sync.dirty));
  await a.evaluate(() => Sync.run({ force: true }));
  ok('Änderung von B kommt auf A an', await waitFor(() => a.evaluate(() => !!findRecipeByName('Von Gerät B'))));
  await b.evaluate(() => { Auth.logout(); }); await b.reload(); await sleep(800);
  ok('nach Sitzungsende öffnet das Konto ohne Passwort', await waitFor(() => b.evaluate(() => !document.getElementById('shell').classList.contains('hidden') && Sync.enabled())));
  await b.evaluate(() => go('settings')); await sleep(300);
  ok('Einstellungen zeigen das Konto statt Abmelden', await b.locator('[data-act=konto]').count() === 1 && await b.locator('[data-act=logout]').count() === 0);

  console.log('Gerät C: eigener lokaler Haushalt, dann Konto');
  const c = await dev(browser, errs, 'C');
  await c.click('[data-x=new]'); await c.fill('#a-n', 'Alt'); await c.fill('#a-p1', 'haushalt2'); await c.fill('#a-p2', 'haushalt2'); await c.click('[data-x=ok]'); await sleep(400);
  await c.evaluate(() => { const r = newRecipe('Nur auf C'); db.recipes.push(r); return persist(); });
  await c.evaluate(() => Konto.login('tim', 'kontopasswort1')); await c.reload(); await sleep(800);
  ok('C verbindet sich mit dem Konto-Haushalt', await waitFor(() => c.evaluate(() => Sync.isPB && Sync.repo.pb === Konto.items('essen')[0].id && !!findRecipeByName('Konto-Linsensuppe'))));
  ok('lokale Rezepte von C bleiben erhalten', await c.evaluate(() => !!findRecipeByName('Nur auf C')));
  await waitFor(() => c.evaluate(() => Sync.state === 'ok' && !Sync.dirty));
  await a.evaluate(() => Sync.run({ force: true }));
  ok('Rezepte von C kommen auf A an', await waitFor(() => a.evaluate(() => !!findRecipeByName('Nur auf C'))));
  ok('Konto hat weiterhin genau einen Haushalt', await c.evaluate(() => Konto.items('essen').length === 1));

  console.log('Gerät D: neues Konto, neuer Haushalt');
  const d = await dev(browser, errs, 'D');
  await d.evaluate(() => Konto.register('anna', 'annapasswort1')); await d.reload(); await sleep(600);
  await d.click('[data-x=new]');
  ok('Einrichten fragt kein Passwort', await d.locator('#a-p1').count() === 0);
  await d.fill('#a-n', 'Annas Küche'); await d.click('[data-x=ok]'); await sleep(600);
  ok('neuer Haushalt sofort im Konto', await waitFor(() => d.evaluate(() => Konto.items('essen').length === 1 && Sync.isPB)));

  console.log('Einladung per Benutzername: Anna wechselt in Tims Haushalt');
  await d.evaluate(() => { const r = newRecipe('Annas Pfannkuchen'); db.recipes.push(r); return persist(); });
  await waitFor(() => d.evaluate(() => Sync.state === 'ok' && !Sync.dirty));
  await a.evaluate(() => go('sync')); await sleep(400);
  ok('Geräteabgleich zeigt „Per Benutzername einladen“', await a.locator('#inv-n').isVisible());
  await a.fill('#inv-n', 'annna'); await sleep(900);
  ok('Tippfehler: „Kein Konto mit diesem Namen“', /Kein Konto/.test(await a.locator('#inv-s').innerText()));
  await a.click('[data-act=invsend]'); await sleep(500);
  ok('Tippfehler: keine Einladung gesendet', await a.evaluate(() => Object.keys(JSON.parse(localStorage.getItem('konto-cache')).sent).length === 0));
  await a.fill('#inv-n', 'ANNA'); await sleep(900);
  ok('Live-Prüfung findet Anna', /Anna|anna/.test(await a.locator('#inv-s').innerText()) && /gefunden/.test(await a.locator('#inv-s').innerText()));
  await a.click('[data-act=invsend]'); await sleep(800);
  ok('Einladung erscheint als offen', await waitFor(() => a.locator('#inv-list', { hasText: 'offen bis' }).isVisible()));
  await a.fill('#inv-n', 'anna'); await a.click('[data-act=invsend]'); await sleep(800);
  await waitFor(async () => (await a.locator('#inv-list [data-act=invw]').count()) === 2);
  await a.locator('#inv-list [data-act=invw]').first().click(); await sleep(300);
  await a.locator('#scrim [data-x=yes]').click(); await sleep(800);
  ok('eine Einladung zurückgezogen', await waitFor(async () => (await a.locator('#inv-list [data-act=invw]').count()) === 1));
  const inbox = await d.evaluate(async () => (await Konto.inbox()).map(x => ({ from: x.from, label: x.item.label })));
  ok('Anna sieht genau eine Einladung von tim', inbox.length === 1 && inbox[0].from === 'tim' && inbox[0].label === 'Familie Test', JSON.stringify(inbox));
  await d.evaluate(async () => { const inv = (await Konto.inbox())[0]; Konto.items('essen').forEach(x => Konto.remove(x.key)); await Konto.accept(inv); });
  await d.reload(); await sleep(1200);
  ok('Anna ist jetzt in Tims Haushalt', await waitFor(() => d.evaluate(() => db.household.name === 'Familie Test' && Sync.repo.pb === Konto.items('essen')[0].id && Konto.items('essen').length === 1)));
  ok('Annas Rezepte wurden mitgenommen, Tims sind da', await d.evaluate(() => !!findRecipeByName('Annas Pfannkuchen') && !!findRecipeByName('Konto-Linsensuppe')));
  await waitFor(() => d.evaluate(() => Sync.state === 'ok' && !Sync.dirty));
  await a.evaluate(() => Sync.run({ force: true }));
  ok('Tim sieht Annas Rezept', await waitFor(() => a.evaluate(() => !!findRecipeByName('Annas Pfannkuchen'))));
  await a.evaluate(() => { go('settings'); go('sync'); }); await sleep(800);
  ok('Tims Liste zeigt „angenommen oder abgelehnt“', await waitFor(() => a.locator('#inv-list', { hasText: 'angenommen oder abgelehnt' }).isVisible()));
  ok('kein seitliches Scrollen', await a.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  ok('keine Seitenfehler', errs.length === 0, errs.join(' | '));
  console.log(`\n${pass} bestanden, ${fail} fehlgeschlagen`);
  await browser.close(); server.close(); process.exit(fail ? 1 : 0);
})().catch(e => { console.log('ABBRUCH', e); process.exit(1); });
