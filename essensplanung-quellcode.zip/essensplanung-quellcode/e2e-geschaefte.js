// E2E: Geschäfte mit Regal-Reihenfolge (Einkaufsliste folgt dem Laden)
// Aufruf: node e2e-geschaefte.js   (SHOTS=<ordner> für Bildschirmfotos)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');

let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };

const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' });
  res.end(fs.readFileSync(f));
});

async function layout(page, label) {
  const r = await page.evaluate(() => {
    const cw = document.documentElement.clientWidth, small = [];
    document.querySelectorAll('#main button, #main .gi, #scrim button, #scrim input').forEach(b => {
      const r = b.getBoundingClientRect(); if (!r.width || !r.height || getComputedStyle(b).visibility === 'hidden') return;
      if (r.height < 44 && !b.closest('.chips.daypick')) small.push((b.innerText || b.getAttribute('aria-label') || b.tagName).trim().slice(0, 24) + ' ' + Math.round(r.height));
    });
    const fonts = [...document.querySelectorAll('#scrim input, #main input:not([type=checkbox])')].filter(e => e.getBoundingClientRect().width && parseFloat(getComputedStyle(e).fontSize) < 16).map(e => e.id);
    return { over: document.documentElement.scrollWidth > cw, small, fonts };
  });
  ok(`${label}: kein seitliches Scrollen`, !r.over);
  ok(`${label}: Bedienelemente ≥ 44 px`, !r.small.length, r.small.join(' | '));
  ok(`${label}: Eingaben ≥ 16 px`, !r.fonts.length, r.fonts.join());
}

(async () => {
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log(`Durchlauf ${scheme}`);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
    const page = await ctx.newPage();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
    const tap = async sel => { await page.locator(sel).first().click(); await sleep(220); };
    const groupsOf = () => page.$$eval('.shopsec', secs => secs.map(s => ({ head: (s.querySelector('h3') || {}).innerText || '', cats: [...s.querySelectorAll('p.cat')].map(p => p.innerText.trim()) })));

    await page.goto(URL_);
    await tap('text=Neuen Haushalt einrichten');
    await page.fill('#a-n', 'Laden-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
    await tap('[data-x=ok]');
    await until(() => page.locator('#tabs button').count().then(n => n === 4));
    await tap('[data-tab=suggest]'); await tap('[data-act=seed]');
    await tap('[data-tab=week]'); await tap('[data-act=fill]'); await tap('[data-act=commit]');
    await tap('[data-tab=shop]');
    for (const t of ['Spülmittel', 'Hafermilch', 'Brot']) { await page.fill('#extra', t); await tap('[data-act=addextra]'); }
    const before = await groupsOf();
    const sm0 = before.find(x => /Supermarkt/.test(x.head));
    ok('ohne Geschäft: Kategorien in der üblichen Reihenfolge', sm0 && sm0.cats.indexOf('Brot & Backwaren') < sm0.cats.indexOf('Haushalt & Reinigung'), sm0 && sm0.cats.join());
    ok('Knopf „Geschäft wählen“ beim Supermarkt', /Geschäft wählen/.test(await page.locator('[data-act=storepick][data-arg=SUPERMARKT]').innerText()));

    console.log('Geschäft anlegen aus der Einkaufsliste');
    await tap('[data-act=storepick][data-arg=SUPERMARKT]');
    ok('Auswahl bietet „Geschäft anlegen“', await page.locator('#scrim .opt:has-text("Geschäft anlegen")').count() === 1);
    await tap('#scrim .opt:has-text("Geschäft anlegen")');
    ok('Namensdialog mit Einkaufsort (Supermarkt vorgewählt)', await page.locator('#ts-in').isVisible() && await page.locator('#scrim [data-k=SUPERMARKT][aria-pressed=true]').count() === 1);
    await page.fill('#ts-in', 'Rewe Hauptstraße'); await tap('#scrim [data-x=yes]');
    ok('Geschäft-Seite öffnet sich', await until(() => page.locator('#ttl').innerText().then(t => t === 'Geschäft')));
    ok('erstes Geschäft wird Standard', await page.isChecked('#st-def'));
    const ord0 = await page.$$eval('.ordrow .ordlbl', e => e.map(x => x.innerText.split('\n')[0]));
    const expect0 = await page.evaluate(() => EP.CATEGORIES.filter(c => EP.categorySource(c.key, db.settings) === 'SUPERMARKT' || c.key === 'SONSTIGES').map(c => c.label));
    ok('Reihenfolge zeigt genau die Kategorien, die beim Supermarkt gekauft werden', ord0.length === expect0.length && expect0.every(l => ord0.includes(l)) && !ord0.includes('Obst'), ord0.join(', '));
    ok('▲ beim ersten deaktiviert', await page.locator('.ordrow').first().locator('.ordbtn').first().isDisabled());
    await layout(page, `[${scheme}] Geschäft`);
    // „Haushalt & Reinigung“ ganz nach oben schieben
    for (let i = 0; i < 30; i++) {
      const labels = await page.$$eval('.ordrow .ordlbl', e => e.map(x => x.innerText.split('\n')[0]));
      const k = labels.indexOf('Haushalt & Reinigung'); if (k <= 0) break;
      await page.locator('.ordrow').nth(k).locator('[aria-label$="nach oben"]').click(); await sleep(120);
    }
    ok('mit ▲ nach oben verschoben', (await page.locator('.ordrow .ordlbl').first().innerText()).startsWith('Haushalt'));
    // eigener Bereich
    await tap('[data-act=secadd]');
    await page.fill('#ts-in', 'Bio-Regal'); await tap('#scrim [data-x=yes]');
    ok('Bereich-Blatt öffnet sich', await until(() => page.locator('#sec-in').isVisible()));
    await layout(page, `[${scheme}] Bereich-Blatt`);
    await page.fill('#sec-in', 'Hafermilch'); await tap('#scrim [data-x=add]');
    ok('Artikel dem Bereich zugeordnet', await page.locator('#scrim .secitem:has-text("Hafermilch")').count() === 1);
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/bereich-${scheme}.png` });
    await tap('#scrim [data-x=no]');
    ok('Bereich steht in der Reihenfolge mit Artikelzahl', /Bio-Regal\s*Eigener Bereich · 1 Artikel/.test(await page.locator('.ordrow:has-text("Bio-Regal")').innerText()));
    // Bereich an Position 2
    for (let i = 0; i < 40; i++) {
      const labels = await page.$$eval('.ordrow .ordlbl', e => e.map(x => x.innerText.split('\n')[0]));
      const k = labels.indexOf('Bio-Regal'); if (k <= 1) break;
      await page.locator('.ordrow').nth(k).locator('[aria-label$="nach oben"]').click(); await sleep(100);
    }
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/geschaeft-${scheme}.png`, fullPage: true });

    console.log('Einkaufsliste folgt dem Laden');
    await tap('[data-tab=shop]');
    const after = await groupsOf(), sm = after.find(x => /Supermarkt/.test(x.head));
    ok('Supermarkt zeigt das Geschäft', /Rewe Hauptstraße/.test(await page.locator('[data-act=storepick][data-arg=SUPERMARKT]').innerText()));
    ok('Reihenfolge: Haushalt, Bio-Regal, dann der Rest', sm.cats[0] === 'Haushalt & Reinigung' && sm.cats[1] === 'Bio-Regal', sm.cats.join(', '));
    ok('Hafermilch steht im Bio-Regal', await page.locator('.shopsec p.cat:has-text("Bio-Regal") + .item, .shopsec p.cat:has-text("Bio-Regal") + div').first().innerText().then(t => /Hafermilch/.test(t)).catch(() => false));
    const txt = await page.evaluate(() => EP.shoppingText(EP.buildShoppingList(db, shopRange.from, shopRange.to), db.settings).split('\n'));
    ok('Kopieren folgt der Laden-Reihenfolge', txt.indexOf('Spülmittel') < txt.indexOf('Hafermilch') && txt.indexOf('Hafermilch') < txt.indexOf('Brot'), txt.slice(0, 6).join(' | '));
    await layout(page, `[${scheme}] Einkaufsliste`);
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/einkauf-laden-${scheme}.png` });
    // Zusatzartikel: Bereich als Ziel anbieten
    await tap('.xname:has-text("Brot")');
    ok('Einsortieren bietet den Bereich des Geschäfts an', await page.locator('#scrim .opt:has-text("Bio-Regal")').count() === 1);
    await tap('#scrim .opt:has-text("Bio-Regal")');
    ok('Brot jetzt im Bio-Regal', (await page.evaluate(() => EP.buildShoppingList(db, shopRange.from, shopRange.to).supermarket.find(g => g.label === 'Bio-Regal').items.map(r => r.name).join())).includes('Brot'));
    await tap('.xname:has-text("Brot")'); await tap('#scrim .opt:has-text("Brot & Backwaren")');
    ok('zurück in die Kategorie nimmt es aus dem Bereich', !(await page.evaluate(() => EP.buildShoppingList(db, shopRange.from, shopRange.to).supermarket.find(g => g.label === 'Bio-Regal').items.map(r => r.name).join())).includes('Brot'));
    // Ohne Geschäft für diese Liste
    await tap('[data-act=storepick][data-arg=SUPERMARKT]');
    ok('Auswahl zeigt Geschäft (Standard) und „Ohne Geschäft“', await page.locator('#scrim .opt:has-text("Rewe Hauptstraße")').count() === 1 && await page.locator('#scrim .opt:has-text("Ohne Geschäft")').count() === 1);
    await tap('#scrim .opt:has-text("Ohne Geschäft")');
    const plain = (await groupsOf()).find(x => /Supermarkt/.test(x.head));
    ok('„Ohne Geschäft“ → übliche Reihenfolge, kein Bio-Regal', !plain.cats.includes('Bio-Regal') && plain.cats.indexOf('Brot & Backwaren') < plain.cats.indexOf('Haushalt & Reinigung'));
    ok('Auswahl gilt nur für diese Liste (gespeichert am Einkauf)', await page.evaluate(() => db.shopping.stores.SUPERMARKT === 'none' && !!db.settings.storeDefault.SUPERMARKT));

    console.log('Verwalten');
    await page.evaluate(() => go('settings')); await sleep(250);
    ok('Einstellungen: Zeile „Geschäfte“ mit Anzahl', /Geschäfte[\s\S]*1/.test(await page.locator('[data-act=to][data-arg=stores]').innerText()));
    await tap('[data-act=to][data-arg=stores]');
    ok('Liste nach Einkaufsort, Standard markiert', await page.locator('[data-act=storeopen]:has-text("Standard")').count() === 1);
    await layout(page, `[${scheme}] Geschäfte`);
    await tap('[data-act=storeadd][data-arg=DROGERIE]');
    await page.fill('#ts-in', 'dm'); await tap('#scrim [data-x=yes]');
    ok('Drogerie-Geschäft angelegt und Standard', await until(() => page.evaluate(() => { const s = EP.storeById(db.settings, db.settings.storeDefault.DROGERIE); return s && s.name === 'dm'; })));
    await tap('[data-act=storename]'); await page.fill('#ts-in', 'dm Bahnhof'); await tap('#scrim [data-x=yes]');
    ok('umbenannt', /dm Bahnhof/.test(await page.locator('[data-act=storename]').innerText()));
    await tap('[data-act=storedel]'); await tap('#scrim [data-x=yes]');
    ok('gelöscht → zurück zur Liste, Standard entfernt', await until(() => page.evaluate(() => !db.settings.storeDefault.DROGERIE && EP.liveStores(db.settings).length === 1)));
    if (scheme === 'light') {
      console.log('Rotation: gelöschte und Saison-Rezepte');
      const info = await page.evaluate(() => {
        const act = EP.activeRecipes(db, 'MAIN');
        const del = act[0], off = act[1];
        del.deleted = true; EP.touch(del);   // wie nach Löschen auf einem anderen Gerät
        const m = EP.monthOf(EP.todayISO());
        off.seasonMonths = [((m + 5) % 12) + 1]; EP.touch(off);   // nur in einem anderen Monat
        return persist().then(() => ({ del: del.name, off: off.name }));
      });
      await page.evaluate(() => go('rotation')); await sleep(300);
      const main = await page.locator('#main').innerText();
      const boxes = await page.$$eval('#main .box .item .nm', e => e.map(x => x.innerText));
      ok('gelöschtes Rezept erscheint nicht mehr', !main.includes(info.del), info.del);
      ok('Saison-Rezept nicht in der Liste, nur im Hinweis', !boxes.some(t => t.startsWith(info.off)) && new RegExp('keine Saison[^\\n]*' + info.off).test(main), info.off);
      ok('keine „Keine Saison“-Plaketten mehr', !(await page.locator('#main .badge:has-text("Keine Saison")').count()));
      ok('Vorschlag ohne gelöschtes Rezept', await page.evaluate(n => EP.nextEntries(db, 8, null, Math.random, 'MAIN', EP.monthOf(EP.todayISO())).every(e => recipeById(e.recipeId).name !== n), info.del));
      if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/rotation.png`, fullPage: true });
    }
    await ctx.close();
  }
  ok('keine Seitenfehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
