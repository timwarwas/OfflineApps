// E2E: Sortierung der Rezeptliste (Name, Neueste, zuletzt/lange nicht/häufig gekocht, schnellste).
// Aufruf: node e2e-sortierung.js   (SHOTS=<ordner> für Bildschirmfotos)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');
let fails = 0, passes = 0;
const ok = (m, c, extra) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || extra === undefined ? '' : ' → ' + extra)); c ? passes++ : fails++; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await sleep(60); } return false; };
const server = http.createServer((req, res) => {
  const f = __dirname + (req.url.split('?')[0] === '/' ? '/essensplanung.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8' }); res.end(fs.readFileSync(f));
});
(async () => {
  await new Promise(r => server.listen(0, r));
  const URL_ = `http://localhost:${server.address().port}/essensplanung.html`;
  const browser = await chromium.launch();
  const errors = [];
  for (const scheme of ['light', 'dark']) {
    console.log(`Durchlauf ${scheme}`);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'de-DE', colorScheme: scheme });
    await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, r => r.abort());
    const page = await ctx.newPage();
    await page.clock.install({ time: new Date('2026-10-29T10:00:00+01:00') }); await page.clock.resume();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errors.push(m.text()); });
    const tap = async sel => { await page.locator(sel).first().click(); await sleep(250); };
    const over = () => page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
    const names = () => page.$$eval('.rlist .rcard .nm', els => els.map(e => e.textContent));
    await page.goto(URL_);
    await tap('text=Neuen Haushalt einrichten');
    await page.fill('#a-n', 'Sortier-Test'); await page.fill('#a-p1', 'geheim123'); await page.fill('#a-p2', 'geheim123');
    await tap('[data-x=ok]');
    await until(() => page.locator('#tabs button').count().then(n => n === 4));
    await page.evaluate(() => {
      const day = 864e5, now = Date.now();
      const mk = (n, age, prep, fav) => { const r = newRecipe(n, 'MAIN'); r.createdAt = now - age * day; r.prepTimeMinutes = prep; r.favorite = !!fav; db.recipes.push(r); return r; };
      const a = mk('Apfelpfannkuchen', 30, 25), b = mk('Bohneneintopf', 2, null, true), c = mk('Chili', 60, 45), d = mk('Dal', 10, 15);
      const cook = (r, date) => db.plan.push(EP.touch({ id: EP.uuid(), date, lane: 'MAIN', type: 'COOK', recipeId: r.id, dayIndex: 1 }));
      cook(a, '2026-10-27'); cook(c, '2026-09-01'); cook(c, '2026-10-01'); cook(c, '2026-10-15'); cook(d, '2026-10-20');
      cook(b, '2026-11-05');   // in der Zukunft: zählt nicht
      persist();
    });
    await tap('[data-tab=recipes]');
    ok('Standard: Favorit oben, dann A–Z', JSON.stringify(await names()) === JSON.stringify(['Bohneneintopf', 'Apfelpfannkuchen', 'Chili', 'Dal']), JSON.stringify(await names()));
    const sb = await page.locator('[data-act=rsort]').boundingBox();
    ok('Sortierknopf neben der Suche, ≥44 px, kein seitliches Scrollen', sb && sb.height >= 44 && sb.x + sb.width <= 390 && !(await over()));
    ok('Knopf zeigt „A–Z“', /A–Z/.test(await page.locator('[data-act=rsort]').innerText()));
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/sort-liste-${scheme}.png` });
    const pick = async (label) => { await tap('[data-act=rsort]'); await tap(`.sortopt:has-text("${label}")`); };
    await tap('[data-act=rsort]');
    ok('Auswahl zeigt 6 Sortierungen, aktuelle markiert', await page.locator('.sortopt').count() === 6 && /Name/.test(await page.locator('.sortopt[aria-pressed=true]').innerText()));
    if (process.env.SHOTS) await page.screenshot({ path: `${process.env.SHOTS}/sort-auswahl-${scheme}.png` });
    await tap('.sortopt:has-text("Zuletzt hinzugefügt")');
    ok('Zuletzt hinzugefügt', JSON.stringify(await names()) === JSON.stringify(['Bohneneintopf', 'Dal', 'Apfelpfannkuchen', 'Chili']), JSON.stringify(await names()));
    ok('… mit „Hinzugefügt vor 2 Tagen“', /Hinzugefügt vor 2 Tagen/.test(await page.locator('.rlist .rcard').first().innerText()));
    await pick('Zuletzt gekocht');
    ok('Zuletzt gekocht (Zukunft zählt nicht)', JSON.stringify(await names()) === JSON.stringify(['Apfelpfannkuchen', 'Dal', 'Chili', 'Bohneneintopf']), JSON.stringify(await names()));
    ok('… „Zuletzt gekocht vor 2 Tagen“ / „Noch nie gekocht“', /vor 2 Tagen/.test(await page.locator('.rlist .rcard').first().innerText()) && /Noch nie gekocht/.test(await page.locator('.rlist .rcard').last().innerText()));
    await pick('Lange nicht gekocht');
    ok('Lange nicht gekocht: nie gekochte zuerst', JSON.stringify(await names()) === JSON.stringify(['Bohneneintopf', 'Chili', 'Dal', 'Apfelpfannkuchen']), JSON.stringify(await names()));
    await pick('Am häufigsten');
    ok('Am häufigsten gekocht', (await names())[0] === 'Chili' && /3× gekocht/.test(await page.locator('.rlist .rcard').first().innerText()));
    await pick('Schnellste');
    ok('Schnellste zuerst, ohne Zeit ans Ende', JSON.stringify(await names()) === JSON.stringify(['Dal', 'Apfelpfannkuchen', 'Chili', 'Bohneneintopf']), JSON.stringify(await names()));
    ok('Knopf zeigt „Schnell“', /Schnell/.test(await page.locator('[data-act=rsort]').innerText()));
    await page.fill('#rq', 'a');
    await sleep(200);
    ok('Suche und Sortierung zusammen', JSON.stringify(await names()) === JSON.stringify(['Dal', 'Apfelpfannkuchen']), JSON.stringify(await names()));
    await page.fill('#rq', ''); await sleep(150);
    await page.reload(); await until(() => page.locator('#tabs button').count().then(n => n === 4)); await tap('[data-tab=recipes]');
    ok('Wahl bleibt nach Neustart erhalten', /Schnell/.test(await page.locator('[data-act=rsort]').innerText()));
    await pick('Name');
    ok('Zurück auf A–Z', (await names())[0] === 'Bohneneintopf');
    await page.setViewportSize({ width: 1180, height: 820 }); await sleep(200);
    ok('iPad quer: kein seitliches Scrollen', !(await over()));
    await ctx.close();
  }
  ok('Keine JS-Fehler', errors.length === 0, errors.join(' | '));
  await browser.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`);
  process.exit(fails ? 1 : 0);
})();
