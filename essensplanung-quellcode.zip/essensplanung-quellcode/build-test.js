/* Testvariante: Inhalt reicht unter die Statusleiste (black-translucent), eigener Speicher → eigene Anmeldung */
const fs = require('fs');
let h = fs.readFileSync(__dirname + '/essensplanung.html', 'utf8');
const rep = (a, b, all) => { if (!h.includes(a)) throw new Error('fehlt: ' + a); h = all ? h.split(a).join(b) : h.replace(a, b); };
rep('content="default"', 'content="black-translucent"');
rep('<meta name="apple-mobile-web-app-title" content="Essensplan">', '<meta name="apple-mobile-web-app-title" content="Essen Test">');
rep('<title>Essensplanung</title>', '<title>Essensplanung Test</title>');
rep("indexedDB.open('essensplanung'", "indexedDB.open('essensplanung-test'");
rep("'ep_", "'eptest_", true);
rep('</style>', `
/* ---------- TEST: Glas bis unter die Statusleiste ---------- */
body{padding-top:0}
.top{padding-top:calc(env(safe-area-inset-top) + 8px);
  background:color-mix(in srgb,var(--enamel) 62%,transparent);-webkit-backdrop-filter:blur(18px) saturate(180%);backdrop-filter:blur(18px) saturate(180%);
  border-bottom-color:color-mix(in srgb,var(--line) 50%,transparent)}
/* dunkler Verlauf nur hinter Uhrzeit/Akku, damit die weiße Schrift von iOS lesbar bleibt */
.top:before{content:'';position:absolute;left:0;right:0;top:0;height:calc(env(safe-area-inset-top) + 6px);pointer-events:none;
  background:linear-gradient(rgba(12,20,38,.55),rgba(12,20,38,.25) 70%,rgba(12,20,38,0))}
@media (prefers-color-scheme:dark){.top:before{background:linear-gradient(rgba(0,0,0,.35),rgba(0,0,0,0))}}
@media (prefers-reduced-transparency:reduce){.top{background:var(--enamel)}}
#auth{padding-top:env(safe-area-inset-top)}
.ttl:after{content:' · Test';font-family:var(--sans);font-size:12px;color:var(--tomato);font-weight:700}
</style>`);
fs.writeFileSync(__dirname + '/essensplanung-test.html', h);
console.log('essensplanung-test.html: ' + (h.length / 1024).toFixed(1) + ' KB');
