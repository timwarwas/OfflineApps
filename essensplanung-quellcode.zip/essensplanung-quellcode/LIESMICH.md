# Essensplanung – Quellcode

Die veröffentlichte Datei `essensplanung.html` wird aus diesen Modulen gebaut.

| Datei | Inhalt |
|---|---|
| `domain.js` | Kernlogik ohne Oberfläche: Datum, Tage pro Gericht, Rotation mit Spuren und Saison, Wochenentwurf, Einheiten, Einkaufsliste, Kategorie-Erkennung, Zusammenführen beim Abgleich, Rezept-Import aus dem Scanner-Chat (`parseRecipeImport`) |
| `seed.js`, `seed.json` | Beispielrezepte (Anhang A der Spezifikation) und Umwandlung ins Datenmodell |
| `samples.json` | Beispiele für Mittagessen (6) und Kuchen (7) |
| `app-core.js` | Speicher (IndexedDB), Verschlüsselung, Anmeldung, Abgleich über den eigenen Pi (PocketBase, verschlüsselt) oder GitHub (alt), Bilder |
| `app-ops.js` | Plan-, Entwurfs-, Rezept-, Zutaten- und Sicherungsoperationen, Reste einzeln verschieben/streichen/weiterrutschen, Rezept-Import (`importRecipes`) |
| `app-ui.js` | Grundgerüst, Dialog-Blätter, Vorschlag, Woche, Einkauf |
| `app-views.js` | Rezepte, Editor, Kochansicht, Zutaten, Einkaufsorte, Rotation, Einstellungen, Anmeldung, Start |
| `style.css` | Gestaltung (Emaille-Leitbild, hell/dunkel, Druck) |
| `build.js` | setzt alles zu `essensplanung.html` zusammen und schreibt den gemeinsamen `sw.js` der Sammlung (Essensplanung, Kosten, Workout) |
| `tests.js` | 51 Logik-Tests (T1–T12 der Spezifikation + Erweiterungen) |
| `e2e.js` | 144 Browsertests mit Playwright, drei Geräte, nachgebaute GitHub-Schnittstelle und nachgebaute PocketBase |
| `anhang_b.txt` | erwarteter Textexport der Einkaufsliste (für T10) |
| `rezept-rotation-spezifikation.md` | ursprüngliche Spezifikation v1.0 |

## Befehle

```
node build.js     # baut essensplanung.html + sw.js
node tests.js     # Logik-Tests
node e2e.js       # Browsertests (braucht Playwright + Chromium)
```

## Abgleich über den Pi

- Ein Haushalt ist ein Datensatz in der PocketBase-Collection `trips` auf `https://kostenpi.tail281e3e.ts.net` (gleiche Regeln wie die Kostenaufteilung).
- Der Verbindungslink `essensplanung.html#join=<id>.<geheimnis>` enthält ein 256-Bit-Geheimnis. Daraus werden per HKDF der AES-GCM-Schlüssel und der Zugangsnachweis `X-Trip-Auth` abgeleitet. Der Server sieht nur verschlüsselte Daten.
- Bilder: je Bild zwei Datensätze (groß `f`, Vorschau `t`) mit fester ID aus SHA-256(Haushalt|Bild|Größe).
- Zusammenführen wie bisher (`EP.mergeDb`); nach jedem Schreiben wird geprüft, ob zwischenzeitlich ein anderes Gerät geschrieben hat.
- Das Geheimnis liegt auf dem Gerät nur mit dem Haushaltspasswort verschlüsselt (wie früher der GitHub-Token).
- Für Tests lässt sich der Server über `localStorage.ep_server` umstellen.
