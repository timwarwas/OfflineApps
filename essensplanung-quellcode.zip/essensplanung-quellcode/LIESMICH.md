# Essensplanung – Quellcode

Die veröffentlichte Datei `essensplanung.html` wird aus diesen Modulen gebaut.

| Datei | Inhalt |
|---|---|
| `domain.js` | Kernlogik ohne Oberfläche: Datum, Tage pro Gericht, Rotation mit Spuren und Saison, Wochenentwurf, Einheiten, Einkaufsliste, Kategorie-Erkennung, Zusammenführen beim Abgleich, Rezept-Import aus dem Scanner-Chat (`parseRecipeImport`) |
| `seed.js`, `seed.json` | Beispielrezepte (Anhang A der Spezifikation) und Umwandlung ins Datenmodell |
| `samples.json` | Beispiele für Mittagessen (6) und Kuchen (7) |
| `app-core.js` | Speicher (IndexedDB), Verschlüsselung, Anmeldung, Abgleich über den eigenen Pi (PocketBase, verschlüsselt) oder GitHub (alt), Bilder |
| `app-ops.js` | Plan-, Entwurfs-, Rezept-, Zutaten- und Sicherungsoperationen, Reste einzeln verschieben/streichen/weiterrutschen, Rezept-Import (`importRecipes`) |
| `app-ui.js` | Grundgerüst, Dialog-Blätter, Vorschlag, Woche, Einkauf |
| `app-views.js` | Rezepte, Editor, Kochansicht, Zutaten, Einkaufsorte, Rotation, Einstellungen, Anmeldung, Start |
| `style.css` | Gestaltung (Emaille-Leitbild, hell/dunkel, Druck) |
| `konto.js`, `push.js` | gemeinsame Module aller Apps (zentrales Konto, Mitteilungen) – unverändert eingebettet, Fassung muss in allen Apps gleich sein |
| `sw-push.js` | Mitteilungs-Teil des Service Workers (entschlüsselt und zeigt Push-Mitteilungen) |
| `pi/` | Push-Dienst für den Pi (`push-dienst.js`, `webpush.js`, Tests `test-dienst.js`), Einrichtungsskripte `push-einrichten.sh`, `nas-backup-einrichten.sh`, Sicherung `pb-nas-backup.sh` – liegen auch im Repo unter `pi/` |
| `build.js` | setzt alles zu `essensplanung.html` zusammen und schreibt den gemeinsamen `sw.js` der Sammlung (inkl. Mitteilungen) |
| `tests.js` | 111 Logik-Tests (T1–T12 der Spezifikation + Erweiterungen) |
| `e2e.js` | 278 Browsertests mit Playwright, drei Geräte, nachgebaute GitHub-Schnittstelle und nachgebaute PocketBase |
| `e2e-konto.js` | Browsertests zentrales Konto |
| `e2e-einkauf.js` | Browsertests Einkaufsliste über Wochen (alles Kommende, Übernahme, Abhaken je Kochtag) und Rotation |
| `e2e-geschaefte.js` | Browsertests Geschäfte mit Regal-Reihenfolge (hell/dunkel) |
| `e2e-push.js` | Browsertests Mitteilungen (Kochtimer, Kocherinnerung, Einkauf, Wochenplan) gegen den echten Push-Dienst |
| `e2e-sortierung.js` | Browsertests Sortierung der Rezeptliste |
| `e2e-vorbereiten.js` | Browsertests Beilagen an Resttagen + Kochansicht „Vorbereiten“ |
| `e2e-einkauf-posten.js` | Browsertests Start in der Einkaufsliste, Einzelposten aufklappen |
| `e2e-markttage.js` | Browsertests Markttage (Markt-Ware an anderen Tagen beim Supermarkt) |
| `e2e-anordnen.js` | Browsertests Einkaufsliste anordnen |
| `e2e-schritte.js` | Browsertests Rezept-Editor: Anleitung in einzelnen Schritten |
| `e2e-portionen.js` | Browsertests Portionen je Kochtag |
| `e2e-siri.js` | Browsertests Siri-Kurzbefehl (startet den echten Push-Dienst aus `pi/` lokal) |
| `pi/` | Kopie von `push-dienst.js`/`webpush.js` aus dem Repo (für `e2e-siri.js`) |
| `e2e-tastatur.js` | Browsertests Gericht wählen mit (simulierter) Tastatur |
| `anhang_b.txt` | erwarteter Textexport der Einkaufsliste (für T10) |
| `rezept-rotation-spezifikation.md` | ursprüngliche Spezifikation v1.0 |

## Befehle

```
node build.js     # baut essensplanung.html + sw.js
node tests.js     # Logik-Tests
node e2e.js       # Browsertests (braucht Playwright + Chromium)
node e2e-konto.js # Konto
node e2e-push.js  # Mitteilungen
node e2e-geschaefte.js  # Geschäfte
node e2e-einkauf.js     # Einkauf über Wochen
node pi/test-dienst.js  # Push-Dienst
```

## Abgleich über den Pi

- Ein Haushalt ist ein Datensatz in der PocketBase-Collection `trips` auf `https://kostenpi.tail281e3e.ts.net` (gleiche Regeln wie die Kostenaufteilung).
- Der Verbindungslink `essensplanung.html#join=<id>.<geheimnis>` enthält ein 256-Bit-Geheimnis. Daraus werden per HKDF der AES-GCM-Schlüssel und der Zugangsnachweis `X-Trip-Auth` abgeleitet. Der Server sieht nur verschlüsselte Daten.
- Bilder: je Bild zwei Datensätze (groß `f`, Vorschau `t`) mit fester ID aus SHA-256(Haushalt|Bild|Größe).
- Zusammenführen wie bisher (`EP.mergeDb`); nach jedem Schreiben wird geprüft, ob zwischenzeitlich ein anderes Gerät geschrieben hat.
- Das Geheimnis liegt auf dem Gerät nur mit dem Haushaltspasswort verschlüsselt (wie früher der GitHub-Token).
- Für Tests lässt sich der Server über `localStorage.ep_server` umstellen.

## Stand der Tests (23.11.2026)
Alle Testreihen grün: `tests.js` (123), `e2e.js` (278, zwei Geräte + Abgleich), `e2e-push.js` (45), `e2e-einkauf.js` (33),
`e2e-geschaefte.js` (83, Saison-Test jetzt ohne Zufall), `e2e-konto.js`, `e2e-einkauf-posten.js`, `e2e-anordnen.js`, `e2e-markttage.js`,
`e2e-sortierung.js`, `e2e-vorbereiten.js`, `e2e-portionen.js`, `e2e-schritte.js`, `e2e-tastatur.js`, `e2e-siri.js`.
`e2e.js` nutzt für die durchgehende Wochenansicht die Hilfen `wk()`, `fill()`, `kwText()`, `daySel()` (aktive Woche = `weekStartISO`).

## Service Worker (seit 23.11.2026)
`build.js` schreibt `sw.js`: Start sofort aus dem Offline-Speicher, im Hintergrund nachladen; ist die geladene Fassung neuer,
bekommt die Seite `{type:'sw-update'}`. `sw-update.js` (gemeinsames Mini-Modul) zeigt dann „Neue Version · Neu laden“ –
eingebaut in Essensplanung (über build.js) und unverändert eingefügt in index, kosten, spiele, workout, verstecken (nicht cocktails).
Test: `/home/claude/work/start-update-e2e.js` (ROOT = Repo-Ordner).

