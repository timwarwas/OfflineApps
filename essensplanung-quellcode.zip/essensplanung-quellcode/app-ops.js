/* ==========================================================================
   Essensplanung – App Teil 2: Operationen
   ========================================================================== */
const recipeById = id => db.recipes.find(r => r.id === id) || null;
const rotById = (d, id) => (d || db).rotation.find(e => e.id === id && !e.deleted) || null;
const ingById = id => db.ingredients.find(i => i.id === id) || null;
const liveRecipes = () => EP.live(db.recipes).filter(r => !r.archivedAt);
const isMain = p => EP.laneOf(p) === 'MAIN';
const mainPlan = d => EP.live((d || db).plan).filter(isMain);
const mainDates = d => new Set(mainPlan(d).map(p => p.date));
/* Hauptgericht-Einträge je Datum */
function planByDate(d) {
  const m = new Map();
  mainPlan(d).forEach(p => m.set(p.date, p));
  return m;
}
/* Eintrag einer Zusatzspur (Mittag, Kuchen) an einem Tag */
function laneAt(src, date, lane) { return EP.live((src || db).plan).find(p => p.date === date && EP.laneOf(p) === lane) || null; }
function laneDays(lane) { return ((db.settings.lanes || {})[lane] || { days: [] }).days; }
function laneActiveOn(lane, date) { return laneDays(lane).includes(EP.parseISO(date).getDay()); }
const unreviewedCount = () => EP.live(db.ingredients).filter(i => i.reviewed === false).length;
const blockEntries = (bid, d) => EP.live((d || db).plan).filter(p => p.blockId === bid).sort((a, b) => a.date.localeCompare(b.date));
function daysOf(recipe) { return EP.daysFor(recipe, db.settings); }
function firstFreeFrom(start) { return EP.nextFreeDates(start, 1, mainDates())[0]; }
/* nächster Tag ab start, an dem die Spur aktiv und noch frei ist */
function firstLaneDay(lane, start) {
  for (let i = 0, d = start; i < 60; i++, d = EP.addDays(d, 1)) if (laneActiveOn(lane, d) && !laneAt(db, d, lane)) return d;
  return start;
}

/* nächster Rotationseintrag für „Tauschen“: möglichst ein anderes Gericht als bisher.
   Holt wie gewohnt einen Eintrag (legt nur bei Bedarf einen Durchlauf an) und weicht sonst auf
   bereits vorhandene offene Einträge aus – ohne zusätzliche Durchläufe zu erzeugen. */
function nextDifferent(src, ex, lane, month, notRecipe) {
  const first = EP.nextEntries(src, 1, ex, rng, lane, month)[0];
  if (!first || first.recipeId !== notRecipe) return first;
  const alt = EP.pendingSorted(src, lane).find(e => !ex.has(e.id) && e.recipeId !== notRecipe && EP.inSeason(recipeById(e.recipeId), month));
  return alt || first;
}

/* ---------- Plan (übernommene Einträge, wirken sofort) ---------- */
function placeBlock(start, o) {
  const recipe = recipeById(o.recipeId);
  const n = daysOf(recipe);
  const dates = EP.nextFreeDates(start, n, mainDates());
  const bid = o.blockId || EP.uuid();
  dates.forEach((date, i) => db.plan.push(EP.touch({
    id: EP.uuid(), date, lane: 'MAIN', type: i ? 'LEFTOVER' : 'COOK', recipeId: recipe.id, blockId: bid,
    dayIndex: i + 1, dayCount: n, rotationEntryId: o.rotationEntryId || null,
    source: o.rotationEntryId ? 'ROTATION' : 'MANUAL', locked: !!o.locked, status: 'PLANNED', note: '', deleted: false,
  })));
  if (o.rotationEntryId) { const e = rotById(null, o.rotationEntryId); if (e && e.status !== 'DONE') EP.planEntry(e); }
  return dates;
}
/* Zusatzspur: ein Gericht an genau einem Tag (kein Resteblock) */
function placeLane(date, lane, recipeId, rotationEntryId) {
  const old = laneAt(db, date, lane);
  if (old) removeBlock(old.blockId, true);
  db.plan.push(EP.touch({ id: EP.uuid(), date, lane, type: 'COOK', recipeId, blockId: EP.uuid(), dayIndex: 1, dayCount: 1,
    rotationEntryId: rotationEntryId || null, source: rotationEntryId ? 'ROTATION' : 'MANUAL', locked: false, status: 'PLANNED', note: '', deleted: false }));
  if (rotationEntryId) { const e = rotById(null, rotationEntryId); if (e && e.status !== 'DONE') EP.planEntry(e); }
}
function swapLane(date, lane) {
  const p = laneAt(db, date, lane); if (!p) return null;
  const info = removeBlock(p.blockId, true);
  const ex = new Set(info && info.rotationEntryId ? [info.rotationEntryId] : []);
  const next = nextDifferent(db, ex, lane, EP.monthOf(date), info.recipeId);
  if (!next) { placeLane(date, lane, info.recipeId, info.rotationEntryId); return null; }
  placeLane(date, lane, next.recipeId, next.id);
  return recipeById(next.recipeId);
}
function removeBlock(bid, releaseIt) {
  const es = blockEntries(bid);
  if (!es.length) return null;
  const info = { recipeId: es[0].recipeId, rotationEntryId: es[0].rotationEntryId, locked: es[0].locked, start: es[0].date };
  es.forEach(EP.tomb);
  if (releaseIt !== false && info.rotationEntryId) {
    const e = rotById(null, info.rotationEntryId);
    if (e && e.status === 'PLANNED') EP.release(db, e);
  }
  return info;
}
function markCooked(bid) {
  const es = blockEntries(bid);
  es.forEach(p => { p.status = 'DONE'; EP.touch(p); });
  const e = es[0] && es[0].rotationEntryId && rotById(null, es[0].rotationEntryId);
  if (e) EP.completeEntry(e);
}
function toggleLock(bid) {
  const es = blockEntries(bid);
  const v = !(es[0] && es[0].locked);
  es.forEach(p => { p.locked = v; EP.touch(p); });
  return v;
}
function swapBlock(bid) {
  const info = removeBlock(bid, true);
  if (!info) return null;
  const ex = new Set(info.rotationEntryId ? [info.rotationEntryId] : []);
  const next = nextDifferent(db, ex, 'MAIN', EP.monthOf(info.start), info.recipeId);
  if (!next) { placeBlock(info.start, info); return null; }
  placeBlock(info.start, { recipeId: next.recipeId, rotationEntryId: next.id, locked: info.locked });
  return recipeById(next.recipeId);
}
function moveBlock(bid, newStart) {
  const info = removeBlock(bid, false);
  if (info) placeBlock(newStart, Object.assign({}, info, { blockId: bid }));
}
/* ---------- Reste einzeln verschieben, streichen, weiterrutschen ---------- */
/* Tage eines Gerichts neu durchzählen (Kochtag 1/n, Reste 2/n …) */
function renumberBlock(bid, src) {
  const es = blockEntries(bid, src), n = es.length;
  es.forEach((p, i) => { if (p.dayIndex !== i + 1 || p.dayCount !== n) { p.dayIndex = i + 1; p.dayCount = n; EP.touch(p); } });
}
/* Prüft, ob Reste an einen Tag passen; liefert eine Fehlermeldung oder '' */
function restMoveCheck(p, date, src) {
  src = src || db;
  if (!date) return 'Bitte einen Tag wählen.';
  const cook = blockEntries(p.blockId, src).find(x => x.type === 'COOK');
  if (cook && date <= cook.date) return `Reste gehen erst nach dem Kochtag (${EP.weekday(cook.date)} ${EP.fmtShort(cook.date)}).`;
  if (date < EP.todayISO()) return 'Dieser Tag liegt in der Vergangenheit.';
  if (date === p.date) return 'Die Reste sind schon an diesem Tag eingeplant.';
  const other = planByDate(src).get(date);
  if (other) return `An diesem Tag ist schon etwas eingeplant (${other.type === 'BLOCKED' ? 'gesperrt' : (recipeById(other.recipeId) || {}).name || 'Gericht'}).`;
  if (draft && src === draft.clone && draft.blocked.has(date)) return 'Dieser Tag ist im Entwurf gesperrt.';
  return '';
}
/* erster passender Tag für Reste nach dem aktuellen */
function restSuggest(p, src) {
  for (let i = 1, d = EP.addDays(p.date, 1); i < 60; i++, d = EP.addDays(d, 1)) if (!restMoveCheck(p, d, src)) return d;
  return EP.addDays(p.date, 1);
}
function moveRest(entryId, date, src) {
  const p = EP.live((src || db).plan).find(x => x.id === entryId);
  if (!p) return;
  p.date = date;
  if (date >= EP.todayISO()) p.status = 'PLANNED';   // aus der Vergangenheit geholte Reste sind wieder offen
  EP.touch(p);
  renumberBlock(p.blockId, src);
}
/* erster freier Tag ab heute für Reste eines vergangenen Tages */
function restFromToday(p, src) {
  for (let i = 0, d = EP.todayISO(); i < 60; i++, d = EP.addDays(d, 1)) if (!restMoveCheck(p, d, src)) return d;
  return null;
}
/* Resttag sperren: in der Zukunft rutschen die Reste weiter; in der Vergangenheit (z. B. doch auswärts
   gegessen) kommen nur die Reste dieses Tages auf den ersten freien Tag ab heute */
function blockRest(p, date, src, extra) {
  if (date < EP.todayISO()) {
    const to = restFromToday(p, src);
    if (to) moveRest(p.id, to, src); else dropRest(p.id, src);
  } else slideLeftovers(p.blockId, date, src, extra);
}
function dropRest(entryId, src) {
  const p = EP.live((src || db).plan).find(x => x.id === entryId);
  if (!p) return;
  EP.tomb(p);
  renumberBlock(p.blockId, src);
}
/* Reste ab einem Tag rutschen auf die nächsten freien Tage (Kochtag bleibt) */
function slideLeftovers(bid, date, src, extra) {
  src = src || db;
  const later = blockEntries(bid, src).filter(x => x.type === 'LEFTOVER' && x.date >= date);
  if (!later.length) return;
  const occ = mainDates(src);
  later.forEach(x => occ.delete(x.date));
  occ.add(date);
  (extra || []).forEach(d => occ.add(d));
  const dates = EP.nextFreeDates(date, later.length, occ);
  const today = EP.todayISO();
  later.forEach((x, i) => { if (x.date !== dates[i]) { x.date = dates[i]; if (x.date >= today) x.status = 'PLANNED'; EP.touch(x); } });
  renumberBlock(bid, src);
}
/* Im Wochenentwurf: Tag mit Übertrag-Resten sperren → Reste rutschen weiter, Entwurf plant drumherum */
function draftBlockCarry(date, note) {
  const p = planByDate(draft.clone).get(date);
  draft.blocked.set(date, note);
  if (p && p.type === 'LEFTOVER') blockRest(p, date, draft.clone, [...draft.blocked.keys()]);
  relayoutDraft();
}
function blockDay(date, note) {
  const p = planByDate().get(date);
  if (p && p.type === 'LEFTOVER') {   // Resttag: nur die Reste rutschen weiter, der Kochtag bleibt
    db.plan.push(EP.touch({ id: EP.uuid(), date, type: 'BLOCKED', recipeId: null, blockId: null, dayIndex: 0, dayCount: 0,
      rotationEntryId: null, source: 'MANUAL', locked: false, status: 'PLANNED', note: note || '', deleted: false }));
    blockRest(p, date);
    return;
  }
  let info = null;
  if (p && p.blockId) info = removeBlock(p.blockId, false);
  else if (p) EP.tomb(p);
  db.plan.push(EP.touch({ id: EP.uuid(), date, type: 'BLOCKED', recipeId: null, blockId: null, dayIndex: 0, dayCount: 0,
    rotationEntryId: null, source: 'MANUAL', locked: false, status: 'PLANNED', note: note || '', deleted: false }));
  if (info) placeBlock(info.start, info); // Reste rutschen weiter (A6)
}
function unblockDay(date) {
  const p = planByDate().get(date);
  if (p && p.type === 'BLOCKED') EP.tomb(p);
}

/* ---------- Wochenentwurf (5.4) ---------- */
let draft = null;
function startDraft(ws) {
  const today = EP.todayISO();
  const days = EP.weekDays(ws), inWeek = new Set(days);
  const clone = { settings: db.settings, recipes: db.recipes, rotation: deep(db.rotation), plan: deep(db.plan) };
  const planLive = EP.live(clone.plan);
  const remove = new Set();
  planLive.forEach(p => {
    if (!inWeek.has(p.date) || p.type === 'BLOCKED' || p.date < today || p.locked) return;
    const cook = planLive.find(x => x.blockId === p.blockId && x.type === 'COOK');
    if (cook && (cook.date < ws || cook.date < today)) return; // Übertrag bzw. bereits begonnen
    remove.add(p.blockId || p.id);
  });
  remove.forEach(bid => {
    const es = planLive.filter(p => p.blockId === bid || p.id === bid);
    es.forEach(EP.tomb);
    const rid = es[0] && es[0].rotationEntryId;
    const e = rid && clone.rotation.find(x => x.id === rid && !x.deleted);
    if (e && e.status === 'PLANNED') EP.release(clone, e);
  });
  draft = { ws, clone, sequence: [], blocked: new Map(), drafts: [], lanes: [] };
  relayoutDraft();
  buildLaneDrafts();
}
/* Zusatzspuren im Entwurf: je aktivem Tag das nächste Gericht der eigenen Rotation */
function buildLaneDrafts() {
  const today = EP.todayISO();
  draft.lanes = [];
  ['LUNCH', 'CAKE'].forEach(lane => {
    const used = new Set();
    EP.weekDays(draft.ws).forEach(d => {
      if (d < today || !laneActiveOn(lane, d) || laneAt(draft.clone, d, lane)) return;
      const e = EP.nextEntries(draft.clone, 1, used, rng, lane, EP.monthOf(d))[0];
      if (!e) return;
      used.add(e.id);
      draft.lanes.push({ id: EP.uuid(), date: d, lane, recipeId: e.recipeId, rotationEntryId: e.id });
    });
  });
}
const laneUsed = lane => new Set(draft.lanes.filter(x => x.lane === lane && x.rotationEntryId).map(x => x.rotationEntryId));
function draftLane(date, lane) { return draft.lanes.find(x => x.date === date && x.lane === lane) || null; }
function draftLaneNext(date, lane) {
  let x = draftLane(date, lane);
  const e = EP.nextEntries(draft.clone, 1, laneUsed(lane), rng, lane, EP.monthOf(date))[0];
  if (!e) return notify('Keine weiteren Gerichte in dieser Rotation.');
  if (!x) { x = { id: EP.uuid(), date, lane }; draft.lanes.push(x); }
  x.recipeId = e.recipeId; x.rotationEntryId = e.id;
}
function draftLanePick(date, lane, recipeId) {
  let x = draftLane(date, lane);
  const used = laneUsed(lane); if (x) used.delete(x.rotationEntryId);
  const e = EP.manualPickEntry(draft.clone, recipeId, used);
  if (!x) { x = { id: EP.uuid(), date, lane }; draft.lanes.push(x); }
  x.recipeId = recipeId; x.rotationEntryId = e ? e.id : null;
}
function draftLaneRemove(date, lane) { draft.lanes = draft.lanes.filter(x => !(x.date === date && x.lane === lane)); }
function relayoutDraft() {
  const days = EP.weekDays(draft.ws);
  const occupied = mainDates(draft.clone);
  draft.blocked.forEach((_, d) => occupied.add(d));
  const res = EP.layoutDraft({
    days, occupied, sequence: draft.sequence,
    nextFn: (ex, start) => EP.nextEntries(draft.clone, 1, ex, rng, 'MAIN', EP.monthOf(start))[0],
    recipeOf: recipeById, settings: db.settings, today: EP.todayISO(),
  });
  draft.sequence = res.sequence;
  draft.drafts = res.drafts;
}
function draftUsed() { return new Set(draft.sequence.filter(s => s.kind === 'ROT').map(s => s.entryId)); }
function draftSwap(bid) {
  const i = draft.sequence.findIndex(s => s.blockId === bid);
  if (i < 0) return;
  const at = (draft.drafts.find(x => x.blockId === bid) || {}).date || draft.ws;
  const next = nextDifferent(draft.clone, draftUsed(), 'MAIN', EP.monthOf(at), draft.sequence[i].recipeId);
  if (!next) return notify('Keine weiteren Gerichte in der Rotation.');
  draft.sequence[i] = { kind: 'ROT', entryId: next.id, recipeId: next.recipeId, blockId: bid, locked: draft.sequence[i].locked };
  relayoutDraft();
}
function draftMove(bid, dir) {
  const i = draft.sequence.findIndex(s => s.blockId === bid), j = i + dir;
  if (i < 0 || j < 0 || j >= draft.sequence.length) return;
  [draft.sequence[i], draft.sequence[j]] = [draft.sequence[j], draft.sequence[i]];
  relayoutDraft();
}
function draftPick(bid, recipeId) {
  const i = draft.sequence.findIndex(s => s.blockId === bid);
  if (i < 0) return;
  const used = draftUsed(); used.delete(draft.sequence[i].entryId);
  const e = EP.manualPickEntry(draft.clone, recipeId, used);
  draft.sequence[i] = e ? { kind: 'ROT', entryId: e.id, recipeId, blockId: bid, locked: draft.sequence[i].locked }
    : { kind: 'MAN', recipeId, blockId: bid, locked: draft.sequence[i].locked };
  relayoutDraft();
}
function draftToggleLock(bid) {
  const s = draft.sequence.find(x => x.blockId === bid);
  if (s) { s.locked = !s.locked; relayoutDraft(); }
}
function commitDraft() {
  const c = draft.clone;
  draft.drafts.forEach(d => {
    c.plan.push(EP.touch(Object.assign({ id: EP.uuid(), deleted: false }, d)));
    if (d.type === 'COOK' && d.rotationEntryId) {
      const e = c.rotation.find(x => x.id === d.rotationEntryId && !x.deleted);
      if (e) EP.planEntry(e);
    }
  });
  draft.lanes.forEach(x => {
    c.plan.push(EP.touch({ id: EP.uuid(), date: x.date, lane: x.lane, type: 'COOK', recipeId: x.recipeId, blockId: EP.uuid(), dayIndex: 1, dayCount: 1,
      rotationEntryId: x.rotationEntryId || null, source: x.rotationEntryId ? 'ROTATION' : 'MANUAL', locked: false, status: 'PLANNED', note: '', deleted: false }));
    const e = x.rotationEntryId && c.rotation.find(r => r.id === x.rotationEntryId && !r.deleted);
    if (e) EP.planEntry(e);
  });
  draft.blocked.forEach((note, date) => c.plan.push(EP.touch({ id: EP.uuid(), date, lane: 'MAIN', type: 'BLOCKED', recipeId: null, blockId: null,
    dayIndex: 0, dayCount: 0, rotationEntryId: null, source: 'MANUAL', locked: false, status: 'PLANNED', note, deleted: false })));
  db.rotation = c.rotation; db.plan = c.plan;
  draft = null;
}
/* Anzeige-Einträge einer Woche (übernommen oder Entwurf): Hauptgerichte + Zusatzspuren */
function weekEntries(ws) {
  const days = EP.weekDays(ws);
  const isDraft = draft && draft.ws === ws;
  const src = isDraft ? draft.clone : db;
  const m = planByDate(src);
  const out = new Map(), lanes = { LUNCH: new Map(), CAKE: new Map() };
  days.forEach(d => {
    if (m.has(d)) out.set(d, Object.assign({ drafted: false }, m.get(d)));
    ['LUNCH', 'CAKE'].forEach(l => { const p = laneAt(src, d, l); if (p) lanes[l].set(d, Object.assign({ drafted: false }, p)); });
  });
  if (isDraft) {
    draft.blocked.forEach((note, d) => out.set(d, { date: d, type: 'BLOCKED', note, drafted: true, extraBlocked: true }));
    draft.drafts.forEach(x => { if (days.includes(x.date)) out.set(x.date, Object.assign({ drafted: true }, x)); });
    draft.lanes.forEach(x => lanes[x.lane].set(x.date, Object.assign({ drafted: true, type: 'COOK' }, x)));
  }
  out.lanes = lanes;
  return out;
}

/* ---------- Rezepte ---------- */
function findRecipeByName(name) {
  const n = name.trim().toLowerCase();
  return EP.live(db.recipes).find(r => r.name.trim().toLowerCase() === n) || null;
}
function newRecipe(name, kind) {
  kind = kind || 'MAIN';
  const max = EP.live(db.recipes).reduce((m, r) => Math.max(m, r.sortOrder || 0), 0);
  return EP.touch({ id: EP.uuid(), name: name.trim().slice(0, 120), kind, seasonMonths: null, inRotation: true, weight: 1,
    servings: kind === 'CAKE' ? 12 : db.settings.portionsPerDay, daysOverride: null, sortOrder: max + 1, notes: '', instructions: '',
    prepTimeMinutes: null, tags: [], archivedAt: null, deleted: false, images: [], ingredients: [] });
}
/* Schnellerfassung – liefert {added, restored, skipped} */
function quickAdd(lines, kind) {
  const res = { added: 0, restored: 0, skipped: 0 };
  lines.map(l => l.replace(/^[-*•\d.)\s]+/, '').trim()).filter(Boolean).forEach(name => {
    const ex = findRecipeByName(name);
    if (ex && !ex.archivedAt) { res.skipped++; return; }
    if (ex) { ex.archivedAt = null; ex.inRotation = true; EP.touch(ex); EP.syncRecipeIntoCycles(db, ex, rng); res.restored++; return; }
    const r = newRecipe(name, kind);
    db.recipes.push(r);
    EP.syncRecipeIntoCycles(db, r, rng);
    res.added++;
  });
  return res;
}
function setWeight(r, w) { r.weight = Math.min(5, Math.max(1, w)); EP.touch(r); EP.syncRecipeIntoCycles(db, r, rng); }
function setInRotation(r, v) { r.inRotation = v; EP.touch(r); EP.syncRecipeIntoCycles(db, r, rng); }
function archiveRecipe(r) { r.archivedAt = Date.now(); EP.touch(r); EP.syncRecipeIntoCycles(db, r, rng); }
/* ---------- Rezept-Import aus dem Scanner-Chat ----------
   items: [{ rec (aus EP.parseRecipeImport), kind, mode: 'new' | 'replace' | 'copy' | 'skip' }]
   liefert { added, replaced, skipped, newIngredients } */
function uniqueRecipeName(name) {
  if (!findRecipeByName(name)) return name;
  for (let i = 2; i < 100; i++) { const n = `${name} (${i})`; if (!findRecipeByName(n)) return n; }
  return name + ' ' + Date.now();
}
function importRecipes(items) {
  const res = { added: 0, replaced: 0, skipped: 0, newIngredients: 0 };
  items.forEach(it => {
    if (it.mode === 'skip') { res.skipped++; return; }
    const src = it.rec, kind = it.kind || src.kind;
    const ings = src.ingredients.map((x, k) => {
      let ing = findIngredient(x.name);
      if (!ing) { ing = createIngredient(x.name, x.category, x.unit || 'STUECK', false); res.newIngredients++; }
      return { ingredientId: ing.id, quantity: x.quantity, unit: x.quantity == null ? null : (x.unit || ing.defaultUnit || 'STUECK'), note: x.note || '', sortOrder: k + 1 };
    });
    const fields = { kind, servings: src.servings, prepTimeMinutes: src.prepTimeMinutes, instructions: src.instructions, ingredients: ings };
    const ex = findRecipeByName(src.name);
    if (ex && it.mode === 'replace') {
      // Bilder, Gewichtung und Rotationsstatus bleiben; Saison nur, wenn im Import angegeben
      Object.assign(ex, fields, { archivedAt: null, tags: src.tags.length ? src.tags : ex.tags, notes: src.notes || ex.notes,
        seasonMonths: src.seasonMonths || ex.seasonMonths, daysOverride: kind === 'MAIN' ? ex.daysOverride : null });
      EP.touch(ex); EP.syncRecipeIntoCycles(db, ex, rng); res.replaced++;
      return;
    }
    const r = newRecipe(ex ? uniqueRecipeName(src.name) : src.name, kind);
    Object.assign(r, fields, { tags: src.tags, notes: src.notes, seasonMonths: src.seasonMonths });
    db.recipes.push(r); EP.syncRecipeIntoCycles(db, r, rng); res.added++;
  });
  return res;
}


/* ---------- Zutaten ---------- */
function findIngredient(name) {
  const n = name.trim().toLowerCase();
  return EP.live(db.ingredients).find(i => i.name.toLowerCase() === n) || null;
}
function createIngredient(name, category, unit, reviewed) {
  const i = EP.touch({ id: EP.uuid(), name: name.trim(), category: category || EP.guessCategory(name), shoppingSource: null,
    defaultUnit: unit || 'STUECK', reviewed: !!reviewed, deleted: false });
  db.ingredients.push(i);
  return i;
}
function ingredientUsage(id) { return liveRecipes().filter(r => r.ingredients.some(x => x.ingredientId === id)).length; }
function mergeIngredient(fromId, toId) {
  EP.live(db.recipes).forEach(r => {
    let ch = false;
    r.ingredients.forEach(x => { if (x.ingredientId === fromId) { x.ingredientId = toId; ch = true; } });
    if (ch) EP.touch(r);
  });
  const f = ingById(fromId); if (f) EP.tomb(f);
}

/* ---------- Einkaufsliste: Zustand je Zeitraum (4.8) ---------- */
function shopState(from, to) {
  if (db.shopping.from !== from || db.shopping.to !== to) {
    db.shopping = EP.touch({ from, to, checkedKeys: [], extraItems: [] });
  }
  return db.shopping;
}

/* ---------- Sicherung ---------- */
async function exportData(withImages) {
  const data = deep(db);
  delete data.household;
  const out = { format: 'essensplanung', version: 1, exportedAt: new Date().toISOString(), data };
  if (withImages) {
    out.images = {};
    for (const r of liveRecipes()) for (const im of r.images) {
      const full = await Images.get(im.fileKey, false), th = await Images.get(im.fileKey, true);
      if (full) out.images[im.fileKey] = { full, thumb: th || full };
    }
  }
  return JSON.stringify(out, null, 1);
}
async function importData(json, mode) {
  const src = repairDb(json.data || json);
  if (json.images) for (const [k, v] of Object.entries(json.images)) await Images.put(k, v.full, v.thumb);
  if (mode === 'replace') {
    // alles Bestehende als gelöscht markieren (damit der Abgleich es auch auf anderen Geräten entfernt)
    ['recipes', 'ingredients', 'rotation', 'plan'].forEach(k => EP.live(db[k]).forEach(EP.tomb));
    ['recipes', 'ingredients', 'rotation', 'plan'].forEach(k => src[k].forEach(x => { EP.touch(x); db[k].push(x); }));
    db.settings = EP.touch(Object.assign({}, src.settings));
    return { recipes: EP.live(src.recipes).length };
  }
  // Zusammenführen per Name
  const idMap = new Map();
  EP.live(src.ingredients).forEach(i => {
    const ex = findIngredient(i.name);
    if (ex) idMap.set(i.id, ex.id);
    else { const n = createIngredient(i.name, i.category, i.defaultUnit, i.reviewed !== false); n.shoppingSource = i.shoppingSource || null; idMap.set(i.id, n.id); }
  });
  let added = 0, updated = 0;
  EP.live(src.recipes).filter(r => !r.archivedAt).forEach(r => {
    const ings = r.ingredients.map(x => Object.assign({}, x, { ingredientId: idMap.get(x.ingredientId) })).filter(x => x.ingredientId);
    const ex = findRecipeByName(r.name);
    if (ex) {
      Object.assign(ex, { kind: r.kind || 'MAIN', seasonMonths: r.seasonMonths || null, servings: r.servings, weight: r.weight, daysOverride: r.daysOverride, notes: r.notes, instructions: r.instructions,
        prepTimeMinutes: r.prepTimeMinutes, tags: r.tags, ingredients: ings, images: r.images.length ? r.images : ex.images, archivedAt: null });
      EP.touch(ex); EP.syncRecipeIntoCycles(db, ex, rng); updated++;
    } else {
      const n = newRecipe(r.name, r.kind);
      Object.assign(n, { seasonMonths: r.seasonMonths || null, inRotation: r.inRotation, weight: r.weight, servings: r.servings, daysOverride: r.daysOverride, notes: r.notes,
        instructions: r.instructions, prepTimeMinutes: r.prepTimeMinutes, tags: r.tags, ingredients: ings, images: r.images });
      db.recipes.push(n); EP.syncRecipeIntoCycles(db, n, rng); added++;
    }
  });
  return { added, updated };
}
