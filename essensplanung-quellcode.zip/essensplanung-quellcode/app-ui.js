/* ==========================================================================
   Essensplanung – App Teil 3: Oberfläche
   ========================================================================== */
const ICON = {
  plate: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/></svg>',
  week: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/></svg>',
  cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 4h2.5l2.2 11h10.6l2-7.5H7"/><circle cx="9.5" cy="19.5" r="1.3"/><circle cx="17" cy="19.5" r="1.3"/></svg>',
  book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 4.5h11a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11M9 8h6"/></svg>',
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M15 5l-7 7 7 7"/></svg>',
  lock: '<svg class="lock" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
};
const TABS = [['suggest', 'Vorschlag', ICON.plate], ['week', 'Woche', ICON.week], ['shop', 'Einkauf', ICON.cart], ['recipes', 'Rezepte', ICON.book]];
const TITLES = { suggest: 'Als Nächstes', week: 'Wochenplan', shop: 'Einkaufsliste', recipes: 'Rezepte',
  edit: 'Rezept', ingredients: 'Zutaten', rotation: 'Rotation', settings: 'Einstellungen', sync: 'Geräteabgleich', sources: 'Einkaufsorte' };
const LANE_LABEL = { MAIN: 'Hauptgerichte', LUNCH: 'Mittag', CAKE: 'Kuchen' };
let suggestLane = 'MAIN';

let route = { name: 'suggest' }, stack = [];
let weekStartISO = EP.weekStart(EP.todayISO());
let shopRange = null;
let recipeFilter = { q: '', status: 'all', tag: '', kind: 'MAIN' };

/* ---------- Hilfen ---------- */
function notify(t) {
  const el = $('#toast'); el.textContent = t; el.classList.add('on');
  clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove('on'), 2400);
}
function daysLabel(n) { return n + ' ' + (n === 1 ? 'Tag' : 'Tage'); }
function rangeLabel(dates) {
  if (!dates.length) return '';
  const a = dates[0], b = dates[dates.length - 1];
  return a === b ? `${EP.weekday(a)} ${EP.fmtShort(a)}` : `${EP.weekday(a)} ${EP.fmtShort(a)}–${EP.weekday(b)} ${EP.fmtShort(b)}`;
}
function coverKey(r) { const c = (r.images || []).find(i => i.isCover) || (r.images || [])[0]; return c ? c.fileKey : null; }
function parseQty(s) {
  if (s == null) return null;
  const t = String(s).trim().replace(',', '.');
  if (!t) return null;
  const v = parseFloat(t);
  return isFinite(v) && v > 0 ? v : null;
}
const unitLabel = u => (u ? EP.UNITS[u].s : '');

/* ---------- Dialog-Blätter ---------- */
function openSheet(html, bind) {
  closeSheet();
  const s = document.createElement('div');
  s.className = 'scrim'; s.id = 'scrim';
  s.innerHTML = `<div class="sheet" role="dialog" aria-modal="true"><div class="grab" aria-hidden="true"><i></i></div>${html}</div>`;
  s.addEventListener('click', e => { if (e.target === s) closeSheet(); });
  document.body.appendChild(s);
  const sheet = s.firstElementChild;
  enableSwipeDown(sheet, s);
  if (bind) bind(sheet);
  const f = $('input,select,textarea', s); if (f && !('ontouchstart' in window)) f.focus();
}
/* Blatt am Griff (oder ganz oben) nach unten ziehen → schließen */
function enableSwipeDown(sheet, scrim) {
  let startY = null, dy = 0, t0 = 0, dragging = false;
  const pointY = e => (e.touches ? e.touches[0].clientY : e.clientY);
  const start = e => {
    const onGrab = !!e.target.closest('.grab');
    if (!onGrab && (sheet.scrollTop > 0 || e.target.closest('input,select,textarea'))) return;
    startY = pointY(e); dy = 0; t0 = Date.now(); dragging = false;
  };
  const move = e => {
    if (startY == null) return;
    dy = Math.max(0, pointY(e) - startY);
    if (!dragging && dy > 6) { dragging = true; sheet.style.transition = 'none'; sheet.style.animation = 'none'; }
    if (!dragging) return;
    sheet.style.transform = `translateY(${dy}px)`;
    scrim.style.background = `rgba(10,16,28,${(0.48 * Math.max(0, 1 - dy / 420)).toFixed(3)})`;
    if (e.cancelable) e.preventDefault();
  };
  const end = () => {
    if (startY == null) return;
    const speed = dy / Math.max(1, Date.now() - t0);
    startY = null;
    if (!dragging) return;
    sheet.addEventListener('click', ev => { ev.stopPropagation(); ev.preventDefault(); }, { capture: true, once: true }); // kein Klick nach dem Ziehen
    if (dy > 90 || speed > 0.6) {
      sheet.style.transition = 'transform .18s ease-in';
      sheet.style.transform = 'translateY(105%)';
      scrim.style.transition = 'background .18s'; scrim.style.background = 'rgba(10,16,28,0)';
      setTimeout(() => { if (scrim.isConnected) scrim.remove(); }, 180);
    } else {
      sheet.style.transition = 'transform .2s ease-out';
      sheet.style.transform = ''; scrim.style.background = '';
    }
  };
  sheet.addEventListener('touchstart', start, { passive: true });
  sheet.addEventListener('touchmove', move, { passive: false });
  sheet.addEventListener('touchend', end);
  sheet.addEventListener('touchcancel', end);
  // Maus/Stift: am Griff ziehen
  const grab = $('.grab', sheet);
  grab.addEventListener('pointerdown', e => {
    if (e.pointerType === 'touch') return;
    start(e); grab.setPointerCapture(e.pointerId);
    const mv = ev => move(ev), up = () => { end(); grab.removeEventListener('pointermove', mv); grab.removeEventListener('pointerup', up); };
    grab.addEventListener('pointermove', mv); grab.addEventListener('pointerup', up);
  });
}
function closeSheet() { const s = $('#scrim'); if (s) s.remove(); }
function confirmSheet(title, detail, yes, no, onYes, danger) {
  openSheet(`<h2>${esc(title)}</h2>${detail ? `<p class="sub" style="margin-top:6px">${esc(detail)}</p>` : ''}
    <div class="btns two"><button class="btn" data-x="no">${esc(no)}</button>
    <button class="btn ${danger ? 'danger' : 'primary'}" data-x="yes">${esc(yes)}</button></div>`, el => {
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { closeSheet(); onYes(); };
  });
}
function promptSheet(title, label, value, okLabel, onOk) {
  openSheet(`<h2>${esc(title)}</h2><label class="field"><span>${esc(label)}</span><input class="in" id="pv" value="${esc(value || '')}"></label>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">${esc(okLabel)}</button></div>`, el => {
    const go = () => { const v = $('#pv', el).value.trim(); closeSheet(); onOk(v); };
    $('[data-x=no]', el).onclick = closeSheet; $('[data-x=yes]', el).onclick = go;
    $('#pv', el).onkeydown = e => { if (e.key === 'Enter') go(); };
  });
}
/* Startdatum wählen, mit Live-Anzeige der belegten Tage */
function dateSheet(title, recipe, start, okLabel, onOk) {
  const occ = mainDates();
  const preview = d => EP.nextFreeDates(d, daysOf(recipe), occ);
  openSheet(`<h2>${esc(title)}</h2><p class="serif" style="font-size:19px;margin-top:4px">${esc(recipe.name)}</p>
    <label class="field"><span>Startdatum (Kochtag)</span><input class="in" type="date" id="dv" value="${start}"></label>
    <p class="hint" id="dp"></p>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">${esc(okLabel)}</button></div>`, el => {
    const upd = () => { const v = $('#dv', el).value; $('#dp', el).textContent = v ? `Belegt ${daysLabel(daysOf(recipe))}: ${rangeLabel(preview(v))}` : ''; };
    $('#dv', el).oninput = upd; upd();
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { const v = $('#dv', el).value; if (!v) return; closeSheet(); onOk(v); };
  });
}
/* Neuen Tag für einen einzelnen Resttag wählen (mit Prüfung) */
function restSheet(recipe, p, src, onOk) {
  openSheet(`<h2>Reste verschieben</h2><p class="serif" style="font-size:19px;margin-top:4px">${esc(recipe ? recipe.name : '')}</p>
    <p class="hint" style="margin-top:0">Bisher: ${EP.weekdayLong(p.date)}, ${EP.fmtShort(p.date)}</p>
    <label class="field"><span>Neuer Tag</span><input class="in" type="date" id="dv" value="${restSuggest(p, src)}"></label>
    <p class="hint" id="dp"></p>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Verschieben</button></div>`, el => {
    const upd = () => {
      const v = $('#dv', el).value, err = restMoveCheck(p, v, src);
      $('#dp', el).textContent = err || `Reste am ${EP.weekdayLong(v)}, ${EP.fmtShort(v)}`;
      $('#dp', el).classList.toggle('warn', !!err);
      $('[data-x=yes]', el).disabled = !!err;
    };
    $('#dv', el).oninput = upd; $('#dv', el).onchange = upd; upd();
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { const v = $('#dv', el).value; if (restMoveCheck(p, v, src)) return; closeSheet(); onOk(v); };
  });
}
/* Tag für eine Zusatzspur wählen */
function laneDateSheet(title, recipe, lane, start, okLabel, onOk) {
  openSheet(`<h2>${esc(title)}</h2><p class="serif" style="font-size:19px;margin-top:4px">${esc(recipe.name)}</p>
    <label class="field"><span>Tag</span><input class="in" type="date" id="dv" value="${start}"></label>
    <p class="hint" id="dp"></p>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">${esc(okLabel)}</button></div>`, el => {
    const upd = () => {
      const v = $('#dv', el).value, o = v && laneAt(db, v, lane);
      $('#dp', el).textContent = !v ? '' : o ? `Ersetzt „${(recipeById(o.recipeId) || {}).name || ''}“ am ${EP.weekday(v)} ${EP.fmtShort(v)}.` : `${LANE_LABEL[lane]} am ${EP.weekdayLong(v)}, ${EP.fmtShort(v)}`;
    };
    $('#dv', el).oninput = upd; upd();
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { const v = $('#dv', el).value; if (!v) return; closeSheet(); onOk(v); };
  });
}
/* Rezept auswählen (aktive zuerst), beschränkt auf eine Art */
function recipePickSheet(title, onPick, kind) {
  kind = kind || 'MAIN';
  const m = EP.monthOf(EP.todayISO());
  const list = liveRecipes().filter(r => EP.laneOf(r) === kind).sort((a, b) => (b.inRotation - a.inRotation) || a.name.localeCompare(b.name, 'de'));
  const html = list.map(r => `<button class="opt" data-id="${r.id}"><span class="grow"><span class="serif" style="font-size:17px">${esc(r.name)}</span>
    <small>${r.inRotation ? 'In Rotation' : 'Pausiert'}${kind === 'MAIN' ? ' · ' + daysLabel(daysOf(r)) : ''}${EP.inSeason(r, m) ? '' : ' · außerhalb der Saison (' + EP.seasonLabel(r) + ')'}</small></span></button>`).join('');
  openSheet(`<h2>${esc(title)}</h2><input class="in" id="ps" placeholder="Rezept suchen" style="margin-top:10px">
    <div class="pick" id="pl">${html || `<p class="empty">Noch keine ${esc(LANE_LABEL[kind])}-Rezepte angelegt.</p>`}</div>`, el => {
    $('#ps', el).oninput = e => { const q = e.target.value.toLowerCase(); $$('.opt', el).forEach(b => b.classList.toggle('hidden', !b.textContent.toLowerCase().includes(q))); };
    $$('.opt', el).forEach(b => b.onclick = () => { closeSheet(); onPick(b.dataset.id); });
  });
}
function optionsSheet(title, sub, opts) {
  openSheet(`<h2>${esc(title)}</h2>${sub ? `<p class="sub">${sub}</p>` : ''}${opts.map((o, i) =>
    `<button class="opt ${o.danger ? 'danger' : ''}" data-i="${i}"><span class="grow">${esc(o.label)}${o.hint ? `<small>${esc(o.hint)}</small>` : ''}</span></button>`).join('')}
    <div class="btns"><button class="btn quiet" data-x="no">Schließen</button></div>`, el => {
    $$('[data-i]', el).forEach(b => b.onclick = () => { closeSheet(); opts[+b.dataset.i].run(); });
    $('[data-x=no]', el).onclick = closeSheet;
  });
}

/* ---------- Navigation ---------- */
function go(name, params) {
  if (TABS.some(t => t[0] === name)) { stack = []; route = { name, params }; }
  else { stack.push(route); route = { name, params }; }
  window.scrollTo(0, 0);
  rerender();
}
function back() {
  if (route.name === 'edit' && editState && editState.dirty) {
    return confirmSheet('Änderungen verwerfen?', 'Das Rezept wurde noch nicht gespeichert.', 'Verwerfen', 'Weiter bearbeiten', () => { editState = null; back(); }, true);
  }
  route = stack.pop() || { name: 'suggest' };
  rerender();
}
async function change(msg) { await persist(); if (msg) notify(msg); rerender(); }

function renderSyncPill() {
  const p = $('#syncpill'); if (!p) return;
  const map = { off: ['', 'Nur dieses Gerät'], ok: ['ok', 'Abgeglichen'], busy: ['busy', 'Gleicht ab …'], err: ['err', 'Abgleich gestört'], offline: ['', 'Offline'] };
  const [cls, txt] = map[Sync.enabled() ? Sync.state : 'off'] || map.off;
  p.className = 'syncpill ' + cls;
  p.innerHTML = `<i></i>${txt}`;
  p.title = Sync.msg || txt;
}
function rerender() {
  if (!db || !$('#shell') || $('#shell').classList.contains('hidden')) return;
  const isTab = TABS.some(t => t[0] === route.name);
  $('#ttl').textContent = route.name === 'edit' ? (editState && editState.isNew ? 'Neues Rezept' : 'Rezept bearbeiten') : TITLES[route.name];
  $('#topleft').innerHTML = isTab
    ? `<a class="iconbtn" href="index.html" aria-label="Zur Übersicht der Apps">${ICON.back}</a>`
    : `<button class="iconbtn" data-act="back" aria-label="Zurück">${ICON.back}</button>`;
  $('#tabs').innerHTML = TABS.map(([k, l, ic]) => `<button data-tab="${k}" ${route.name === k || (!isTab && stack[0] && stack[0].name === k) ? 'aria-current="page"' : ''}>${ic}${l}</button>`).join('');
  const views = { suggest: vSuggest, week: vWeek, shop: vShop, recipes: vRecipes, edit: vEdit, ingredients: vIngredients, rotation: vRotation, settings: vSettings, sync: vSync, sources: vSources };
  const main = $('#main');
  main.innerHTML = (views[route.name] || vSuggest)();
  const binder = BIND[route.name]; if (binder) binder(main);
  renderSyncPill();
  const n = unreviewedCount(), gb = $('#gearbadge');
  if (gb) { gb.textContent = n; gb.classList.toggle('hidden', !n); $('#gear').setAttribute('aria-label', n ? `Einstellungen – ${n} neue Zutat${n === 1 ? '' : 'en'} zuordnen` : 'Einstellungen'); }
  Images.hydrate(main);
}

/* ---------- Vorschlag (5.3) ---------- */
function laneSeg(cur, act) {
  return `<div class="seg lane-seg">${EP.LANES.map(l => `<button data-act="${act}" data-arg="${l.key}" aria-pressed="${cur === l.key}">${LANE_LABEL[l.key]}</button>`).join('')}</div>`;
}
function vSuggest() {
  const lane = suggestLane;
  const month = EP.monthOf(EP.todayISO());
  const sig = () => db.rotation.length + ':' + db.rotation.filter(e => e.status === 'SKIPPED').length;
  const before = sig();
  const next = EP.nextEntries(db, 6, null, rng, lane, month);
  if (sig() !== before) persist();
  const seg = laneSeg(lane, 'slane');
  const laneHint = lane === 'MAIN' ? '' : laneDays(lane).length
    ? `<p class="hint" style="text-align:center">${lane === 'LUNCH' ? 'Mittagessen' : 'Kuchen'} ist eingeplant für: ${laneDays(lane).slice().sort((x, y) => ((x + 6) % 7) - ((y + 6) % 7)).map(d => ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'][d]).join(', ')} – änderbar in den Einstellungen.</p>`
    : `<p class="hint" style="text-align:center">Für ${lane === 'LUNCH' ? 'Mittagessen' : 'Kuchen'} sind keine Tage gewählt – das stellst du in den Einstellungen ein.</p>`;
  if (!next.length) {
    const hasAny = liveRecipes().some(r => EP.laneOf(r) === lane);
    const txt = { MAIN: ['Noch nichts in der Rotation', 'Leg deine Gerichte im Reiter Rezepte an – ein Name reicht für den Anfang.'],
      LUNCH: ['Noch keine Mittagsgerichte', 'Kleine Gerichte fürs Wochenende, z. B. Brot mit Spinat und Ei oder Nudelsuppe. Sie haben ihre eigene Rotation.'],
      CAKE: ['Noch keine Kuchen', 'Kuchen kommen zusätzlich zum Essen dazu und haben ihre eigene Rotation.'] }[lane];
    const allOut = hasAny && liveRecipes().filter(r => EP.laneOf(r) === lane && r.inRotation).every(r => !EP.inSeason(r, month));
    return `${seg}<div class="empty"><p class="serif">${allOut ? 'Gerade hat nichts Saison' : txt[0]}</p><p>${allOut ? 'Alle Gerichte dieser Rotation sind auf andere Monate beschränkt.' : txt[1]}</p>
      <div class="btns"><button class="btn primary" data-act="tabkind" data-arg="${lane}">Rezepte anlegen</button>
      ${lane === 'MAIN' ? (liveRecipes().length ? '' : '<button class="btn" data-act="seed">Beispielrezepte laden</button>')
        : `<button class="btn" data-act="seedlane" data-arg="${lane}">${lane === 'LUNCH' ? '6 Mittagsgerichte als Vorschlag laden' : '7 Kuchen als Vorschlag laden'}</button>`}</div></div>${laneHint}`;
  }
  const e = next[0], r = recipeById(e.recipeId), n = daysOf(r), ck = coverKey(r);
  const prog = EP.cycleProgress(db, lane);
  const occ = r.weight > 1 ? ` (${e.occurrence}/${r.weight})` : '';
  const meta = lane === 'MAIN' ? `${r.servings} Portionen, reicht für ${daysLabel(n)}${occ}` : `${r.servings} ${lane === 'CAKE' ? 'Stücke' : 'Portionen'}${occ}`;
  const season = EP.seasonLabel(r);
  return `${seg}<div class="plate-wrap">
      <div class="plate ${lane !== 'MAIN' ? 'plate-' + lane.toLowerCase() : ''}">${ck ? `<img data-img="${ck}" data-thumb="0" alt="">` : `<span class="dish">${esc(r.name)}</span>`}</div>
      ${ck ? `<div class="dish-under">${esc(r.name)}</div>` : ''}
      <p class="plate-meta">${meta}${r.prepTimeMinutes ? `, ${r.prepTimeMinutes} min` : ''}${season ? `<br>Saison: ${season}` : ''}</p>
    </div>
    <div class="btns">
      <button class="btn primary" data-act="accept" data-arg="${e.id}">Übernehmen</button>
      <div class="btns two" style="margin-top:0">
        <button class="btn" data-act="postpone" data-arg="${e.id}">Später</button>
        <button class="btn" data-act="skip" data-arg="${e.id}">Diesmal auslassen</button>
      </div>
      <button class="btn quiet" data-act="pickself">Selbst wählen</button>
    </div>
    ${prog ? `<div class="progress">Durchlauf ${prog.cycle} · ${prog.current} von ${prog.total} ${lane === 'CAKE' ? 'Kuchen' : 'Gerichten'}
      <div class="progress-bar"><i style="width:${Math.round((prog.current - 1) / prog.total * 100)}%"></i></div></div>` : ''}
    ${laneHint}
    ${next.length > 1 ? `<h3>Danach</h3><ol class="queue box">${next.slice(1, 6).map((x, i) => {
      const rr = recipeById(x.recipeId);
      return `<li><span class="n">${i + 2}.</span><span class="nm">${esc(rr.name)}</span><span class="d">${lane === 'MAIN' ? daysLabel(daysOf(rr)) : ''}</span></li>`;
    }).join('')}</ol>` : ''}`;
}

/* ---------- Woche (5.4) ---------- */
function laneVisible(lane) { return laneDays(lane).length > 0 && liveRecipes().some(r => EP.laneOf(r) === lane); }
function vWeek() {
  const ws = weekStartISO, days = EP.weekDays(ws), today = EP.todayISO();
  const isDraft = draft && draft.ws === ws;
  const ents = weekEntries(ws);
  const kw = EP.isoWeek(ws);
  const showLane = { LUNCH: laneVisible('LUNCH'), CAKE: laneVisible('CAKE') };
  const rows = days.map(d => {
    const p = ents.get(d);
    const cls = ['day', d === today ? 'today' : '', d < today ? 'past' : '', p && p.drafted ? 'drafted' : ''].join(' ');
    let body;
    if (!p) body = `<div class="nm free">${d < today ? '–' : 'Frei'}</div>`;
    else if (p.type === 'BLOCKED') body = `<div class="nm free">Gesperrt</div><div class="tags"><span class="badge block">${esc(p.note || 'Kein Kochen')}</span></div>`;
    else {
      const r = recipeById(p.recipeId);
      const carry = p.type === 'LEFTOVER' && blockEntries(p.blockId, isDraft ? draft.clone : db).concat(isDraft ? draft.drafts.filter(x => x.blockId === p.blockId) : [])
        .some(x => x.type === 'COOK' && x.date < ws);
      const b = p.type === 'COOK' ? `<span class="badge cook">Kochtag${p.dayCount > 1 ? ` 1/${p.dayCount}` : ''}</span>`
        : `<span class="badge rest">Reste ${p.dayIndex}/${p.dayCount}</span>`;
      body = `<div class="nm">${esc(r ? r.name : 'Gelöschtes Rezept')}</div><div class="tags">${b}${carry ? '<span class="badge">Übertrag</span>' : ''}
        ${p.status === 'DONE' && p.type === 'COOK' ? '<span class="badge done">Gekocht</span>' : ''}${p.source === 'MANUAL' && p.type === 'COOK' ? '<span class="badge">Selbst gewählt</span>' : ''}</div>`;
    }
    const laneLines = ['LUNCH', 'CAKE'].map(l => {
      const x = ents.lanes[l].get(d);
      if (!x && !(showLane[l] && laneActiveOn(l, d) && d >= today)) return '';
      const r = x && recipeById(x.recipeId);
      return `<button class="laneline ${x && x.drafted ? 'drafted' : ''} lane-${l.toLowerCase()}" data-act="lane" data-arg="${d}|${l}">
        <span class="lanelbl">${LANE_LABEL[l]}</span><span class="nm ${x ? '' : 'free'}">${x ? esc(r ? r.name : 'Gelöschtes Rezept') : 'Frei'}</span>
        ${x && x.status === 'DONE' ? `<span class="badge done">${l === 'CAKE' ? 'Gebacken' : 'Gekocht'}</span>` : ''}</button>`;
    }).join('');
    return `<div class="${cls}"><button class="daymain" data-act="day" data-arg="${d}"><div class="dt"><b>${EP.weekday(d)}</b><span>${EP.fmtShort(d)}</span></div>
      <div class="what">${body}</div>${p && p.locked ? ICON.lock : ''}</button>${laneLines}</div>`;
  }).join('');
  return `<div class="weekhead">
      <button class="iconbtn" data-act="wk" data-arg="-7" aria-label="Vorige Woche">${ICON.back}</button>
      <div class="kw"><b>KW ${kw}</b><span>${EP.fmtRange(ws, days[6])}</span></div>
      <button class="iconbtn" data-act="wk" data-arg="7" aria-label="Nächste Woche" style="transform:scaleX(-1)">${ICON.back}</button>
    </div>
    ${ws !== EP.weekStart(today) ? '<div style="text-align:center;margin:-6px 0 10px"><button class="btn quiet small" data-act="wk" data-arg="0" style="display:inline-flex">Zur aktuellen Woche</button></div>' : ''}
    ${isDraft ? `<div class="draftbar"><b>Entwurf</b> – noch nicht gespeichert. Tippe auf einen Tag, um zu tauschen, zu verschieben oder selbst zu wählen.</div>` : ''}
    <div class="days">${rows}</div>
    ${isDraft
      ? `<div class="btns two"><button class="btn" data-act="discard">Verwerfen</button><button class="btn primary" data-act="commit">Plan übernehmen</button></div>`
      : `<div class="btns two"><button class="btn primary" data-act="fill">Woche füllen</button><button class="btn" data-act="toshop">Einkaufsliste</button></div>`}`;
}
/* Aktionen für Mittag / Kuchen an einem Tag */
function laneActions(d, lane) {
  const ws = weekStartISO, isDraft = draft && draft.ws === ws;
  const x = weekEntries(ws).lanes[lane].get(d);
  const r = x && recipeById(x.recipeId);
  const what = lane === 'CAKE' ? 'Kuchen' : 'Mittagessen';
  const title = `${what} am ${EP.weekdayLong(d)}, ${EP.fmtShort(d)}`;
  const opts = [];
  if (isDraft) {
    if (x && x.drafted) {
      opts.push({ label: 'Tauschen', hint: 'Nächstes aus der ' + what + '-Rotation', run: () => { draftLaneNext(d, lane); rerender(); } });
      opts.push({ label: 'Selbst wählen', run: () => recipePickSheet(what + ' wählen', id => { draftLanePick(d, lane, id); rerender(); }, lane) });
      opts.push({ label: 'Diesmal kein ' + what, danger: true, run: () => { draftLaneRemove(d, lane); rerender(); } });
    } else if (!x) {
      opts.push({ label: 'Nächstes aus der Rotation', run: () => { draftLaneNext(d, lane); rerender(); } });
      opts.push({ label: 'Selbst wählen', run: () => recipePickSheet(what + ' wählen', id => { draftLanePick(d, lane, id); rerender(); }, lane) });
    } else opts.push({ label: 'Bleibt unverändert', hint: 'Bereits gekocht oder fixiert', run: () => {} });
    return optionsSheet(title, r ? esc(r.name) : '', opts);
  }
  if (!x) {
    opts.push({ label: 'Nächstes aus der Rotation', run: () => {
      const e = EP.nextEntries(db, 1, null, rng, lane, EP.monthOf(d))[0];
      if (!e) return notify('Keine Gerichte in dieser Rotation.');
      placeLane(d, lane, e.recipeId, e.id); change('Eingeplant.');
    } });
    opts.push({ label: 'Selbst wählen', run: () => recipePickSheet(what + ' wählen', id => { const e = EP.manualPickEntry(db, id); placeLane(d, lane, id, e ? e.id : null); change('Eingeplant.'); }, lane) });
  } else {
    if (x.status !== 'DONE') opts.push({ label: lane === 'CAKE' ? 'Als gebacken markieren' : 'Als gekocht markieren', run: () => { markCooked(x.blockId); change('Erledigt.'); } });
    if (r && (r.instructions || r.ingredients.length)) opts.push({ label: 'Kochansicht öffnen', run: () => openCook(r.id) });
    if (d >= EP.todayISO()) {
      opts.push({ label: 'Tauschen', hint: 'Nächstes aus der ' + what + '-Rotation', run: () => { const nr = swapLane(d, lane); change(nr ? 'Getauscht gegen ' + nr.name + '.' : 'Keine weiteren Gerichte in dieser Rotation.'); } });
      opts.push({ label: 'Selbst wählen', run: () => recipePickSheet(what + ' wählen', id => { const e = EP.manualPickEntry(db, id); placeLane(d, lane, id, e ? e.id : null); change('Ersetzt.'); }, lane) });
    }
    opts.push({ label: 'Aus dem Plan entfernen', danger: true, hint: 'Kommt wieder nach vorne in die Rotation', run: () => { removeBlock(x.blockId, true); change('Entfernt.'); } });
  }
  optionsSheet(title, r ? esc(r.name) : '', opts);
}
function dayActions(d) {
  const ws = weekStartISO, today = EP.todayISO();
  const isDraft = draft && draft.ws === ws;
  const p = weekEntries(ws).get(d);
  const title = `${EP.weekdayLong(d)}, ${EP.fmtDate(d)}`;
  const opts = [];
  if (isDraft) {
    if (p && p.drafted && p.blockId) {
      const idx = draft.sequence.findIndex(s => s.blockId === p.blockId);
      opts.push({ label: 'Tauschen', hint: 'Nächstes Gericht aus der Rotation', run: () => { draftSwap(p.blockId); rerender(); } });
      if (idx > 0) opts.push({ label: 'Früher einplanen', run: () => { draftMove(p.blockId, -1); rerender(); } });
      if (idx < draft.sequence.length - 1) opts.push({ label: 'Später einplanen', run: () => { draftMove(p.blockId, 1); rerender(); } });
      opts.push({ label: 'Selbst wählen', run: () => recipePickSheet('Gericht wählen', id => { draftPick(p.blockId, id); rerender(); }) });
      opts.push({ label: p.locked ? 'Fixierung lösen' : 'Fixieren', hint: 'Wird beim erneuten Füllen nicht überschrieben', run: () => { draftToggleLock(p.blockId); rerender(); } });
    }
    const carry = p && !p.drafted && p.type === 'LEFTOVER';
    if (carry) {
      const cr = recipeById(p.recipeId);
      opts.push({ label: 'Reste verschieben', hint: 'Übertrag aus der Vorwoche auf einen anderen Tag legen', run: () => restSheet(cr, p, draft.clone, nd => { moveRest(p.id, nd, draft.clone); relayoutDraft(); rerender(); }) });
      opts.push({ label: 'Reste streichen', hint: 'z. B. eingefroren oder schon gegessen – der Tag wird frei', run: () => { dropRest(p.id, draft.clone); relayoutDraft(); rerender(); } });
      opts.push({ label: 'Tag sperren', hint: d < EP.todayISO() ? 'z. B. doch auswärts gegessen – diese Reste kommen auf heute oder später' : 'z. B. Auswärts essen – die Reste rutschen einen Tag weiter', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => { draftBlockCarry(d, note); rerender(); }) });
    }
    if (p && p.extraBlocked) opts.push({ label: 'Tag wieder freigeben', run: () => { draft.blocked.delete(d); relayoutDraft(); rerender(); } });
    else if (!p || p.drafted) opts.push({ label: 'Tag sperren', hint: 'z. B. Auswärts essen – Reste rutschen weiter', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => { draft.blocked.set(d, note); relayoutDraft(); rerender(); }) });
    addLaneOptions(d, opts);
    if (!opts.length) opts.push({ label: 'Dieser Tag bleibt unverändert', hint: 'Fixiert, gesperrt oder Übertrag aus der Vorwoche', run: () => {} });
    return optionsSheet(title, p && p.recipeId ? esc(recipeById(p.recipeId).name) : '', opts);
  }
  if (!p) {
    opts.push({ label: 'Nächstes aus der Rotation', run: () => {
      const e = EP.nextEntries(db, 1, null, rng, 'MAIN', EP.monthOf(d))[0];
      if (!e) return notify('Keine Gerichte in der Rotation.');
      placeBlock(d, { recipeId: e.recipeId, rotationEntryId: e.id }); change('Eingeplant.');
    } });
    opts.push({ label: 'Selbst wählen', run: () => recipePickSheet('Gericht wählen', id => {
      const e = EP.manualPickEntry(db, id); placeBlock(d, { recipeId: id, rotationEntryId: e ? e.id : null }); change('Eingeplant.');
    }) });
    opts.push({ label: 'Tag sperren', hint: 'z. B. Auswärts essen', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => { blockDay(d, note); change('Tag gesperrt.'); }) });
  } else if (p.type === 'BLOCKED') {
    opts.push({ label: 'Tag wieder freigeben', run: () => { unblockDay(d); change('Tag freigegeben.'); } });
    opts.push({ label: 'Notiz ändern', run: () => promptSheet('Notiz ändern', 'Notiz', p.note, 'Speichern', note => { const x = planByDate().get(d); x.note = note; EP.touch(x); change(); }) });
  } else {
    const r = recipeById(p.recipeId);
    if (p.status !== 'DONE') opts.push({ label: 'Als gekocht markieren', run: () => { markCooked(p.blockId); change('Als gekocht markiert.'); } });
    if (r && (r.instructions || r.ingredients.length)) opts.push({ label: 'Kochansicht öffnen', run: () => openCook(r.id) });
    if (d >= today) {
      opts.push({ label: 'Tauschen', hint: 'Nächstes Gericht aus der Rotation', run: () => { const nr = swapBlock(p.blockId); change(nr ? 'Getauscht gegen ' + nr.name + '.' : 'Keine weiteren Gerichte in der Rotation.'); } });
      if (p.type === 'LEFTOVER') {
        opts.push({ label: 'Reste verschieben', hint: 'Nur diesen Resttag auf einen anderen Tag legen', run: () => restSheet(r, p, null, nd => { moveRest(p.id, nd); change('Reste verschoben.'); }) });
        opts.push({ label: 'Reste streichen', hint: 'z. B. eingefroren oder schon gegessen – der Tag wird frei', run: () => { dropRest(p.id); change('Resttag gestrichen.'); } });
      }
      opts.push({ label: p.type === 'LEFTOVER' ? 'Ganzes Gericht verschieben' : 'Verschieben', hint: p.type === 'LEFTOVER' ? 'Kochtag und alle Reste' : '', run: () => {
        const cook = blockEntries(p.blockId).find(x => x.type === 'COOK');
        dateSheet('Verschieben', r, cook ? cook.date : d, 'Verschieben', nd => { moveBlock(p.blockId, nd); change('Verschoben.'); });
      } });
      opts.push({ label: 'Selbst wählen', hint: 'Dieses Gericht ersetzen', run: () => recipePickSheet('Gericht wählen', id => {
        const cook = blockEntries(p.blockId).find(x => x.type === 'COOK');
        const info = removeBlock(p.blockId, true);
        const e = EP.manualPickEntry(db, id);
        placeBlock(cook ? cook.date : d, { recipeId: id, rotationEntryId: e ? e.id : null, locked: info && info.locked });
        change('Ersetzt.');
      }) });
      opts.push({ label: 'Tag sperren', hint: p.type === 'LEFTOVER' ? 'z. B. Auswärts essen – die Reste rutschen einen Tag weiter' : 'Reste rutschen auf den nächsten freien Tag', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => { blockDay(d, note); change('Tag gesperrt.'); }) });
    } else if (p.type === 'LEFTOVER') {
      opts.push({ label: 'Tag sperren', hint: 'z. B. doch auswärts gegessen – diese Reste kommen auf heute oder später', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => { blockDay(d, note); change('Tag gesperrt, Reste neu eingeplant.'); }) });
      opts.push({ label: 'Reste verschieben', hint: 'Auf heute oder einen späteren Tag legen', run: () => restSheet(r, p, null, nd => { moveRest(p.id, nd); change('Reste verschoben.'); }) });
      opts.push({ label: 'Reste streichen', hint: 'z. B. eingefroren oder weggeworfen', run: () => { dropRest(p.id); change('Resttag gestrichen.'); } });
    }
    opts.push({ label: p.locked ? 'Fixierung lösen' : 'Fixieren', hint: 'Fixierte Gerichte bleiben beim Füllen der Woche stehen', run: () => { const v = toggleLock(p.blockId); change(v ? 'Fixiert.' : 'Fixierung gelöst.'); } });
    opts.push({ label: 'Aus dem Plan entfernen', danger: true, hint: 'Das Gericht kommt wieder nach vorne in die Rotation', run: () => { removeBlock(p.blockId, true); change('Entfernt.'); } });
  }
  addLaneOptions(d, opts);
  optionsSheet(title, p && p.recipeId ? esc((recipeById(p.recipeId) || {}).name || '') : '', opts);
}
/* „Mittagessen/Kuchen hinzufügen“ für Tage, an denen keine Zeile dafür angezeigt wird */
function addLaneOptions(d, opts) {
  const ents = weekEntries(weekStartISO);
  ['LUNCH', 'CAKE'].forEach(l => {
    if (ents.lanes[l].get(d)) return;                                           // schon etwas eingeplant
    if (laneVisible(l) && laneActiveOn(l, d) && d >= EP.todayISO()) return;     // Zeile ist ohnehin sichtbar
    if (!liveRecipes().some(r => EP.laneOf(r) === l)) return;                   // keine Rezepte dieser Art
    const o = { label: l === 'LUNCH' ? 'Mittagessen hinzufügen' : 'Kuchen hinzufügen',
      hint: 'Zusätzlich zum Hauptgericht an diesem Tag', run: () => laneActions(d, l) };
    const i = opts.findIndex(x => x.danger);           // rote Aktion bleibt ganz unten
    i === -1 ? opts.push(o) : opts.splice(i, 0, o);
  });
}

/* ---------- Einkauf (5.5) ---------- */
function vShop() {
  if (!shopRange) shopRange = { from: weekStartISO, to: EP.addDays(weekStartISO, 6) };
  const { from, to } = shopRange;
  const isWeek = EP.weekStart(from) === from && EP.addDays(from, 6) === to;
  const list = EP.buildShoppingList(db, from, to);
  const showQ = db.settings.marketListShowQuantities;
  const item = (r, withAmt) => `<label class="item ${r.checked ? 'checked' : ''}"><input type="checkbox" data-check="${esc(r.key)}" ${r.checked ? 'checked' : ''}>
    <span class="nm">${esc(r.name)}</span>${withAmt && r.amount ? `<span class="amt">${esc(r.amount)}</span>` : ''}</label>`;
  const empty = !list.recipes.length;
  return `<div class="weekhead noprint">
      <button class="iconbtn" data-act="shopwk" data-arg="-7" aria-label="Vorige Woche">${ICON.back}</button>
      <div class="kw"><b>${isWeek ? 'KW ' + EP.isoWeek(from) : 'Eigener Zeitraum'}</b><span>${EP.fmtRange(from, to)}</span></div>
      <button class="iconbtn" data-act="shopwk" data-arg="7" aria-label="Nächste Woche" style="transform:scaleX(-1)">${ICON.back}</button>
    </div>
    <details class="box noprint rangebox" ${isWeek ? '' : 'open'}><summary>Zeitraum anpassen</summary>
      <div class="dategrid">
        <label><span class="hint">Von</span><input class="in" type="date" id="sf" value="${from}"></label>
        <label><span class="hint">Bis</span><input class="in" type="date" id="st" value="${to}"></label>
      </div></details>
    <h2 style="margin-top:18px" class="printonly-h">Einkauf ${EP.fmtRange(from, to)}</h2>
    <p class="sub">${empty ? 'In diesem Zeitraum ist nichts gekocht geplant.' : 'Für: ' + esc(list.recipes.join(', '))}</p>
    ${list.warnings.length ? `<ul class="box warnbox" style="margin-top:12px">${list.warnings.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}
    ${list.market.length ? `<section class="shopsec box"><h3>Markt <small>${list.market.length}</small></h3>${list.market.map(r => item(r, showQ)).join('')}</section>` : ''}
    ${list.supermarket.length ? `<section class="shopsec box"><h3>Supermarkt</h3>${list.supermarket.map(g =>
      `<p class="cat">${esc(g.label)}</p>${g.items.map(r => item(r, true)).join('')}`).join('')}</section>` : ''}
    <section class="shopsec box"><h3>Zusätzlich</h3>
      ${list.extraItems.map((x, i) => `<div class="item ${x.checked ? 'checked' : ''}"><input type="checkbox" data-extra="${i}" ${x.checked ? 'checked' : ''} aria-label="Abhaken">
        <span class="nm">${esc(x.text)}</span><button class="btn quiet small noprint" data-act="delextra" data-arg="${i}" aria-label="Entfernen">✕</button></div>`).join('')}
      <div class="quick noprint" style="margin-top:8px"><input class="in" id="extra" placeholder="z. B. Spülmittel" enterkeyhint="done"><button class="btn primary" data-act="addextra" aria-label="Hinzufügen">+</button></div>
    </section>
    ${list.pantry.length ? `<details class="shopsec box"><summary>Vorrat prüfen (${list.pantry.length})</summary>${list.pantry.map(r => item(r, false)).join('')}</details>` : ''}
    <div class="btns noprint">
      <button class="btn primary" data-act="copyshop">Als Text kopieren</button>
      <div class="btns two" style="margin-top:0">
        ${navigator.share ? '<button class="btn" data-act="shareshop">Teilen</button>' : ''}
        <button class="btn" data-act="printshop" ${navigator.share ? '' : 'style="grid-column:1/-1"'}>Drucken</button>
      </div>
    </div>`;
}
function shopText() {
  const { from, to } = shopRange;
  return EP.shoppingText(EP.buildShoppingList(db, from, to), db.settings);
}
