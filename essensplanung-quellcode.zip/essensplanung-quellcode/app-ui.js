/* ==========================================================================
   Essensplanung – App Teil 3: Oberfläche
   ========================================================================== */
const ICON = {
  chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>',
  sort: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4v16M3.5 16.5 7 20l3.5-3.5M17 20V4M13.5 7.5 17 4l3.5 3.5"/></svg>',
  pot: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 10h16v6a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4z"/><path d="M2 11h2M20 11h2M9 7.5V5M12 7.5V4M15 7.5V5"/></svg>',
  plate: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/></svg>',
  week: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/></svg>',
  cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 4h2.5l2.2 11h10.6l2-7.5H7"/><circle cx="9.5" cy="19.5" r="1.3"/><circle cx="17" cy="19.5" r="1.3"/></svg>',
  book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 4.5h11a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11M9 8h6"/></svg>',
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M15 5l-7 7 7 7"/></svg>',
  oplus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>',
  ocheck: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  oswap: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4L4 7l3 3M4 7h13M17 20l3-3-3-3M20 17H7"/></svg>',
  osearch: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>',
  odice: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="3.5"/><circle cx="9" cy="9" r="1.2" fill="currentColor"/><circle cx="15" cy="15" r="1.2" fill="currentColor"/><circle cx="15" cy="9" r="1.2" fill="currentColor"/><circle cx="9" cy="15" r="1.2" fill="currentColor"/></svg>',
  omove: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 9.5h17M9 14.5h6M13 12.5l2 2-2 2"/></svg>',
  oup: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M6 11l6-6 6 6"/></svg>',
  odown: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M6 13l6 6 6-6"/></svg>',
  opin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
  ounpin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.5-2"/></svg>',
  opencil: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/></svg>',
  otrash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13"/></svg>',
  oout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10"/><path d="M17 21V3c-2.2 1-3.5 3.5-3.5 7v3H17"/></svg>',
  oopen: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  obowl: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 11h17a8.5 8.5 0 0 1-17 0z"/><path d="M9 7c0-1.5 1-2 1-3.5M13 7c0-1.5 1-2 1-3.5"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.8z"/></svg>',
  starOn: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.8z"/></svg>',
  omore: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="5.5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="18.5" cy="12" r="1.8"/></svg>',
  ocake: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="8" rx="8" ry="3"/><path d="M4 8v8c0 1.7 3.6 3 8 3s8-1.3 8-3V8"/></svg>',
  oinfo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
  ox: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  oimage: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M20.5 16l-5-5-8 8"/></svg>',
  omerge: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 4v5a5 5 0 0 0 5 5h7M15 11l3 3-3 3M6 20v-6"/></svg>',
  ostar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg>',
  opeople: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14.2c2.9.3 5 2.6 5 5.8"/></svg>',
  lock: '<svg class="lock" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
};
const TABS = [['week', 'Woche', ICON.week], ['suggest', 'Vorschlag', ICON.plate], ['shop', 'Einkauf', ICON.cart], ['recipes', 'Rezepte', ICON.book]];
const TITLES = { suggest: 'Als Nächstes', week: 'Wochenplan', shop: 'Einkaufsliste', recipes: 'Rezepte',
  edit: 'Rezept', ingredients: 'Zutaten', rotation: 'Rotation', settings: 'Einstellungen', sync: 'Geräteabgleich', sources: 'Einkaufsorte',
  stores: 'Geschäfte', store: 'Geschäft' };
/* Bezeichnungen der Rezept-Arten – eigene Namen aus den Einstellungen (settings.kindNames) haben Vorrang */
const LANE_DEF = { MAIN: 'Hauptgerichte', LUNCH: 'Mittag', CAKE: 'Kuchen', SIDE: 'Beilagen', SPECIAL: 'Besonderes' };
const DISH_DEF = { MAIN: 'Hauptgericht', LUNCH: 'Mittag', CAKE: 'Kuchen', SIDE: 'Beilage', SPECIAL: 'Besonderes' };
const customKind = k => { const n = typeof db !== 'undefined' && db && db.settings && db.settings.kindNames && db.settings.kindNames[k]; return n && String(n).trim() || ''; };
/* Trennhilfe für enge Umschalter (fünf Arten nebeneinander) */
const segLbl = t => esc(t).replace(/^Hauptgericht/, 'Haupt&shy;gericht').replace(/^Besonderes$/, 'Beson&shy;deres').replace(/^Mittagessen$/, 'Mittag&shy;essen');
const laneWhat = l => customKind(l) || (l === 'LUNCH' ? 'Mittagessen' : l === 'CAKE' ? 'Kuchen' : LANE_DEF[l]);
const LANE_LABEL = new Proxy(LANE_DEF, { get: (o, k) => (typeof k === 'string' && customKind(k)) || o[k] });
const DISH_LABEL = new Proxy(DISH_DEF, { get: (o, k) => (typeof k === 'string' && customKind(k)) || o[k] });
let suggestLane = 'MAIN';
const suggestPick = {};   // je Spur: { date, replace: blockId|null } – Zieltag des Vorschlags

const HOME = 'shop';   // Start-Reiter
let route = { name: HOME }, stack = [];
let recentEdit = false;   // Vorschläge „Zuletzt verwendet“ bearbeiten
let weekStartISO = EP.weekStart(EP.todayISO());
let shopRange = null;
let recipeFilter = { q: '', status: 'all', tag: '', kind: 'MAIN' };

/* ---------- Hilfen ---------- */
function notify(t, undo) {
  const el = $('#toast');
  el.innerHTML = `<span>${esc(t)}</span>${undo ? '<button class="undo" type="button">Rückgängig</button>' : ''}`;
  el.classList.toggle('act', !!undo); el.classList.add('on');
  if (undo) $('.undo', el).onclick = () => { el.classList.remove('on', 'act'); clearTimeout(el._t); undo(); };
  clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove('on', 'act'), undo ? 6000 : 2400);
}
function daysLabel(n) { return n + ' ' + (n === 1 ? 'Tag' : 'Tage'); }
function rangeLabel(dates) {
  if (!dates.length) return '';
  const a = dates[0], b = dates[dates.length - 1];
  return a === b ? `${EP.weekday(a)} ${EP.fmtShort(a)}` : `${EP.weekday(a)} ${EP.fmtShort(a)}–${EP.weekday(b)} ${EP.fmtShort(b)}`;
}
function coverKey(r) { const c = (r.images || []).find(i => i.isCover) || (r.images || [])[0]; return c ? c.fileKey : null; }
function parseQty(s) {
  if (s == null) return null;
  const t = String(s).trim().replace(',', '.');
  if (!t) return null;
  const v = parseFloat(t);
  return isFinite(v) && v > 0 ? v : null;
}
const unitLabel = u => (u ? EP.UNITS[u].s : '');

/* ---------- Dialog-Blätter ---------- */
function openSheet(html, bind) {
  closeSheet();
  const s = document.createElement('div');
  s.className = 'scrim'; s.id = 'scrim';
  s.innerHTML = `<div class="sheet" role="dialog" aria-modal="true"><div class="grab" aria-hidden="true"><i></i></div>${html}</div>`;
  s.addEventListener('click', e => { if (e.target === s) closeSheet(); });
  document.body.appendChild(s);
  const sheet = s.firstElementChild;
  enableSwipeDown(sheet, s);
  if (bind) bind(sheet);
  const f = $('input,select,textarea', s); if (f && !('ontouchstart' in window)) f.focus();
}
/* Blatt am Griff (oder ganz oben) nach unten ziehen → schließen */
function enableSwipeDown(sheet, scrim) {
  let startY = null, dy = 0, t0 = 0, dragging = false;
  const pointY = e => (e.touches ? e.touches[0].clientY : e.clientY);
  const start = e => {
    const onGrab = !!e.target.closest('.grab');
    if (!onGrab && (sheet.scrollTop > 0 || e.target.closest('input,select,textarea'))) return;
    startY = pointY(e); dy = 0; t0 = Date.now(); dragging = false;
  };
  const move = e => {
    if (startY == null) return;
    dy = Math.max(0, pointY(e) - startY);
    if (!dragging && dy > 6) { dragging = true; sheet.style.transition = 'none'; sheet.style.animation = 'none'; }
    if (!dragging) return;
    sheet.style.transform = `translateY(${dy}px)`;
    scrim.style.background = `rgba(10,16,28,${(0.48 * Math.max(0, 1 - dy / 420)).toFixed(3)})`;
    if (e.cancelable) e.preventDefault();
  };
  const end = () => {
    if (startY == null) return;
    const speed = dy / Math.max(1, Date.now() - t0);
    startY = null;
    if (!dragging) return;
    sheet.addEventListener('click', ev => { ev.stopPropagation(); ev.preventDefault(); }, { capture: true, once: true }); // kein Klick nach dem Ziehen
    if (dy > 90 || speed > 0.6) {
      sheet.style.transition = 'transform .18s ease-in';
      sheet.style.transform = 'translateY(105%)';
      scrim.style.transition = 'background .18s'; scrim.style.background = 'rgba(10,16,28,0)';
      setTimeout(() => { if (scrim.isConnected) scrim.remove(); }, 180);
    } else {
      sheet.style.transition = 'transform .2s ease-out';
      sheet.style.transform = ''; scrim.style.background = '';
    }
  };
  sheet.addEventListener('touchstart', start, { passive: true });
  sheet.addEventListener('touchmove', move, { passive: false });
  sheet.addEventListener('touchend', end);
  sheet.addEventListener('touchcancel', end);
  // Maus/Stift: am Griff ziehen
  const grab = $('.grab', sheet);
  grab.addEventListener('pointerdown', e => {
    if (e.pointerType === 'touch') return;
    start(e); grab.setPointerCapture(e.pointerId);
    const mv = ev => move(ev), up = () => { end(); grab.removeEventListener('pointermove', mv); grab.removeEventListener('pointerup', up); };
    grab.addEventListener('pointermove', mv); grab.addEventListener('pointerup', up);
  });
}
function closeSheet() { const s = $('#scrim'); if (s) s.remove(); }
function confirmSheet(title, detail, yes, no, onYes, danger) {
  openSheet(`<h2>${esc(title)}</h2>${detail ? `<p class="sub" style="margin-top:6px">${esc(detail)}</p>` : ''}
    <div class="btns two"><button class="btn" data-x="no">${esc(no)}</button>
    <button class="btn ${danger ? 'danger' : 'primary'}" data-x="yes">${esc(yes)}</button></div>`, el => {
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { closeSheet(); onYes(); };
  });
}
function promptSheet(title, label, value, okLabel, onOk) {
  openSheet(`<h2>${esc(title)}</h2><label class="field"><span>${esc(label)}</span><input class="in" id="pv" value="${esc(value || '')}"></label>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">${esc(okLabel)}</button></div>`, el => {
    const go = () => { const v = $('#pv', el).value.trim(); closeSheet(); onOk(v); };
    $('[data-x=no]', el).onclick = closeSheet; $('[data-x=yes]', el).onclick = go;
    $('#pv', el).onkeydown = e => { if (e.key === 'Enter') go(); };
  });
}
/* Startdatum wählen, mit Live-Anzeige der belegten Tage */
function dateSheet(title, recipe, start, okLabel, onOk) {
  const occ = mainDates();
  const preview = d => EP.nextFreeDates(d, daysOf(recipe), occ);
  openSheet(`<h2>${esc(title)}</h2><p class="serif" style="font-size:19px;margin-top:4px">${esc(recipe.name)}</p>
    <label class="field"><span>Startdatum (Kochtag)</span><input class="in" type="date" id="dv" value="${start}"></label>
    <p class="hint" id="dp"></p>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">${esc(okLabel)}</button></div>`, el => {
    const upd = () => { const v = $('#dv', el).value; $('#dp', el).textContent = v ? `Belegt ${daysLabel(daysOf(recipe))}: ${rangeLabel(preview(v))}` : ''; };
    $('#dv', el).oninput = upd; upd();
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { const v = $('#dv', el).value; if (!v) return; closeSheet(); onOk(v); };
  });
}
/* Neuen Tag für einen einzelnen Resttag wählen (mit Prüfung) */
function restSheet(recipe, p, src, onOk) {
  openSheet(`<h2>Reste verschieben</h2><p class="serif" style="font-size:19px;margin-top:4px">${esc(recipe ? recipe.name : '')}</p>
    <p class="hint" style="margin-top:0">Bisher: ${EP.weekdayLong(p.date)}, ${EP.fmtShort(p.date)}</p>
    <label class="field"><span>Neuer Tag</span><input class="in" type="date" id="dv" value="${restSuggest(p, src)}"></label>
    <p class="hint" id="dp"></p>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Verschieben</button></div>`, el => {
    const upd = () => {
      const v = $('#dv', el).value, err = restMoveCheck(p, v, src);
      $('#dp', el).textContent = err || `Reste am ${EP.weekdayLong(v)}, ${EP.fmtShort(v)}`;
      $('#dp', el).classList.toggle('warn', !!err);
      $('[data-x=yes]', el).disabled = !!err;
    };
    $('#dv', el).oninput = upd; $('#dv', el).onchange = upd; upd();
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { const v = $('#dv', el).value; if (restMoveCheck(p, v, src)) return; closeSheet(); onOk(v); };
  });
}
/* Tag für eine Zusatzspur wählen */
function laneDateSheet(title, recipe, lane, start, okLabel, onOk) {
  openSheet(`<h2>${esc(title)}</h2><p class="serif" style="font-size:19px;margin-top:4px">${esc(recipe.name)}</p>
    <label class="field"><span>Tag</span><input class="in" type="date" id="dv" value="${start}"></label>
    <p class="hint" id="dp"></p>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">${esc(okLabel)}</button></div>`, el => {
    const upd = () => {
      const v = $('#dv', el).value, o = v && laneAt(db, v, lane);
      $('#dp', el).textContent = !v ? '' : o ? `Ersetzt „${(recipeById(o.recipeId) || {}).name || ''}“ am ${EP.weekday(v)} ${EP.fmtShort(v)}.` : `${LANE_LABEL[lane]} am ${EP.weekdayLong(v)}, ${EP.fmtShort(v)}`;
    };
    $('#dv', el).oninput = upd; upd();
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { const v = $('#dv', el).value; if (!v) return; closeSheet(); onOk(v); };
  });
}
/* ---------- Planungsstand eines Rezepts: für die Auswahl und die Doppel-Prüfung ---------- */
const activeDraft = () => (draft && draft.ws === weekStartISO ? draft : null);
/* künftige, noch nicht gekochte Kochtermine (inkl. Entwurf der angezeigten Woche) */
function plannedCooks(recipeId) {
  const today = EP.todayISO(), dr = activeDraft(), out = [];
  EP.live((dr ? dr.clone : db).plan).forEach(p => {
    if (p.type === 'COOK' && p.recipeId === recipeId && p.date >= today && p.status !== 'DONE') out.push({ date: p.date, lane: EP.laneOf(p), id: p.id, blockId: p.blockId });
  });
  if (dr) {
    dr.drafts.forEach(x => { if (x.type === 'COOK' && x.recipeId === recipeId && x.date >= today) out.push({ date: x.date, lane: 'MAIN', blockId: x.blockId, drafted: true }); });
    dr.lanes.forEach(x => { if (x.recipeId === recipeId && x.date >= today) out.push({ date: x.date, lane: x.lane, drafted: true }); });
  }
  return out.sort((a, b) => a.date.localeCompare(b.date));
}
function lastCooked(recipeId) {
  const today = EP.todayISO();
  return EP.live(db.plan).filter(p => p.type === 'COOK' && p.recipeId === recipeId && p.date < today).reduce((m, p) => (p.date > m ? p.date : m), '');
}
function agoText(date) {
  const n = Math.round((EP.parseISO(EP.todayISO()) - EP.parseISO(date)) / 864e5);
  return n <= 0 ? 'heute' : n === 1 ? 'gestern' : n < 14 ? `vor ${n} Tagen` : n < 60 ? `vor ${Math.round(n / 7)} Wochen` : n < 365 ? `vor ${Math.round(n / 30)} Monaten` : 'vor über einem Jahr';
}
/* Stand in der Rotation: 'next' | 'open' | 'done' | null */
function rotationState(r) {
  const lane = EP.laneOf(r);
  if (!EP.ROTATES(lane) || !r.inRotation) return null;
  const pend = EP.pendingSorted(db, lane);
  if (!pend.length) return null;
  if (pend[0].recipeId === r.id) return 'next';
  const cur = pend[0].cycleNumber;
  return pend.some(e => e.recipeId === r.id && e.cycleNumber === cur) ? 'open' : 'done';
}
/* Infozeile in der Rezeptauswahl */
function recipeInfo(r, opts) {
  opts = opts || {};
  const parts = [];
  const pl = plannedCooks(r.id).filter(x => x.date !== opts.date && !(opts.ignore && opts.ignore(x)));
  const near = opts.date ? (pl.find(x => x.date > opts.date) || pl[pl.length - 1]) : pl[0];
  if (pl.length) parts.push(`<b class="pinfo warn">Eingeplant am ${EP.weekday(near.date)} ${EP.fmtShort(near.date)}${pl.length > 1 ? ` (+${pl.length - 1})` : ''}</b>`);
  const st = rotationState(r);
  if (EP.ROTATES(EP.laneOf(r))) {
    if (!r.inRotation) parts.push('Außerhalb der Rotation');
    else if (!pl.length) parts.push({ next: '<b class="pinfo next">Als Nächstes dran</b>', open: 'Noch offen im Durchlauf', done: 'In diesem Durchlauf schon dran', null: 'In Rotation' }[st]);
  }
  const lc = lastCooked(r.id);
  if (lc) parts.push('zuletzt ' + agoText(lc));
  return parts.join(' · ');
}
/* Rezept ist schon an einem anderen Tag eingeplant → vorziehen/verlegen oder doppelt kochen?
   run(o): o = verlegter Termin (vorher entfernen) oder null (normal einplanen) */
function canPull(o) { return o.lane === 'EXTRA' || !activeDraft() || o.drafted; }
function removeOther(o) {
  if (o.lane === 'EXTRA') return removeExtra(o.id);
  if (activeDraft()) { if (o.lane === 'MAIN') draftSwap(o.blockId); else draftLaneRemove(o.date, o.lane); return; }
  removeBlock(o.blockId, true);
}
function pickCheck(recipeId, date, ignore, run) {
  const others = plannedCooks(recipeId).filter(x => x.date !== date && !(ignore && ignore(x)));
  if (!others.length) return run(null);
  const r = recipeById(recipeId), o = others.find(x => x.date > date) || others[others.length - 1], od = `${EP.weekday(o.date)} ${EP.fmtShort(o.date)}`, nd = `${EP.weekday(date)} ${EP.fmtShort(date)}`;
  const opts = [];
  if (canPull(o)) opts.push({ label: `Auf ${nd} ${o.date > date ? 'vorziehen' : 'verschieben'}`, hint: `Am ${od} fällt es dann weg${o.lane === 'MAIN' && !o.drafted ? ' – der Tag wird frei' : ''}`, icon: o.date > date ? 'up' : 'down', tone: 'rim', group: 0, run: () => run(o) });
  opts.push({ label: 'Doppelt kochen', icon: 'plus', tone: 'basil', group: 1, run: () => run(null) });
  optionsSheet(`Schon eingeplant`, `„${esc(r.name)}“ steht ${others.length > 1 ? `schon ${others.length}× im Plan, als Nächstes` : ''} am ${EP.weekdayLong(o.date)}, ${EP.fmtShort(o.date)}${others.length > 1 ? '' : ' im Plan'}`, opts);
}
/* Rückmeldung nach dem Einplanen: was ist mit der Rotation passiert? */
function pickMsg(recipeId, e, o) {
  if (o) return `Verlegt vom ${EP.weekday(o.date)}.`;
  const r = recipeById(recipeId), lane = EP.laneOf(r);
  if (e) { const first = EP.pendingSorted(db, lane)[0]; return first && first.id === e.id ? 'Eingeplant.' : 'Eingeplant · vorgezogen'; }
  if (EP.ROTATES(lane) && r.inRotation) return 'Eingeplant · zusätzlich';
  return 'Eingeplant.';
}
/* Rezept auswählen, beschränkt auf eine Art. Pausierte nur mit Schalter „Auch außerhalb der Rotation“.
   opts.kinds: Arten zum Umschalten (für zusätzliche Gerichte) */
function recipePickSheet(title, onPick, kind, opts) {
  opts = opts || {};
  let cur = kind || 'MAIN';
  const m = EP.monthOf(EP.todayISO());
  const kinds = opts.kinds || null;
  const pickHtml = () => {
    const rot = EP.ROTATES(cur), all = !rot || !!LS.get('ep_showPaused');
    const every = liveRecipes().filter(r => EP.laneOf(r) === cur);
    const list = every.filter(r => all || r.inRotation).sort((a, b) => (!!b.favorite - !!a.favorite) || (rot ? b.inRotation - a.inRotation : 0) || a.name.localeCompare(b.name, 'de'));
    const rows = list.map(r => `<button class="opt" data-id="${r.id}"><span class="grow"><span class="serif" style="font-size:17px">${r.favorite ? '<span class="favstar" aria-label="Favorit">★</span> ' : ''}${esc(r.name)}</span>
      <small>${[recipeInfo(r, opts), cur === 'MAIN' ? daysLabel(daysOf(r)) : ''].filter(Boolean).join(' · ')}${EP.inSeason(r, m) ? '' : ' · außerhalb der Saison (' + EP.seasonLabel(r) + ')'}</small></span></button>`).join('');
    const empty = !every.length ? `Noch keine ${esc(LANE_LABEL[cur])}-Rezepte angelegt.`
      : `Keine ${esc(LANE_LABEL[cur])}-Rezepte in der Rotation – Schalter oben einschalten, um die übrigen zu sehen.`;
    return rows || `<p class="empty">${empty}</p>`;
  };
  const toggleHtml = () => EP.ROTATES(cur) ? `<label class="row pausetog"><span class="grow">Auch Rezepte außerhalb der Rotation</span>
      <span class="switch"><input type="checkbox" id="pt" ${LS.get('ep_showPaused') ? 'checked' : ''} aria-label="Auch Rezepte außerhalb der Rotation anzeigen"><i></i></span></label>` : '';
  openSheet(`<h2>${esc(title)}</h2>
    ${kinds ? `<div class="seg ${kinds.length > 4 ? 'seg5' : 'seg4'} kind-seg" id="pk">${kinds.map(k => `<button data-k="${k}" aria-pressed="${k === cur}">${segLbl(DISH_LABEL[k])}</button>`).join('')}</div>` : ''}
    <div id="ptw">${toggleHtml()}</div>
    <input class="in" id="ps" placeholder="Rezept suchen" style="margin-top:10px">
    <div class="pick" id="pl">${pickHtml()}</div>`, el => {
    const filter = () => { const q = $('#ps', el).value.toLowerCase(); $$('#pl .opt', el).forEach(b => b.classList.toggle('hidden', !b.textContent.toLowerCase().includes(q))); };
    const bindList = () => { $$('#pl .opt', el).forEach(b => b.onclick = () => { if (kinds) opts.onKind && opts.onKind(cur); closeSheet(); onPick(b.dataset.id); }); filter(); };
    const bindToggle = () => { const t = $('#pt', el); if (t) t.onchange = () => { LS.set('ep_showPaused', t.checked); $('#pl', el).innerHTML = pickHtml(); bindList(); }; };
    $('#ps', el).oninput = filter;
    $$('#pk button', el).forEach(b => b.onclick = () => {
      cur = b.dataset.k;
      $$('#pk button', el).forEach(x => x.setAttribute('aria-pressed', x === b));
      $('#ptw', el).innerHTML = toggleHtml(); bindToggle();
      $('#pl', el).innerHTML = pickHtml(); bindList();
    });
    bindToggle(); bindList();
  });
}
/* Aussehen der Menüpunkte: Symbol, Farbe und Gruppe (Reihenfolge) – aus dem Text abgeleitet, per o.icon/o.tone überschreibbar */
const OPT_STYLE = [
  [/^Kochansicht/, 'pot', 'rim', 0], [/^Backform/, 'cake', 'mustard', 0], [/^Als (gekocht|gebacken)/, 'check', 'basil', 0],
  [/^Tauschen/, 'swap', 'rim', 1], [/^Nächstes aus/, 'dice', 'rim', 1], [/^(Selbst wählen|Anderes Gericht)/, 'search', 'rim', 1],
  [/^Früher/, 'up', 'rim', 1, 1], [/^Später/, 'down', 'rim', 1, 1], [/verschieben$|^Verschieben/i, 'move', 'rim', 1],
  [/^Fixierung lösen/, 'unpin', 'rim', 1, 1], [/^Fixieren/, 'pin', 'rim', 1, 1], [/^Notiz/, 'pencil', 'rim', 1, 1],
  [/^(Mittagessen|Kuchen|Noch ein Gericht) hinzufügen$/, 'plus', 'basil', 2, 1], [/hinzufügen$/, 'plus', 'basil', 2], [/^Tag wieder freigeben/, 'open', 'basil', 2],
  [/^Tag sperren/, 'out', 'tomato', 3],
  [/^(Aus dem Plan entfernen|Diesmal kein|Bild entfernen)/, 'trash', 'tomato', 4], [/^Reste streichen/, 'x', 'tomato', 4],
  [/unverändert/, 'info', 'speckle', 5], [/Titelbild/, 'image', 'rim', 1], [/^Zusammenführen/, 'merge', 'rim', 1], [/^Alles ersetzen/, 'swap', 'tomato', 4],
];
function optStyle(o) {
  const m = OPT_STYLE.find(([re]) => re.test(o.label)) || [null, 'bowl', 'rim', 1];
  return { icon: ICON['o' + (o.icon || m[1])] || ICON[o.icon || m[1]] || ICON.obowl, tone: o.tone || (o.danger ? 'tomato' : m[2]), group: o.group != null ? o.group : (o.danger ? 4 : m[3]), more: o.more != null ? o.more : !!m[4] };
}
/* Eingabe eines Namens (statt prompt): onOk(wert, auswahl) läuft nach dem Schließen */
function textSheet(title, sub, value, ok, onOk, choices) {
  openSheet(`<h2>${esc(title)}</h2>${sub ? `<p class="sub" style="margin-top:6px">${esc(sub)}</p>` : ''}
    <input class="in" id="ts-in" value="${esc(value || '')}" style="margin-top:12px" autocomplete="off" enterkeyhint="done">
    ${choices ? `<div class="seg" style="margin-top:12px">${choices.list.map(([k, l]) => `<button type="button" data-k="${k}" aria-pressed="${k === choices.cur}">${esc(l)}</button>`).join('')}</div>` : ''}
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">${esc(ok)}</button></div>`, el => {
    const inp = $('#ts-in', el);
    $$('[data-k]', el).forEach(b => b.onclick = () => $$('[data-k]', el).forEach(x => x.setAttribute('aria-pressed', String(x === b))));
    const done = () => {
      const v = inp.value.trim(); if (!v) { inp.focus(); return; }
      const c = $('[data-k][aria-pressed=true]', el);
      closeSheet(); onOk(v, c && c.dataset.k);
    };
    $('[data-x=no]', el).onclick = closeSheet; $('[data-x=yes]', el).onclick = done;
    inp.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); done(); } };
  });
}
function optionsSheet(title, sub, opts, chip) {
  let list = opts.map((o, i) => Object.assign({ i }, o, optStyle(o))).sort((a, b) => a.group - b.group || a.i - b.i);
  // Selten Gebrauchtes unter „Mehr …“, sobald das Menü lang wird (mindestens zwei Einträge dahinter)
  const moreList = list.length > 6 && list.filter(o => o.more).length >= 2 ? list.filter(o => o.more) : [];
  if (moreList.length) list = list.filter(o => !o.more);
  const btn = o => `<button class="opt tone-${o.tone} ${o.danger ? 'danger' : ''}" data-i="${o.i}"><span class="oic">${o.icon}</span><span class="grow">${esc(o.label)}${o.hint ? `<small>${esc(o.hint)}</small>` : ''}</span></button>`;
  const render = l => l.map((o, k) => `${k && o.group !== l[k - 1].group ? '<div class="optgap"></div>' : ''}${btn(o)}`).join('');
  const dangerAt = list.findIndex(o => o.group >= 4);
  const head = dangerAt < 0 ? list : list.slice(0, dangerAt), tail = dangerAt < 0 ? [] : list.slice(dangerAt);
  const moreHtml = moreList.length ? `<div class="optgap"></div><button class="opt moretoggle tone-speckle" data-more aria-expanded="false"><span class="oic">${ICON.omore}</span><span class="grow">Mehr …<small>${esc(moreList.map(o => o.label).join(' · '))}</small></span></button>
    <div class="optmore hidden">${render(moreList)}</div>` : '';
  const html = render(head) + moreHtml + (tail.length ? '<div class="optgap"></div>' + render(tail) : '');
  openSheet(`<h2>${esc(title)}</h2>${sub || chip ? `<div class="opthead">${sub ? `<span class="sub">${sub}</span>` : ''}${chip || ''}</div>` : ''}<div class="optlist">${html}</div>
    <div class="btns"><button class="btn quiet" data-x="no">Schließen</button></div>`, el => {
    $$('[data-i]', el).forEach(b => b.onclick = () => { closeSheet(); opts[+b.dataset.i].run(); });
    const mt = $('[data-more]', el);
    if (mt) mt.onclick = () => { $('.optmore', el).classList.remove('hidden'); mt.remove(); };
    $('[data-x=no]', el).onclick = closeSheet;
  });
}
/* Rückgängig: Stand von Plan und Rotation vor einer Aktion merken, bei Bedarf wiederherstellen.
   Wiederhergestellte Einträge werden neu gestempelt, damit der Abgleich sie nicht überschreibt. */
function undoable(fn) {
  const snap = draft ? null : { plan: deep(db.plan), rotation: deep(db.rotation) }; // im Entwurf kein Rückgängig
  const msg = fn();
  return change(msg, snap);
}
function restoreSnap(snap) {
  ['plan', 'rotation'].forEach(k => {
    const cur = new Map(db[k].map(x => [x.id, x])), ids = new Set(snap[k].map(x => x.id));
    snap[k].forEach(o => {
      const c = cur.get(o.id);
      if (!c) { db[k].push(EP.touch(deep(o))); return; }
      if (JSON.stringify(c) === JSON.stringify(o)) return;
      Object.keys(c).forEach(key => delete c[key]); Object.assign(c, deep(o)); EP.touch(c);
    });
    db[k].forEach(x => { if (!ids.has(x.id) && !x.deleted) EP.tomb(x); });
  });
}

/* ---------- Navigation ---------- */
function go(name, params) {
  if (TABS.some(t => t[0] === name)) { stack = []; route = { name, params }; }
  else { stack.push(route); route = { name, params }; }
  window.scrollTo(0, 0);
  if (typeof favPinned !== 'undefined') favPinned = null;
  rerender();
  if (name === 'week') scrollToToday();
}
/* Zurück-Geste (iPhone: vom linken Rand wischen) und Android-Zurück: Der Verlauf spiegelt die Ebenen der App
   (Woche 0, anderer Reiter 1, Unterseiten +1 je Stufe, Kochansicht +1, offenes Blatt +1). Einträge entstehen nur direkt
   nach einem Antippen – Safari und Chrome überspringen beim Zurückwischen Einträge, die ohne Bedienung angelegt wurden. */
const BackNav = (() => {
  let expect = null;
  try { history.scrollRestoration = 'manual'; } catch (e) {}   // Zurück im Verlauf soll die Scrollposition nicht verstellen
  const hd = () => { try { return (history.state && history.state.bd) || 0; } catch (e) { return 0; } };
  const cookOpen = () => { const cv = $('#cookview'); return !!cv && !cv.classList.contains('hidden'); };
  const depth = () => {
    if (!$('#shell') || $('#shell').classList.contains('hidden')) return 0;
    const root = stack.length ? stack[0].name : route.name;
    return stack.length + (root !== HOME ? 1 : 0) + (cookOpen() ? 1 : 0) + ($('#scrim') ? 1 : 0);
  };
  const handle = () => {
    if ($('#scrim')) { closeSheet(); return true; }
    if (cookOpen()) { closeCook(); return true; }
    if (!$('#shell') || $('#shell').classList.contains('hidden')) return false;
    if (!TABS.some(t => t[0] === route.name)) { back(); return true; }
    if (route.name !== HOME) { go(HOME); return true; }
    return false;
  };
  function sync() {
    try {
      if (expect != null) return;
      const want = depth(), have = hd();
      if (want > have) { for (let d = have + 1; d <= want; d++) history.pushState({ bd: d }, ''); }
      else if (want < have) { expect = want; history.go(want - have); }
    } catch (e) {}
  }
  const later = () => setTimeout(sync, 0);
  addEventListener('popstate', () => {
    const now = hd();
    if (expect != null) { if (now <= expect) { expect = null; later(); } return; }   // Verlauf nach „Zurück“ in der App nachgezogen
    if (now < depth()) handle();                                                      // Zurück-Geste: eine Ebene zurück
    later();
  });
  ['click', 'touchend', 'keydown'].forEach(t => document.addEventListener(t, later, true));
  return { sync, handle, depth, arm: later };
})();
/* heutigen Tag ins Bild holen, falls er nicht sichtbar ist */
function scrollToToday() {
  const el = $('.day.today'); if (!el) return;
  const b = el.getBoundingClientRect(), head = (($('.top') || {}).offsetHeight || 60) + (($('.wksep') || {}).offsetHeight || 56);
  if (b.top < head || b.bottom > window.innerHeight - 100) window.scrollTo(0, Math.max(0, window.scrollY + b.top - head - 8));
}
function back() {
  if (route.name === 'edit' && editState && editState.dirty) {
    return confirmSheet('Änderungen verwerfen?', 'Das Rezept wurde noch nicht gespeichert.', 'Verwerfen', 'Weiter bearbeiten', () => { editState = null; back(); }, true);
  }
  route = stack.pop() || { name: HOME };
  rerender();
}
async function change(msg, snap) {
  await persist();
  if (msg) notify(msg, snap && (() => { restoreSnap(snap); change('Rückgängig gemacht.'); }));
  rerender();
}

function renderSyncPill() {
  const p = $('#syncpill'); if (!p) return;
  const map = { off: ['', 'Nur dieses Gerät'], ok: ['ok', 'Abgeglichen'], busy: ['busy', 'Gleicht ab …'], err: ['err', 'Abgleich gestört'], offline: ['', 'Offline'] };
  const [cls, txt] = map[Sync.enabled() ? Sync.state : 'off'] || map.off;
  p.className = 'syncpill ' + cls;
  p.innerHTML = `<i></i>${txt}`;
  p.title = Sync.msg || txt;
}
function rerender() {
  if (!db || !$('#shell') || $('#shell').classList.contains('hidden')) return;
  const isTab = TABS.some(t => t[0] === route.name);
  $('#ttl').textContent = route.name === 'edit' ? (editState && editState.isNew ? 'Neues Rezept' : 'Rezept bearbeiten') : TITLES[route.name];
  $('#topleft').innerHTML = isTab
    ? `<a class="iconbtn" href="index.html" aria-label="Zur Übersicht der Apps">${ICON.back}</a>`
    : `<button class="iconbtn" data-act="back" aria-label="Zurück">${ICON.back}</button>`;
  $('#tabs').innerHTML = TABS.map(([k, l, ic]) => `<button data-tab="${k}" ${route.name === k || (!isTab && stack[0] && stack[0].name === k) ? 'aria-current="page"' : ''}>${ic}${l}</button>`).join('');
  const views = { suggest: vSuggest, week: vWeek, shop: vShop, recipes: vRecipes, edit: vEdit, ingredients: vIngredients, rotation: vRotation, settings: vSettings, sync: vSync, sources: vSources, stores: vStores, store: vStore };
  const main = $('#main');
  main.className = 'r-' + route.name;   // für breite Bildschirme (iPad, quer): Aufteilung je Ansicht
  main.innerHTML = (views[route.name] || vSuggest)();
  const binder = BIND[route.name]; if (binder) binder(main);
  renderSyncPill();
  const editing = route.name === 'edit';   // Rezept bearbeiten: „Speichern“ immer oben erreichbar
  $('#hdrsave').classList.toggle('hidden', !editing); $('#syncpill').classList.toggle('hidden', editing); $('#gear').classList.toggle('hidden', editing);
  const n = unreviewedCount(), gb = $('#gearbadge');
  if (gb) { gb.textContent = n; gb.classList.toggle('hidden', !n); $('#gear').setAttribute('aria-label', n ? `Einstellungen – ${n} neue Zutat${n === 1 ? '' : 'en'} zuordnen` : 'Einstellungen'); }
  Images.hydrate(main);
}

/* ---------- Vorschlag (5.3) ---------- */
function laneSeg(cur, act, kinds) {
  return `<div class="seg lane-seg ${kinds && kinds.length > 4 ? 'seg5' : kinds && kinds.length > 3 ? 'seg4' : ''}">${(kinds || EP.LANES).map(l => `<button data-act="${act}" data-arg="${l.key}" aria-pressed="${cur === l.key}">${segLbl(LANE_LABEL[l.key])}</button>`).join('')}</div>`;
}
/* Tagesleiste im Vorschlag: welche Tage zeigen, welcher ist gewählt, welche würde das Gericht belegen */
function suggestDays(lane) {
  const today = EP.todayISO(), out = [];
  if (lane === 'MAIN') { for (let i = 0; i < 14; i++) out.push(EP.addDays(today, i)); return out; }
  for (let i = 0; i < 70 && out.length < 8; i++) { const d = EP.addDays(today, i); if (laneActiveOn(lane, d)) out.push(d); }
  return out;
}
function suggestBusy(lane, d) { return lane === 'MAIN' ? planByDate().get(d) || null : laneAt(db, d, lane); }
function suggestTarget(lane, r) {
  const today = EP.todayISO();
  let t = suggestPick[lane];
  if (t && (t.date < today || (lane !== 'MAIN' && !laneActiveOn(lane, t.date)))) t = null;
  if (t && t.replace && !EP.live(db.plan).some(p => p.blockId === t.replace)) t = null;
  if (t && !t.replace && suggestBusy(lane, t.date)) t = null;
  if (!t) t = { date: lane === 'MAIN' ? firstFreeFrom(today) : firstLaneDay(lane, today), replace: null };
  suggestPick[lane] = t;
  let dates = [t.date];
  if (lane === 'MAIN' && r) {
    const occ = mainDates();
    if (t.replace) EP.live(db.plan).filter(p => p.blockId === t.replace).forEach(p => occ.delete(p.date));
    dates = EP.nextFreeDates(t.date, daysOf(r), occ);
  }
  const old = t.replace && EP.live(db.plan).find(p => p.blockId === t.replace);
  return Object.assign({}, t, { dates, replacing: old ? recipeById(old.recipeId) : null });
}
/* „Mi 07.10.“, „Mi 07. + Do 08.10.“, „Mi 07.–Fr 09.10.“ */
function shortRange(ds) {
  const f = d => `${EP.weekday(d)} ${EP.fmtShort(d)}`, g = d => `${EP.weekday(d)} ${d.slice(8)}.`;
  if (ds.length === 1) return f(ds[0]);
  const consec = ds.every((d, i) => !i || d === EP.addDays(ds[i - 1], 1));
  if (ds.length === 2) return `${g(ds[0])} + ${f(ds[1])}`;
  return consec ? `${g(ds[0])}–${f(ds[ds.length - 1])}` : ds.map(g).join(', ');
}
function suggestStrip(lane, t) {
  const today = EP.todayISO(), sel = new Set(t.dates);
  return `<div class="dstrip" role="group" aria-label="Tag wählen">${suggestDays(lane).map(d => {
    const p = suggestBusy(lane, d), blocked = p && p.type === 'BLOCKED', r = p && p.recipeId ? recipeById(p.recipeId) : null;
    const st = blocked ? 'blocked' : p ? 'busy' : 'free';
    const lbl = `${EP.weekdayLong(d)}, ${EP.fmtShort(d)}: ${blocked ? 'gesperrt' : r ? r.name : 'frei'}${sel.has(d) ? ' (gewählt)' : ''}`;
    return `<button class="dchip ${st}${sel.has(d) ? ' sel' : ''}${d === t.date ? ' start' : ''}${d === today ? ' today' : ''}" data-act="sday" data-arg="${d}" aria-label="${esc(lbl)}">
      <small>${d === today ? 'Heute' : EP.weekday(d)}</small><b>${+d.slice(8)}</b><i></i></button>`;
  }).join('')}</div>`;
}
function vSuggest() {
  const lane = suggestLane;
  const month = EP.monthOf(EP.todayISO());
  const sig = () => db.rotation.length + ':' + db.rotation.filter(e => e.deleted).length + ':' + db.rotation.filter(e => e.status === 'SKIPPED').length;
  const before = sig();
  const next = EP.nextEntries(db, 6, null, rng, lane, month);
  if (sig() !== before) persist();
  const seg = laneSeg(lane, 'slane');
  const laneHint = lane === 'MAIN' ? '' : laneDays(lane).length
    ? `<p class="hint" style="text-align:center">${esc(laneWhat(lane))} an: ${laneDays(lane).slice().sort((x, y) => ((x + 6) % 7) - ((y + 6) % 7)).map(d => ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'][d]).join(', ')}</p>`
    : `<p class="hint" style="text-align:center">Keine Tage gewählt (Einstellungen).</p>`;
  if (!next.length) {
    const hasAny = liveRecipes().some(r => EP.laneOf(r) === lane);
    const txt = { MAIN: ['Noch nichts in der Rotation', 'Leg deine Gerichte im Reiter Rezepte an – ein Name reicht für den Anfang.'],
      LUNCH: ['Noch keine Mittagsgerichte', 'Kleine Gerichte fürs Wochenende, z. B. Brot mit Spinat und Ei oder Nudelsuppe. Sie haben ihre eigene Rotation.'],
      CAKE: ['Noch keine Kuchen', 'Kuchen kommen zusätzlich zum Essen dazu und haben ihre eigene Rotation.'] }[lane];
    const allOut = hasAny && liveRecipes().filter(r => EP.laneOf(r) === lane && r.inRotation).every(r => !EP.inSeason(r, month));
    return `${seg}<div class="empty"><p class="serif">${allOut ? 'Gerade hat nichts Saison' : txt[0]}</p><p>${allOut ? 'Alle Gerichte dieser Rotation sind auf andere Monate beschränkt.' : txt[1]}</p>
      <div class="btns"><button class="btn primary" data-act="tabkind" data-arg="${lane}">Rezepte anlegen</button>
      ${lane === 'MAIN' ? (liveRecipes().length ? '' : '<button class="btn" data-act="seed">Beispielrezepte laden</button>')
        : `<button class="btn" data-act="seedlane" data-arg="${lane}">${lane === 'LUNCH' ? '6 Mittagsgerichte als Vorschlag laden' : '7 Kuchen als Vorschlag laden'}</button>`}</div></div>${laneHint}`;
  }
  const e = next[0], r = recipeById(e.recipeId), n = daysOf(r), ck = coverKey(r);
  const prog = EP.cycleProgress(db, lane);
  const occ = r.weight > 1 ? ` (${e.occurrence}/${r.weight})` : '';
  const meta = lane === 'MAIN' ? `${r.servings} Portionen, reicht für ${daysLabel(n)}${occ}` : `${r.servings} ${lane === 'CAKE' ? 'Stücke' : 'Portionen'}${occ}`;
  const season = EP.seasonLabel(r);
  const t = suggestTarget(lane, r);
  const busyNote = t.replacing ? `ersetzt „${esc(t.replacing.name)}“` : '';
  return `${seg}${suggestStrip(lane, t)}
    <p class="dstrip-info">${lane === 'MAIN' ? (t.dates.length > 1 ? `Belegt ${shortRange(t.dates)}` : shortRange(t.dates)) : `${LANE_LABEL[lane]} am ${shortRange(t.dates)}`}${busyNote ? ` · ${busyNote}` : ''}</p>
    <div class="plate-wrap">
      <div class="plate ${lane !== 'MAIN' ? 'plate-' + lane.toLowerCase() : ''}">${ck ? `<img data-img="${ck}" data-thumb="0" alt="">` : `<span class="dish">${esc(r.name)}</span>`}</div>
      ${ck ? `<div class="dish-under">${esc(r.name)}</div>` : ''}
      <p class="plate-meta">${meta}${r.prepTimeMinutes ? `, ${r.prepTimeMinutes} min` : ''}${season ? `<br>Saison: ${season}` : ''}</p>
    </div>
    <div class="btns">
      <button class="btn primary" data-act="accept" data-arg="${e.id}">Für ${shortRange(t.dates)} einplanen</button>
      <div class="btns two" style="margin-top:0">
        <button class="btn" data-act="postpone" data-arg="${e.id}">Später</button>
        <button class="btn" data-act="skip" data-arg="${e.id}">Diesmal auslassen</button>
      </div>
      <button class="btn quiet" data-act="pickself">Selbst wählen</button>
    </div>
    ${prog ? `<div class="progress">Durchlauf ${prog.cycle} · ${prog.current} von ${prog.total} ${lane === 'CAKE' ? 'Kuchen' : 'Gerichten'}
      <div class="progress-bar"><i style="width:${Math.round((prog.current - 1) / prog.total * 100)}%"></i></div></div>` : ''}
    ${laneHint}
    ${next.length > 1 ? `<h3>Danach</h3><ol class="queue box">${next.slice(1, 6).map((x, i) => {
      const rr = recipeById(x.recipeId);
      return `<li><span class="n">${i + 2}.</span><span class="nm">${esc(rr.name)}</span><span class="d">${lane === 'MAIN' ? daysLabel(daysOf(rr)) : ''}</span></li>`;
    }).join('')}</ol>` : ''}`;
}

/* ---------- Woche (5.4) ---------- */
/* Direktknopf in die Kochansicht (bei leeren Rezepten zeigt sie einen Hinweis zum Ergänzen) */
function cookBtn(r) {
  if (!r) return '';
  return `<button class="cookbtn" data-act="cook" data-arg="${r.id}" aria-label="Kochansicht: ${esc(r.name)}">${ICON.pot}</button>`;
}
function laneVisible(lane) { return laneDays(lane).length > 0 && liveRecipes().some(r => EP.laneOf(r) === lane); }
/* Durchgehende Wochenansicht: Wochen untereinander, KW als mitlaufende Trennzeile.
   weekStartISO bleibt die „aktive“ Woche für Menüs und Entwurf; sie wird beim Antippen eines Tages gesetzt. */
let weekRange = null;   // { from: Montag der ersten gezeigten Woche, weeks: Anzahl }
function ensureWeekShown(ws) {
  const today = EP.todayISO();
  if (!weekRange) weekRange = { from: EP.addDays(EP.weekStart(today), -7), weeks: 6 };
  if (ws < weekRange.from) { const n = Math.round((EP.parseISO(weekRange.from) - EP.parseISO(ws)) / 6048e5); weekRange.from = ws; weekRange.weeks += n; }
  const last = EP.addDays(weekRange.from, 7 * (weekRange.weeks - 1));
  if (ws > last) weekRange.weeks += Math.round((EP.parseISO(ws) - EP.parseISO(last)) / 6048e5) + 1;
}
function weekBlock(ws, today, showLane) {
  const days = EP.weekDays(ws);
  const isDraft = draft && draft.ws === ws;
  const ents = weekEntries(ws);
  const kw = EP.isoWeek(ws);
  const rows = days.map(d => {
    const p = ents.get(d);
    const cls = ['day', d === today ? 'today' : '', d < today ? 'past' : '', p && p.drafted ? 'drafted' : ''].join(' ');
    let body;
    if (!p) body = `<div class="nm free">${d < today ? '–' : 'Frei'}</div>`;
    else if (p.type === 'BLOCKED') body = `<div class="nm free">Gesperrt</div><div class="tags"><span class="badge block">${esc(p.note || 'Kein Kochen')}</span></div>`;
    else {
      const r = recipeById(p.recipeId);
      const carry = p.type === 'LEFTOVER' && blockEntries(p.blockId, isDraft ? draft.clone : db).concat(isDraft ? draft.drafts.filter(x => x.blockId === p.blockId) : [])
        .some(x => x.type === 'COOK' && x.date < ws);
      const b = p.type === 'COOK' ? `<span class="badge cook">Kochtag${p.dayCount > 1 ? ` 1/${p.dayCount}` : ''}</span>`
        : `<span class="badge rest">Reste ${p.dayIndex}/${p.dayCount}</span>`;
      body = `<div class="nm">${esc(r ? r.name : 'Gelöschtes Rezept')}</div><div class="tags">${b}${r && EP.laneOf(r) === 'SPECIAL' ? `<span class="badge special">${esc(DISH_LABEL.SPECIAL)}</span>` : ''}${p.guests && p.type === 'COOK' ? `<span class="badge guests">👥 ${p.guests}</span>` : ''}${carry ? '<span class="badge">Übertrag</span>' : ''}
        ${p.status === 'DONE' && p.type === 'COOK' ? '<span class="badge done">Gekocht</span>' : ''}${p.source === 'MANUAL' && p.type === 'COOK' ? '<span class="badge">Selbst gewählt</span>' : ''}</div>`;
    }
    const laneLines = ['LUNCH', 'CAKE'].map(l => {
      const x = ents.lanes[l].get(d);
      if (!x && !(showLane[l] && laneActiveOn(l, d) && d >= today)) return '';
      const r = x && recipeById(x.recipeId);
      return `<div class="dayrow lanerow"><button class="laneline ${x && x.drafted ? 'drafted' : ''} lane-${l.toLowerCase()}" data-act="lane" data-arg="${d}|${l}">
        <span class="lanelbl">${LANE_LABEL[l]}</span><span class="nm ${x ? '' : 'free'}">${x ? esc(r ? r.name : 'Gelöschtes Rezept') : 'Frei'}${x && x.pan ? `<small class="panlbl">${esc(EP.panLabel(x.pan))}</small>` : ''}${x && x.guests ? `<small class="panlbl">👥 ${x.guests}</small>` : ''}</span>
        ${x && x.status === 'DONE' ? `<span class="badge done">${l === 'CAKE' ? 'Gebacken' : 'Gekocht'}</span>` : ''}</button>${x ? cookBtn(r) : ''}</div>`;
    }).join('');
    const extraLines = (ents.extras.get(d) || []).map(x => {
      const r = recipeById(x.recipeId), k = x.dishKind || 'MAIN';
      return `<div class="dayrow lanerow"><button class="laneline lane-extra lane-x-${k.toLowerCase()}" data-act="extra" data-arg="${x.id}">
        <span class="lanelbl">${DISH_LABEL[k] || 'Gericht'}</span><span class="nm">${esc(r ? r.name : 'Gelöschtes Rezept')}</span>
        ${x.status === 'DONE' ? `<span class="badge done">${k === 'CAKE' ? 'Gebacken' : 'Gekocht'}</span>` : ''}</button>${cookBtn(r)}</div>`;
    }).join('');
    const mainRecipe = p && p.recipeId ? recipeById(p.recipeId) : null;
    const sg = !isDraft && d >= today ? sideSuggestions(ents, d).sides : [];
    const sideLine = sg.length ? `<div class="dayrow lanerow sidesug"><div class="sidesugin"><span class="lanelbl">Dazu?</span>
      <span class="sidechips">${sg.map(s => `<button class="chip small" data-act="sideadd" data-arg="${d}|${s.id}" aria-label="${esc(s.name)} dazu einplanen">+ ${esc(s.name)}</button>`).join('')}</span>
      <button class="sideoff" data-act="sideoff" data-arg="${d}" aria-label="Diesmal keine Beilage vorschlagen">✕</button></div></div>` : '';
    const specialLine = showLane.SPECIAL && d >= today && isSpecialDay(d) && !specialOn(ents, d)
      ? `<div class="dayrow lanerow"><button class="laneline lane-special" data-act="special" data-arg="${d}">
        <span class="lanelbl">${esc(DISH_LABEL.SPECIAL)}</span><span class="nm free">${isDraft && !p ? 'Freigehalten – ' : ''}Gericht wählen</span><span class="plus" aria-hidden="true">+</span></button></div>` : '';
    return `<div class="${cls}"><div class="dayrow"><button class="daymain" data-act="day" data-arg="${d}"><div class="dt"><b>${EP.weekday(d)}</b><span>${EP.fmtShort(d)}</span>${d === today ? '<i class="todaypill">Heute</i>' : ''}</div>
      <div class="what">${body}</div>${p && p.locked ? ICON.lock : ''}</button>${cookBtn(mainRecipe)}</div>${specialLine}${laneLines}${extraLines}${sideLine}</div>`;
  }).join('');
  const canFill = !draft && days[6] >= today;
  return `<section class="wkblock${isDraft ? ' drafting' : ''}${ws === EP.weekStart(today) ? ' current' : ''}" data-ws="${ws}">
    <div class="wksep weekhead"><div class="kw"><b>KW ${kw}</b><span>${EP.fmtRange(ws, days[6])}</span></div>
      <div class="wkbtns">${canFill ? `<button class="btn small primary" data-act="fill" data-arg="${ws}" aria-label="KW ${kw} füllen">Füllen</button>` : ''}
        <button class="iconbtn" data-act="toshop" data-arg="${ws}" aria-label="Einkaufsliste KW ${kw}">${ICON.cart}</button></div></div>
    ${isDraft ? `<div class="draftbar"><b>Entwurf</b> – noch nicht gespeichert. Tippe auf einen Tag, um zu tauschen, zu verschieben oder selbst zu wählen.</div>` : ''}
    <div class="days">${rows}</div>
    ${isDraft ? `<div class="btns two"><button class="btn" data-act="discard">Verwerfen</button><button class="btn primary" data-act="commit">Plan übernehmen</button></div>` : ''}
  </section>`;
}
function vWeek() {
  const today = EP.todayISO();
  ensureWeekShown(weekStartISO);
  if (draft) ensureWeekShown(draft.ws);
  const showLane = { LUNCH: laneVisible('LUNCH'), CAKE: laneVisible('CAKE'), SPECIAL: hasSpecial() };
  const weeks = Array.from({ length: weekRange.weeks }, (_, i) => EP.addDays(weekRange.from, 7 * i));
  return `<div class="wktop"><button class="btn quiet small" data-act="wkearlier">Frühere Woche zeigen</button></div>
    ${weeks.map(ws => weekBlock(ws, today, showLane)).join('')}
    <div class="wkmore" id="wkmore"><button class="btn quiet" data-act="wkmore">Weitere Wochen laden</button></div>
    <button class="todaybtn hidden" id="todaybtn" data-act="wk" data-arg="0" aria-label="Zu heute springen">Heute</button>`;
}
/* eine Woche in den sichtbaren Bereich holen (unter die mitlaufende Kopfzeile) */
function scrollToWeek(ws, smooth) {
  const el = $(`.wkblock[data-ws="${ws}"]`); if (!el) return;
  const top = el.getBoundingClientRect().top + window.scrollY - (($('.top') || {}).offsetHeight || 0) - 4;
  window.scrollTo({ top: Math.max(0, top), behavior: smooth ? 'smooth' : 'auto' });
}
/* steht an diesem Tag schon ein besonderes Gericht (Hauptgericht, Mittag oder zusätzlich)? */
function specialOn(ents, d) {
  const isSp = x => x && x.recipeId && EP.laneOf(recipeById(x.recipeId) || {}) === 'SPECIAL';
  return isSp(ents.get(d)) || isSp(ents.lanes.LUNCH.get(d)) || (ents.extras.get(d) || []).some(isSp);
}
/* Besonderes Gericht wählen, dann: als Abendessen (statt des Hauptgerichts) oder als Mittagessen */
function specialPick(d) {
  if (draft && draft.ws === EP.weekStart(d)) return notify('Erst den Entwurf übernehmen oder verwerfen.');
  recipePickSheet(`${DISH_LABEL.SPECIAL} am ${EP.weekdayLong(d)}`, id => {
    const r = recipeById(id), p = planByDate().get(d), lunch = laneAt(db, d, 'LUNCH');
    const pr = p && p.recipeId && recipeById(p.recipeId), lr = lunch && recipeById(lunch.recipeId);
    const go = slot => pickCheck(id, d, null, o => undoable(() => { if (o) removeOther(o); placeSpecial(d, id, slot); return slot === 'LUNCH' ? 'Als Mittagessen eingeplant.' : 'Als Abendessen eingeplant.'; }));
    optionsSheet(r ? r.name : '', `${EP.weekdayLong(d)}, ${EP.fmtShort(d)}`, [
      { label: 'Als Abendessen', icon: 'bowl', group: 0, hint: pr ? `statt „${pr.name}“` : '', run: () => go('MAIN') },
      { label: 'Als Mittagessen', icon: 'bowl', tone: 'basil', group: 0, hint: lr ? `statt „${lr.name}“` : '', run: () => go('LUNCH') },
    ]);
  }, 'SPECIAL', { date: d });
}
/* Gäste: Personen für dieses Gericht – Zutaten auf der Einkaufsliste und in der Kochansicht werden angepasst */
function guestSheet(p) {
  const r = recipeById(p.recipeId), pp = db.settings.portionsPerDay;
  let n = p.guests || pp;
  const info = () => {
    const f = EP.guestFactor({ guests: n }, r, db.settings);
    return n === pp ? `Wie immer (${pp} ${pp === 1 ? 'Person' : 'Personen'}).` : `Zutaten für ${Math.round((r.servings || pp) * f)} statt ${r.servings || pp} Portionen – die Reste bleiben gleich.`;
  };
  openSheet(`<h2>Personen</h2><p class="serif" style="font-size:19px;margin-top:4px">${esc(r ? r.name : '')}</p>
    <p class="sub">${EP.weekdayLong(p.date)}, ${EP.fmtShort(p.date)}</p>
    <div class="stepper big" style="margin:16px auto"><button data-x="m" aria-label="Weniger">−</button><output id="gn">${n}</output><button data-x="p" aria-label="Mehr">+</button></div>
    <p class="hint" id="gi" style="text-align:center">${info()}</p>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Übernehmen</button></div>`, el => {
    const upd = d => { n = Math.max(1, Math.min(30, n + d)); $('#gn', el).textContent = n; $('#gi', el).textContent = info(); };
    $('[data-x=m]', el).onclick = () => upd(-1);
    $('[data-x=p]', el).onclick = () => upd(1);
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => { closeSheet(); setGuests(p.id, n); change(n === pp ? 'Wieder wie immer.' : `Für ${n} Personen.`); };
  });
}
const guestOpt = p => ({ label: 'Personen / Gäste', icon: 'people', group: 0, hint: p.guests ? `${p.guests} Personen` : '', run: () => guestSheet(p) });
/* Aktionen für Mittag / Kuchen an einem Tag */
function laneActions(d, lane) {
  const ws = weekStartISO, isDraft = draft && draft.ws === ws;
  const x = weekEntries(ws).lanes[lane].get(d);
  const r = x && recipeById(x.recipeId);
  const what = laneWhat(lane);
  const title = `${what} am ${EP.weekdayLong(d)}, ${EP.fmtShort(d)}`;
  const opts = [];
  if (isDraft) {
    if (x && x.drafted) {
      opts.push({ label: 'Tauschen', run: () => { draftLaneNext(d, lane); rerender(); } });
      opts.push({ label: 'Selbst wählen', run: () => recipePickSheet(what + ' wählen', id => pickCheck(id, d, null, o => { if (o) removeOther(o); draftLanePick(d, lane, id); rerender(); }), lane, { date: d }) });
      opts.push({ label: 'Diesmal kein ' + what, danger: true, run: () => { draftLaneRemove(d, lane); rerender(); } });
    } else if (!x) {
      opts.push({ label: 'Nächstes aus der Rotation', run: () => { draftLaneNext(d, lane); rerender(); } });
      opts.push({ label: 'Selbst wählen', run: () => recipePickSheet(what + ' wählen', id => pickCheck(id, d, null, o => { if (o) removeOther(o); draftLanePick(d, lane, id); rerender(); }), lane, { date: d }) });
    } else opts.push({ label: 'Bleibt unverändert', hint: 'Bereits gekocht oder fixiert', run: () => {} });
    return optionsSheet(title, r ? esc(r.name) : '', opts);
  }
  if (!x) {
    opts.push({ label: 'Nächstes aus der Rotation', run: () => {
      const e = EP.nextEntries(db, 1, null, rng, lane, EP.monthOf(d))[0];
      if (!e) return notify('Keine Gerichte in dieser Rotation.');
      undoable(() => { placeLane(d, lane, e.recipeId, e.id); return 'Eingeplant.'; });
    } });
    opts.push({ label: 'Selbst wählen', run: () => recipePickSheet(what + ' wählen', id => pickCheck(id, d, null, o => undoable(() => { if (o) removeOther(o); const e = EP.manualPickEntry(db, id), m = pickMsg(id, e, o); placeLane(d, lane, id, e ? e.id : null); return m; })), lane, { date: d }) });
  } else {
    if (x.status !== 'DONE') opts.push({ label: lane === 'CAKE' ? 'Als gebacken markieren' : 'Als gekocht markieren', run: () => undoable(() => { markCooked(x.blockId); return 'Erledigt.'; }) });
    if (r && (r.instructions || r.ingredients.length)) opts.push({ label: 'Kochansicht öffnen', run: () => openCook(r.id) });
    if (r && lane === 'LUNCH' && x.date >= EP.todayISO()) opts.push(guestOpt(x));
    if (r && lane === 'CAKE') opts.push({ label: 'Backform', hint: x.pan ? EP.panLabel(x.pan) : r.pan ? EP.panLabel(r.pan) : '', run: () => planPanSheet(x, r) });
    if (d >= EP.todayISO()) {
      opts.push({ label: 'Tauschen', run: () => undoable(() => { const nr = swapLane(d, lane); return nr ? 'Getauscht gegen ' + nr.name + '.' : 'Keine weiteren Gerichte in dieser Rotation.'; }) });
      opts.push({ label: 'Selbst wählen', run: () => recipePickSheet(what + ' wählen', id => pickCheck(id, d, y => y.blockId === x.blockId, o => undoable(() => { if (o) removeOther(o); const e = EP.manualPickEntry(db, id), m = pickMsg(id, e, o); placeLane(d, lane, id, e ? e.id : null); return m.replace('Eingeplant', 'Ersetzt'); })), lane, { date: d, ignore: y => y.blockId === x.blockId }) });
    }
    opts.push({ label: 'Aus dem Plan entfernen', danger: true, run: () => undoable(() => { removeBlock(x.blockId, true); return 'Entfernt.'; }) });
  }
  optionsSheet(title, r ? esc(r.name) : '', opts);
}
/* Statusmarke im Kopf des Tagesmenüs */
function dayChip(p) {
  if (!p) return '<span class="badge">Frei</span>';
  if (p.type === 'BLOCKED') return `<span class="badge block">${esc(p.note || 'Gesperrt')}</span>`;
  if (p.type === 'LEFTOVER') return `<span class="badge rest">Reste ${p.dayIndex}/${p.dayCount}</span>`;
  return `<span class="badge cook">Kochtag${p.dayCount > 1 ? ` 1/${p.dayCount}` : ''}</span>${p.status === 'DONE' ? '<span class="badge done">Gekocht</span>' : ''}${p.locked ? '<span class="badge">Fixiert</span>' : ''}`;
}
function dayActions(d) {
  const ws = weekStartISO, today = EP.todayISO();
  const isDraft = draft && draft.ws === ws;
  const p = weekEntries(ws).get(d);
  const title = `${EP.weekdayLong(d)}, ${EP.fmtDate(d)}`;
  const opts = [];
  if (isDraft) {
    if (p && p.drafted && p.blockId) {
      const idx = draft.sequence.findIndex(s => s.blockId === p.blockId);
      opts.push({ label: 'Tauschen', run: () => { draftSwap(p.blockId); rerender(); } });
      if (idx > 0) opts.push({ label: 'Früher einplanen', run: () => { draftMove(p.blockId, -1); rerender(); } });
      if (idx < draft.sequence.length - 1) opts.push({ label: 'Später einplanen', run: () => { draftMove(p.blockId, 1); rerender(); } });
      opts.push({ label: 'Selbst wählen', run: () => recipePickSheet('Gericht wählen', id => pickCheck(id, p.date, y => y.blockId === p.blockId, o => { if (o) removeOther(o); draftPick(p.blockId, id); rerender(); }), 'MAIN', { date: p.date, ignore: y => y.blockId === p.blockId }) });
      opts.push({ label: p.locked ? 'Fixierung lösen' : 'Fixieren', run: () => { draftToggleLock(p.blockId); rerender(); } });
    }
    const carry = p && !p.drafted && p.type === 'LEFTOVER';
    if (carry) {
      const cr = recipeById(p.recipeId);
      opts.push({ label: 'Reste verschieben', run: () => restSheet(cr, p, draft.clone, nd => { moveRest(p.id, nd, draft.clone); relayoutDraft(); rerender(); }) });
      opts.push({ label: 'Reste streichen', run: () => { dropRest(p.id, draft.clone); relayoutDraft(); rerender(); } });
      opts.push({ label: 'Tag sperren', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => { draftBlockCarry(d, note); rerender(); }) });
    }
    if (p && p.extraBlocked) opts.push({ label: 'Tag wieder freigeben', run: () => { draft.blocked.delete(d); relayoutDraft(); rerender(); } });
    else if (!p || p.drafted) opts.push({ label: 'Tag sperren', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => { draft.blocked.set(d, note); relayoutDraft(); rerender(); }) });
    addLaneOptions(d, opts);
    if (!opts.length) opts.push({ label: 'Dieser Tag bleibt unverändert', hint: 'Fixiert, gesperrt oder Übertrag aus der Vorwoche', run: () => {} });
    return optionsSheet(title, p && p.recipeId ? esc(recipeById(p.recipeId).name) : '', opts, dayChip(p));
  }
  if (!p) {
    opts.push({ label: 'Nächstes aus der Rotation', run: () => {
      const e = EP.nextEntries(db, 1, null, rng, 'MAIN', EP.monthOf(d))[0];
      if (!e) return notify('Keine Gerichte in der Rotation.');
      undoable(() => { placeBlock(d, { recipeId: e.recipeId, rotationEntryId: e.id }); return 'Eingeplant.'; });
    } });
    opts.push({ label: 'Selbst wählen', run: () => recipePickSheet('Gericht wählen', id => pickCheck(id, d, null, o => undoable(() => {
      if (o) removeOther(o);
      const e = EP.manualPickEntry(db, id), m = pickMsg(id, e, o); placeBlock(d, { recipeId: id, rotationEntryId: e ? e.id : null }); return m;
    })), 'MAIN', { date: d }) });
    opts.push({ label: 'Tag sperren', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => undoable(() => { blockDay(d, note); return 'Tag gesperrt.'; })) });
  } else if (p.type === 'BLOCKED') {
    opts.push({ label: 'Tag wieder freigeben', run: () => undoable(() => { unblockDay(d); return 'Tag freigegeben.'; }) });
    opts.push({ label: 'Notiz ändern', run: () => promptSheet('Notiz ändern', 'Notiz', p.note, 'Speichern', note => { const x = planByDate().get(d); x.note = note; EP.touch(x); change(); }) });
  } else {
    const r = recipeById(p.recipeId);
    if (p.status !== 'DONE') opts.push({ label: 'Als gekocht markieren', run: () => undoable(() => { markCooked(p.blockId); return 'Als gekocht markiert.'; }) });
    if (r && (r.instructions || r.ingredients.length)) opts.push({ label: 'Kochansicht öffnen', run: () => openCook(r.id) });
    if (r && p.type === 'COOK' && d >= today) opts.push(guestOpt(p));
    if (d >= today) {
      opts.push({ label: 'Tauschen', run: () => undoable(() => { const nr = swapBlock(p.blockId); return nr ? 'Getauscht gegen ' + nr.name + '.' : 'Keine weiteren Gerichte in der Rotation.'; }) });
      if (p.type === 'LEFTOVER') {
        opts.push({ label: 'Reste verschieben', run: () => restSheet(r, p, null, nd => undoable(() => { moveRest(p.id, nd); return 'Reste verschoben.'; })) });
        opts.push({ label: 'Reste streichen', run: () => undoable(() => { dropRest(p.id); return 'Resttag gestrichen.'; }) });
      }
      opts.push({ label: p.type === 'LEFTOVER' ? 'Ganzes Gericht verschieben' : 'Verschieben', run: () => {
        const cook = blockEntries(p.blockId).find(x => x.type === 'COOK');
        dateSheet('Verschieben', r, cook ? cook.date : d, 'Verschieben', nd => undoable(() => { moveBlock(p.blockId, nd); return 'Verschoben.'; }));
      } });
      opts.push({ label: 'Selbst wählen', run: () => recipePickSheet('Gericht wählen', id => pickCheck(id, d, y => y.blockId === p.blockId, o => undoable(() => {
        const cook = blockEntries(p.blockId).find(x => x.type === 'COOK');
        const info = removeBlock(p.blockId, true);
        if (o) removeOther(o);
        const e = EP.manualPickEntry(db, id), m = pickMsg(id, e, o);
        placeBlock(cook ? cook.date : d, { recipeId: id, rotationEntryId: e ? e.id : null, locked: info && info.locked });
        return m.replace(/^Eingeplant/, 'Ersetzt');
      })), 'MAIN', { date: d, ignore: y => y.blockId === p.blockId }) });
      opts.push({ label: 'Tag sperren', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => undoable(() => { blockDay(d, note); return 'Tag gesperrt.'; })) });
    } else if (p.type === 'LEFTOVER') {
      opts.push({ label: 'Tag sperren', run: () => promptSheet('Tag sperren', 'Notiz', 'Auswärts essen', 'Sperren', note => undoable(() => { blockDay(d, note); return 'Tag gesperrt, Reste neu eingeplant.'; })) });
      opts.push({ label: 'Reste verschieben', run: () => restSheet(r, p, null, nd => undoable(() => { moveRest(p.id, nd); return 'Reste verschoben.'; })) });
      opts.push({ label: 'Reste streichen', run: () => undoable(() => { dropRest(p.id); return 'Resttag gestrichen.'; }) });
    }
    opts.push({ label: p.locked ? 'Fixierung lösen' : 'Fixieren', run: () => { const v = toggleLock(p.blockId); change(v ? 'Fixiert.' : 'Fixierung gelöst.'); } });
    opts.push({ label: 'Aus dem Plan entfernen', danger: true, run: () => undoable(() => { removeBlock(p.blockId, true); return 'Entfernt.'; }) });
  }
  addLaneOptions(d, opts);
  optionsSheet(title, p && p.recipeId ? esc((recipeById(p.recipeId) || {}).name || '') : '', opts, dayChip(p));
}
/* Zusätzliche Gerichte: beliebig viele pro Tag, jeder Art, ohne Rotation */
let extraKind = null;
const EXTRA_KINDS = ['MAIN', 'LUNCH', 'SIDE', 'CAKE', 'SPECIAL'];
function addExtraSheet(d) {
  const has = k => liveRecipes().some(r => EP.laneOf(r) === k);
  const k = extraKind || (has('SIDE') ? 'SIDE' : 'MAIN');
  recipePickSheet(`Weiteres Gericht am ${EP.weekday(d)} ${EP.fmtShort(d)}`, id => pickCheck(id, d, null, o => {
    undoable(() => { if (o) removeOther(o); const more = addSide(d, id); return o ? pickMsg(id, null, o) : 'Hinzugefügt' + sideMoreMsg(more) + '.'; });
  }), k, { kinds: EXTRA_KINDS, onKind: v => { extraKind = v; }, date: d });
}
function extraOption(d) {
  return { label: 'Weiteres Gericht hinzufügen', run: () => addExtraSheet(d) };
}
/* Zusätzliches Gericht verschieben: Tage der Woche als Knöpfe, dazu freie Datumswahl */
function extraMoveSheet(x, r) {
  const ws = EP.weekStart(x.date), days = EP.weekDays(ws), today = EP.todayISO();
  openSheet(`<h2>Verschieben</h2><p class="serif" style="font-size:19px;margin-top:4px">${esc(r ? r.name : '')}</p>
    <div class="daychips">${days.map(d => `<button class="chip" data-d="${d}" ${d === x.date ? 'aria-pressed="true" disabled' : ''}><b>${EP.weekday(d)}</b> ${EP.fmtShort(d)}${d === today ? ' · heute' : ''}</button>`).join('')}</div>
    <label class="field"><span>Oder anderes Datum</span><input class="in" type="date" id="dv" value="${x.date}"></label>
    <div class="btns two"><button class="btn" data-x="no">Abbrechen</button><button class="btn primary" data-x="yes">Verschieben</button></div>`, el => {
    const doMove = v => { if (!v || v === x.date) return closeSheet(); closeSheet(); undoable(() => { moveExtra(x.id, v); return `Verschoben auf ${EP.weekday(v)} ${EP.fmtShort(v)}.`; }); };
    $$('[data-d]', el).forEach(b => b.onclick = () => doMove(b.dataset.d));
    $('[data-x=no]', el).onclick = closeSheet;
    $('[data-x=yes]', el).onclick = () => doMove($('#dv', el).value);
  });
}
function extraActions(id) {
  const src = draft && draft.ws === weekStartISO ? draft.clone : db;
  const x = EP.live(src.plan).find(p => p.id === id) || EP.live(db.plan).find(p => p.id === id);
  if (!x) return;
  const r = recipeById(x.recipeId), k = x.dishKind || 'MAIN';
  const opts = [];
  if (r && (r.instructions || r.ingredients.length)) opts.push({ label: 'Kochansicht öffnen', run: () => openCook(r.id) });
  if (r && k === 'CAKE' && !(draft && draft.ws === weekStartISO)) opts.push({ label: 'Backform', hint: x.pan ? EP.panLabel(x.pan) : r.pan ? EP.panLabel(r.pan) : '', run: () => planPanSheet(x, r) });
  opts.push({ label: 'Anderes Gericht wählen', run: () => recipePickSheet('Gericht wählen', nid => pickCheck(nid, x.date, y => y.id === id, o => undoable(() => { if (o) removeOther(o); replaceExtra(id, nid); return 'Ersetzt.'; })), k, { kinds: EXTRA_KINDS, date: x.date, ignore: y => y.id === id }) });
  opts.push({ label: 'Auf anderen Tag verschieben', run: () => extraMoveSheet(x, r) });
  opts.push({ label: 'Noch ein Gericht hinzufügen', run: () => addExtraSheet(x.date) });
  opts.push({ label: 'Aus dem Plan entfernen', danger: true, run: () => undoable(() => { removeExtra(id); return 'Entfernt.'; }) });
  optionsSheet(`${DISH_LABEL[k]} am ${EP.weekdayLong(x.date)}, ${EP.fmtShort(x.date)}`, r ? esc(r.name) : '', opts);
}
/* „Mittagessen/Kuchen hinzufügen“ für Tage, an denen keine Zeile dafür angezeigt wird */
function addLaneOptions(d, opts) {
  const ents = weekEntries(weekStartISO);
  ['LUNCH', 'CAKE'].forEach(l => {
    if (ents.lanes[l].get(d)) return;                                           // schon etwas eingeplant
    if (laneVisible(l) && laneActiveOn(l, d) && d >= EP.todayISO()) return;     // Zeile ist ohnehin sichtbar
    if (!liveRecipes().some(r => EP.laneOf(r) === l)) return;                   // keine Rezepte dieser Art
    const o = { label: l === 'LUNCH' ? 'Mittagessen hinzufügen' : 'Kuchen hinzufügen',
      run: () => laneActions(d, l) };
    const i = opts.findIndex(x => x.danger);           // rote Aktion bleibt ganz unten
    i === -1 ? opts.push(o) : opts.splice(i, 0, o);
  });
  if (hasSpecial() && d >= EP.todayISO() && !(draft && draft.ws === EP.weekStart(d)) && !specialOn(ents, d)) {
    const o = { label: `${DISH_LABEL.SPECIAL} wählen`, icon: 'star', tone: 'rim', group: 1, run: () => specialPick(d) };
    const i = opts.findIndex(x => x.danger);
    i === -1 ? opts.push(o) : opts.splice(i, 0, o);
  }
  if (draft && draft.ws === EP.weekStart(d) && !ents.get(d) && specialFree([d]).length) {
    opts.unshift({ label: 'Doch normal füllen', icon: 'dice', group: 1, run: () => { draft.specialOff.add(d); relayoutDraft(); rerender(); } });
  }
  if (liveRecipes().length) {
    const i = opts.findIndex(x => x.danger);
    i === -1 ? opts.push(extraOption(d)) : opts.splice(i, 0, extraOption(d));
  }
}

/* ---------- Einkauf (5.5) ---------- */
const shopOpen = new Set();   // aufgeklappte Zeilen (Einzelposten)
function vShop() {
  const { from, to, mode } = curShopRange();
  const isWeek = EP.weekStart(from) === from && EP.addDays(from, 6) === to;
  const list = EP.buildShoppingList(db, from, to);
  const showQ = db.settings.marketListShowQuantities;
  const item = (r, withAmt) => r.extra != null
    ? `<div class="item xitem ${r.checked ? 'checked' : ''}"><input type="checkbox" data-extra="${r.extra}" ${r.checked ? 'checked' : ''} aria-label="${esc(r.name)} abhaken">
      <button class="nm xname" data-act="xcat" data-arg="${r.extra}" aria-label="${esc(r.name)}: bearbeiten oder einsortieren">${esc(r.name)}<small>zusätzlich</small></button>
      ${r.amount ? `<span class="amt xamt">${esc(r.amount)}</span>` : ''}
      <button class="btn quiet small noprint xedit" data-act="xedit" data-arg="${r.extra}" aria-label="${esc(r.name)} bearbeiten">${ICON.opencil}</button>
<button class="btn quiet small noprint xdel" data-act="delextra" data-arg="${r.extra}" aria-label="${esc(r.name)} entfernen">✕</button></div>`
    : (() => {
      const multi = r.parts && r.parts.length > 1, open = multi && shopOpen.has(r.key);
      const who = [].concat(r.dishes || [], r.extras && r.extras.length ? ['selbst hinzugefügt'] : []);
      return `<label class="item ${r.checked ? 'checked' : ''}${multi ? ' hasparts' : ''}"><input type="checkbox" data-check="${esc(r.key)}" ${r.checked ? 'checked' : ''}>
    <span class="nm">${esc(r.name)}${who.length ? `<small class="dish">für ${who.map(esc).join(', ')}</small>` : ''}</span>${withAmt && r.amount ? `<span class="amt">${esc(r.amount)}</span>` : ''}
    ${multi ? `<button class="partsbtn noprint" data-act="shopparts" data-arg="${esc(r.key)}" aria-expanded="${open}" aria-label="${esc(r.name)}: Einzelposten ${open ? 'zuklappen' : 'zeigen'}"><span>${r.parts.length}</span>${ICON.chev}</button>` : ''}</label>
    ${open ? `<div class="parts noprint">${r.parts.map(q => `<div class="part${q.checked ? ' checked' : ''}"><span class="pl">${esc(q.label)}${q.date ? `<small>${EP.weekday(q.date)} ${EP.fmtShort(q.date)}</small>` : ''}</span>
      <span class="amt">${esc(q.amount || '')}</span>${q.extra ? `<button class="btn quiet small xdel" data-act="delextra" data-arg="${q.extra}" aria-label="Selbst hinzugefügt: ${esc(r.name)} löschen">✕</button>` : '<span class="xsp"></span>'}</div>`).join('')}</div>` : ''}`;
    })();
  const groups = gs => gs.map(g => `<p class="cat">${esc(g.label)}</p>${g.items.map(r => item(r, true)).join('')}`).join('');
  const onList = new Set(list.extraItems.map(x => EP.normExtra(x.text)));
  const sugg = EP.extraSuggestions(extraStats(), EP.todayISO(), onList, 8), recent = sugg.map(x => x.text);
  const empty = !list.recipes.length && !list.extraItems.length;
  const anyStore = k => EP.liveStores(db.settings).some(x => x.kind === k);
  const storeChip = (k, lbl) => `<button class="storechip noprint" data-act="storepick" data-arg="${k}" aria-label="Geschäft für ${lbl} wählen">${list.stores[k] ? esc(list.stores[k].name) : anyStore(k) ? 'Ohne Geschäft' : 'Geschäft wählen'} ▾</button>`;
  const head = (k, lbl, n) => `<div class="shophead"><h3>${lbl}${n != null ? ` <small>${n}</small>` : ''}</h3>${storeChip(k, lbl)}</div>`;
  const marketHtml = list.marketGroups
    ? list.marketGroups.map(g => `<p class="cat">${esc(g.label)}</p>${g.items.map(r => item(r, showQ)).join('')}`).join('')
    : list.market.map(r => item(r, showQ)).join('');
  const nChecked = list.market.concat(...list.supermarket.map(g => g.items), ...list.drogerie.map(g => g.items), list.pantry).filter(r => r.checked).length;
  return `<div class="seg shopmode noprint"><button data-act="shopmode" data-arg="all" aria-pressed="${mode === 'all'}">Alles Kommende</button><button data-act="shopmode" data-arg="week" aria-pressed="${mode !== 'all'}">Nach Woche</button></div>
    ${mode === 'all' ? `<div class="weekhead noprint"><div class="kw"><b>Ab heute</b><span>${EP.fmtRange(from, to)}</span></div></div>` : `<div class="weekhead noprint">
      <button class="iconbtn" data-act="shopwk" data-arg="-7" aria-label="Vorige Woche">${ICON.back}</button>
      <div class="kw"><b>${isWeek ? 'KW ' + EP.isoWeek(from) : 'Eigener Zeitraum'}</b><span>${EP.fmtRange(from, to)}</span></div>
      <button class="iconbtn" data-act="shopwk" data-arg="7" aria-label="Nächste Woche" style="transform:scaleX(-1)">${ICON.back}</button>
    </div>`}
    <details class="box noprint rangebox" ${mode === 'custom' ? 'open' : ''}><summary>Zeitraum anpassen</summary>
      <div class="dategrid">
        <label><span class="hint">Von</span><input class="in" type="date" id="sf" value="${from}"></label>
        <label><span class="hint">Bis</span><input class="in" type="date" id="st" value="${to}"></label>
      </div></details>
    <h2 style="margin-top:18px" class="printonly-h">Einkauf ${EP.fmtRange(from, to)}</h2>
    <p class="sub">${!list.recipes.length ? 'In diesem Zeitraum ist nichts gekocht geplant.' : 'Für: ' + esc(list.recipes.join(', '))}</p>

    ${list.warnings.length ? `<ul class="box warnbox" style="margin-top:12px">${list.warnings.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}
    <div class="shopcols">
    ${list.market.length ? `<section class="shopsec box">${head('MARKT', 'Markt', list.market.length)}${marketHtml}</section>` : ''}
    ${list.supermarket.length ? `<section class="shopsec box">${head('SUPERMARKT', 'Supermarkt')}${groups(list.supermarket)}</section>` : ''}
    ${list.drogerie.length ? `<section class="shopsec box">${head('DROGERIE', 'Drogerie')}${groups(list.drogerie)}</section>` : ''}
    </div>
    <section class="shopsec box noprint"><h3>Weitere Artikel</h3>
      <div class="quick" style="margin-top:8px"><input class="in" id="extra" placeholder="z. B. 2 Packungen Feta" enterkeyhint="done" autocomplete="off"><button class="btn primary" data-act="addextra" aria-label="Hinzufügen">+</button></div>
      ${recent.length ? `<div class="recenthead"><span class="hint">${recentEdit ? 'Antippen zum Entfernen' : 'Vorschläge'}</span>
        <button class="btn quiet small" data-act="recentedit">${recentEdit ? 'Fertig' : 'Bearbeiten'}</button></div>
      <div class="chips recentx${recentEdit ? ' editing' : ''}">${recent.map(t => recentEdit
        ? `<button class="chip" data-act="recentdel" data-arg="${esc(t)}" aria-label="${esc(t)} aus den Vorschlägen entfernen">✕ ${esc(t)}</button>`
        : (x => `<button class="chip${x.due ? ' due' : ''}" data-act="recentx" data-arg="${esc(t)}" aria-label="${esc(t)} hinzufügen${x.due ? `, wieder fällig (etwa alle ${x.every} Tage)` : x.n > 1 ? `, ${x.n}-mal gekauft` : ''}">${x.due ? '↻' : '+'} ${esc(t)}</button>`)(sugg.find(y => y.text === t))).join('')}</div>` : ''}
    </section>
    ${list.pantry.length ? `<details class="shopsec box"><summary>Vorrat prüfen (${list.pantry.length})</summary>${list.pantry.map(r => item(r, false)).join('')}</details>` : ''}
    <div class="btns two noprint shopclean ${nChecked || list.removedCount ? '' : 'hidden'}">
      <button class="btn ${nChecked ? '' : 'hidden'}" data-act="clearchecked">Abgehakte entfernen (${nChecked})</button>
      ${list.removedCount ? `<button class="btn quiet" data-act="showremoved">Entfernte zeigen (${list.removedCount})</button>` : ''}</div>
    <div class="btns noprint">
      <button class="btn primary" data-act="copyshop">Offene Zutaten kopieren</button>
      <div class="btns two" style="margin-top:0">
        ${navigator.share ? '<button class="btn" data-act="shareshop">Teilen</button>' : ''}
        <button class="btn" data-act="printshop" ${navigator.share ? '' : 'style="grid-column:1/-1"'}>Drucken</button>
      </div>
    </div>`;
}
function shopText() { return EP.shoppingText(curShopList(), db.settings); }
