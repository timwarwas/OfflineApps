// E2E: schneller Start aus dem Offline-Speicher + Hinweis „Neue Version“ (Service Worker, alle Apps außer Cocktails).
// Aufruf: node start-update-e2e.js   (ROOT=<Ordner mit den Dateien>)
const G = require('child_process').execSync('npm root -g').toString().trim();
const { chromium } = require(G + '/playwright');
const http = require('http'), fs = require('fs');
const ROOT = process.env.ROOT || '/home/claude/offlineapps';
let fails = 0, passes = 0;
const ok = (m, c, x) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c || x === undefined ? '' : ' → ' + x)); c ? passes++ : fails++; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const state = { slow: 0, version: '', offline: false };
const server = http.createServer(async (req, res) => {
  let u = req.url.split('?')[0]; if (u.endsWith('/')) u += 'index.html'; const f = ROOT + u;
  if (state.offline) { req.socket.destroy(); return; }
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  let body = fs.readFileSync(f);
  if (u.endsWith('.html')) { if (state.slow) await sleep(state.slow); if (state.version) body = Buffer.from(String(body).replace('</body>', `<i id="ver" hidden>${state.version}</i></body>`)); }
  res.writeHead(200, { 'Content-Type': f.endsWith('.js') ? 'text/javascript' : f.endsWith('.webmanifest') ? 'application/manifest+json' : 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
  res.end(body);
});
(async () => {
  await new Promise(r => server.listen(0, r)); const base = `http://localhost:${server.address().port}/`;
  const b = await chromium.launch(); const errors = [];
  for (const [app, ready] of [['essensplanung', 'text=Neuen Haushalt einrichten'], ['kosten', 'text=Neue Reise'], ['spiele', 'text=Flip7'], ['workout', 'text=Weiter zur Vorschau'], ['index', '.apptile'], ['verstecken', 'body']]) {
    for (const scheme of app === 'essensplanung' ? ['light', 'dark'] : ['light']) {
      console.log(`${app} (${scheme})`);
      Object.assign(state, { slow: 0, version: 'v1', offline: false });
      const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, locale: 'de-DE', colorScheme: scheme, serviceWorkers: 'allow' });
      const p = await ctx.newPage(); p.on('pageerror', e => errors.push(app + ': ' + e.message));
      await p.goto(base + app + '.html'); await p.waitForSelector(ready, { timeout: 15000 });
      await p.waitForFunction(() => navigator.serviceWorker && navigator.serviceWorker.controller, null, { timeout: 15000 }).catch(() => {});
      await p.reload(); await p.waitForSelector(ready); await sleep(800);   // jetzt sicher im Offline-Speicher
      ok('Service Worker steuert die Seite', await p.evaluate(() => !!navigator.serviceWorker.controller));
      state.slow = 6000;
      let t0 = Date.now(); await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForSelector(ready); const tSlow = Date.now() - t0;
      ok(`Start bei langsamem Netz (Server 6 s) nach ${tSlow} ms`, tSlow < 1500, tSlow);
      ok('kein Hinweis, solange nichts Neues da ist', await sleep(6500).then(() => p.locator('#sw-update').count()) === 0);
      state.slow = 0; state.offline = true;
      t0 = Date.now(); await p.reload({ waitUntil: 'domcontentloaded' }); await p.waitForSelector(ready); const tOff = Date.now() - t0;
      ok(`Start ohne Netz nach ${tOff} ms`, tOff < 1500, tOff);
      state.offline = false; state.version = 'v2';
      await p.reload(); await p.waitForSelector(ready);
      ok('startet zuerst mit der gespeicherten Fassung', await p.locator('#ver').textContent() === 'v1');
      await p.waitForSelector('#sw-update', { timeout: 12000 }).catch(() => {});
      const bt = p.locator('#sw-update');
      ok('Hinweis „Neue Version · Neu laden“ erscheint', await bt.count() === 1 && /Neue Version/.test(await bt.innerText()));
      if (await bt.count()) {
        const bb = await bt.boundingBox();
        await sleep(400); const bb2 = await bt.boundingBox();
        ok('Hinweis ≥44 px, im Bild', bb2.height >= 44 && bb2.x >= 0 && bb2.x + bb2.width <= 390 && bb2.y >= 0, JSON.stringify(bb2));
        if (app === 'essensplanung') await p.screenshot({ path: `/home/claude/work/shots/neue-version-${scheme}.png` });
        await bt.click(); await p.waitForSelector(ready); await sleep(300);
        ok('„Neu laden“ zeigt die neue Fassung', await p.locator('#ver').textContent() === 'v2');
      }
      await ctx.close();
    }
  }
  ok('Keine JS-Fehler', !errors.length, errors.join(' | '));
  await b.close(); server.close();
  console.log(`\n${passes} bestanden, ${fails} fehlgeschlagen`); process.exit(fails ? 1 : 0);
})();
